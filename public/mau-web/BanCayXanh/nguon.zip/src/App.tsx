import { useState, useEffect } from 'react';
import { PageTab, Product, CartItem, Order, UserProfile, Voucher, BlogArticle } from './types';
import {
  allProducts,
  initialCartItems,
  initialOrders,
  initialUserProfile,
  initialVouchers,
  blogArticles,
} from './data/mockData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { DeskPlantsPage } from './pages/DeskPlantsPage';
import { InteriorPlantsPage } from './pages/InteriorPlantsPage';
import { SucculentsPage } from './pages/SucculentsPage';
import { CactusPage } from './pages/CactusPage';
import { AccountPage } from './pages/AccountPage';
import { CartPage } from './pages/CartPage';
import { WishlistPage } from './pages/WishlistPage';
import { ConsultationModal } from './components/ConsultationModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { EditProfileModal } from './components/EditProfileModal';
import { CheckoutModal } from './components/CheckoutModal';
import { StoreLocationsModal } from './components/StoreLocationsModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ArticleModal } from './components/ArticleModal';
import { Toast } from './components/Toast';

export default function App() {
  // Navigation tab state
  const [currentTab, setCurrentTab] = useState<PageTab>('trang-chu');

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('vx_cart');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return initialCartItems;
      }
    }
    return initialCartItems;
  });

  // Wishlist state
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(() => {
    const saved = localStorage.getItem('vx_wishlist');
    if (saved) {
      try {
        return new Set(JSON.parse(saved));
      } catch {
        return new Set(['db-1', 'sd-1', 'xr-1', 'nt-1']);
      }
    }
    return new Set(['db-1', 'sd-1', 'xr-1', 'nt-1']);
  });

  // User profile state
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('vx_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return initialUserProfile;
      }
    }
    return initialUserProfile;
  });

  // Orders state
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('vx_orders');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return initialOrders;
      }
    }
    return initialOrders;
  });

  // Vouchers state
  const [vouchers] = useState<Voucher[]>(initialVouchers);
  const [appliedVoucher, setAppliedVoucher] = useState<Voucher | null>(initialVouchers[0]);

  // Modal states
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [isOrderTrackingOpen, setIsOrderTrackingOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isStoreLocationsOpen, setIsStoreLocationsOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<BlogArticle | null>(null);

  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showViewCartInToast, setShowViewCartInToast] = useState(false);

  // Persist cart
  useEffect(() => {
    localStorage.setItem('vx_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  // Persist wishlist
  useEffect(() => {
    localStorage.setItem('vx_wishlist', JSON.stringify(Array.from(wishlistIds)));
  }, [wishlistIds]);

  // Persist profile
  useEffect(() => {
    localStorage.setItem('vx_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  // Persist orders
  useEffect(() => {
    localStorage.setItem('vx_orders', JSON.stringify(orders));
  }, [orders]);

  // Handle URL hash changes
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as PageTab;
      if (
        [
          'trang-chu',
          'cay-de-ban',
          'cay-noi-that',
          'sen-da',
          'xuong-rong',
          'tai-khoan',
          'gio-hang',
          'yeu-thich',
        ].includes(hash)
      ) {
        setCurrentTab(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const triggerToast = (message: string, showViewCart = false) => {
    setToastMessage(message);
    setShowViewCartInToast(showViewCart);
    setTimeout(() => {
      setToastMessage((prev) => (prev === message ? null : prev));
    }, 3200);
  };

  const handleNavigate = (tab: PageTab) => {
    setCurrentTab(tab);
    window.location.hash = tab;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (product: Product, quantity = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity, potOption: product.specs || 'Chậu men sứ cao cấp' }];
    });
    triggerToast(`Đã thêm "${product.name}" vào giỏ hàng!`, true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    const item = cartItems.find((i) => i.product.id === productId);
    setCartItems((prev) => prev.filter((i) => i.product.id !== productId));
    if (item) {
      triggerToast(`Đã bỏ "${item.product.name}" khỏi giỏ hàng.`);
    }
  };

  const handleClearCart = () => {
    setCartItems([]);
    triggerToast('Đã xóa tất cả sản phẩm trong giỏ hàng.');
  };

  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) => {
      const next = new Set(prev);
      if (next.has(product.id)) {
        next.delete(product.id);
        triggerToast(`Đã bỏ "${product.name}" khỏi danh sách yêu thích.`);
      } else {
        next.add(product.id);
        triggerToast(`Đã lưu "${product.name}" vào danh sách yêu thích!`);
      }
      return next;
    });
  };

  const handleApplyVoucher = (code: string): boolean => {
    const found = vouchers.find(
      (v) => v.code.toUpperCase() === code.toUpperCase()
    );
    if (found) {
      setAppliedVoucher(found);
      triggerToast(`Áp dụng mã ưu đãi "${found.code}" thành công!`);
      return true;
    }
    triggerToast(`Mã ưu đãi "${code}" không hợp lệ.`);
    return false;
  };

  const handlePlaceOrderSuccess = (orderId: string) => {
    const newOrder: Order = {
      id: orderId,
      date: `Đặt lúc ${new Date().toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
      })} - Hôm nay`,
      status: 'delivering',
      statusText: 'Đang chuẩn bị hàng (Hỏa tốc)',
      statusDetail: 'Kho Vườn Xanh đang đóng gói 3 lớp chống sốc',
      driver: {
        name: 'Trần Văn Mạnh',
        eta: '14:00 hôm nay',
        phone: '0933 678 910',
        vehicle: 'Yamaha Sirius 29X1-567.89',
      },
      items: cartItems.map((c) => ({
        name: c.product.name,
        image: c.product.image,
        specs: c.potOption || c.product.specs || 'Kèm chậu men sứ',
        price: c.product.price,
        quantity: c.quantity,
      })),
      total: cartItems.reduce((s, i) => s + i.product.price * i.quantity, 0),
    };

    setOrders((prev) => [newOrder, ...prev]);
    setCartItems([]);

    // Increase member points
    setUserProfile((prev) => ({
      ...prev,
      points: prev.points + 50,
      neededPoints: Math.max(0, prev.neededPoints - 50),
    }));
  };

  const handleReorder = (orderId: string) => {
    const order = orders.find((o) => o.id === orderId || o.id === `VX-${orderId}`);
    if (order) {
      order.items.forEach((it) => {
        const prod = allProducts.find((p) => p.name === it.name) || {
          id: `custom-${Math.random()}`,
          name: it.name,
          category: 'cay-de-ban' as const,
          categoryLabel: 'Cây cảnh',
          price: it.price,
          rating: 4.8,
          reviewsCount: 15,
          image: it.image,
          specs: it.specs,
        };
        handleAddToCart(prod, it.quantity);
      });
      handleNavigate('gio-hang');
    }
  };

  const handleOpenArticle = (articleId: string) => {
    const art = blogArticles.find((b) => b.id === articleId);
    if (art) {
      setSelectedArticle(art);
    }
  };

  const wishlistProducts = allProducts.filter((p) => wishlistIds.has(p.id));
  const cartItemTotalCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-[#2c332d] flex flex-col font-sans">
      {/* 1. Global Navigation Header */}
      <Header
        currentTab={currentTab}
        onNavigate={handleNavigate}
        cartCount={cartItemTotalCount}
        wishlistCount={wishlistIds.size}
        onOpenStoreLocations={() => setIsStoreLocationsOpen(true)}
        onOpenOrderTracking={() => setIsOrderTrackingOpen(true)}
        allProducts={allProducts}
        onSelectProduct={(p) => setSelectedProduct(p)}
      />

      {/* 2. Main Page View (Offset for fixed 165px header) */}
      <div className="flex-1 pt-[148px] sm:pt-[158px] lg:pt-[168px]">
        {currentTab === 'trang-chu' && (
          <HomePage
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenArticle={handleOpenArticle}
          />
        )}

        {currentTab === 'cay-de-ban' && (
          <DeskPlantsPage
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
            onSelectProduct={(p) => setSelectedProduct(p)}
          />
        )}

        {currentTab === 'cay-noi-that' && (
          <InteriorPlantsPage
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenConsultation={() => setIsConsultationOpen(true)}
          />
        )}

        {currentTab === 'sen-da' && (
          <SucculentsPage
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenConsultation={() => setIsConsultationOpen(true)}
          />
        )}

        {currentTab === 'xuong-rong' && (
          <CactusPage
            onNavigate={handleNavigate}
            onAddToCart={handleAddToCart}
            onToggleWishlist={handleToggleWishlist}
            wishlistIds={wishlistIds}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenArticle={handleOpenArticle}
          />
        )}

        {currentTab === 'tai-khoan' && (
          <AccountPage
            onNavigate={handleNavigate}
            userProfile={userProfile}
            orders={orders}
            vouchers={vouchers}
            onOpenEditProfile={() => setIsEditProfileOpen(true)}
            onOpenOrderTracking={() => setIsOrderTrackingOpen(true)}
            onApplyVoucher={(code) => {
              handleApplyVoucher(code);
              handleNavigate('gio-hang');
            }}
            onReorder={handleReorder}
          />
        )}

        {currentTab === 'gio-hang' && (
          <CartPage
            onNavigate={handleNavigate}
            cartItems={cartItems}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveFromCart}
            onClearCart={handleClearCart}
            onAddToCart={handleAddToCart}
            appliedVoucher={appliedVoucher}
            onApplyVoucher={handleApplyVoucher}
            onOpenCheckout={() => setIsCheckoutOpen(true)}
            onOpenConsultation={() => setIsConsultationOpen(true)}
          />
        )}

        {currentTab === 'yeu-thich' && (
          <WishlistPage
            onNavigate={handleNavigate}
            wishlistProducts={wishlistProducts}
            onAddToCart={handleAddToCart}
            onRemoveFromWishlist={handleToggleWishlist}
            onSelectProduct={(p) => setSelectedProduct(p)}
          />
        )}
      </div>

      {/* 3. Global Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenOrderTracking={() => setIsOrderTrackingOpen(true)}
        onOpenStoreLocations={() => setIsStoreLocationsOpen(true)}
      />

      {/* 4. Modals and Dialogs */}
      <ConsultationModal
        isOpen={isConsultationOpen}
        onClose={() => setIsConsultationOpen(false)}
        onSubmitSuccess={(msg) => triggerToast(msg)}
      />

      <OrderTrackingModal
        isOpen={isOrderTrackingOpen}
        onClose={() => setIsOrderTrackingOpen(false)}
        order={orders[0] || initialOrders[0]}
      />

      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
        profile={userProfile}
        onSave={(updated) => {
          setUserProfile(updated);
          triggerToast('Đã cập nhật thông tin tài khoản thành công!');
        }}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        userProfile={userProfile}
        appliedVoucher={appliedVoucher}
        onPlaceOrderSuccess={handlePlaceOrderSuccess}
      />

      <StoreLocationsModal
        isOpen={isStoreLocationsOpen}
        onClose={() => setIsStoreLocationsOpen(false)}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedProduct ? wishlistIds.has(selectedProduct.id) : false}
      />

      <ArticleModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
        onNavigateCategory={() => handleNavigate('cay-de-ban')}
      />

      {/* 5. Toast Feedback */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
        onViewCart={showViewCartInToast ? () => handleNavigate('gio-hang') : undefined}
      />
    </div>
  );
}
