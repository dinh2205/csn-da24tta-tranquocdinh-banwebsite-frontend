import React from 'react';
import { BlogArticle } from '../types';

interface ArticleModalProps {
  article: BlogArticle | null;
  onClose: () => void;
  onNavigateCategory: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({
  article,
  onClose,
  onNavigateCategory,
}) => {
  if (!article) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <span className="font-label-category uppercase tracking-wider text-[#b02d29] text-xs font-bold">
            Cẩm nang Vườn Xanh • {article.category}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4">
          <h2 className="font-headline-lg text-xl sm:text-2xl font-bold text-gray-900 leading-snug">
            {article.title}
          </h2>
          <div className="text-xs text-gray-400">Đăng ngày: {article.date}</div>

          <div className="w-full h-56 rounded-2xl overflow-hidden shadow-xs">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-3 text-xs sm:text-sm text-gray-700 leading-relaxed">
            <p className="font-semibold text-gray-900">{article.snippet}</p>
            <p>
              Đối với người yêu cây cảnh đô thị, việc duy trì một chậu cây xanh tốt nơi góc phòng làm việc không hề khó nếu bạn nắm vững nhịp sinh học tự nhiên của từng dòng cây:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-xs text-gray-600">
              <li>
                <strong>Quan sát độ ẩm đất:</strong> Không tưới theo lịch cố định, hãy dùng ngón tay hoặc que tăm kiểm tra bề mặt đất cách mặt chậu 2-3cm.
              </li>
              <li>
                <strong>Đón nắng gián tiếp:</strong> Ánh nắng sớm trước 9 giờ sáng mang lại nguồn diệp lục dồi dào mà không làm cháy bỏng phiến lá non.
              </li>
              <li>
                <strong>Thoát nước tối ưu:</strong> Luôn dùng chậu có lỗ thoát nước và đĩa lót tách rời để tránh đọng nước gây thối rễ.
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-xs font-semibold text-gray-700 cursor-pointer"
            >
              Đóng bài viết
            </button>
            <button
              type="button"
              onClick={() => {
                onClose();
                onNavigateCategory();
              }}
              className="px-5 py-2 bg-[#234729] hover:bg-[#1a3820] text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
            >
              Khám phá sản phẩm liên quan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
