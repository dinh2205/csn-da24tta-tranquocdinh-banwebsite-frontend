import React, { useState } from 'react';
import { CartItem, UserProfile, Voucher } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  userProfile: UserProfile;
  appliedVoucher: Voucher | null;
  onPlaceOrderSuccess: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  userProfile,
  appliedVoucher,
  onPlaceOrderSuccess,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'vietqr' | 'momo' | 'card'>('cod');
  const [recipientName, setRecipientName] = useState(userProfile.name);
  const [recipientPhone, setRecipientPhone] = useState(userProfile.phone);
  const [deliveryAddress, setDeliveryAddress] = useState(userProfile.address);
  const [notes, setNotes] = useState(userProfile.deliveryNotes);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderCompleteId, setOrderCompleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  const rawSubtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const isFreeShip = rawSubtotal >= 300000;
  const shippingFee = isFreeShip ? 0 : 30000;

  let voucherDiscount = 0;
  if (appliedVoucher?.discountPercent) {
    voucherDiscount = Math.round((rawSubtotal * appliedVoucher.discountPercent) / 100);
    if (appliedVoucher.maxDiscount && voucherDiscount > appliedVoucher.maxDiscount) {
      voucherDiscount = appliedVoucher.maxDiscount;
    }
  }

  const finalTotal = Math.max(0, rawSubtotal + shippingFee - voucherDiscount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    setTimeout(() => {
      const generatedId = `VX-${Math.floor(10000 + Math.random() * 90000)}`;
      setIsProcessing(false);
      setOrderCompleteId(generatedId);
      onPlaceOrderSuccess(generatedId);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100 max-h-[90vh] overflow-y-auto">
        {orderCompleteId ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#234729] flex items-center justify-center mx-auto shadow-xs">
              <span className="material-symbols-outlined text-[36px]">check_circle</span>
            </div>
            <h2 className="font-headline-lg text-2xl font-bold text-gray-900">
              Đặt Hàng Thành Công!
            </h2>
            <p className="text-xs text-gray-600 max-w-md mx-auto leading-relaxed">
              Mã đơn hàng của bạn là <strong className="text-[#b02d29]">#{orderCompleteId}</strong>. Vườn Xanh đang chuẩn bị cây và đóng gói 3 lớp chống sốc giao đến bạn trong hôm nay.
            </p>

            <div className="p-4 bg-[#f5f3f0] rounded-2xl text-left text-xs space-y-2 border border-[#eae8e5] max-w-md mx-auto">
              <div className="flex justify-between">
                <span className="text-gray-500">Người nhận:</span>
                <span className="font-bold text-gray-900">{recipientName} - {recipientPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Địa chỉ giao:</span>
                <span className="font-bold text-gray-900 truncate max-w-[220px]">{deliveryAddress}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Hình thức thanh toán:</span>
                <span className="font-bold text-[#b02d29] uppercase">
                  {paymentMethod === 'cod' ? 'Thanh toán khi nhận cây (COD)' : 'Chuyển khoản điện tử'}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-gray-200 text-sm font-bold text-gray-900">
                <span>Tổng số tiền:</span>
                <span className="text-[#b02d29]">{finalTotal.toLocaleString('vi-VN')}đ</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 bg-[#234729] text-white text-xs font-semibold rounded-xl hover:opacity-90 shadow-xs cursor-pointer"
              >
                Đóng &amp; Theo dõi đơn hàng
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h3 className="font-headline-sm text-base font-bold text-gray-900">
                  Thông Tin Thanh Toán &amp; Giao Hàng
                </h3>
                <p className="text-[11px] text-gray-500">Bước 2: Hoàn tất đơn hàng cây xanh</p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {/* Recipient Details */}
              <div className="space-y-2">
                <span className="font-bold text-gray-800 block uppercase tracking-wider text-[11px]">
                  1. Thông tin người nhận
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    placeholder="Họ và tên"
                    className="bg-[#f5f3f0] px-3.5 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
                  />
                  <input
                    type="tel"
                    required
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    placeholder="Số điện thoại"
                    className="bg-[#f5f3f0] px-3.5 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
                  />
                </div>
                <input
                  type="text"
                  required
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="Địa chỉ giao hàng chi tiết"
                  className="w-full bg-[#f5f3f0] px-3.5 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
                />
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ghi chú thêm (VD: Giao giờ hành chính, gọi trước...)"
                  className="w-full bg-[#f5f3f0] px-3.5 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
                />
              </div>

              {/* Payment Methods */}
              <div className="space-y-2 pt-2 border-t border-gray-100">
                <span className="font-bold text-gray-800 block uppercase tracking-wider text-[11px]">
                  2. Phương thức thanh toán
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-[#234729] bg-emerald-50/50 font-bold text-gray-900'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="accent-[#234729]"
                    />
                    <div>
                      <p className="text-xs">Thanh toán khi nhận hàng (COD)</p>
                      <p className="text-[10px] text-gray-500 font-normal">Đồng kiểm tra cây trước khi trả tiền</p>
                    </div>
                  </label>

                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'vietqr'
                        ? 'border-[#234729] bg-emerald-50/50 font-bold text-gray-900'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'vietqr'}
                      onChange={() => setPaymentMethod('vietqr')}
                      className="accent-[#234729]"
                    />
                    <div>
                      <p className="text-xs">Chuyển khoản VietQR</p>
                      <p className="text-[10px] text-gray-500 font-normal">Quét mã QR tự động xác nhận</p>
                    </div>
                  </label>

                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'momo'
                        ? 'border-[#234729] bg-emerald-50/50 font-bold text-gray-900'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'momo'}
                      onChange={() => setPaymentMethod('momo')}
                      className="accent-[#234729]"
                    />
                    <div>
                      <p className="text-xs">Ví MoMo / ZaloPay</p>
                      <p className="text-[10px] text-gray-500 font-normal">Thanh toán ví điện tử nhanh chóng</p>
                    </div>
                  </label>

                  <label
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      paymentMethod === 'card'
                        ? 'border-[#234729] bg-emerald-50/50 font-bold text-gray-900'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'card'}
                      onChange={() => setPaymentMethod('card')}
                      className="accent-[#234729]"
                    />
                    <div>
                      <p className="text-xs">Thẻ ATM / VNPAY</p>
                      <p className="text-[10px] text-gray-500 font-normal">Hỗ trợ mọi ngân hàng nội địa</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Order total review */}
              <div className="bg-[#f5f3f0] p-4 rounded-2xl space-y-1.5 border border-[#eae8e5]">
                <div className="flex justify-between text-gray-600">
                  <span>Tạm tính:</span>
                  <span>{rawSubtotal.toLocaleString('vi-VN')}đ</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Phí vận chuyển:</span>
                  <span className="text-[#b02d29] font-semibold">{isFreeShip ? 'Miễn phí (0đ)' : '30.000đ'}</span>
                </div>
                {voucherDiscount > 0 && (
                  <div className="flex justify-between text-[#b02d29]">
                    <span>Ưu đãi voucher ({appliedVoucher?.code}):</span>
                    <span>-{voucherDiscount.toLocaleString('vi-VN')}đ</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-gray-200 text-sm font-bold text-gray-900">
                  <span>Tổng thanh toán:</span>
                  <span className="text-base text-[#b02d29]">{finalTotal.toLocaleString('vi-VN')}đ</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                style={{ backgroundColor: '#1E4D2B' }}
                className="w-full py-3.5 text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-95 transition-opacity flex items-center justify-center gap-2 shadow-xs cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Đang xử lý đơn hàng...</span>
                  </>
                ) : (
                  <>
                    <span>Xác Nhận Đặt Hàng ({finalTotal.toLocaleString('vi-VN')}đ)</span>
                    <span className="material-symbols-outlined text-[18px]">check</span>
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
