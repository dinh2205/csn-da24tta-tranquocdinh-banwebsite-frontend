import React, { useState } from 'react';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitSuccess: (msg: string) => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  onSubmitSuccess,
}) => {
  const [name, setName] = useState('Nguyễn Thu Hà');
  const [phone, setPhone] = useState('0982 123 419');
  const [spaceType, setSpaceType] = useState('Phòng khách căn hộ chung cư');
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitSuccess('Yêu cầu tư vấn phong thủy đã gửi! Chuyên viên Vườn Xanh sẽ liên hệ bạn qua Zalo/SĐT trong 15 phút.');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative space-y-5 animate-in fade-in duration-200 border border-gray-100 font-sans">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#ffdad6] text-[#b02d29] flex items-center justify-center">
              <span className="material-symbols-outlined text-[22px]">potted_plant</span>
            </div>
            <div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">
                Đăng Ký Tư Vấn Cây Phong Thủy
              </h3>
              <p className="text-[11px] text-gray-500">Miễn phí 100% cùng chuyên gia Vườn Xanh</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        <p className="text-xs text-gray-600 leading-relaxed">
          Chuyên viên thực vật học &amp; phong thủy của Vườn Xanh sẽ tư vấn loài cây, hướng bài trí và màu sắc chậu tương sinh với bản mệnh của bạn.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-700 block">Họ và tên của bạn</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ví dụ: Nguyễn Thu Hà"
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729] border border-transparent"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-700 block">Số điện thoại / Zalo</label>
            <input
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="09xx xxx xxx"
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729] border border-transparent"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-700 block">Không gian bạn muốn bài trí</label>
            <select
              value={spaceType}
              onChange={(e) => setSpaceType(e.target.value)}
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-xs text-gray-900 focus:outline-none cursor-pointer border border-transparent"
            >
              <option>Bàn làm việc văn phòng</option>
              <option>Phòng khách căn hộ chung cư</option>
              <option>Biệt thự / Nhà phố rộng</option>
              <option>Sảnh lễ tân công ty</option>
              <option>Ban công / Sân thượng đón nắng</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-700 block">Năm sinh hoặc nhu cầu đặc biệt (tùy chọn)</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="VD: Sinh năm 1992, muốn cây hút bức xạ và hút tài lộc..."
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729] border border-transparent"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-[#234729] text-white text-xs font-bold rounded-xl hover:opacity-95 transition-opacity flex items-center justify-center gap-2 shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">send</span>
              <span>Gửi Yêu Cầu Chuyên Gia</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
