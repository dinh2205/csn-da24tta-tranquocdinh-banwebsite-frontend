import React, { useState } from 'react';
import { UserProfile } from '../types';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  onSave: (updated: UserProfile) => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSave,
}) => {
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);
  const [email, setEmail] = useState(profile.email);
  const [address, setAddress] = useState(profile.address);
  const [deliveryNotes, setDeliveryNotes] = useState(profile.deliveryNotes);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...profile,
      name,
      phone,
      email,
      address,
      deliveryNotes,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[22px] text-[#234729]">edit_note</span>
            <h3 className="font-headline-sm text-base font-bold text-gray-900">
              Chỉnh Sửa Hồ Sơ &amp; Địa Chỉ
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="font-semibold text-gray-700 block">Họ và tên</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-gray-700 block">Số điện thoại</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
              />
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-gray-700 block">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-gray-700 block">Địa chỉ nhận cây cảnh</label>
            <textarea
              rows={2}
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-[#f5f3f0] p-3 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
            />
          </div>

          <div className="space-y-1">
            <label className="font-semibold text-gray-700 block">Ghi chú giao hàng</label>
            <input
              type="text"
              value={deliveryNotes}
              onChange={(e) => setDeliveryNotes(e.target.value)}
              placeholder="VD: Giao giờ hành chính, gọi trước 15 phút..."
              className="w-full bg-[#f5f3f0] px-4 py-2.5 rounded-xl text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
            />
          </div>

          <div className="pt-2 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold cursor-pointer"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-[#234729] text-white font-semibold hover:opacity-90 transition-opacity shadow-xs cursor-pointer"
            >
              Lưu thay đổi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
