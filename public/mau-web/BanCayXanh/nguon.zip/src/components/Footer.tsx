import React from 'react';
import { PageTab } from '../types';

interface FooterProps {
  onNavigate: (tab: PageTab) => void;
  onOpenOrderTracking: () => void;
  onOpenStoreLocations: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenOrderTracking,
  onOpenStoreLocations,
}) => {
  return (
    <footer style={{ backgroundColor: '#173322', color: '#d1d5db' }} className="w-full mt-16 font-sans">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 pt-14 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 items-start">
          {/* Brand Col */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[28px]" style={{ color: '#4ade80' }}>
                eco
              </span>
              <span className="text-2xl font-bold tracking-tight text-white leading-none">
                Vườn Xanh
              </span>
            </div>
            <p className="text-sm leading-relaxed text-gray-300 pr-4">
              Vườn Xanh – Mang thiên nhiên đến gần bạn<br />
              Chuyên cung cấp cây cảnh, chậu cây và phụ kiện trang trí. Đồng hành cùng bạn kiến tạo không gian sống xanh, lành mạnh và hạnh phúc hơn mỗi ngày.
            </p>
            <div className="flex items-center gap-2.5 pt-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="w-8 h-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80"
                style={{ backgroundColor: '#0d2115' }}
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                </svg>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-8 h-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80"
                style={{ backgroundColor: '#0d2115' }}
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                aria-label="YouTube"
                className="w-8 h-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80"
                style={{ backgroundColor: '#0d2115' }}
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noreferrer"
                aria-label="TikTok"
                className="w-8 h-8 rounded-full flex items-center justify-center text-white transition-opacity hover:opacity-80"
                style={{ backgroundColor: '#0d2115' }}
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-1.01-.02 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Col 2: Policy */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider" style={{ color: '#4ade80' }}>
              CHÍNH SÁCH
            </h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách bảo hành
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách đổi trả
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách vận chuyển
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Chính sách bảo mật
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Care */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider" style={{ color: '#4ade80' }}>
              HỖ TRỢ KHÁCH HÀNG
            </h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="hover:text-white transition-colors cursor-pointer">
                Hướng dẫn mua hàng
              </li>
              <li
                onClick={onOpenOrderTracking}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Theo dõi đơn hàng
              </li>
              <li className="hover:text-white transition-colors cursor-pointer">
                Câu hỏi thường gặp
              </li>
              <li
                onClick={() => onNavigate('tai-khoan')}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Liên hệ
              </li>
            </ul>
          </div>

          {/* Col 4: Contact */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider" style={{ color: '#4ade80' }}>
              LIÊN HỆ
            </h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] shrink-0">call</span>
                <a href="tel:19006868" className="hover:text-white">1900 6868</a>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] shrink-0">mail</span>
                <a href="mailto:info@vuonxanh.vn" className="hover:text-white">info@vuonxanh.vn</a>
              </li>
              <li
                onClick={onOpenStoreLocations}
                className="flex items-start gap-2 hover:text-white cursor-pointer"
              >
                <span className="material-symbols-outlined text-[16px] shrink-0 mt-0.5">location_on</span>
                <span>123 Nguyễn Văn Cừ, Q.1, TP. HCM</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] shrink-0">schedule</span>
                <span>8:00 – 22:00 (T2 – CN)</span>
              </li>
            </ul>
          </div>

          {/* Col 5: Slogan quote */}
          <div className="lg:col-span-2 flex flex-col items-end justify-center text-right pt-4 lg:pt-6">
            <div className="space-y-1">
              <p
                className="text-xl font-normal leading-tight italic"
                style={{ fontFamily: "'Playfair Display', serif", color: '#a7f3d0' }}
              >
                Sống xanh,<br />
                Sống hạnh phúc ♡
              </p>
              <div className="flex justify-end pt-2">
                <span className="material-symbols-outlined text-[32px] opacity-70" style={{ color: '#22c55e' }}>
                  eco
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div
          className="pt-6 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400"
          style={{ borderColor: 'rgba(255, 255, 255, 0.08)' }}
        >
          <p>© 2024 Vườn Xanh. Tất cả quyền được bảo lưu.</p>
          <p>Thiên nhiên luôn có cách làm chúng ta mỉm cười ♡</p>
        </div>
      </div>
    </footer>
  );
};
