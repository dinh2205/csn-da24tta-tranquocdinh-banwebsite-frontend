import React, { useState } from 'react';
import { PageTab, Product } from '../types';
import { BRAND_LOGO_URL } from '../data/mockData';

interface HeaderProps {
  currentTab: PageTab;
  onNavigate: (tab: PageTab) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenStoreLocations: () => void;
  onOpenOrderTracking: () => void;
  allProducts: Product[];
  onSelectProduct: (product: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onNavigate,
  cartCount,
  wishlistCount,
  onOpenStoreLocations,
  onOpenOrderTracking,
  allProducts,
  onSelectProduct,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const searchResults = searchQuery.trim()
    ? allProducts
        .filter((p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .slice(0, 5)
    : [];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchResults.length > 0) {
      onSelectProduct(searchResults[0]);
      setIsSearchFocused(false);
      setSearchQuery('');
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-40 bg-white/95 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)] font-sans">
      {/* 1. Top Utility Bar */}
      <div className="w-full text-white text-[12px] py-1.5 px-4 lg:px-12 bg-[#234729]">
        <div className="max-w-7xl mx-auto flex items-center justify-between font-normal flex-wrap gap-2">
          {/* Left items */}
          <div className="flex items-center gap-3 sm:gap-4 flex-wrap text-white/90">
            <a
              href="tel:19006868"
              className="flex items-center gap-1.5 font-medium hover:text-white transition-opacity"
            >
              <span className="material-symbols-outlined text-[15px]">call</span>
              <span>1900 6868</span>
            </a>
            <span className="opacity-40">|</span>
            <a
              href="mailto:info@vuonxanh.vn"
              className="flex items-center gap-1.5 hover:text-white transition-opacity"
            >
              <span className="material-symbols-outlined text-[15px]">mail</span>
              <span>info@vuonxanh.vn</span>
            </a>
            <span className="opacity-40 hidden sm:inline">|</span>
            <span className="hidden sm:flex items-center gap-1.5 text-white/95">
              <span className="material-symbols-outlined text-[15px]">local_shipping</span>
              <span>Miễn phí vận chuyển đơn từ 300.000đ</span>
            </span>
          </div>

          {/* Right items */}
          <div className="flex items-center gap-3 sm:gap-4 text-white/90">
            <button
              onClick={onOpenOrderTracking}
              type="button"
              className="hover:underline transition-all cursor-pointer text-left"
            >
              Theo dõi đơn hàng
            </button>
            <span className="opacity-40">|</span>
            <button
              onClick={onOpenStoreLocations}
              type="button"
              className="flex items-center gap-1 hover:underline transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">location_on</span>
              <span>Hệ thống cửa hàng</span>
            </button>
            <span className="opacity-40">|</span>
            <div className="flex items-center gap-1 cursor-pointer hover:opacity-90">
              <span className="text-[14px]">🇻🇳</span>
              <span className="font-medium text-xs">VN</span>
              <span className="material-symbols-outlined text-[14px]">keyboard_arrow_down</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Middle Main Header */}
      <div className="w-full bg-white border-b border-[#ecebe6] py-3 px-4 lg:px-12">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 sm:gap-6">
          {/* Brand Logo */}
          <button
            onClick={() => onNavigate('trang-chu')}
            className="flex items-center gap-2.5 shrink-0 group cursor-pointer border-none bg-transparent p-0 text-left"
          >
            <img
              src={BRAND_LOGO_URL}
              alt="Vườn Xanh - Sống xanh hơn mỗi ngày"
              className="h-10 sm:h-12 w-auto object-contain transition-transform duration-200 group-hover:scale-[1.02]"
            />
          </button>

          {/* Center Search Bar */}
          <div className="flex-1 max-w-xl mx-2 relative">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
                placeholder="Tìm kiếm cây cảnh, chậu cây, phụ kiện..."
                className="w-full bg-[#fcfbf9] text-[#2c3d31] placeholder-[#8f9b93] text-[13px] px-4 py-2.5 pr-12 rounded-lg border border-[#d6ddd7] focus:outline-none focus:border-[#234729] focus:bg-white transition-all shadow-xs"
              />
              <button
                type="submit"
                aria-label="Tìm kiếm"
                className="absolute right-1 top-1 bottom-1 px-3.5 bg-[#264e36] hover:bg-[#1e3e2b] text-white rounded-md flex items-center justify-center transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">search</span>
              </button>
            </form>

            {/* Live Autocomplete Dropdown */}
            {isSearchFocused && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50 animate-in fade-in duration-150">
                <div className="p-2 text-[11px] font-bold uppercase tracking-wider text-gray-400 bg-gray-50 border-b border-gray-100">
                  Gợi ý tìm kiếm ({searchResults.length})
                </div>
                <div className="divide-y divide-gray-50">
                  {searchResults.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onSelectProduct(item);
                        setIsSearchFocused(false);
                        setSearchQuery('');
                      }}
                      className="w-full flex items-center gap-3 p-2.5 hover:bg-[#f6f9f6] text-left transition-colors cursor-pointer"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-10 h-10 rounded-md object-cover shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] font-medium text-gray-900 truncate">
                          {item.name}
                        </p>
                        <p className="text-[11px] text-gray-500">
                          {item.categoryLabel}
                        </p>
                      </div>
                      <span className="text-[13px] font-bold text-[#b02d29]">
                        {item.price.toLocaleString('vi-VN')}₫
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Actions & Slogan */}
          <div className="flex items-center gap-4 sm:gap-5 shrink-0 text-[#28372d]">
            {/* Account */}
            <button
              onClick={() => onNavigate('tai-khoan')}
              className={`flex items-center gap-1.5 text-[13px] font-medium transition-colors cursor-pointer ${
                currentTab === 'tai-khoan'
                  ? 'text-[#234729] font-bold'
                  : 'hover:text-[#234729]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">person</span>
              <span className="hidden lg:inline">Tài khoản</span>
            </button>

            {/* Wishlist */}
            <button
              onClick={() => onNavigate('yeu-thich')}
              className={`flex items-center gap-1.5 text-[13px] font-medium transition-colors cursor-pointer relative ${
                currentTab === 'yeu-thich'
                  ? 'text-[#234729] font-bold'
                  : 'hover:text-[#234729]'
              }`}
            >
              <div className="relative flex items-center">
                <span className="material-symbols-outlined text-[20px]">favorite</span>
                {wishlistCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-[#234729] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center leading-none">
                    {wishlistCount}
                  </span>
                )}
              </div>
              <span className="hidden lg:inline">Yêu thích</span>
            </button>

            {/* Cart with Red Badge */}
            <button
              onClick={() => onNavigate('gio-hang')}
              className={`flex items-center gap-1.5 text-[13px] font-medium transition-colors cursor-pointer relative ${
                currentTab === 'gio-hang'
                  ? 'text-[#234729] font-bold'
                  : 'hover:text-[#234729]'
              }`}
            >
              <div className="relative flex items-center">
                <span className="material-symbols-outlined text-[22px]">shopping_basket</span>
                <span className="absolute -top-1.5 -right-2 bg-[#d73229] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center leading-none">
                  {cartCount}
                </span>
              </div>
              <span className="hidden lg:inline ml-0.5">Giỏ hàng</span>
            </button>

            {/* Slogan graphic quote */}
            <div className="hidden xl:flex items-center pl-4 border-l border-[#e4e4df] select-none text-[#1b4327]">
              <div className="text-right leading-tight pr-1">
                <span
                  className="block text-[15px] font-medium italic"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  “Thêm cây,
                </span>
                <span
                  className="block text-[15px] font-semibold italic"
                  style={{ fontFamily: "'Playfair Display', serif" }}
                >
                  Thêm hạnh phúc!”
                </span>
              </div>
              <span
                className="material-symbols-outlined text-[#2a5938] text-[20px] ml-1"
                style={{ fontVariationSettings: "'FILL' 1" }}
              >
                eco
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Bottom Category Navigation Bar */}
      <div className="w-full bg-[#fbf7ee] border-b border-[#ece5d4] px-4 lg:px-12">
        <div className="max-w-7xl mx-auto flex items-center">
          <nav className="flex items-center gap-2 sm:gap-6 md:gap-8 overflow-x-auto text-[14px] text-[#2c3d31] whitespace-nowrap scrollbar-none py-2.5">
            <button
              onClick={() => onNavigate('trang-chu')}
              className={`p-1 flex items-center transition-colors cursor-pointer ${
                currentTab === 'trang-chu'
                  ? 'text-[#20452b]'
                  : 'text-[#556459] hover:text-[#20452b]'
              }`}
              title="Trang chủ"
            >
              <span className="material-symbols-outlined text-[20px]">home</span>
            </button>

            <button
              onClick={() => onNavigate('trang-chu')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'trang-chu'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Trang chủ
            </button>

            <button
              onClick={() => onNavigate('cay-de-ban')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'cay-de-ban'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Cây để bàn
            </button>

            <button
              onClick={() => onNavigate('cay-noi-that')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'cay-noi-that'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Cây nội thất
            </button>

            <button
              onClick={() => onNavigate('sen-da')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'sen-da'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Sen đá
            </button>

            <button
              onClick={() => onNavigate('xuong-rong')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'xuong-rong'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Xương rồng
            </button>

            <button
              onClick={() => onNavigate('tai-khoan')}
              className={`transition-colors cursor-pointer ${
                currentTab === 'tai-khoan'
                  ? 'text-[#20452b] font-bold border-b-2 border-[#20452b] pb-0.5'
                  : 'font-medium text-[#2c3d31] hover:text-[#20452b]'
              }`}
            >
              Thông Tin Cá Nhân
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
