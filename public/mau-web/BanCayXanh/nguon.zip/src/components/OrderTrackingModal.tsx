import React from 'react';
import { Order } from '../types';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  order,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-gray-900">Mã đơn #{order.id}</span>
              <span className="px-2 py-0.5 rounded-full bg-[#ffdad6] text-[#b02d29] text-[10px] font-bold">
                Hỏa tốc 2H
              </span>
            </div>
            <p className="text-[11px] text-gray-500 mt-0.5">{order.date}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Driver Card */}
        {order.driver && (
          <div className="bg-[#f5f3f0] p-4 rounded-2xl flex items-center justify-between border border-[#eae8e5]">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-[#234729] text-white flex items-center justify-center font-bold text-sm shadow-xs">
                AN
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-gray-900">
                  Tài xế: {order.driver.name}
                </h4>
                <p className="text-[11px] text-gray-500">
                  {order.driver.vehicle} • Đang cách bạn 1.2km
                </p>
                <span className="text-[11px] font-semibold text-[#b02d29]">
                  Dự kiến giao: {order.driver.eta}
                </span>
              </div>
            </div>

            <a
              href={`tel:${order.driver.phone}`}
              className="px-3.5 py-2 bg-[#234729] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs hover:opacity-90"
            >
              <span className="material-symbols-outlined text-[16px]">call</span>
              <span>Gọi</span>
            </a>
          </div>
        )}

        {/* Live Tracking Map Graphic Mockup */}
        <div className="relative h-44 rounded-2xl overflow-hidden bg-emerald-50 border border-emerald-100 flex items-center justify-center">
          <div
            className="absolute inset-0 opacity-40 bg-[radial-gradient(#234729_1px,transparent_1px)]"
            style={{ backgroundSize: '16px 16px' }}
          />
          {/* Simulated Route */}
          <div className="relative z-10 w-full px-6 flex items-center justify-between">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-[#234729] text-white flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-[16px]">store</span>
              </div>
              <span className="text-[10px] font-bold text-gray-800 mt-1">Kho Vườn Xanh</span>
            </div>

            <div className="flex-1 mx-3 h-1 bg-gradient-to-r from-[#234729] via-[#b02d29] to-gray-300 rounded-full relative">
              <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 text-[18px] animate-bounce">
                🛵
              </span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-[#b02d29] text-white flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-[16px]">home</span>
              </div>
              <span className="text-[10px] font-bold text-gray-800 mt-1">Detech Tower</span>
            </div>
          </div>
        </div>

        {/* Tracking Milestones */}
        <div className="space-y-3 pt-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700">
            Tiến trình vận chuyển
          </h4>
          <div className="space-y-3 relative pl-6 before:content-[''] before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[2px] before:bg-gray-200">
            <div className="relative text-xs">
              <span className="absolute -left-[22px] top-0.5 w-3 h-3 rounded-full bg-[#234729] ring-4 ring-emerald-100" />
              <p className="font-bold text-gray-900">Đang giao hàng (Hỏa tốc)</p>
              <p className="text-[11px] text-gray-500">10:15 - Shipper đã lấy hàng và đang di chuyển</p>
            </div>

            <div className="relative text-xs">
              <span className="absolute -left-[22px] top-0.5 w-3 h-3 rounded-full bg-[#234729]" />
              <p className="font-semibold text-gray-800">Đóng gói 3 lớp chống sốc &amp; nẹp gốc</p>
              <p className="text-[11px] text-gray-500">09:45 - Kỹ thuật viên kiểm tra sức khỏe cây</p>
            </div>

            <div className="relative text-xs">
              <span className="absolute -left-[22px] top-0.5 w-3 h-3 rounded-full bg-[#234729]" />
              <p className="font-semibold text-gray-800">Tiếp nhận đơn hàng thành công</p>
              <p className="text-[11px] text-gray-500">09:20 - Hệ thống Vườn Xanh xác nhận đơn</p>
            </div>
          </div>
        </div>

        {/* Order Items */}
        <div className="pt-2 border-t border-gray-100 space-y-2">
          <span className="text-xs font-bold text-gray-800 block">Sản phẩm trong đơn:</span>
          {order.items.map((item, idx) => (
            <div key={idx} className="flex items-center justify-between text-xs text-gray-700">
              <span className="truncate pr-2">
                {item.quantity}x {item.name}
              </span>
              <span className="font-bold text-gray-900 shrink-0">
                {(item.price * item.quantity).toLocaleString('vi-VN')}đ
              </span>
            </div>
          ))}
          <div className="flex justify-between items-baseline pt-2 border-t border-gray-100 text-xs font-bold text-gray-900">
            <span>Tổng thanh toán:</span>
            <span className="text-base text-[#b02d29]">{order.total.toLocaleString('vi-VN')}đ</span>
          </div>
        </div>
      </div>
    </div>
  );
};
