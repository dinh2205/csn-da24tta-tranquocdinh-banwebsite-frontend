import React, { useState } from 'react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onToggleWishlist: (product: Product) => void;
  isWishlisted: boolean;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
}) => {
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <span className="font-label-category uppercase tracking-wider text-[#b02d29] text-xs font-bold">
            {product.categoryLabel}
          </span>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-start">
          {/* Image */}
          <div className="relative aspect-square rounded-2xl overflow-hidden bg-[#f5f3f0] shadow-xs border border-gray-100">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.badge && (
              <span className="absolute top-3 left-3 bg-[#b02d29] text-white px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider shadow-xs">
                {product.badge}
              </span>
            )}
            <button
              type="button"
              onClick={() => onToggleWishlist(product)}
              className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center shadow-xs transition-colors cursor-pointer ${
                isWishlisted ? 'text-[#b02d29]' : 'text-gray-400 hover:text-[#b02d29]'
              }`}
            >
              <span
                className={`material-symbols-outlined text-[18px] ${
                  isWishlisted ? 'material-symbols-fill' : ''
                }`}
              >
                favorite
              </span>
            </button>
          </div>

          {/* Details */}
          <div className="space-y-4">
            <div>
              <h2 className="font-headline-md text-lg sm:text-xl font-bold text-gray-900 leading-snug">
                {product.name}
              </h2>
              <div className="flex items-center gap-2 mt-1.5 text-xs text-gray-500">
                <div className="flex items-center text-amber-500">
                  <span className="material-symbols-outlined text-[15px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    star
                  </span>
                </div>
                <span className="font-bold text-gray-900">{product.rating}</span>
                <span className="text-gray-400">({product.reviewsCount} đánh giá từ khách hàng)</span>
              </div>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="font-headline-lg text-2xl font-bold text-[#b02d29]">
                {product.price.toLocaleString('vi-VN')}đ
              </span>
              {product.originalPrice && (
                <span className="text-xs line-through text-gray-400">
                  {product.originalPrice.toLocaleString('vi-VN')}đ
                </span>
              )}
            </div>

            <p className="text-xs text-gray-600 leading-relaxed">
              {product.description ||
                'Cây được chăm sóc kỹ lưỡng tại vườn ươm Vườn Xanh, bảo đảm bộ rễ khỏe mạnh và tán lá xanh tươi thuần khí hậu.'}
            </p>

            {product.specs && (
              <div className="bg-[#f5f3f0] p-3 rounded-xl text-xs text-gray-700 border border-[#eae8e5]">
                <strong className="text-gray-900 block mb-0.5">Quy cách &amp; Phụ kiện:</strong>
                <span>{product.specs}</span>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="flex items-center gap-3 pt-2">
              <span className="text-xs font-semibold text-gray-700">Số lượng:</span>
              <div className="flex items-center bg-[#f5f3f0] rounded-xl px-2 py-1 border border-gray-200">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-6 h-6 flex items-center justify-center text-gray-600 hover:text-gray-900 cursor-pointer"
                >
                  -
                </button>
                <span className="w-8 text-center text-xs font-bold text-gray-900">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-6 h-6 flex items-center justify-center text-gray-600 hover:text-gray-900 cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            {/* CTA */}
            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  onAddToCart(product, quantity);
                  onClose();
                }}
                style={{ backgroundColor: '#1E4D2B' }}
                className="flex-1 py-3 bg-[#234729] text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-95 transition-opacity flex items-center justify-center gap-2 shadow-xs cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                <span>Thêm vào giỏ</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
