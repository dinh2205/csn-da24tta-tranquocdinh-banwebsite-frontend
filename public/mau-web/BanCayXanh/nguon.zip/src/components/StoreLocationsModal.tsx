import React from 'react';

interface StoreLocationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StoreLocationsModal: React.FC<StoreLocationsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const stores = [
    {
      city: 'TP. Hồ Chí Minh (Showroom Trung Tâm)',
      address: '123 Nguyễn Văn Cừ, Phường 2, Quận 1, TP. HCM',
      phone: '1900 6868 - Ext 1',
      hours: '8:00 – 22:00 (T2 – CN)',
      mapNote: 'Có bãi đỗ xe ô tô và xe máy rộng rãi, vườn ươm 500m2 trải nghiệm thực tế',
    },
    {
      city: 'Hà Nội (Chi nhánh Cầu Giấy)',
      address: 'Tầng 1, Tòa Detech Tower, Số 8 Tôn Thất Thuyết, Cầu Giấy, Hà Nội',
      phone: '1900 6868 - Ext 2',
      hours: '8:30 – 21:30 (T2 – CN)',
      mapNote: 'Khu trưng bày cây văn phòng & cây phong thủy phong cách Scandinavian',
    },
    {
      city: 'Hà Nội (Chi nhánh Đống Đa)',
      address: '45 Tây Sơn, Quang Trung, Đống Đa, Hà Nội',
      phone: '1900 6868 - Ext 3',
      hours: '8:30 – 21:30 (T2 – CN)',
      mapNote: 'Chuyên các dòng sen đá, xương rồng tiểu cảnh & phụ kiện gốm Bát Tràng',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 font-sans">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in fade-in duration-200 border border-gray-100 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[24px] text-[#234729]">location_on</span>
            <div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">
                Hệ Thống Cửa Hàng Vườn Xanh
              </h3>
              <p className="text-[11px] text-gray-500">Ghé thăm vườn ươm &amp; tự tay chọn cây ưng ý</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-600 transition-colors cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="space-y-4">
          {stores.map((s, idx) => (
            <div
              key={idx}
              className="bg-[#f5f3f0] p-4 rounded-2xl border border-[#eae8e5] space-y-2 hover:bg-[#eae8e5] transition-colors"
            >
              <h4 className="font-bold text-xs sm:text-sm text-gray-900 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#234729]" />
                <span>{s.city}</span>
              </h4>
              <p className="text-xs text-gray-700 flex items-start gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-gray-500 shrink-0 mt-0.5">
                  pin_drop
                </span>
                <span>{s.address}</span>
              </p>
              <div className="flex flex-wrap items-center gap-4 text-[11px] text-gray-600 pt-1">
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px] text-[#234729]">call</span>
                  <span>{s.phone}</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px] text-[#234729]">schedule</span>
                  <span>{s.hours}</span>
                </span>
              </div>
              <p className="text-[11px] text-gray-500 italic bg-white/70 p-2 rounded-lg">
                💡 {s.mapNote}
              </p>
            </div>
          ))}
        </div>

        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 bg-[#234729] text-white text-xs font-semibold rounded-xl hover:opacity-90 shadow-xs cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
