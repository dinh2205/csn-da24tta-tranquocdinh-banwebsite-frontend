import React from 'react';

interface ToastProps {
  message: string | null;
  onClose: () => void;
  onViewCart?: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose, onViewCart }) => {
  if (!message) return null;

  return (
    <aside
      aria-label="Thông báo"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-[#141b2b] text-white px-4 py-3 rounded-2xl shadow-2xl border border-gray-700 animate-in fade-in slide-in-from-bottom-5 duration-300 font-sans"
    >
      <span className="w-7 h-7 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
        <span className="material-symbols-outlined text-[17px]">check</span>
      </span>
      <p className="text-xs font-medium pr-2 max-w-xs">{message}</p>
      {onViewCart && (
        <button
          type="button"
          onClick={() => {
            onClose();
            onViewCart();
          }}
          className="text-xs font-bold text-emerald-400 hover:text-emerald-300 underline cursor-pointer shrink-0"
        >
          Xem giỏ
        </button>
      )}
      <button
        type="button"
        onClick={onClose}
        className="text-gray-400 hover:text-white text-xs ml-1 cursor-pointer"
      >
        ✕
      </button>
    </aside>
  );
};
