import React, { useState } from 'react';
import { PageTab, UserProfile, Order, Voucher } from '../types';

interface AccountPageProps {
  onNavigate: (tab: PageTab) => void;
  userProfile: UserProfile;
  orders: Order[];
  vouchers: Voucher[];
  onOpenEditProfile: () => void;
  onOpenOrderTracking: () => void;
  onApplyVoucher: (code: string) => void;
  onReorder: (orderId: string) => void;
}

export const AccountPage: React.FC<AccountPageProps> = ({
  onNavigate,
  userProfile,
  orders,
  vouchers,
  onOpenEditProfile,
  onOpenOrderTracking,
  onApplyVoucher,
  onReorder,
}) => {
  const [activeMenu, setActiveMenu] = useState<'profile' | 'orders' | 'address' | 'wishlist' | 'vouchers'>('profile');
  const [reviewOrderModal, setReviewOrderModal] = useState<string | null>(null);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewText, setReviewText] = useState<string>('');
  const [reviewSubmitted, setReviewSubmitted] = useState<boolean>(false);

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Breadcrumb Bar */}
      <div className="w-full bg-[#f5f3f0] py-3.5 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center gap-2 text-xs text-gray-500">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-gray-900 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="text-gray-300">/</span>
          <span className="text-gray-900 font-semibold">Tài khoản thành viên</span>
        </div>
      </div>

      {/* 2. Main Content Layout */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: User Sidebar */}
          <aside className="lg:col-span-4 xl:col-span-3 space-y-6">
            {/* Profile Identity Card */}
            <div className="bg-white p-6 rounded-2xl shadow-xs border border-gray-100 text-center relative overflow-hidden">
              <div className="absolute -top-12 -right-12 w-28 h-28 bg-[#f5f3f0] rounded-full opacity-60 pointer-events-none" />

              {/* Avatar with Greenery Accents */}
              <div className="relative w-24 h-24 mx-auto mb-4">
                <img
                  className="w-full h-full object-cover rounded-full shadow-md border-2 border-white"
                  src={userProfile.avatar}
                  alt={userProfile.name}
                />
                <span
                  className="absolute bottom-0 right-1 w-7 h-7 bg-[#234729] text-white rounded-full flex items-center justify-center shadow-xs"
                  title="Đã xác thực"
                >
                  <span className="material-symbols-outlined text-[16px]">eco</span>
                </span>
              </div>

              <h2 className="font-headline-md text-lg sm:text-xl font-bold text-gray-900 mb-1">
                {userProfile.name}
              </h2>
              <p className="text-xs text-gray-500 mb-4">{userProfile.email}</p>

              {/* Membership Badge & Level Progress */}
              <div className="bg-[#f5f3f0] p-3.5 rounded-xl text-left space-y-2 border border-[#eae8e5]">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#b02d29] flex items-center gap-1">
                    <span className="material-symbols-outlined text-[18px]">workspace_premium</span>
                    <span>{userProfile.tier}</span>
                  </span>
                  <span className="font-bold text-gray-900">{userProfile.points} điểm</span>
                </div>

                {/* Progress Bar to Next Level */}
                <div className="w-full bg-[#e4e2df] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#b02d29] h-full rounded-full transition-all duration-700"
                    style={{ width: `${(userProfile.points / (userProfile.points + userProfile.neededPoints)) * 100}%` }}
                  />
                </div>

                <p className="text-[11px] text-gray-500 flex justify-between">
                  <span>Hạng hiện tại</span>
                  <span>
                    Cần thêm {userProfile.neededPoints} điểm để lên{' '}
                    <strong className="text-gray-900">{userProfile.nextTier}</strong>
                  </span>
                </p>
              </div>
            </div>

            {/* Sidebar Navigation Menu */}
            <nav className="bg-white p-2.5 rounded-2xl shadow-xs border border-gray-100 text-xs font-medium space-y-1">
              <button
                type="button"
                onClick={() => setActiveMenu('profile')}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors cursor-pointer text-left ${
                  activeMenu === 'profile'
                    ? 'bg-[#f5f3f0] text-gray-900 font-bold'
                    : 'text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900'
                }`}
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px] text-[#234729]">person</span>
                  <span>Thông tin cá nhân</span>
                </span>
                <span className="material-symbols-outlined text-[18px] text-gray-400">chevron_right</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMenu('orders')}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors cursor-pointer text-left ${
                  activeMenu === 'orders'
                    ? 'bg-[#f5f3f0] text-gray-900 font-bold'
                    : 'text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900'
                }`}
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">local_mall</span>
                  <span>Đơn hàng của tôi</span>
                </span>
                <span className="px-2 py-0.5 text-[11px] rounded-full bg-[#eae8e5] font-bold text-gray-800">
                  {orders.length} đơn
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveMenu('address');
                  onOpenEditProfile();
                }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">location_on</span>
                  <span>Sổ địa chỉ nhận hàng</span>
                </span>
                <span className="material-symbols-outlined text-[18px] text-gray-400">chevron_right</span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('yeu-thich')}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">favorite</span>
                  <span>Cây yêu thích</span>
                </span>
                <span className="px-2 py-0.5 text-[11px] rounded-full bg-[#eae8e5] font-bold text-gray-800">
                  8 cây
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveMenu('vouchers')}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">sell</span>
                  <span>Ưu đãi / Voucher</span>
                </span>
                <span className="px-2 py-0.5 text-[11px] rounded-full bg-[#ffdad6] text-[#b02d29] font-bold">
                  2 mã mới
                </span>
              </button>

              <button
                type="button"
                onClick={() => onNavigate('cay-de-ban')}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-gray-600 hover:bg-[#f5f3f0] hover:text-gray-900 transition-colors cursor-pointer text-left"
              >
                <span className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">bookmark</span>
                  <span>Cẩm nang đã lưu</span>
                </span>
                <span className="material-symbols-outlined text-[18px] text-gray-400">chevron_right</span>
              </button>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => alert('Đăng xuất tài khoản thành công!')}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[#b02d29] hover:bg-[#ffdad6]/40 transition-colors font-semibold cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">logout</span>
                  <span>Đăng xuất</span>
                </button>
              </div>
            </nav>
          </aside>

          {/* Right Column: Account Workspace */}
          <section className="lg:col-span-8 xl:col-span-9 space-y-8">
            {/* Ecological Achievement Banner */}
            <div className="bg-[#141b2b] text-white p-6 sm:p-8 rounded-2xl shadow-md relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-2.5 z-10 max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 font-label-category uppercase tracking-wider text-emerald-300 text-[11px] font-bold">
                  <span className="material-symbols-outlined text-[14px]">nature_people</span>
                  <span>Tác động xanh tích cực</span>
                </div>
                <h3 className="font-headline-lg text-xl sm:text-2xl leading-tight text-white font-bold">
                  Bạn đã cùng Vườn Xanh mang 5 mầm xanh về tổ ấm
                </h3>
                <p className="text-xs sm:text-sm text-gray-300 leading-relaxed">
                  Theo ước tính sinh thái, 5 chậu cây của bạn đã hấp thụ xấp xỉ ~18.5kg CO2 mỗi năm và tạo ẩm tự nhiên cho 45m² không gian sống yêu dấu.
                </p>
              </div>

              {/* Ecological Micro Graphic Ring */}
              <div className="shrink-0 flex items-center justify-center p-4 bg-white/10 rounded-2xl backdrop-blur-xs">
                <div className="relative w-28 h-28 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-white/20"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="3"
                    />
                    <path
                      className="text-emerald-400"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeDasharray="85, 100"
                      strokeLinecap="round"
                      strokeWidth="3"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="font-headline-md text-2xl font-bold text-white leading-none">
                      5
                    </span>
                    <span className="text-[10px] uppercase text-gray-300 tracking-wider font-medium mt-0.5">
                      Cây xanh
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Personal Info Card */}
            <div className="bg-white rounded-2xl p-6 lg:p-8 shadow-xs border border-gray-100 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-4">
                <div>
                  <h3 className="font-headline-md text-lg font-bold text-gray-900">
                    Thông tin tài khoản
                  </h3>
                  <p className="text-xs text-gray-500">
                    Quản lý hồ sơ cá nhân và địa chỉ mặc định nhận cây cảnh
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onOpenEditProfile}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#f5f3f0] text-gray-900 hover:bg-[#234729] hover:text-white text-xs font-semibold transition-all shrink-0 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">edit_square</span>
                  <span>Chỉnh sửa thông tin</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <span className="text-[11px] text-gray-400 uppercase tracking-wider block font-bold">
                    Họ và tên
                  </span>
                  <p className="font-headline-sm text-sm sm:text-base text-gray-900 font-semibold">
                    {userProfile.name}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] text-gray-400 uppercase tracking-wider block font-bold">
                    Số điện thoại
                  </span>
                  <p className="font-headline-sm text-sm sm:text-base text-gray-900 font-semibold">
                    {userProfile.phone}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] text-gray-400 uppercase tracking-wider block font-bold">
                    Email liên hệ
                  </span>
                  <p className="font-headline-sm text-sm sm:text-base text-gray-900 font-semibold">
                    {userProfile.email}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] text-gray-400 uppercase tracking-wider block font-bold">
                    Ngày tham gia Vườn Xanh
                  </span>
                  <p className="font-headline-sm text-sm sm:text-base text-gray-900 font-semibold">
                    {userProfile.joinDate}
                  </p>
                </div>

                {/* Default Address */}
                <div className="md:col-span-2 space-y-1 bg-[#f5f3f0] p-4 rounded-xl border border-[#eae8e5]">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-label-category uppercase tracking-wider text-[#b02d29] flex items-center gap-1 text-[11px] font-bold">
                      <span className="material-symbols-outlined text-[16px]">pin_drop</span>
                      <span>Địa chỉ giao hàng mặc định</span>
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#e4e2df] text-gray-700 font-bold">
                      Mặc định
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-gray-800 leading-relaxed">
                    {userProfile.address}
                  </p>
                  <p className="text-[11px] text-gray-500 pt-1">
                    Ghi chú giao hàng: {userProfile.deliveryNotes}
                  </p>
                </div>
              </div>
            </div>

            {/* Recent Orders Workspace */}
            <div className="bg-white rounded-2xl p-6 lg:p-8 shadow-xs border border-gray-100 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-4">
                <div>
                  <h3 className="font-headline-md text-lg font-bold text-gray-900">
                    Đơn hàng gần đây
                  </h3>
                  <p className="text-xs text-gray-500">
                    Theo dõi lộ trình giao nhận và bảo hành cây xanh 30 ngày
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onOpenOrderTracking}
                  className="text-xs font-semibold text-[#b02d29] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Xem tất cả đơn hàng</span>
                  <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
                </button>
              </div>

              {/* Order 1: Ongoing Delivery */}
              <div className="bg-[#f5f3f0] rounded-2xl p-5 md:p-6 space-y-4 border border-[#eae8e5]">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-gray-900">#VX-88921</span>
                    <span className="text-gray-300">|</span>
                    <span className="text-xs text-gray-500">
                      Đặt lúc 09:20 - Hôm nay (25/10/2025)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#b02d29] animate-pulse" />
                    <span className="px-3 py-1 rounded-full bg-[#ffdad6]/60 text-[#b02d29] text-xs font-bold">
                      Đang giao hàng (Hỏa tốc 2H)
                    </span>
                  </div>
                </div>

                {/* Items Stream */}
                <div className="space-y-4">
                  {/* Item 1 */}
                  <div className="flex items-center gap-4">
                    <img
                      className="w-16 h-16 object-cover rounded-xl shrink-0 shadow-2xs border border-gray-100 bg-white"
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuA3weAvw-5Ze3S9TkVI0l3R1B3ZR-2q8McQ-mdD_o6jt3aEBCy0-wuJJK5kkm2B_bYb-rwtAnA18yTBrWjpMG360lbtKGCED1FcMqhTBZWMKooSr6Q6Iq8vxgZBBfQ9bNaJTkQyxhUxDupJ6bBy-Dz4KP5qqQ8XDzet5XfsJh4eUHXqsNdcHTpF3oB8HnPLlQCQznOkLu5jUNmclmyi0OuZhkC4LYfGZ8hYIJ_gR-D6nZgtuwmyV1ly"
                      alt="Cây Bàng Singapore Dáng Trụ"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-headline-sm text-xs sm:text-sm font-bold text-gray-900 truncate">
                        Cây Bàng Singapore Dáng Trụ (Cao 70cm)
                      </h4>
                      <p className="text-[11px] text-gray-500">
                        Tặng kèm đĩa lót + Gói sỏi rải mặt + Sách chăm sóc
                      </p>
                      <span className="text-xs text-gray-900 font-semibold sm:hidden block mt-1">
                        290.000đ × 1
                      </span>
                    </div>
                    <div className="text-right hidden sm:block">
                      <span className="font-headline-sm text-sm font-bold text-gray-900">
                        290.000đ
                      </span>
                      <p className="text-[11px] text-gray-500">SL: 1</p>
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div className="flex items-center gap-4">
                    <img
                      className="w-16 h-16 object-cover rounded-xl shrink-0 shadow-2xs border border-gray-100 bg-white"
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuBaw4Q_dd4qgp-G4RF1_l-5OygCUrFdupUnmxFPRzsmTv_cF1uOrjvrqgEEq-f0eU6lMkx1yT2Tl3Wfqp_6MKgm23BgccCaeEaC55b3bJs34GGFEDrxunDVmkX6EHDGTxl11tbfpCdhWkJReHS-TQZ_7c3TPUpAEesa2ZMpQqKPKX17Tx0xZixseJVT3yVBd4Cp1GJmqnWJkZ1Nc7bmmhwP-fHbDT4Rsrp9yYELweFAYVvnA_zH313E"
                      alt="Sen Đá Ruby Đỏ Cổ Thụ"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-headline-sm text-xs sm:text-sm font-bold text-gray-900 truncate">
                        Sen Đá Ruby Đỏ Cổ Thụ (Chậu Mini)
                      </h4>
                      <p className="text-[11px] text-gray-500">
                        Phân khúc cao cấp, chịu hạn tốt
                      </p>
                      <span className="text-xs text-gray-900 font-semibold sm:hidden block mt-1">
                        65.000đ × 1
                      </span>
                    </div>
                    <div className="text-right hidden sm:block">
                      <span className="font-headline-sm text-sm font-bold text-gray-900">
                        65.000đ
                      </span>
                      <p className="text-[11px] text-gray-500">SL: 1</p>
                    </div>
                  </div>
                </div>

                {/* Subfooter */}
                <div className="pt-3 border-t border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2 text-gray-800 text-xs">
                    <span className="material-symbols-outlined text-[18px] text-[#b02d29]">local_shipping</span>
                    <span>Tài xế Nguyễn Văn An đang giao tới - Dự kiến: <strong>11:30 hôm nay</strong></span>
                  </div>
                  <div className="flex items-center justify-between sm:justify-end gap-4">
                    <span className="text-xs text-gray-500">
                      Tổng tiền:{' '}
                      <strong className="font-headline-sm text-sm sm:text-base text-[#b02d29] font-bold">
                        355.000đ
                      </strong>
                    </span>
                    <button
                      type="button"
                      onClick={onOpenOrderTracking}
                      className="px-4 py-2 rounded-xl bg-[#234729] text-white hover:opacity-90 text-xs font-semibold transition-opacity cursor-pointer shadow-xs"
                    >
                      Xem lộ trình
                    </button>
                  </div>
                </div>
              </div>

              {/* Order 2: Completed */}
              <div className="bg-[#f5f3f0] rounded-2xl p-5 md:p-6 space-y-4 border border-[#eae8e5]">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-gray-900">#VX-77412</span>
                    <span className="text-gray-300">|</span>
                    <span className="text-xs text-gray-500">Hoàn thành ngày 12/10/2025</span>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#eae8e5] text-gray-700 text-xs font-semibold flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-[#234729]">check_circle</span>
                    <span>Đã giao thành công</span>
                  </span>
                </div>

                <div className="flex items-center gap-4">
                  <img
                    className="w-16 h-16 object-cover rounded-xl shrink-0 shadow-2xs border border-gray-100 bg-white"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuAAGyh6o5GPpiGctcqf6EAyHDI7ZF1qkVzWTJk2156NSAZBfAwbwCNzhFJRAzamGE8xP1a25lpOGMRVWcp16GXQdXKPU3IWclnCgeOOiyTIanrpGiQI1q9QI0Rhd-eavuGaSoTFKky4d8EjYaenDpyf8sNWuRjDl2uszvz2wLnM7xrRGvYlQnhMFXaOqJ-4Sw0wZ-6kQcJZVRSdeLd2nJBUVJv-Ndbt-ivsHqymjZeMTRGCxsSvKCG7"
                    alt="Chậu Gốm Sứ Bát Tràng"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-headline-sm text-xs sm:text-sm font-bold text-gray-900 truncate">
                      Chậu Gốm Sứ Bát Tràng Dáng Trụ Trắng Mờ (Size L)
                    </h4>
                    <p className="text-[11px] text-gray-500">
                      Màu: Men kem mờ • Kèm đĩa hứng nước rời
                    </p>
                    <span className="text-xs text-gray-900 font-semibold sm:hidden block mt-1">
                      160.000đ × 2
                    </span>
                  </div>
                  <div className="text-right hidden sm:block">
                    <span className="font-headline-sm text-sm font-bold text-gray-900">
                      320.000đ
                    </span>
                    <p className="text-[11px] text-gray-500">SL: 2</p>
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <span className="text-xs text-gray-500 flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-[#b02d29]">verified</span>
                    <span>Đang trong thời hạn bảo hành cây &amp; chậu (Còn 17 ngày)</span>
                  </span>
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => setReviewOrderModal('#VX-77412')}
                      className="px-4 py-1.5 rounded-xl border border-gray-300 hover:bg-white text-xs font-medium transition-colors cursor-pointer"
                    >
                      Đánh giá sản phẩm
                    </button>
                    <button
                      type="button"
                      onClick={() => onReorder('VX-77412')}
                      className="px-4 py-1.5 rounded-xl bg-[#eae8e5] hover:bg-[#234729] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Mua lại
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Available Vouchers & Special Offers */}
            <div className="bg-white rounded-2xl p-6 lg:p-8 shadow-xs border border-gray-100 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-headline-md text-lg font-bold text-gray-900">
                    Mã giảm giá dành riêng cho Hà
                  </h3>
                  <p className="text-xs text-gray-500">
                    Ưu đãi thành viên tích lũy mầm xanh Vườn Xanh
                  </p>
                </div>
                <span className="material-symbols-outlined text-[#b02d29] text-[28px]">redeem</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {vouchers.map((v) => (
                  <div
                    key={v.code}
                    className="p-4 rounded-2xl bg-[#f5f3f0] border-l-4 border-[#b02d29] flex items-start justify-between gap-4 border border-[#eae8e5]"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-[#b02d29] text-white rounded text-[10px] font-bold uppercase tracking-wider">
                          {v.badge}
                        </span>
                        <span className="text-[11px] text-gray-500">HSD: {v.expiry}</span>
                      </div>
                      <h4 className="font-headline-sm text-sm font-bold text-gray-900">
                        {v.title}
                      </h4>
                      <p className="text-xs text-gray-500">{v.desc}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onApplyVoucher(v.code)}
                      className="px-3.5 py-1.5 rounded-xl bg-[#234729] text-white text-xs font-semibold hover:opacity-90 transition-opacity shrink-0 cursor-pointer shadow-xs"
                    >
                      Dùng ngay
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Review Modal */}
      {reviewOrderModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-headline-sm text-base font-bold text-gray-900">
                Đánh giá đơn hàng {reviewOrderModal}
              </h3>
              <button
                type="button"
                onClick={() => setReviewOrderModal(null)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {reviewSubmitted ? (
              <div className="py-6 text-center space-y-2">
                <span className="material-symbols-outlined text-[42px] text-[#234729]">check_circle</span>
                <p className="text-sm font-bold text-gray-900">Cảm ơn bạn đã đánh giá!</p>
                <p className="text-xs text-gray-500">Bạn được tặng thêm 20 điểm mầm xanh tích lũy.</p>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setReviewSubmitted(true);
                  setTimeout(() => {
                    setReviewOrderModal(null);
                    setReviewSubmitted(false);
                  }, 1800);
                }}
                className="space-y-4"
              >
                <div>
                  <label className="text-xs font-medium text-gray-600 block mb-1">
                    Đánh giá chất lượng cây &amp; đóng gói
                  </label>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="text-2xl text-amber-500 cursor-pointer"
                      >
                        {star <= reviewRating ? '★' : '☆'}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-medium text-gray-600 block mb-1">
                    Cảm nhận thực tế của bạn
                  </label>
                  <textarea
                    rows={3}
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder="Chậu cây rất đẹp, đóng gói cẩn thận..."
                    className="w-full bg-[#f5f3f0] p-3 rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-[#234729]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#234729] text-white text-xs font-bold rounded-xl hover:opacity-90 cursor-pointer shadow-xs"
                >
                  Gửi đánh giá
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
