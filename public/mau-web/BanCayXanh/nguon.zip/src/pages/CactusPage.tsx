import React, { useState, useMemo } from 'react';
import { PageTab, Product } from '../types';
import { cactusList } from '../data/mockData';

interface CactusPageProps {
  onNavigate: (tab: PageTab) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
  onSelectProduct: (product: Product) => void;
  onOpenArticle: (articleId: string) => void;
}

export const CactusPage: React.FC<CactusPageProps> = ({
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onSelectProduct,
  onOpenArticle,
}) => {
  const [selectedCare, setSelectedCare] = useState<string>('all');
  const [selectedPlacement, setSelectedPlacement] = useState<string>('Cạnh máy tính');
  const [sortOption, setSortOption] = useState<string>('best-seller');
  const [hasFlowerFilter, setHasFlowerFilter] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(1);

  const filteredProducts = useMemo(() => {
    return cactusList.filter((prod) => {
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-asc') return a.price - b.price;
      if (sortOption === 'price-desc') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      return b.reviewsCount - a.reviewsCount;
    });
  }, [sortOption]);

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Breadcrumb & Highlights */}
      <section className="w-full bg-[#f5f3f0]/80 py-3">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between text-xs text-gray-500 font-label-meta">
          <nav className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('trang-chu')}
              className="hover:text-gray-900 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[14px]">home</span>
              <span>Trang chủ</span>
            </button>
            <span className="text-gray-300">/</span>
            <span className="text-[#b02d29] font-semibold">Xương rồng</span>
          </nav>

          <div className="hidden sm:flex items-center gap-4 text-gray-600">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#b02d29]"></span>
              <span>48 giống xương rồng thuần khí hậu</span>
            </span>
            <span className="text-gray-300">|</span>
            <span className="flex items-center gap-1">
              <span className="material-symbols-outlined text-[16px] text-[#234729]">check_circle</span>
              <span>Đảm bảo còn nguyên gai &amp; dáng chuẩn</span>
            </span>
          </div>
        </div>
      </section>

      {/* 2. Hero Banner: Xương Rồng Gai Góc & Hoa Rực Nắng */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mt-6">
        <div className="relative bg-white rounded-2xl overflow-hidden shadow-xs border border-gray-100">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[340px]">
            {/* Left Content */}
            <div className="lg:col-span-7 p-6 sm:p-10 lg:p-12 flex flex-col justify-between relative z-10">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="font-label-category uppercase tracking-widest text-[#b02d29] bg-[#ffdad6]/60 px-3 py-1 rounded-full text-[11px] font-bold">
                    Bộ Sưu Tập Tự Nhiên
                  </span>
                  <span className="text-gray-500 text-xs flex items-center gap-1">
                    <span className="material-symbols-outlined text-[14px] text-[#b02d29]">flare</span>
                    <span>Lọc bức xạ màn hình 94%</span>
                  </span>
                </div>

                <h1 className="font-headline-xl text-3xl sm:text-4xl lg:text-5xl text-gray-900 leading-tight tracking-tight">
                  Xương Rồng Gai Góc <br />
                  <span className="italic font-normal text-[#b02d29] font-headline-xl">
                    &amp; Hoa Rực Nắng
                  </span>
                </h1>

                <p className="font-body-lead text-gray-600 mt-4 max-w-xl text-sm sm:text-base leading-relaxed">
                  Biểu tượng của sức sống kiên cường vượt bão giông. Lựa chọn lý tưởng cho bàn làm việc hiện đại: hút bức xạ điện từ, thanh lọc trường khí và gần như không cần tốn công chăm bẵm.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-4 mt-8 pt-4">
                <div className="flex items-center gap-3 bg-[#f5f3f0] px-4 py-2.5 rounded-xl border border-[#eae8e5]">
                  <span className="material-symbols-outlined text-[#b02d29] text-[22px]">water_drop</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-gray-900">Chỉ tưới 1-2 lần/tuần</span>
                    <span className="text-[11px] text-gray-500">Không lo cây héo khi đi công tác</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-[#f5f3f0] px-4 py-2.5 rounded-xl border border-[#eae8e5]">
                  <span className="material-symbols-outlined text-[#b02d29] text-[22px]">shield_with_heart</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-gray-900">Bảo hành sống 30 ngày</span>
                    <span className="text-[11px] text-gray-500">1 đổi 1 tận nơi nếu hỏng dập</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Visual Showcase */}
            <div className="lg:col-span-5 relative min-h-[260px] lg:min-h-full">
              <img
                className="w-full h-full object-cover"
                data-alt="Cactus showcase"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCcO42efPlNU8lYBj8OFawHh8-32wdXcQHBomEBNO11Zs-HWZTu6ldZ4Aj1M5hKe5YhfgC6mj1f8DbZPS0ZR8w26yl-rm-j1LrePcFwzSIwh7S-DnrZi7-vw4DqXrExsGqeOgRk_HwtbksD_RUE7ibpYTCesuto7RAOaObz5_rLtRyDg3QShTP5FYhLnDvYVxI1szc1J_hF5u-LiFO11A5gvzlV0CE4pHeKoY5mAOlgPv0hlFNqUMeG"
                alt="Bộ sưu tập xương rồng gai góc và hoa rực nắng"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-white via-transparent to-transparent" />
              <div className="absolute bottom-4 right-4 bg-[#234729] text-white px-3.5 py-2 rounded-xl shadow-md backdrop-blur-sm flex items-center gap-2">
                <span className="material-symbols-outlined text-emerald-300 text-[18px]">verified</span>
                <span className="text-xs font-medium">100% Cây thuần rễ khoẻ</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Quick Category Navigator (6 Chips) */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mt-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            {
              title: 'Có nở hoa',
              sub: '16 mẫu rực rỡ',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0yqrHtAIkEiGwWaXQuvzsJnUSM9ONSFNJBKP-cA-rL0NHPlFjnGNOjrw7D_KpUo7r2n8-qb9xnWl71lPek-UyTvfWYmmy-nMFPNg0BwRdP87apXog4c1Y51Zam0qBS5-qtC9p0hnARxty4jmdCi8gSvH48RwFb0E_tDVr1VX5jyojZ7Ud1UNMaXgp3ZRZyfyMxvsENX7jAUJYcGnP8JYGZp1uEMMqhgBzb9htaelezVfPgwtaviYS',
            },
            {
              title: 'Tai Thỏ Mini',
              sub: 'Dễ thương để bàn',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCvsm5v6bpp6-mEEXiEXoTvJ_Emsg9Y62WXHDeZQvQ2gXQTk9R53quOvM5Ra-sN0c4ehw8Yhzm9ci1vSK4dcL3uCZid_pbeUPeJGlE6bPEmb-XCFgbFt5mg1r-GXMZL0ox_VFxMFH6kpb1GU8NiwDn7V3ek5V3xgyyPpEquK-owaZz6u4uthat2pOrM3j1_q0T8QWRFoj6vif3er1UNvlLnXqmNscBRXltibf0u0gHDEGc1Hv7T3g90',
            },
            {
              title: 'Dáng Núi & Trụ',
              sub: 'Thế kiên cường',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDwDe3LvY6a_cZawKmKDIflwWcOIUVllld-RY4ENzJTkM3ibMgqeM1006je6JYALo4wd4P7ZxmAWaDM9ZgPLgBD9WRnIYrv3OTHSpBnZAYe4x55ifIWOmsiB1DKkD2DHLif_kXfZ6BIsk6JShLcurffMgEopMvQ6tYGs9rISGZpsVwhYTRaV0cszrRG5CoeXNuMRJtn1B7QZ8XNMjXpAL8r8BjgOAt9LZLa0y0_rUM1kXx4sJpx7-ev',
            },
            {
              title: 'Trứng Chim',
              sub: 'Lông mềm mịn',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBEMn5zaTXMyZGFX7kt2d9NrZvm19X6ieAWL4xpvmSH5jJy2f8zRQ1vkPakk82fCX3uNI_ci52yaxfMXhl4oTprDcRqagzq84gno7A8w31sbMMoEUoyVws1tqVr8Y7SYpyR7QjjLvSkA0M3iKqbxdtTgdzG3yY3Yd8ZWMs0QjCC0GAp6phQN-5rRSFp9EUHEp2Xcg0zO1II3pZNrdxALIcH-aI-cGX1gDojywJwL7IJ_BAxBUTe8N3W',
            },
            {
              title: 'Bát Tiên Phong Thuỷ',
              sub: 'Chiêu tài rước lộc',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAmCRc06rhqPkpbjg0NBw1pAz6zCB76tJ6nNR4oG_NV2_YcJ9ChglHctJvZfqwre1l4JFlsPNWKp7bzbXwLJt7v9AqXYlqxjjNe7uQL1IIdvrS0pjCvhtfIAataywp7vFeQZdTdjhUmHhkvwolRU9jt_5TaNfd2HJk6nWwJ_VREVYLx6csgCOaYBs-eOZb1vTED4bjvv9vADu6mTSTo0HSBnwIYA8SUkt7opT-T51AnAyIk-3yBaXM6',
            },
            {
              title: 'Combo Quà Tặng',
              sub: 'Tiết kiệm 20%',
              highlight: true,
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCKU5ug5RafGRVIVSNMviJXe-d9ypJfRw_NPtruIiOdBFyxX56sHeFoUwo3JWdwhwzsTTZ8ELy5vIVIPph8EyY7nT00SjjychBCKHZyq55LofVZ8xEGfvaZLZUm0AH-u0ChpLX9J-qhWJ93YiucOgBcKNRkaJggmD48ixZIcNDJiQAXad0rLvpzPC4ALNcabwPmZ6bawcdgkbuBOuCpFg-siAMZlhDcQYsyThUrRqoA5YiR4RixsqP6',
            },
          ].map((cat, idx) => (
            <div
              key={idx}
              className="bg-white p-3 rounded-2xl flex items-center gap-3 shadow-xs hover:shadow-md transition-shadow cursor-pointer border border-gray-100"
            >
              <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 shadow-xs">
                <img
                  className="w-full h-full object-cover"
                  src={cat.img}
                  alt={cat.title}
                />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold text-gray-900 truncate">{cat.title}</span>
                <span
                  className={`text-[11px] truncate ${
                    cat.highlight ? 'text-[#b02d29] font-bold' : 'text-gray-500'
                  }`}
                >
                  {cat.sub}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Main Catalog Content: Filters + 8 Cactus Products */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar Filters */}
          <aside className="lg:col-span-3 bg-white p-6 rounded-2xl shadow-xs border border-gray-100 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#b02d29] text-[20px]">tune</span>
                <span className="font-headline-sm text-sm font-bold text-gray-900">Bộ Lọc Tìm Kiếm</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setHasFlowerFilter(true);
                  setSelectedCare('all');
                  setSelectedPlacement('Bàn làm việc');
                }}
                className="text-xs text-[#b02d29] hover:underline cursor-pointer font-medium"
              >
                Xoá lọc
              </button>
            </div>

            {/* Dạng hoa & Vẻ đẹp */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center justify-between">
                <span>Dạng hoa &amp; Vẻ đẹp</span>
                <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
              </h4>
              <div className="space-y-2 text-xs text-gray-700">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasFlowerFilter}
                    onChange={(e) => setHasFlowerFilter(e.target.checked)}
                    className="w-4 h-4 accent-[#b02d29] rounded"
                  />
                  <span>Đang có nụ / Nở hoa</span>
                  <span className="ml-auto text-gray-400">(12)</span>
                </label>
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 accent-[#b02d29] rounded" />
                  <span>Xương rồng dáng núi (Không hoa)</span>
                  <span className="ml-auto text-gray-400">(18)</span>
                </label>
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 accent-[#b02d29] rounded" />
                  <span>Xương rồng tròn gai mút</span>
                  <span className="ml-auto text-gray-400">(9)</span>
                </label>
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 accent-[#b02d29] rounded" />
                  <span>Tai thỏ / Lông nhung</span>
                  <span className="ml-auto text-gray-400">(9)</span>
                </label>
              </div>
            </div>

            <div className="w-full h-px bg-gray-100" />

            {/* Mức độ chăm sóc */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center justify-between">
                <span>Mức độ chăm sóc</span>
                <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
              </h4>
              <div className="space-y-2 text-xs text-gray-700">
                {[
                  { id: 'all', label: 'Tất cả độ khó' },
                  { id: 'super-easy', label: 'Siêu dễ trồng (Dành cho người mới)' },
                  { id: 'indoor', label: 'Ít cần tưới nước (Phòng máy lạnh)' },
                  { id: 'sunny', label: 'Chịu nắng gắt tốt (Ban công, sân khấu)' },
                ].map((diff) => (
                  <label key={diff.id} className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="radio"
                      name="cactus-difficulty"
                      checked={selectedCare === diff.id}
                      onChange={() => setSelectedCare(diff.id)}
                      className="w-4 h-4 accent-[#b02d29]"
                    />
                    <span>{diff.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="w-full h-px bg-gray-100" />

            {/* Không gian trang trí */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center justify-between">
                <span>Không gian trang trí</span>
                <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
              </h4>
              <div className="flex flex-wrap gap-2 text-xs">
                {['Bàn làm việc', 'Cạnh máy tính', 'Cửa sổ', 'Quầy thu ngân', 'Kệ sách'].map((place) => (
                  <button
                    key={place}
                    type="button"
                    onClick={() => setSelectedPlacement(place)}
                    className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                      selectedPlacement === place
                        ? 'bg-[#b02d29] text-white font-medium'
                        : 'bg-[#f5f3f0] text-gray-700 hover:bg-[#eae8e5]'
                    }`}
                  >
                    {place}
                  </button>
                ))}
              </div>
            </div>

            {/* Banner Bảo hiểm */}
            <div className="bg-[#f5f3f0] p-4 rounded-xl space-y-1.5 border border-[#eae8e5]">
              <p className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#b02d29] text-[18px]">verified_user</span>
                <span>Bảo hiểm gai rễ trọn vẹn</span>
              </p>
              <p className="text-[11px] text-gray-600 leading-relaxed">
                Mọi chậu xương rồng đều được bọc xốp bóng khí 3 lớp chuyên dụng. Cây gãy gai hoặc vỡ chậu khi ship sẽ được Vườn Xanh gửi mới miễn phí 100%.
              </p>
            </div>
          </aside>

          {/* Product Grid Stream */}
          <main className="lg:col-span-9 space-y-6">
            <div className="bg-white p-4 rounded-2xl shadow-xs border border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs sm:text-sm">
                <span className="font-bold text-gray-900">Tìm thấy 48 sản phẩm</span>
                <span className="text-gray-300">|</span>
                <span className="text-gray-500">Hiển thị các dòng xương rồng kháng xạ tốt nhất</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500">Sắp xếp theo:</span>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="bg-[#f5f3f0] text-gray-900 text-xs px-3 py-1.5 rounded-lg focus:outline-none cursor-pointer"
                >
                  <option value="best-seller">Bán chạy nhất</option>
                  <option value="price-asc">Giá tăng dần</option>
                  <option value="price-desc">Giá giảm dần</option>
                  <option value="rating">Đánh giá cao nhất</option>
                </select>
              </div>
            </div>

            {/* 8 Cactus Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredProducts.map((prod) => {
                const isWishlisted = wishlistIds.has(prod.id);
                return (
                  <article
                    key={prod.id}
                    className="bg-white rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-shadow group flex flex-col border border-gray-100"
                  >
                    <div className="relative w-full aspect-square bg-[#f5f3f0] overflow-hidden">
                      {prod.badge && (
                        <span className="absolute top-2.5 left-2.5 z-10 bg-[#b02d29] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-xs">
                          {prod.badge}
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(prod);
                        }}
                        className={`absolute top-2.5 right-2.5 z-10 w-7 h-7 bg-white/80 backdrop-blur rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                          isWishlisted ? 'text-[#b02d29]' : 'text-gray-500 hover:text-[#b02d29]'
                        }`}
                      >
                        <span
                          className={`material-symbols-outlined text-[16px] ${
                            isWishlisted ? 'material-symbols-fill' : ''
                          }`}
                        >
                          favorite
                        </span>
                      </button>
                      <img
                        src={prod.image}
                        alt={prod.name}
                        onClick={() => onSelectProduct(prod)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                      />
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div
                        onClick={() => onSelectProduct(prod)}
                        className="cursor-pointer"
                      >
                        <span className="text-[10px] text-[#b02d29] font-bold uppercase tracking-wider block">
                          {prod.fengShui || 'Cây mọng nước'}
                        </span>
                        <h3 className="font-headline-sm text-sm sm:text-[15px] font-bold text-gray-900 line-clamp-2 mt-0.5 leading-snug group-hover:text-[#b02d29] transition-colors">
                          {prod.name}
                        </h3>
                        <div className="flex items-center gap-1.5 mt-2 text-xs text-gray-500">
                          <span className="flex items-center text-amber-500 font-bold">
                            <span className="material-symbols-outlined text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                              star
                            </span>
                            <span className="text-gray-900 ml-0.5">{prod.rating}</span>
                          </span>
                          <span className="text-gray-400">({prod.reviewsCount})</span>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 flex items-center justify-between border-t border-gray-50">
                        <div>
                          <span className="text-base sm:text-lg font-bold text-[#b02d29]">
                            {prod.price.toLocaleString('vi-VN')}đ
                          </span>
                          {prod.originalPrice && (
                            <span className="block text-[11px] text-gray-400 line-through">
                              {prod.originalPrice.toLocaleString('vi-VN')}đ
                            </span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => onAddToCart(prod)}
                          style={{ backgroundColor: '#1E4D2B' }}
                          className="w-9 h-9 rounded-xl flex items-center justify-center text-white transition-opacity hover:opacity-90 shadow-xs cursor-pointer"
                          title="Thêm vào giỏ"
                        >
                          <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>

            {/* Pagination */}
            <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-xs text-gray-500">
                Đang hiển thị <strong>8</strong> trên <strong>48</strong> chậu xương rồng
              </p>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="w-8 h-8 rounded-lg bg-[#f5f3f0] text-gray-500 flex items-center justify-center hover:bg-[#eae8e5] transition-colors disabled:opacity-40 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">chevron_left</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(1)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold cursor-pointer ${
                    currentPage === 1 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                  }`}
                >
                  1
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(2)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold cursor-pointer ${
                    currentPage === 2 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                  }`}
                >
                  2
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(3)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold cursor-pointer ${
                    currentPage === 3 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                  }`}
                >
                  3
                </button>
                <button
                  type="button"
                  disabled={currentPage === 3}
                  onClick={() => setCurrentPage(3)}
                  className="w-8 h-8 rounded-lg bg-white border border-gray-200 text-gray-700 flex items-center justify-center hover:bg-[#f5f3f0] transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">chevron_right</span>
                </button>
              </div>
            </div>
          </main>
        </div>
      </section>

      {/* 5. Packaging Standards: Đóng Gói 3 Lớp Chống Sốc An Toàn Tuyệt Đối */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mt-16">
        <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-xs border border-gray-100">
          <div className="max-w-2xl mx-auto text-center space-y-3 mb-10">
            <span className="font-label-category uppercase tracking-widest text-[#b02d29] font-bold text-xs">
              Quy chuẩn đóng gói Vườn Xanh
            </span>
            <h2 className="font-headline-xl text-2xl sm:text-3xl lg:text-4xl text-gray-900">
              Đóng Gói 3 Lớp Chống Sốc An Toàn Tuyệt Đối
            </h2>
            <p className="font-body-md text-gray-600 text-sm sm:text-base leading-relaxed">
              Chúng tôi hiểu nỗi lo gai gãy, dập cành hay tràn đất khi vận chuyển xương rồng xa. Mỗi đơn hàng tại Vườn Xanh đều được đóng gói theo quy chuẩn khắt khe.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-[#f5f3f0] p-6 rounded-2xl relative flex flex-col justify-between border border-[#eae8e5]">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-[#b02d29] font-headline-md font-bold shadow-xs">
                  01
                </div>
                <div className="w-full h-36 rounded-xl overflow-hidden shadow-xs">
                  <img
                    className="w-full h-full object-cover"
                    data-alt="Packing step 1"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCdal0YCb-vorPaJr2EN0g5utZDyPrP_j_EAf5-e7P_mLar1ViAkpbfIQ-wrpm2Yw-Ecyo0BzVr848jVQF1OPQeAZhM4Vvgc0N-QL1GpvDqld3x2IZ4JjAc5suHR4UYJ0K58eWsb1r6xXJ1Ct5BrfIEJD1zkgEl4GdmZHFmZrdwp3ZrrtfZlQ9-vYnuPrLg8mwch9ddd-ArcuIumu2dBPj5Y9RFjp0deQX-FssqzTs69N1YXVg_-VPE"
                    alt="Lớp 1: Cố định gốc & Bọc nón bảo vệ gai"
                  />
                </div>
                <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
                  Lớp 1: Cố định gốc &amp; Bọc nón bảo vệ gai
                </h3>
                <p className="text-xs text-gray-600 leading-relaxed">
                  Gốc cây được cố định màng xốp vi sinh giữ đất không văng ra ngoài. Thân và gai nhọn được bao phủ bằng ống trụ carton định hình riêng biệt.
                </p>
              </div>
              <div className="mt-4 pt-3 flex items-center gap-2 text-[#b02d29] text-xs font-semibold border-t border-[#eae8e5]">
                <span className="material-symbols-outlined text-[16px]">lock</span>
                <span>Chống đổ đất 100%</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-[#f5f3f0] p-6 rounded-2xl relative flex flex-col justify-between border border-[#eae8e5]">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-[#b02d29] font-headline-md font-bold shadow-xs">
                  02
                </div>
                <div className="w-full h-36 rounded-xl overflow-hidden shadow-xs">
                  <img
                    className="w-full h-full object-cover"
                    data-alt="Packing step 2"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuBO07wFn9G2WV9jkG7IJqPSYmuMlhd2gnehrJd55VaMzmF3tyU7Qw2xDe8nYYVGYgNkm64Z2NC-QVGng-9Qar8s7PF084f-cPxDFwzoLOUl6_0VFzWegsuf1jF2xE8fGBwmWqhyCALYyCja6a_RxdcdQKxXp7qKCn_XW1aW7MnexGQesQk7b7LIQfq7THamJtjzqYdlNKB_umKd43fhA6sAZ2qLWMFwzXdeSc7AoUE54JzD2VGn1jtm"
                    alt="Lớp 2: Xốp bóng khí 3 lớp giảm chấn"
                  />
                </div>
                <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
                  Lớp 2: Xốp bóng khí 3 lớp giảm chấn
                </h3>
                <p className="text-xs text-gray-600 leading-relaxed">
                  Toàn bộ chậu sứ hoặc chậu đất nung được quấn bóng khí giảm va đập đa chiều, đảm bảo không rạn nứt dù vận chuyển đường dài xuyên tỉnh.
                </p>
              </div>
              <div className="mt-4 pt-3 flex items-center gap-2 text-[#b02d29] text-xs font-semibold border-t border-[#eae8e5]">
                <span className="material-symbols-outlined text-[16px]">shield</span>
                <span>Chống va đập mạnh</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-[#f5f3f0] p-6 rounded-2xl relative flex flex-col justify-between border border-[#eae8e5]">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-[#b02d29] font-headline-md font-bold shadow-xs">
                  03
                </div>
                <div className="w-full h-36 rounded-xl overflow-hidden shadow-xs">
                  <img
                    className="w-full h-full object-cover"
                    data-alt="Packing step 3"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuBUFK8bmgEyuVFiuuqlfhe3e_7ePG-1y-mC-YDebEbA9kYuQ0JUtwLePimeHb2euyb-n2oTm-dKJcfnnTsEImSGsN-nMCyvA6VBgOF-4PITENfNL7EIVBlQF3LnOLcv7_WzOD6S7sKLF9OLBdwFUwRJ2wUcIU82JCRoZxJk7wZhjkRZzgKSqj-uOuP8TVpp4w8L-7bNuijbMhhYphLU44bOXq8XIr8ec-HJ02I2gN-oUoO4LqfXD0im"
                    alt="Lớp 3: Thùng carton 5 lớp & Nhãn Hàng Sống"
                  />
                </div>
                <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
                  Lớp 3: Thùng carton 5 lớp &amp; Nhãn Hàng Sống
                </h3>
                <p className="text-xs text-gray-600 leading-relaxed">
                  Thùng carton cứng 5 lớp có lỗ thở đối lưu khí, dán nhãn ưu tiên "Hàng Cây Sống Dễ Vỡ" để đơn vị vận chuyển xếp ở tầng trên cùng.
                </p>
              </div>
              <div className="mt-4 pt-3 flex items-center gap-2 text-[#b02d29] text-xs font-semibold border-t border-[#eae8e5]">
                <span className="material-symbols-outlined text-[16px]">air</span>
                <span>Lưu thông không khí</span>
              </div>
            </div>
          </div>

          {/* Cam kết đồng kiểm */}
          <div className="mt-8 bg-[#f5f3f0] p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-[#eae8e5]">
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-[#b02d29] text-[28px]">
                sentiment_very_satisfied
              </span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-gray-900">
                  Đồng kiểm hàng trước khi thanh toán
                </h4>
                <p className="text-xs text-gray-500">
                  Khách hàng được mở kiểm tra chậu và gai cây nguyên vẹn trước khi nhận hàng từ shipper.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('gio-hang')}
              className="px-5 py-2.5 bg-[#234729] text-white text-xs font-bold rounded-xl hover:opacity-90 transition-opacity whitespace-nowrap cursor-pointer shadow-xs"
            >
              Tìm hiểu thêm về chính sách
            </button>
          </div>
        </div>
      </section>

      {/* 6. Mẹo Chăm Sóc Xương Rồng Tại Bàn Làm Việc */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 mt-16 mb-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-gray-100">
          <div>
            <span className="font-label-category uppercase tracking-widest text-[#b02d29] font-bold text-xs">
              Cẩm nang vườn xinh
            </span>
            <h2 className="font-headline-xl text-2xl sm:text-3xl text-gray-900 mt-1">
              Bí Quyết Giữ Xương Rồng Tươi Tắn &amp; Mau Ra Hoa
            </h2>
          </div>
          <button
            onClick={() => onNavigate('trang-chu')}
            className="text-xs font-bold text-[#b02d29] flex items-center gap-1 hover:underline mt-2 md:mt-0 cursor-pointer"
          >
            <span>Xem tất cả bài viết</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-3">
            <span className="text-[10px] text-[#b02d29] font-bold uppercase tracking-wider block">Ánh sáng</span>
            <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
              Bao nhiêu nắng là đủ cho xương rồng văn phòng?
            </h3>
            <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
              Xương rồng cần ít nhất 3-4 giờ nắng gián tiếp mỗi ngày. Nếu để trong phòng kín hoàn toàn, cuối tuần bạn nên mang chậu ra cạnh bệ cửa sổ phơi nắng sớm.
            </p>
            <button
              onClick={() => onOpenArticle('bl-1')}
              className="inline-block text-xs font-semibold text-gray-900 hover:text-[#b02d29] underline pt-2 cursor-pointer"
            >
              Đọc tiếp →
            </button>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-3">
            <span className="text-[10px] text-[#b02d29] font-bold uppercase tracking-wider block">Tưới nước</span>
            <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
              Quy tắc "Khô ráo hoàn toàn mới tưới"
            </h3>
            <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
              Sai lầm lớn nhất là tưới quá nhiều khiến rễ bị úng thối. Dùng que tăm xiên sâu vào đất, nếu tăm khô cong hoàn toàn thì mới tưới một lượng nước nhỏ vào gốc.
            </p>
            <button
              onClick={() => onOpenArticle('bl-2')}
              className="inline-block text-xs font-semibold text-gray-900 hover:text-[#b02d29] underline pt-2 cursor-pointer"
            >
              Đọc tiếp →
            </button>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-3">
            <span className="text-[10px] text-[#b02d29] font-bold uppercase tracking-wider block">Kích thích hoa</span>
            <h3 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
              Làm sao để cây xương rồng trổ hoa đều đặn?
            </h3>
            <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
              Các dòng Gymno và Bánh Sinh Nhật rất siêng hoa. Chỉ cần bổ sung vài viên phân tan chậm NPK giàu Phốt-pho và giữ cây ở nơi nhiều gió thoáng mát.
            </p>
            <button
              onClick={() => onOpenArticle('bl-3')}
              className="inline-block text-xs font-semibold text-gray-900 hover:text-[#b02d29] underline pt-2 cursor-pointer"
            >
              Đọc tiếp →
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
