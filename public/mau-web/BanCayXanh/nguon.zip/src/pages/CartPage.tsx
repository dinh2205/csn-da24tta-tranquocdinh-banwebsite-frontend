import React, { useState } from 'react';
import { PageTab, CartItem, Product, Voucher } from '../types';
import { crossSellItems } from '../data/mockData';

interface CartPageProps {
  onNavigate: (tab: PageTab) => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onAddToCart: (product: Product) => void;
  appliedVoucher: Voucher | null;
  onApplyVoucher: (code: string) => boolean;
  onOpenCheckout: () => void;
  onOpenConsultation: () => void;
}

export const CartPage: React.FC<CartPageProps> = ({
  onNavigate,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onAddToCart,
  appliedVoucher,
  onApplyVoucher,
  onOpenCheckout,
  onOpenConsultation,
}) => {
  const [voucherCodeInput, setVoucherCodeInput] = useState('VUONXANH15');
  const [voucherFeedback, setVoucherFeedback] = useState<string | null>(
    'Đã kích hoạt mã giảm 15% cho đơn đầu tiên'
  );

  // Subtotal calculations
  const rawSubtotal = cartItems.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const totalItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Free shipping threshold: 300.000đ
  const isFreeShip = rawSubtotal >= 300000;
  const shippingFee = isFreeShip ? 0 : 30000;
  const shippingDiscount = isFreeShip ? 30000 : 0;

  // Voucher discount
  let voucherDiscount = 0;
  if (appliedVoucher) {
    if (appliedVoucher.discountPercent) {
      voucherDiscount = Math.round((rawSubtotal * appliedVoucher.discountPercent) / 100);
      if (appliedVoucher.maxDiscount && voucherDiscount > appliedVoucher.maxDiscount) {
        voucherDiscount = appliedVoucher.maxDiscount;
      }
    }
  }

  const finalTotal = Math.max(0, rawSubtotal + shippingFee - voucherDiscount);

  const handleApplyCode = () => {
    if (!voucherCodeInput.trim()) return;
    const success = onApplyVoucher(voucherCodeInput.trim());
    if (success) {
      setVoucherFeedback('Đã áp dụng mã thành công!');
    } else {
      setVoucherFeedback('Mã ưu đãi không hợp lệ hoặc đã hết hạn.');
    }
  };

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Progress Header & Breadcrumb */}
      <div className="w-full bg-[#f5f3f0] px-6 lg:px-12 py-5 shadow-2xs border-b border-gray-100">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-5">
          {/* Breadcrumb */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs text-gray-500">
            <button
              onClick={() => onNavigate('trang-chu')}
              className="hover:text-gray-900 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">home</span>
              <span>Trang chủ</span>
            </button>
            <span className="text-gray-300">/</span>
            <span className="text-gray-900 font-semibold">Giỏ hàng của bạn</span>
          </nav>

          {/* Stepper / Checkout Pipeline */}
          <div className="flex items-center gap-3 text-xs">
            {/* Step 1: Active */}
            <div className="flex items-center gap-2 text-gray-900 font-bold">
              <span className="w-6 h-6 rounded-full bg-[#234729] text-white flex items-center justify-center text-[11px]">
                1
              </span>
              <span>1. Giỏ hàng</span>
            </div>
            <div className="w-8 h-[2px] bg-[#234729]" />

            {/* Step 2 */}
            <div className="flex items-center gap-2 text-gray-400">
              <span className="w-6 h-6 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center text-[11px]">
                2
              </span>
              <span className="hidden sm:inline">2. Thông tin thanh toán</span>
            </div>
            <div className="w-8 h-[2px] bg-gray-200" />

            {/* Step 3 */}
            <div className="flex items-center gap-2 text-gray-400">
              <span className="w-6 h-6 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center text-[11px]">
                3
              </span>
              <span className="hidden sm:inline">3. Hoàn tất đặt hàng</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main Content Body */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 w-full">
        {/* Free Shipping Milestone Alert */}
        <div className="bg-white p-5 rounded-2xl shadow-xs border border-gray-100 mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-10 h-10 rounded-full bg-[#ffdad6] flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[#b02d29] text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                local_shipping
              </span>
            </div>
            <div>
              <p className="font-headline-sm text-sm sm:text-base text-gray-900 leading-snug">
                {isFreeShip ? (
                  <>
                    Tuyệt vời! Đơn hàng của bạn đã đạt{' '}
                    <span className="text-[#b02d29] font-bold">
                      {rawSubtotal.toLocaleString('vi-VN')}đ
                    </span>
                  </>
                ) : (
                  <>
                    Mua thêm{' '}
                    <span className="text-[#b02d29] font-bold">
                      {(300000 - rawSubtotal).toLocaleString('vi-VN')}đ
                    </span>{' '}
                    để được FREESHIP!
                  </>
                )}
              </p>
              <p className="text-xs text-gray-500 mt-0.5">
                Bạn được <span className="font-bold text-gray-800">MIỄN PHÍ VẬN CHUYỂN TOÀN QUỐC</span> cho đơn hàng trên 300.000đ.
              </p>
            </div>
          </div>

          {/* Mini Shipping Progress Visualization */}
          <div className="w-full sm:w-56 shrink-0 space-y-1.5">
            <div className="flex justify-between text-xs text-gray-500">
              <span>Tiến trình nhận Freeship</span>
              <span className="font-bold text-[#b02d29]">
                {Math.min(100, Math.round((rawSubtotal / 300000) * 100))}% Đạt
              </span>
            </div>
            <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#b02d29] rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, Math.round((rawSubtotal / 300000) * 100))}%`,
                }}
              />
            </div>
          </div>
        </div>

        {/* Dual Column Architecture */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Product Cart Stream (Cols 8) */}
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <h1 className="font-headline-lg text-lg sm:text-xl font-bold text-gray-900">
                  Giỏ hàng của bạn{' '}
                  <span className="text-sm font-normal text-gray-500">
                    ({cartItems.length} loại sản phẩm)
                  </span>
                </h1>
                {cartItems.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearCart}
                    className="text-xs text-[#b02d29] hover:underline flex items-center gap-1 font-medium cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[16px]">delete_sweep</span>
                    <span>Xóa tất cả</span>
                  </button>
                )}
              </div>

              {/* Product Table / Cards List */}
              {cartItems.length === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <span className="material-symbols-outlined text-[48px] text-gray-300">
                    shopping_basket
                  </span>
                  <p className="text-sm text-gray-600 font-medium">Giỏ hàng của bạn đang trống</p>
                  <button
                    type="button"
                    onClick={() => onNavigate('cay-de-ban')}
                    className="px-5 py-2.5 bg-[#234729] text-white text-xs font-semibold rounded-xl hover:opacity-90 cursor-pointer shadow-xs"
                  >
                    Khám phá cây cảnh ngay
                  </button>
                </div>
              ) : (
                <div className="space-y-4 pt-4">
                  {cartItems.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-[#f5f3f0]/50 hover:bg-[#f5f3f0] transition-colors border border-transparent hover:border-gray-200"
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-20 h-20 rounded-xl object-cover bg-white shrink-0 shadow-xs border border-gray-100"
                        />
                        <div className="space-y-1 min-w-0">
                          <span className="font-label-category uppercase tracking-wider text-[#b02d29] text-[10px] font-bold">
                            {item.product.categoryLabel}
                          </span>
                          <h3 className="font-headline-sm text-sm sm:text-[15px] font-bold text-gray-900 truncate">
                            {item.product.name}
                          </h3>
                          <p className="text-xs text-gray-500">
                            {item.potOption || item.product.specs || 'Kèm chậu men sứ cao cấp'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-5 w-full sm:w-auto">
                        <div className="text-right">
                          <div className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
                            {(item.product.price * item.quantity).toLocaleString('vi-VN')}đ
                          </div>
                          {item.product.originalPrice ? (
                            <div className="text-[11px] text-gray-400 line-through">
                              {(item.product.originalPrice * item.quantity).toLocaleString('vi-VN')}đ
                            </div>
                          ) : (
                            <div className="text-[11px] text-gray-500">
                              {item.product.price.toLocaleString('vi-VN')}đ / cây
                            </div>
                          )}
                        </div>

                        {/* Quantity Modifier */}
                        <div className="flex items-center bg-white rounded-lg px-2 py-1 shadow-2xs border border-gray-200">
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center text-gray-700 hover:text-[#b02d29] transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[16px]">remove</span>
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-gray-900">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center text-gray-700 hover:text-[#b02d29] transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[16px]">add</span>
                          </button>
                        </div>

                        {/* Delete Action */}
                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.product.id)}
                          aria-label="Xóa sản phẩm"
                          className="text-gray-400 hover:text-[#b02d29] p-1 transition-colors cursor-pointer"
                          title="Xóa khỏi giỏ"
                        >
                          <span className="material-symbols-outlined text-[20px]">delete</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Actions Beneath Stream */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-8 pt-5 bg-[#f5f3f0]/30 -mx-6 -mb-6 p-6 rounded-b-2xl border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => onNavigate('cay-de-ban')}
                  className="text-xs font-semibold text-[#234729] hover:text-[#b02d29] flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">arrow_back</span>
                  <span>Tiếp tục chọn thêm cây khác</span>
                </button>
                <span className="text-xs text-gray-500">
                  Tất cả cây cảnh đều được tuyển chọn kỹ lưỡng &amp; đóng gói chống sốc 5 lớp.
                </span>
              </div>
            </div>

            {/* Cross-sell / Upsell Essentials */}
            <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#b02d29] text-[22px]">add_circle</span>
                  <h2 className="font-headline-sm text-sm sm:text-base font-bold text-gray-900">
                    Gợi ý mua kèm tiện lợi cho cây
                  </h2>
                </div>
                <span className="text-xs text-gray-500">Ưu đãi giảm 20% khi mua kèm giỏ</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {crossSellItems.map((cs) => (
                  <div
                    key={cs.id}
                    className="flex items-center justify-between p-3.5 rounded-xl bg-[#f5f3f0] hover:bg-[#eae8e5] transition-colors border border-[#eae8e5]"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={cs.image}
                        alt={cs.name}
                        className="w-14 h-14 rounded-xl object-cover bg-white shrink-0 shadow-2xs border border-gray-100"
                      />
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-gray-900 truncate">{cs.name}</h4>
                        <p className="text-[11px] text-gray-500 truncate">{cs.specs}</p>
                        <p className="text-xs text-[#b02d29] font-bold pt-0.5">
                          {cs.price.toLocaleString('vi-VN')}đ{' '}
                          {cs.originalPrice && (
                            <span className="text-[10px] line-through text-gray-400 font-normal">
                              {cs.originalPrice.toLocaleString('vi-VN')}đ
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onAddToCart(cs)}
                      style={{ backgroundColor: '#1E4D2B' }}
                      className="px-3 py-1.5 text-white text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity shrink-0 flex items-center gap-1 shadow-xs cursor-pointer ml-2"
                    >
                      <span className="material-symbols-outlined text-[16px]">add</span>
                      <span>Thêm</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Order Summary & Checkout Box (Cols 4) */}
          <div className="lg:col-span-4 space-y-6">
            {/* Order Summary Card */}
            <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-5">
              <h2 className="font-headline-md text-base sm:text-lg font-bold text-gray-900">
                Tóm tắt đơn hàng
              </h2>

              {/* Cost Calculation */}
              <div className="space-y-3 text-xs sm:text-sm text-gray-600">
                <div className="flex justify-between items-center">
                  <span>Tạm tính ({totalItemCount} món):</span>
                  <span className="font-bold text-gray-900">
                    {rawSubtotal.toLocaleString('vi-VN')}đ
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1">
                    Phí vận chuyển:
                    <span
                      className="material-symbols-outlined text-[16px] text-gray-400"
                      title="Miễn phí toàn quốc cho đơn từ 300.000đ"
                    >
                      info
                    </span>
                  </span>
                  <span className="font-bold text-[#b02d29]">
                    {isFreeShip ? 'Miễn phí (0đ)' : '30.000đ'}
                  </span>
                </div>

                {isFreeShip && (
                  <div className="flex justify-between items-center text-[#b02d29]">
                    <span>Ưu đãi vận chuyển:</span>
                    <span className="font-medium">-30.000đ</span>
                  </div>
                )}

                {voucherDiscount > 0 && (
                  <div className="flex justify-between items-center text-[#b02d29]">
                    <span>Voucher ({appliedVoucher?.code}):</span>
                    <span className="font-medium">-{voucherDiscount.toLocaleString('vi-VN')}đ</span>
                  </div>
                )}
              </div>

              {/* Coupon Code Input Box */}
              <div className="pt-3 pb-2 space-y-2 border-t border-gray-100">
                <label
                  htmlFor="coupon-code"
                  className="font-label-category uppercase tracking-wider text-gray-600 text-[11px] font-bold block"
                >
                  Mã giảm giá / Voucher ưu đãi
                </label>
                <div className="flex gap-2">
                  <input
                    id="coupon-code"
                    type="text"
                    value={voucherCodeInput}
                    onChange={(e) => setVoucherCodeInput(e.target.value.toUpperCase())}
                    placeholder="Nhập mã ưu đãi..."
                    className="flex-1 bg-[#f5f3f0] px-3 py-2 rounded-xl text-xs font-semibold text-gray-900 placeholder:text-gray-400 focus:outline-none focus:bg-white focus:ring-1 focus:ring-[#234729] border border-transparent focus:border-gray-200"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCode}
                    className="px-4 py-2 bg-[#eae8e5] text-gray-900 text-xs font-bold rounded-xl hover:bg-[#234729] hover:text-white transition-colors cursor-pointer"
                  >
                    Áp dụng
                  </button>
                </div>
                {voucherFeedback && (
                  <div className="flex items-center gap-1 text-[11px] text-[#234729] font-medium pt-1">
                    <span className="material-symbols-outlined text-[14px]">check_circle</span>
                    <span>{voucherFeedback}</span>
                  </div>
                )}
              </div>

              {/* Total Calculation */}
              <div className="pt-4 bg-[#f5f3f0] -mx-6 px-6 py-4 rounded-xl space-y-1 border-t border-gray-100">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-bold text-gray-900">Tổng thanh toán:</span>
                  <span className="font-headline-lg text-xl sm:text-2xl text-[#b02d29] font-bold">
                    {finalTotal.toLocaleString('vi-VN')}đ
                  </span>
                </div>
                <p className="text-right text-[11px] text-gray-500">
                  (Đã bao gồm VAT và kiểm tra hàng)
                </p>
              </div>

              {/* Major CTA */}
              <button
                type="button"
                onClick={onOpenCheckout}
                disabled={cartItems.length === 0}
                style={{ backgroundColor: '#1E4D2B' }}
                className="w-full h-12 text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:opacity-95 transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer disabled:opacity-50"
              >
                <span>Tiến hành đặt hàng ngay</span>
                <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
              </button>

              {/* Alternative Direct Order Button */}
              <a
                href="tel:19006868"
                className="w-full py-2.5 bg-[#f5f3f0] text-gray-900 text-xs font-semibold rounded-xl hover:bg-[#eae8e5] transition-colors flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">phone_in_talk</span>
                <span>Tư vấn đặt nhanh qua Hotline: 1900 6868</span>
              </a>
            </div>

            {/* Trust & Guarantees Box */}
            <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-100 space-y-4">
              <h3 className="font-label-category uppercase tracking-wider text-gray-900 text-xs font-bold">
                Cam kết an tâm khi mua cây tại Vườn Xanh
              </h3>
              <div className="space-y-3.5 text-xs text-gray-600">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 mt-0.5 text-[#b02d29]">
                    <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      eco
                    </span>
                  </div>
                  <div>
                    <strong className="text-gray-900 block font-semibold">Bảo hành cây sống 30 ngày</strong>
                    <span>Miễn phí tư vấn dưỡng cây hoặc đổi cây mới nếu cây bị hư úa trong vòng 1 tháng đầu.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 mt-0.5 text-[#b02d29]">
                    <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      sync_saved_locally
                    </span>
                  </div>
                  <div>
                    <strong className="text-gray-900 block font-semibold">Đổi trả 1-1 nếu gãy rụng</strong>
                    <span>Hoàn tiền 100% hoặc gửi bù cây tức thì nếu cây bị dập nát, gãy cành do vận chuyển.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 mt-0.5 text-[#b02d29]">
                    <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      fact_check
                    </span>
                  </div>
                  <div>
                    <strong className="text-gray-900 block font-semibold">Kiểm tra cây trước khi trả tiền</strong>
                    <span>Đồng kiểm cùng shipper khi nhận hàng, đúng cây đúng chậu mới thanh toán.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Plant Care Hotline Card */}
            <div
              onClick={onOpenConsultation}
              className="bg-[#141b2b] text-white rounded-2xl p-5 flex items-center gap-4 cursor-pointer hover:bg-[#1a2337] transition-colors shadow-xs"
            >
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0 text-emerald-300">
                <span className="material-symbols-outlined text-[26px]">support_agent</span>
              </div>
              <div>
                <h4 className="font-headline-sm text-sm font-bold text-white leading-tight">
                  Bạn cần tư vấn phong thủy?
                </h4>
                <p className="text-[11px] text-gray-300 pt-1">
                  Đội ngũ nghệ nhân làm vườn của chúng tôi luôn sẵn sàng hỗ trợ bạn 24/7.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
