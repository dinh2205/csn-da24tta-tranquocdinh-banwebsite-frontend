import React, { useState, useMemo } from 'react';
import { PageTab, Product } from '../types';
import { deskPlantsList } from '../data/mockData';

interface DeskPlantsPageProps {
  onNavigate: (tab: PageTab) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
  onSelectProduct: (product: Product) => void;
}

export const DeskPlantsPage: React.FC<DeskPlantsPageProps> = ({
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onSelectProduct,
}) => {
  // Filter state
  const [selectedPrices, setSelectedPrices] = useState<string[]>(['100-250']);
  const [selectedLights, setSelectedLights] = useState<string[]>(['shade']);
  const [selectedFengShui, setSelectedFengShui] = useState<string[]>([]);
  const [careDifficulty, setCareDifficulty] = useState<string>('easy');
  const [sortOption, setSortOption] = useState<string>('best-seller');
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Toggle helpers
  const handlePriceToggle = (val: string) => {
    setSelectedPrices((prev) =>
      prev.includes(val) ? prev.filter((p) => p !== val) : [...prev, val]
    );
  };

  const handleLightToggle = (val: string) => {
    setSelectedLights((prev) =>
      prev.includes(val) ? prev.filter((l) => l !== val) : [...prev, val]
    );
  };

  const handleFengShuiToggle = (val: string) => {
    setSelectedFengShui((prev) =>
      prev.includes(val) ? prev.filter((f) => f !== val) : [...prev, val]
    );
  };

  const handleResetFilters = () => {
    setSelectedPrices([]);
    setSelectedLights([]);
    setSelectedFengShui([]);
    setCareDifficulty('all');
  };

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return deskPlantsList.filter((prod) => {
      // Price filter
      if (selectedPrices.length > 0) {
        const matchesPrice = selectedPrices.some((p) => {
          if (p === 'under-100') return prod.price < 100000;
          if (p === '100-250') return prod.price >= 100000 && prod.price <= 250000;
          if (p === 'over-250') return prod.price > 250000;
          return true;
        });
        if (!matchesPrice) return false;
      }

      // Light filter
      if (selectedLights.length > 0) {
        if (prod.light && !selectedLights.includes(prod.light)) {
          return false;
        }
      }

      // Feng Shui filter
      if (selectedFengShui.length > 0) {
        if (prod.fengShui && !selectedFengShui.includes(prod.fengShui)) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-asc') return a.price - b.price;
      if (sortOption === 'price-desc') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      return b.reviewsCount - a.reviewsCount;
    });
  }, [selectedPrices, selectedLights, selectedFengShui, sortOption]);

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Breadcrumb Bar */}
      <section className="w-full bg-[#f5f3f0]/70 py-3">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between text-gray-500 font-label-meta text-xs">
          <nav className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('trang-chu')}
              className="hover:text-gray-900 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[15px]">home</span>
              <span>Trang chủ</span>
            </button>
            <span className="text-gray-300">/</span>
            <span className="text-gray-900 font-semibold">Cây để bàn</span>
          </nav>

          <div className="hidden sm:flex items-center gap-2 text-[#b02d29] font-medium">
            <span className="material-symbols-outlined text-[16px]">local_florist</span>
            <span>Cam kết bù mới 100% nếu dập gãy khi vận chuyển</span>
          </div>
        </div>
      </section>

      {/* 2. Collection Hero Banner */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 w-full my-6">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#e4e2df] via-[#efeeeb] to-[#f5f3f0] shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center gap-6 p-6 sm:p-10 lg:p-12 relative z-10">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 bg-white px-3.5 py-1 rounded-full shadow-xs text-[#b02d29] font-label-category uppercase tracking-wider text-[11px] font-bold">
                <span className="material-symbols-outlined text-[14px]">eco</span>
                <span>Bộ sưu tập để bàn 2025</span>
              </div>

              <h1 className="font-headline-xl text-3xl sm:text-4xl text-gray-900 leading-tight">
                Cây Để Bàn Thanh Lọc Không Khí &amp; Phong Thủy
              </h1>

              <p className="font-body-lead text-gray-600 max-w-xl text-sm sm:text-base leading-relaxed">
                Điểm tô góc làm việc và học tập tràn ngập năng lượng tích cực, hút bức xạ điện tử và mang lại sự an yên mỗi ngày.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-medium">
                <span className="inline-flex items-center gap-1.5 bg-white/90 px-3 py-1.5 rounded-lg text-gray-800 shadow-2xs">
                  <span className="material-symbols-outlined text-[#b02d29] text-[18px]">workspace_premium</span>
                  <span>Dễ sống trong nhà</span>
                </span>
                <span className="inline-flex items-center gap-1.5 bg-white/90 px-3 py-1.5 rounded-lg text-gray-800 shadow-2xs">
                  <span className="material-symbols-outlined text-[#b02d29] text-[18px]">nest_heat_link_gen_3</span>
                  <span>Lọc bụi mịn 2.5PM</span>
                </span>
                <span className="inline-flex items-center gap-1.5 bg-white/90 px-3 py-1.5 rounded-lg text-gray-800 shadow-2xs">
                  <span className="material-symbols-outlined text-[#b02d29] text-[18px]">redeem</span>
                  <span>Tặng kèm sỏi dinh dưỡng</span>
                </span>
              </div>
            </div>

            <div className="lg:col-span-5 relative flex justify-center items-center">
              <div className="w-full aspect-[4/3] rounded-2xl overflow-hidden shadow-md relative">
                <img
                  className="w-full h-full object-cover"
                  data-alt="Desk plants"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0VuNGIwLLKjSkUum9m3dfcJ0AxHurRMenn_OEMNTMB0g4z2jaDWJjn-lnXd9izQlJAZY9w4kHiYNp4pN3buoDYioNqobvCrwvhBr4zPjQcz2OLfYcYXchb216_QOLyKFMqFhFuYG99yms2y9RpEryamvkr4p3ozoiIAUDu6J3JB3zbHR837FTjJKVuNPJaC-FRuV_PJ_0U49Pq0rxylAmBdOo27nbPJWtaj0ozPnEXA56JzwFhKxE"
                  alt="Bộ sưu tập cây để bàn"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3 rounded-xl flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#b02d29] text-[20px]">air</span>
                    <span className="text-xs sm:text-[13px] font-semibold text-gray-900">
                      Giảm 80% bức xạ từ màn hình máy tính
                    </span>
                  </div>
                  <span className="text-xs text-[#b02d29] font-bold">Tìm hiểu →</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Quick Feature Strip */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 w-full mb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white p-5 rounded-2xl shadow-xs border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 text-[#234729]">
              <span className="material-symbols-outlined text-[20px]">local_shipping</span>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-900">Giao hỏa tốc 2H</h4>
              <p className="text-[11px] text-gray-500">Áp dụng nội thành Hà Nội &amp; TP.HCM</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 text-[#b02d29]">
              <span className="material-symbols-outlined text-[20px]">health_and_safety</span>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-900">Bảo hành 30 ngày</h4>
              <p className="text-[11px] text-gray-500">Đổi cây miễn phí nếu héo úa</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 text-[#234729]">
              <span className="material-symbols-outlined text-[20px]">support_agent</span>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-900">Bác sĩ cây xanh</h4>
              <p className="text-[11px] text-gray-500">Tư vấn bệnh cây trọn đời</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#f5f3f0] flex items-center justify-center shrink-0 text-[#b02d29]">
              <span className="material-symbols-outlined text-[20px]">package_2</span>
            </div>
            <div>
              <h4 className="text-xs font-bold text-gray-900">Đóng gói an toàn</h4>
              <p className="text-[11px] text-gray-500">Hộp xốp định hình kháng sốc</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Main Catalog Area: Sidebar + Products */}
      <section className="max-w-7xl mx-auto px-6 lg:px-12 w-full mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* SIDEBAR FILTERS (3 Cols) */}
          <aside className="lg:col-span-3 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-xs border border-gray-100 space-y-6">
              {/* Filter Header */}
              <div className="flex items-center justify-between pb-3 bg-[#fbf7ee] p-2.5 rounded-xl">
                <span className="text-sm font-bold text-gray-900 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[18px]">tune</span>
                  <span>Bộ lọc nâng cao</span>
                </span>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-xs text-[#b02d29] hover:underline cursor-pointer font-medium"
                >
                  Xóa tất cả
                </button>
              </div>

              {/* Price Filter */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                    Mức giá (VNĐ)
                  </h3>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
                </div>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedPrices.includes('under-100')}
                        onChange={() => handlePriceToggle('under-100')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>Dưới 100.000đ</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(8)</span>
                  </label>

                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedPrices.includes('100-250')}
                        onChange={() => handlePriceToggle('100-250')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>100.000đ - 250.000đ</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(14)</span>
                  </label>

                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedPrices.includes('over-250')}
                        onChange={() => handlePriceToggle('over-250')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>Trên 250.000đ</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(2)</span>
                  </label>
                </div>
              </div>

              {/* Light Requirements */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                    Nhu cầu ánh sáng
                  </h3>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
                </div>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedLights.includes('shade')}
                        onChange={() => handleLightToggle('shade')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>Ưa bóng râm (Đèn bàn)</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(9)</span>
                  </label>

                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedLights.includes('partial')}
                        onChange={() => handleLightToggle('partial')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>Bán râm (Cạnh cửa sổ)</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(11)</span>
                  </label>

                  <label className="flex items-center justify-between hover:text-gray-900 cursor-pointer group">
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={selectedLights.includes('full')}
                        onChange={() => handleLightToggle('full')}
                        className="w-4 h-4 rounded text-[#234729] accent-[#234729] cursor-pointer"
                      />
                      <span>Cần nhiều sáng</span>
                    </span>
                    <span className="text-gray-400 group-hover:text-gray-900">(4)</span>
                  </label>
                </div>
              </div>

              {/* Feng Shui Meaning */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                    Ý nghĩa phong thủy
                  </h3>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-700">
                  {['Tài lộc', 'May mắn', 'Bình an', 'Trừ tà khí'].map((fs) => (
                    <label
                      key={fs}
                      className="flex items-center gap-2 bg-[#f5f3f0] px-2.5 py-1.5 rounded-lg cursor-pointer hover:bg-[#eae8e5] transition-colors"
                    >
                      <input
                        type="checkbox"
                        checked={selectedFengShui.includes(fs)}
                        onChange={() => handleFengShuiToggle(fs)}
                        className="accent-[#b02d29] w-3.5 h-3.5"
                      />
                      <span>{fs}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Ease of Care */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
                    Độ dễ chăm sóc
                  </h3>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
                </div>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="radio"
                      name="care"
                      checked={careDifficulty === 'easy'}
                      onChange={() => setCareDifficulty('easy')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span>Dành cho người mới (Ít tưới)</span>
                  </label>
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="radio"
                      name="care"
                      checked={careDifficulty === 'careful'}
                      onChange={() => setCareDifficulty('careful')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span>Cần chăm sóc kỹ lưỡng</span>
                  </label>
                </div>
              </div>

              {/* Applied Filters Tags */}
              <div className="pt-3 bg-[#f5f3f0] p-3 rounded-xl space-y-1.5">
                <p className="text-[11px] text-gray-500 font-medium">Đang lọc theo:</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedPrices.includes('100-250') && (
                    <span className="inline-flex items-center gap-1 bg-white px-2 py-0.5 rounded text-[11px] font-medium text-gray-800 shadow-2xs">
                      100k - 250k
                      <button
                        onClick={() => handlePriceToggle('100-250')}
                        className="hover:text-[#b02d29] cursor-pointer"
                      >
                        ×
                      </button>
                    </span>
                  )}
                  {selectedLights.includes('shade') && (
                    <span className="inline-flex items-center gap-1 bg-white px-2 py-0.5 rounded text-[11px] font-medium text-gray-800 shadow-2xs">
                      Ưa bóng râm
                      <button
                        onClick={() => handleLightToggle('shade')}
                        className="hover:text-[#b02d29] cursor-pointer"
                      >
                        ×
                      </button>
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Care Tips Widget in Sidebar */}
            <div className="bg-gradient-to-br from-[#eae8e5] to-[#efeeeb] p-5 rounded-2xl shadow-xs space-y-2.5 border border-[#e4e2df]">
              <div className="flex items-center gap-2 text-[#b02d29]">
                <span className="material-symbols-outlined text-[20px]">psychology_alt</span>
                <span className="text-xs font-bold uppercase tracking-wide">Mẹo chọn cây bàn làm việc</span>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">
                Hãy chọn các dòng cây bản dày mọng nước hoặc trầu bà, lưỡi hổ nếu bạn thường xuyên ngồi phòng điều hòa từ 8-10 tiếng mỗi ngày.
              </p>
              <button
                type="button"
                onClick={() => {
                  const guideElem = document.getElementById('desk-care-guide');
                  guideElem?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-1 text-xs font-bold text-gray-900 hover:text-[#b02d29] transition-colors cursor-pointer"
              >
                <span>Đọc sổ tay chăm sóc</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
          </aside>

          {/* MAIN PRODUCT GRID (9 Cols) */}
          <div className="lg:col-span-9 space-y-6">
            {/* Sort & Control Bar */}
            <div className="bg-white p-4 rounded-2xl shadow-xs border border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-700">
                <span className="font-bold text-gray-900">{filteredProducts.length} sản phẩm</span>
                <span className="text-gray-400">trong danh mục Cây Để Bàn</span>
              </div>

              <div className="flex items-center gap-3">
                <label htmlFor="desk-sort" className="text-xs text-gray-500 whitespace-nowrap">
                  Sắp xếp:
                </label>
                <div className="relative inline-block w-44">
                  <select
                    id="desk-sort"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value)}
                    className="w-full bg-[#f5f3f0] text-gray-900 text-xs px-3 py-2 pr-8 rounded-lg appearance-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#234729]"
                  >
                    <option value="best-seller">Bán chạy</option>
                    <option value="price-asc">Giá tăng dần</option>
                    <option value="price-desc">Giá giảm dần</option>
                    <option value="rating">Đánh giá cao</option>
                  </select>
                  <span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none text-[16px]">
                    unfold_more
                  </span>
                </div>
              </div>
            </div>

            {/* PRODUCT GRID (8 Products matching exact prompt) */}
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredProducts.map((prod) => {
                const isWishlisted = wishlistIds.has(prod.id);
                return (
                  <article
                    key={prod.id}
                    className="group bg-white rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-shadow border border-gray-100 flex flex-col justify-between relative"
                  >
                    <div className="relative w-full aspect-square bg-[#f5f3f0] overflow-hidden">
                      {prod.badge && (
                        <span className="absolute top-2.5 left-2.5 z-10 bg-[#b02d29] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shadow-xs">
                          {prod.badge}
                        </span>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(prod);
                        }}
                        aria-label="Yêu thích"
                        className={`absolute top-2.5 right-2.5 z-10 w-7 h-7 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center transition-colors cursor-pointer ${
                          isWishlisted ? 'text-[#b02d29]' : 'text-gray-500 hover:text-[#b02d29]'
                        }`}
                      >
                        <span
                          className={`material-symbols-outlined text-[17px] ${
                            isWishlisted ? 'material-symbols-fill' : ''
                          }`}
                        >
                          favorite
                        </span>
                      </button>

                      <img
                        src={prod.image}
                        alt={prod.name}
                        onClick={() => onSelectProduct(prod)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                      />
                    </div>

                    <div className="p-3.5 flex flex-col flex-1 justify-between gap-3">
                      <div
                        onClick={() => onSelectProduct(prod)}
                        className="space-y-1 cursor-pointer"
                      >
                        <h3 className="font-headline-sm text-sm sm:text-[15px] font-bold text-gray-900 group-hover:text-[#b02d29] transition-colors line-clamp-1">
                          {prod.name}
                        </h3>
                        <div className="flex items-center gap-1.5 text-xs text-gray-500">
                          <span className="material-symbols-outlined text-amber-500 text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                            star
                          </span>
                          <span className="font-bold text-gray-800">{prod.rating}</span>
                          <span className="text-gray-400">({prod.reviewsCount})</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="text-base sm:text-lg font-bold text-[#b02d29]">
                          {prod.price.toLocaleString('vi-VN')}₫
                        </div>
                        <button
                          type="button"
                          onClick={() => onAddToCart(prod)}
                          style={{ backgroundColor: '#234e32' }}
                          className="w-full text-white text-[12px] font-bold uppercase py-2 rounded-lg flex items-center justify-center gap-1.5 transition-colors hover:opacity-90 cursor-pointer shadow-xs"
                        >
                          <span className="material-symbols-outlined text-[16px]">shopping_cart</span>
                          <span>Thêm vào giỏ</span>
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>

            {/* Pagination */}
            <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl shadow-xs border border-gray-100">
              <p className="text-xs text-gray-500">
                Hiển thị <strong className="text-gray-900">1 - {filteredProducts.length}</strong> trong tổng số <strong className="text-gray-900">24</strong> cây để bàn
              </p>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#f5f3f0] text-gray-400 hover:text-gray-900 hover:bg-[#eae8e5] transition-colors disabled:opacity-40 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">chevron_left</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(1)}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold cursor-pointer ${
                    currentPage === 1
                      ? 'bg-[#234729] text-white'
                      : 'bg-[#f5f3f0] text-gray-800 hover:bg-[#eae8e5]'
                  }`}
                >
                  1
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(2)}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold cursor-pointer ${
                    currentPage === 2
                      ? 'bg-[#234729] text-white'
                      : 'bg-[#f5f3f0] text-gray-800 hover:bg-[#eae8e5]'
                  }`}
                >
                  2
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(3)}
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold cursor-pointer ${
                    currentPage === 3
                      ? 'bg-[#234729] text-white'
                      : 'bg-[#f5f3f0] text-gray-800 hover:bg-[#eae8e5]'
                  }`}
                >
                  3
                </button>
                <button
                  type="button"
                  disabled={currentPage === 3}
                  onClick={() => setCurrentPage(3)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center bg-[#f5f3f0] text-gray-800 hover:bg-[#eae8e5] transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Editorial Guide: Chăm Sóc Cây Văn Phòng */}
      <section id="desk-care-guide" className="max-w-7xl mx-auto px-6 lg:px-12 w-full mb-12">
        <div className="bg-[#efeeeb] p-8 lg:p-10 rounded-2xl space-y-6 border border-[#e4e2df]">
          <div className="max-w-3xl space-y-2">
            <span className="font-label-category uppercase tracking-wider text-[#b02d29] font-bold text-xs">
              Cẩm nang Vườn Xanh
            </span>
            <h2 className="font-headline-lg text-2xl sm:text-3xl text-gray-900">
              Lưu ý vàng để chậu cây để bàn luôn xanh tốt
            </h2>
            <p className="font-body-md text-gray-600 text-sm sm:text-base leading-relaxed">
              Cây xanh để bàn làm việc tiếp xúc nhiều với máy lạnh và ánh sáng nhân tạo. Dưới đây là 3 nguyên tắc chăm sóc đơn giản từ chuyên gia cây cảnh sinh thái:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="bg-white p-5 rounded-xl space-y-2 shadow-xs border border-gray-100">
              <div className="flex items-center gap-2 text-[#b02d29] font-bold text-base">
                <span className="material-symbols-outlined">water_drop</span>
                <span>Tưới đúng nguyên tắc</span>
              </div>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Chỉ tưới khi mặt đất se khô từ 2-3 cm. Mỗi lần tưới khoảng 50-80ml, không tưới quá đẫm gây úng rễ trong phòng kín.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl space-y-2 shadow-xs border border-gray-100">
              <div className="flex items-center gap-2 text-[#b02d29] font-bold text-base">
                <span className="material-symbols-outlined">light_mode</span>
                <span>Phơi nắng sớm</span>
              </div>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Cho cây tắm nắng dịu buổi sáng khoảng 1-2 tiếng mỗi tuần (trước 9h sáng) để cây tổng hợp chất diệp lục và giữ màu tươi sáng.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl space-y-2 shadow-xs border border-gray-100">
              <div className="flex items-center gap-2 text-[#b02d29] font-bold text-base">
                <span className="material-symbols-outlined">cleaning_services</span>
                <span>Vệ sinh mặt lá</span>
              </div>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Dùng khăn mềm ẩm lau sạch bụi bám trên tán lá định kỳ 10 ngày/lần để tăng tối đa hiệu suất thanh lọc không khí và hút bức xạ.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
