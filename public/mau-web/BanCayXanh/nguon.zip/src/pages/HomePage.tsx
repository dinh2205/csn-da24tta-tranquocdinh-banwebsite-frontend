import React, { useState, useEffect } from 'react';
import { PageTab, Product } from '../types';
import { deskPlantsList, cactusList, succulentsList, blogArticles, testimonials } from '../data/mockData';

interface HomePageProps {
  onNavigate: (tab: PageTab) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
  onSelectProduct: (product: Product) => void;
  onOpenArticle: (articleId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onSelectProduct,
  onOpenArticle,
}) => {
  const [activeTab, setActiveTab] = useState<'best' | 'new' | 'sale'>('best');
  const [timeLeft, setTimeLeft] = useState({ hours: 5, minutes: 12, seconds: 36 });

  // Countdown timer simulation for Flash Sale
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 5, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Products for the 6-product grid
  const featuredProducts: Product[] = [
    deskPlantsList[0], // Monstera mini
    deskPlantsList[1], // Trầu bà xanh
    succulentsList[6], // Sen đá mix
    cactusList[0],     // Xương rồng tròn
    deskPlantsList[3], // Lưỡi hổ để bàn
    deskPlantsList[4], // Kim tiền mini
  ];

  return (
    <div className="w-full font-sans">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-6">
        {/* 1. HeroSection: 2 Banners */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Main Hero Banner (Col 9) */}
          <div className="lg:col-span-9 relative rounded-2xl overflow-hidden shadow-sm bg-gradient-to-r from-emerald-50 to-stone-100 min-h-[320px] flex items-center">
            <img
              alt="Không gian sống xanh ngập tràn ánh sáng"
              className="absolute inset-0 w-full h-full object-cover object-center"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDkg5D1G_Waoe29d6ytiFTYqbHghIut-5EzVgrXEVZ4W0SX4_JJPIl2SJILCqASPWJ_015K3oCxYj533p4rvT2E1RNBb5H8h_p02_26jfk7xgwr2ANigGDMTumEKzwPwmEiHx6EfJ81Ru2wI-VlR4Flmsv7uRfHpf7FGCa8fxxtyONfSy3KMpQpnv_Foop7TqPEh958ifKA7EuHNJCE8AuNQH18v3kbGlqCLuSUMgvTydGaAfQaM7bR"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/75 to-transparent/10" />

            <div className="relative z-10 pl-6 sm:pl-10 pr-4 py-8 max-w-[500px]">
              <h2
                className="text-3xl sm:text-4xl font-bold text-gray-900 leading-tight"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                Mang thiên nhiên<br />
                vào không gian sống
              </h2>
              <p className="text-gray-600 text-xs sm:text-sm mt-3 font-normal leading-relaxed">
                Những chậu cây nhỏ, thay đổi lớn<br />
                cho một cuộc sống xanh và hạnh phúc hơn!
              </p>
              <div className="flex items-center gap-3 mt-6">
                <button
                  onClick={() => onNavigate('cay-de-ban')}
                  className="bg-[#F07A2B] hover:bg-[#de6e22] text-white px-5 py-2.5 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2 transition shadow-sm cursor-pointer"
                >
                  <span>Mua ngay</span>
                  <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
                </button>
                <button
                  onClick={() => onNavigate('cay-noi-that')}
                  className="bg-white/85 hover:bg-white text-gray-800 border border-gray-300 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-medium transition backdrop-blur-sm cursor-pointer"
                >
                  Khám phá bộ sưu tập
                </button>
              </div>

              {/* Carousel Dots */}
              <div className="flex items-center gap-1.5 mt-6">
                <span className="w-2.5 h-2.5 rounded-full bg-[#2E5B37]" />
                <span className="w-2 h-2 rounded-full bg-gray-400 opacity-60" />
                <span className="w-2 h-2 rounded-full bg-gray-400 opacity-60" />
                <span className="w-2 h-2 rounded-full bg-gray-400 opacity-60" />
              </div>
            </div>

            {/* Handwritten badge */}
            <div className="absolute right-8 top-8 hidden xl:block text-right pointer-events-none">
              <div
                className="text-[#2E5B37] text-2xl font-bold rotate-[-4deg] drop-shadow-xs"
                style={{ fontFamily: "'Dancing Script', cursive" }}
              >
                “Cây xanh<br />
                là liều thuốc<br />
                cho tâm hồn ♡”
              </div>
            </div>
          </div>

          {/* Secondary Promo Banner (Col 3) */}
          <div className="lg:col-span-3 bg-[#EFE9DD] rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden shadow-xs border border-[#E3DCCE]">
            <div className="relative z-10">
              <span className="text-[11px] font-bold tracking-widest text-[#2E5B37] uppercase block mb-1">
                Ưu đãi đặc biệt
              </span>
              <p className="text-xs font-medium text-gray-700">Giảm đến</p>
              <div className="text-4xl font-black text-[#E8502A] tracking-tight my-0.5">30%</div>
              <p className="text-xs text-gray-600 font-medium">Cho các mẫu chậu decor</p>
              <button
                onClick={() => onNavigate('cay-de-ban')}
                className="inline-flex items-center gap-1.5 mt-3.5 bg-[#2E5B37] hover:bg-[#23462a] text-white text-[12px] font-semibold px-3.5 py-1.5 rounded-full transition cursor-pointer"
              >
                <span>Xem ngay</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
            <div className="mt-3 flex justify-end">
              <img
                alt="Chậu cây decor ưu đãi"
                className="w-28 h-32 object-contain drop-shadow-md rounded-lg"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBUNG77dxmB-EzFu26sTsj5VzlCkVu35ix0mzbPBHKBjlRLXHjkYWynCSAIgURtglZk7Zndzp_hBtVAmkm2wtlKIx4wsvrX9_HoXF2uTs9vw9IBxeYWZ-qNDUiAM7XPhLGpx75Ie14NiP_zjacTN5_5fnrvvrCNj10mN5-EGWbIqdnG5c_TKCXAFttSIerLZehBHEenJXO76taBhCs5ezSUZzWBM-Gc64nUdlZ9e6detT48P3GFhl3F"
              />
            </div>
          </div>
        </section>

        {/* 2. Value Propositions Bar */}
        <section className="bg-[#F7F3EC] rounded-xl py-3 px-6 grid grid-cols-2 md:grid-cols-4 gap-4 border border-[#EBE3D3]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-[#2E5B37] flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[20px]">local_shipping</span>
            </div>
            <div>
              <h4 className="text-[12px] font-bold text-gray-800 leading-snug">Giao hàng toàn quốc</h4>
              <p className="text-[10px] text-gray-500">Nhanh chóng - An toàn</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-[#2E5B37] flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[20px]">eco</span>
            </div>
            <div>
              <h4 className="text-[12px] font-bold text-gray-800 leading-snug">Cây khỏe mạnh</h4>
              <p className="text-[10px] text-gray-500">Được tuyển chọn kỹ lưỡng</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-[#2E5B37] flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[20px]">support_agent</span>
            </div>
            <div>
              <h4 className="text-[12px] font-bold text-gray-800 leading-snug">Tư vấn chăm sóc</h4>
              <p className="text-[10px] text-gray-500">Đồng hành cùng bạn</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-100/70 text-[#2E5B37] flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[20px]">assignment_return</span>
            </div>
            <div>
              <h4 className="text-[12px] font-bold text-gray-800 leading-snug">Đổi trả dễ dàng</h4>
              <p className="text-[10px] text-gray-500">Trong 7 ngày</p>
            </div>
          </div>
        </section>

        {/* 3. Categories and Promo Stack */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left: 7 Featured Categories (Col 8) */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wide">
                Danh mục nổi bật
              </h3>
              <button
                onClick={() => onNavigate('cay-de-ban')}
                className="text-[11px] font-medium text-gray-600 hover:text-[#2E5B37] flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2.5">
              {[
                {
                  tab: 'cay-de-ban' as PageTab,
                  label: 'Cây để bàn',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuBoVeYmIUB9-fTblOyplKPOYYi4wJ-hWmw2eeOHdfU4IOLe3PnOOk43gh1vBmk61XSsei8mla9zOj4N5dZIeG1dy23h9cILtzWV2MbiZkVqaUscNkdDyqFF-HRkITpthE6B2ANSqLmKeX-IXv4SAjc6Q0RRT3_J-m_fQHW6lbiDp6ImK9oo7jhoSHgg5KAGqeZmt2DvYWPdkG56yci46VzTI-mzw38_ugmdAzeD0ZGsZtwVCx_O7maT',
                },
                {
                  tab: 'cay-noi-that' as PageTab,
                  label: 'Cây phong thủy',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuAqq3eYgDibDMsrK-nqQAHbiPlmKzJ-SnYyaL3UBem0iw4StS_XVmi_1DjzrZM9C3BKPfno4-y2oY-F8PuxI52nFeEA1PBm5uZlsFktrMRnaJZri-mxDrfer8xHAPSr-w8WjcIbKB1CkQ6ls7YaiirsbnRGNxtTVhU9jgc6LFxfGkojIqePpN6p7PDHsfwXz2J6TBXMV9tUO2Ec2Fz1dKFC2XK6pSrRZozy_S6t5yMGT_vA340-dy3K',
                },
                {
                  tab: 'sen-da' as PageTab,
                  label: 'Sen đá',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuCknD90f8zY4agscISYoaOi7NmwXerclCZ22ENAxUTumsxZOxaySEY8mMIXXr3xfEpzm8WN8NTQCdKil6SFHFMF8S-XJgdT8XdZW1s1Z-ao5FEZgwAt_f9KUxP_oto4nRZ2bdxMn70lqbqoqHiuKBBRxsD3XPki42aSf8wHXZXC4sT601td8CiLULFHACE7dEs5yb6qX89WdN46br_v3Y2tB32kfeUgoBuuBwEHm64wPuNktrCPtVFu',
                },
                {
                  tab: 'xuong-rong' as PageTab,
                  label: 'Xương rồng',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuDgTk9yZy-bzf00cbz5LjSHTIA09FI2axdrulJWgOeJ0bOyhro9fK6Qm9nqICSwD1avENQj-vzM4MaC9uCLzrXlsfAdBs7e2H92xE8iqjfkvZYyE_ee5FyeLujfFQ3WIMrgxcX3b06t5a0cnKaHVB58RT9Qci18Hj2CcLqjsZjC5c4pY7qcsA2iQ74sTYphsB6BGNttGV6Rq9Nau13LSEowzRmXoswj1gjp6x0UBuELj091_bKY3F_G',
                },
                {
                  tab: 'cay-noi-that' as PageTab,
                  label: 'Cây treo',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuBWThrRz9obKqfzZoYZZTt7u9RKUkHHjh-qCxAZuVAUczwQYNRZp0e7E7A1hjkGF7icIeA4gC9F5rC6TWjsxb39PxC0izRo74ox8h1Mq6yBH58qqWWlQ4SU-WmNUesqRsY2YGtQCB7BBfolMlhyUZXtaVSmR7ZLahlGfXmZ8uo2Erk7_bs9pnRh5lofTG-TIoB7kjABW0Gy_2n8XQ4HPPFL_J9zc4aFqyHCn7KAX8FQl8022on_1zzx',
                },
                {
                  tab: 'cay-de-ban' as PageTab,
                  label: 'Chậu decor',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuCccBasIrf9y8FzW8NzBqJO7CgRNv941sHwejjPSl8VNX67Rf0KQ-xp30qkdygk0UuX-bADUdrsJrm8ncHTgnQVxOB3MZY7LTtk8NvJ-z5Dp7pzOLCNifaj5I5GR5QLNDYisIc5LO7rot-TL749_q80dmp_m9hEM-Upia8s7vAt4Hfzr14GNTzq2uY3VoNBXY4ZqLDcsB_0nYAflqnsqA5z2lR0l2r46tan1LoP7djuDsu1Ep6dwdO9',
                },
                {
                  tab: 'gio-hang' as PageTab,
                  label: 'Phụ kiện',
                  image:
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuCx1q59oroBf__BNUsI-CGiVq5k16StHBM64xgwu9SW3e4M40zLjHbmPKGp4MqPviXm52ywKbD2OsOlifuTFwmP2ktPn0oDUninuqeTh9hpDzMHNsEnVut6cmj_wDqGqZmw0rxRvm1loGAzFNBeUz1WS22O_2H8btgrg3mNRq4L1VOo3snIcDAKHWmNNTnjmmCsdV_MYXbVt6PjrvDn7nd3XpH1he7x-nFEll-fJQ6VL_AdLHKzaloZ',
                },
              ].map((cat, idx) => (
                <button
                  key={idx}
                  onClick={() => onNavigate(cat.tab)}
                  className="bg-[#F6F4EF] hover:bg-[#eae6dd] rounded-xl p-2.5 text-center flex flex-col items-center hover:shadow-xs transition cursor-pointer group border border-transparent hover:border-[#ded8cc]"
                >
                  <div className="w-14 h-14 rounded-lg overflow-hidden mb-1.5 shadow-xs">
                    <img
                      alt={cat.label}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      src={cat.image}
                    />
                  </div>
                  <span className="text-[11px] font-semibold text-gray-800 leading-tight">
                    {cat.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Right: Combo Quà Tặng & Flash Sale (Col 4) */}
          <div className="lg:col-span-4 flex flex-col gap-2.5">
            {/* Gift Combo Banner */}
            <div
              onClick={() => onNavigate('xuong-rong')}
              className="bg-[#F6E9DD] hover:bg-[#eddcca] transition rounded-xl p-3 flex items-center justify-between border border-[#ebd8c8] cursor-pointer shadow-xs"
            >
              <div className="pl-2">
                <span className="text-[10px] font-bold text-[#F07A2B] uppercase tracking-wider block">
                  Combo quà tặng
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-gray-800 mt-0.5 leading-snug">
                  Trao cây xanh<br />
                  Gửi yêu thương
                </h4>
              </div>
              <img
                alt="Combo Quà Tặng"
                className="w-28 h-14 object-cover rounded-lg shadow-xs"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCCAFzgP0f1EN44LCXWKYQTtqcLmV3kQJvUZQhIFOWHVjLx0JPxJ7HrfyeDnil6Aa-7-HJ3sBXq0jv3Zmy-0brka8s5x-6GBRDsyyFphVYRqqjAHF5b5pNcUdDwPK-zQv9He54175EEa1OK8BKjLw0ctSp1_pcU7novX636maabehuIUgDN_eCN5tW-X0R7mYf4yTUxlApHrTttXig0DLv0lwWIMUAjDPGNyDLLvA7JhzLH3pn-rEUG"
              />
            </div>

            {/* Flash Sale Banner */}
            <div className="bg-[#2E5B37] rounded-xl px-4 py-2.5 text-white flex items-center justify-between shadow-sm">
              <div>
                <span className="text-xs font-black uppercase tracking-wider block leading-tight">
                  FLASH SALE
                </span>
                <span className="text-[10px] text-emerald-100 font-normal">Cây xinh giá tốt</span>
              </div>

              {/* Countdown Digits */}
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold">
                <span className="bg-[#1D3B23] px-1.5 py-0.5 rounded text-white">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-[#1D3B23] px-1.5 py-0.5 rounded text-white">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-[#1D3B23] px-1.5 py-0.5 rounded text-white">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onNavigate('cay-de-ban')}
                className="bg-[#F07A2B] hover:bg-[#de6e22] text-white text-[11px] font-semibold px-3 py-1 rounded-full flex items-center gap-1 transition cursor-pointer"
              >
                <span>Săn ngay</span>
                <span className="material-symbols-outlined text-[12px]">arrow_forward</span>
              </button>
            </div>
          </div>
        </section>

        {/* 4. Products and Inspirations Section */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left: 6 Featured Products (Col 8) */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-3 border-b border-gray-100 pb-2">
              <div className="flex items-center gap-5">
                <h3 className="text-sm font-bold text-gray-900">Sản phẩm nổi bật</h3>
                <div className="flex items-center gap-3 text-[11px] font-medium text-gray-500">
                  <button
                    onClick={() => setActiveTab('best')}
                    className={`pb-1 transition cursor-pointer ${
                      activeTab === 'best'
                        ? 'text-[#2E5B37] font-bold border-b-2 border-[#2E5B37]'
                        : 'hover:text-gray-800'
                    }`}
                  >
                    Bán chạy
                  </button>
                  <button
                    onClick={() => setActiveTab('new')}
                    className={`pb-1 transition cursor-pointer ${
                      activeTab === 'new'
                        ? 'text-[#2E5B37] font-bold border-b-2 border-[#2E5B37]'
                        : 'hover:text-gray-800'
                    }`}
                  >
                    Mới về
                  </button>
                  <button
                    onClick={() => setActiveTab('sale')}
                    className={`pb-1 transition cursor-pointer ${
                      activeTab === 'sale'
                        ? 'text-[#2E5B37] font-bold border-b-2 border-[#2E5B37]'
                        : 'hover:text-gray-800'
                    }`}
                  >
                    Ưu đãi
                  </button>
                </div>
              </div>
              <button
                onClick={() => onNavigate('cay-de-ban')}
                className="text-[11px] font-medium text-gray-600 hover:text-[#2E5B37] flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
              </button>
            </div>

            {/* 6 Products Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
              {featuredProducts.map((prod) => {
                const isWishlisted = wishlistIds.has(prod.id);
                return (
                  <div
                    key={prod.id}
                    className="bg-white rounded-xl p-2.5 border border-gray-100 hover:shadow-md transition flex flex-col justify-between group"
                  >
                    <div className="relative w-full aspect-square bg-[#F7F6F2] rounded-lg overflow-hidden mb-1.5">
                      <img
                        alt={prod.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        src={prod.image}
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(prod);
                        }}
                        className={`absolute top-1 right-1 w-6 h-6 rounded-full bg-white/85 flex items-center justify-center text-xs transition cursor-pointer ${
                          isWishlisted ? 'text-[#b02d29]' : 'text-gray-400 hover:text-[#b02d29]'
                        }`}
                        title="Yêu thích"
                      >
                        <span
                          className={`material-symbols-outlined text-[15px] ${
                            isWishlisted ? 'material-symbols-fill' : ''
                          }`}
                        >
                          favorite
                        </span>
                      </button>
                    </div>

                    <div
                      onClick={() => onSelectProduct(prod)}
                      className="cursor-pointer"
                    >
                      <h4 className="text-[11px] font-semibold text-gray-800 truncate group-hover:text-[#2E5B37] transition">
                        {prod.name}
                      </h4>
                      <div className="flex items-center text-[9px] text-gray-500 gap-1 my-0.5">
                        <span className="text-amber-500">★</span>
                        <span className="font-bold text-gray-700">{prod.rating}</span>
                        <span>({prod.reviewsCount})</span>
                      </div>
                      <div className="text-[12px] font-bold text-[#b02d29] mb-1.5">
                        {prod.price.toLocaleString('vi-VN')}đ
                      </div>
                    </div>

                    <button
                      onClick={() => onAddToCart(prod)}
                      className="w-full bg-[#2E5B37] hover:bg-[#22452a] text-white text-[10px] font-medium py-1.5 rounded flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[13px]">shopping_cart</span>
                      <span>Thêm giỏ</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Green Space Inspirations (Col 4) */}
          <div className="lg:col-span-4">
            <div className="flex items-center justify-between mb-3 border-b border-gray-100 pb-2">
              <h3 className="text-sm font-bold text-gray-900">Gợi ý không gian xanh</h3>
              <button
                onClick={() => onNavigate('cay-noi-that')}
                className="text-[11px] font-medium text-gray-600 hover:text-[#2E5B37] flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
              </button>
            </div>

            {/* 2x2 Grid of Inspirations */}
            <div className="grid grid-cols-2 gap-2.5">
              <div
                onClick={() => onNavigate('cay-noi-that')}
                className="relative h-24 rounded-xl overflow-hidden group cursor-pointer shadow-xs"
              >
                <img
                  alt="Phòng khách"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBf3rgIsS4Qo8pr1PNuSLKfWLAPTP0TntwmnoCjhB6shOyIpGsMWgtL9DvQzAcUrG4ChQkVi3pPKxePXXDavcVdvXk1VXNsmpvtLc8fXDK1Q7td2i79m06OHTIgBvKzTi3GRn8fCu95IP2i4DhCfhlsVPyDlaaA8oHe-D37qTd_eJbyVxA9YnkjgxLB06Ma3DOHmina6BVfJNc_RlfRm1S4gksb2DIY3FcnLQyDM3e1R3AEFUuw-sB_"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2.5">
                  <span className="text-white text-[11px] font-bold leading-tight">Phòng khách</span>
                  <span className="text-[9px] text-gray-200">Sang trọng & gần gũi</span>
                </div>
              </div>

              <div
                onClick={() => onNavigate('cay-de-ban')}
                className="relative h-24 rounded-xl overflow-hidden group cursor-pointer shadow-xs"
              >
                <img
                  alt="Bàn làm việc"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDt8V02atHC93Iep3HLaojEdE0ZuF5_cda6OvS0h5SxzpxvxxdFBWU0Wl3FejsAQvlvzXuViyGZ2m3ckgPgovXMbGZ1UUatG0EMG3Gx-fZpAXLX6IBo4N8k2MKztl4-YnLcACnYLZQQgqeZFx9dBWk70VVV5Ykw6WlY7F6qLhcOqeTlCVeKHGgRvWWzUcrQ4NBkoFspGqgJC9JsVgwi-uVKEslTxoNKw4WDsE0gz7xGydRhVMVFS6CI"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2.5">
                  <span className="text-white text-[11px] font-bold leading-tight">Bàn làm việc</span>
                  <span className="text-[9px] text-gray-200">Thêm năng lượng tích cực</span>
                </div>
              </div>

              <div
                onClick={() => onNavigate('sen-da')}
                className="relative h-24 rounded-xl overflow-hidden group cursor-pointer shadow-xs"
              >
                <img
                  alt="Ban công"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBXG0Sw-8Egah2Z2ynqKu3M2-3xF211ncT_Nq8ScN04Bon6TJqndcBiDzVv9QdIP1qbxVc4xifa4EA6U2q9jP0KSnLwVHBylulpNJ1hiJ6FlwV4jqElfS0BHFy5jhOmYo2YTWzE2UHXaKS4mgh2oBvI0PgChh7WwsHyswvpM3-smaxCYPb5ROttM2Pp6BT8_ThFjk3Gbt6fXnskSxsMA4VgRAMo9bT0TTOPcpMseN-VQaiW0L4CRT1M"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2.5">
                  <span className="text-white text-[11px] font-bold leading-tight">Ban công</span>
                  <span className="text-[9px] text-gray-200">Góc nhỏ, niềm vui lớn</span>
                </div>
              </div>

              <div
                onClick={() => onNavigate('cay-noi-that')}
                className="relative h-24 rounded-xl overflow-hidden group cursor-pointer shadow-xs"
              >
                <img
                  alt="Quán cà phê"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0JWiQMT61xepRLMBxYbgOaDXOEvIl-XYPG-zf958zmHN0BGhTpPYj52rUbf9FbUVPWNCRpZe-XtVVY5T1CE0-HvlnO1uGjmAO3fVF6F95rU_HVOj8VjBF9PYHpXI5r06bjkRsp95N4fd48smQS80p7X9NX5Huz-CiPK3diHbI8jOBu6IHs6r5mAnf2vrMeB1a3wy8w6GK0HTFWzVSB2OPsJLr4B1ozkyvBO4V5RXRvM0kU_Jlr-a0"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-2.5">
                  <span className="text-white text-[11px] font-bold leading-tight">Quán cà phê</span>
                  <span className="text-[9px] text-gray-200">Không gian xanh thu hút</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 5. Blog & Testimonials Section */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left: Blog (Col 7) */}
          <div className="lg:col-span-7">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-gray-900">Cẩm nang chăm cây</h3>
              <button
                onClick={() => onNavigate('cay-de-ban')}
                className="text-[11px] font-medium text-gray-600 hover:text-[#2E5B37] flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {blogArticles.map((art) => (
                <div
                  key={art.id}
                  onClick={() => onOpenArticle(art.id)}
                  className="flex items-center gap-3 group bg-white p-2.5 rounded-xl border border-gray-100 hover:border-emerald-200 hover:shadow-xs transition cursor-pointer"
                >
                  <img
                    alt={art.title}
                    className="w-16 h-14 object-cover rounded-lg shrink-0 shadow-xs"
                    src={art.image}
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[11px] font-semibold text-gray-800 group-hover:text-[#2E5B37] transition line-clamp-2 leading-snug">
                      {art.title}
                    </h4>
                    <span className="text-[9px] text-gray-400 mt-1 block">
                      {art.date}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Testimonials (Col 5) */}
          <div className="lg:col-span-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-gray-900">Khách hàng nói về Vườn Xanh</h3>
              <button
                onClick={() => onNavigate('tai-khoan')}
                className="text-[11px] font-medium text-gray-600 hover:text-[#2E5B37] flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[13px]">arrow_forward</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {testimonials.map((test) => (
                <div
                  key={test.id}
                  className="bg-white p-3 rounded-xl border border-gray-100 flex flex-col justify-between shadow-xs"
                >
                  <div>
                    <div className="flex items-center text-amber-500 text-[11px] mb-1.5">
                      {'★'.repeat(test.rating)}
                    </div>
                    <p className="text-[11px] text-gray-600 italic leading-relaxed line-clamp-3">
                      {test.content}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-gray-50">
                    <img
                      alt={test.name}
                      className="w-8 h-8 rounded-full object-cover shadow-xs"
                      src={test.avatar}
                    />
                    <div>
                      <h5 className="text-[11px] font-bold text-gray-800 leading-tight">
                        {test.name}
                      </h5>
                      <span className="text-[9px] text-gray-400">{test.location}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
