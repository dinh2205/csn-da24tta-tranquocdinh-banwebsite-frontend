import React, { useState, useMemo } from 'react';
import { PageTab, Product } from '../types';
import { interiorPlantsList } from '../data/mockData';

interface InteriorPlantsPageProps {
  onNavigate: (tab: PageTab) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
  onSelectProduct: (product: Product) => void;
  onOpenConsultation: () => void;
}

export const InteriorPlantsPage: React.FC<InteriorPlantsPageProps> = ({
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onSelectProduct,
  onOpenConsultation,
}) => {
  const [selectedSizes, setSelectedSizes] = useState<string[]>(['mid', 'large']);
  const [selectedPlaces, setSelectedPlaces] = useState<string[]>(['living', 'office']);
  const [selectedPriceTier, setSelectedPriceTier] = useState<string>('all');
  const [selectedPots, setSelectedPots] = useState<string[]>(['ceramic', 'composite']);
  const [sortOption, setSortOption] = useState<string>('popular');
  const [currentPage, setCurrentPage] = useState<number>(1);

  const handleSizeToggle = (val: string) => {
    setSelectedSizes((prev) =>
      prev.includes(val) ? prev.filter((s) => s !== val) : [...prev, val]
    );
  };

  const handlePlaceToggle = (val: string) => {
    setSelectedPlaces((prev) =>
      prev.includes(val) ? prev.filter((p) => p !== val) : [...prev, val]
    );
  };

  const handlePotToggle = (val: string) => {
    setSelectedPots((prev) =>
      prev.includes(val) ? prev.filter((p) => p !== val) : [...prev, val]
    );
  };

  const handleResetFilters = () => {
    setSelectedSizes(['mid', 'large', 'huge']);
    setSelectedPlaces(['living', 'bedroom', 'office', 'balcony']);
    setSelectedPriceTier('all');
    setSelectedPots(['ceramic', 'composite', 'cement']);
  };

  const filteredProducts = useMemo(() => {
    return interiorPlantsList.filter((prod) => {
      if (selectedPriceTier === 'under350' && prod.price >= 350000) return false;
      if (selectedPriceTier === '350-600' && (prod.price < 350000 || prod.price > 600000)) return false;
      if (selectedPriceTier === 'above600' && prod.price <= 600000) return false;
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-asc') return a.price - b.price;
      if (sortOption === 'price-desc') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      return b.reviewsCount - a.reviewsCount;
    });
  }, [selectedPriceTier, sortOption]);

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Breadcrumb Strip */}
      <section className="w-full bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-3 flex flex-wrap items-center justify-between gap-4">
          <nav className="flex items-center gap-2 font-label-meta text-xs text-gray-500">
            <button
              onClick={() => onNavigate('trang-chu')}
              className="hover:text-gray-900 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">home</span>
              <span>Trang chủ</span>
            </button>
            <span className="text-gray-300">/</span>
            <span className="font-semibold text-gray-900">Cây nội thất</span>
          </nav>

          <div className="flex items-center gap-6 text-xs text-gray-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#b02d29]"></span>
              <span>Hiện có <strong className="text-gray-800">28 mẫu cây lớn</strong> sẵn hàng</span>
            </span>
            <span className="hidden md:inline-flex items-center gap-1.5 text-[#234729]">
              <span className="material-symbols-outlined text-[16px]">eco</span>
              <span>Bảo hành dáng cây 30 ngày</span>
            </span>
          </div>
        </div>
      </section>

      {/* 2. Hero Section */}
      <section className="w-full bg-[#f5f3f0]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Text lead */}
            <div className="lg:col-span-7 space-y-5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-white rounded-full shadow-2xs">
                <span className="material-symbols-outlined text-[16px] text-[#b02d29]">spa</span>
                <span className="font-label-category uppercase tracking-wider text-[#b02d29] text-[11px] font-bold">
                  Bộ sưu tập cao cấp
                </span>
              </div>

              <h1 className="font-headline-xl text-3xl sm:text-4xl text-gray-900 leading-tight">
                Cây Nội Thất Kiến Tạo <br />
                <span className="italic font-normal text-[#b02d29]">Không Gian Xanh Sang Trọng</span>
              </h1>

              <p className="font-body-lead text-gray-600 max-w-2xl text-sm sm:text-base leading-relaxed">
                Tuyển chọn những dáng cây đại phát lộc như Bàng Singapore, Phát Tài Núi, Kim Tiền Đại — thanh lọc khí thở, nâng tầm kiến trúc căn hộ và biệt thự hiện đại.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <a
                  href="#danh-sach-noi-that"
                  className="px-6 py-3.5 bg-[#234729] text-white font-label-ui text-xs font-semibold rounded-xl hover:bg-[#1a3820] transition-colors inline-flex items-center gap-2 shadow-xs"
                >
                  <span>Khám phá danh mục</span>
                  <span className="material-symbols-outlined text-[18px]">arrow_downward</span>
                </a>

                <button
                  type="button"
                  onClick={onOpenConsultation}
                  className="px-5 py-3.5 bg-white text-gray-800 font-label-ui text-xs font-semibold rounded-xl shadow-xs hover:bg-gray-50 transition-colors inline-flex items-center gap-2 cursor-pointer border border-gray-200"
                >
                  <span className="material-symbols-outlined text-[18px] text-[#b02d29]">support_agent</span>
                  <span>Tư vấn phong thủy miễn phí</span>
                </button>
              </div>

              <div className="pt-4 grid grid-cols-3 gap-4 max-w-md text-xs text-gray-600">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#b02d29] text-[20px]">local_shipping</span>
                  <span>Giao tận phòng</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#b02d29] text-[20px]">potted_plant</span>
                  <span>Sang chậu tại chỗ</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#b02d29] text-[20px]">water_drop</span>
                  <span>Dưỡng chất 6 tháng</span>
                </div>
              </div>
            </div>

            {/* Featured Visual Composition */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-xl bg-white">
                <img
                  className="w-full h-[360px] lg:h-[400px] object-cover"
                  data-alt="Interior plants"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuA3rQPtB0RTfHyUCWkSLmyBWQpqiK4IVCMEQBmW86yH11lHUsvFhx2bVp_O0r9Doi8MTXJCvkoKgSLY2PonBbUblOxd8T8v6Tta6PUiBiRAdOgf8_zRacPcBboOnZfBBf-yDkT3kXlVE79AHHBCdfGX7xMV-f90DE_86WHovi4ijvkQgsi6-LltzzT-Rw219L86vxZDS_sTviyBwIQ_QsFJ3jVBUtRWWlLQfJTD2gHLccWonq4q0Y5K"
                  alt="Không gian phòng khách sang trọng với cây nội thất"
                />
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md shadow-md flex items-center justify-between border border-white/50">
                  <div>
                    <span className="font-label-category uppercase text-[#b02d29] text-[10px] font-bold tracking-wider">
                      Phối cảnh thực tế
                    </span>
                    <p className="font-headline-sm text-xs sm:text-sm font-bold text-gray-900 mt-0.5">
                      Căn hộ The Matrix One, Nam Từ Liêm
                    </p>
                  </div>
                  <span className="px-3 py-1 bg-[#f5f3f0] text-gray-800 font-label-ui text-xs rounded-full font-bold">
                    1m8 - 2m2
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Main Catalog Area: Sidebar + 8 Products */}
      <section id="danh-sach-noi-that" className="w-full max-w-7xl mx-auto px-6 lg:px-12 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar Filters */}
          <aside className="lg:col-span-3 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-xs border border-gray-100 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-gray-900 text-[20px]">tune</span>
                  <h2 className="font-headline-sm text-sm font-bold text-gray-900">Bộ lọc cây</h2>
                </div>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="text-xs text-[#b02d29] hover:underline cursor-pointer font-medium"
                >
                  Đặt lại
                </button>
              </div>

              {/* Kích thước cây */}
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-wide text-gray-700 flex items-center justify-between">
                  <span>Kích thước cây</span>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">height</span>
                </span>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedSizes.includes('mid')}
                      onChange={() => handleSizeToggle('mid')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Cỡ trung (60 - 100cm)</span>
                    <span className="ml-auto text-gray-400">(12)</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedSizes.includes('large')}
                      onChange={() => handleSizeToggle('large')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Cỡ lớn (1m2 - 1m8)</span>
                    <span className="ml-auto text-gray-400">(10)</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedSizes.includes('huge')}
                      onChange={() => handleSizeToggle('huge')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Cây đại (Trên 1m8)</span>
                    <span className="ml-auto text-gray-400">(6)</span>
                  </label>
                </div>
              </div>

              {/* Vị trí bài trí */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <span className="text-xs font-bold uppercase tracking-wide text-gray-700 flex items-center justify-between">
                  <span>Vị trí bài trí</span>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">chair</span>
                </span>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPlaces.includes('living')}
                      onChange={() => handlePlaceToggle('living')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Phòng khách sang trọng</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPlaces.includes('bedroom')}
                      onChange={() => handlePlaceToggle('bedroom')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Phòng ngủ thư giãn</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPlaces.includes('office')}
                      onChange={() => handlePlaceToggle('office')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Sảnh &amp; văn phòng</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPlaces.includes('balcony')}
                      onChange={() => handlePlaceToggle('balcony')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Ban công nhiều nắng</span>
                  </label>
                </div>
              </div>

              {/* Khoảng giá */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <span className="text-xs font-bold uppercase tracking-wide text-gray-700 flex items-center justify-between">
                  <span>Khoảng giá (VNĐ)</span>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">payments</span>
                </span>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center gap-2.5 cursor-pointer p-1">
                    <input
                      type="radio"
                      name="interior-price"
                      checked={selectedPriceTier === 'all'}
                      onChange={() => setSelectedPriceTier('all')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="text-gray-800">Tất cả mức giá</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1">
                    <input
                      type="radio"
                      name="interior-price"
                      checked={selectedPriceTier === 'under350'}
                      onChange={() => setSelectedPriceTier('under350')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="text-gray-800">Dưới 350.000đ</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1">
                    <input
                      type="radio"
                      name="interior-price"
                      checked={selectedPriceTier === '350-600'}
                      onChange={() => setSelectedPriceTier('350-600')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="text-gray-800">350.000đ - 600.000đ</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1">
                    <input
                      type="radio"
                      name="interior-price"
                      checked={selectedPriceTier === 'above600'}
                      onChange={() => setSelectedPriceTier('above600')}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="text-gray-800">Trên 600.000đ</span>
                  </label>
                </div>
              </div>

              {/* Chất liệu chậu */}
              <div className="space-y-3 pt-3 border-t border-gray-100">
                <span className="text-xs font-bold uppercase tracking-wide text-gray-700 flex items-center justify-between">
                  <span>Chất liệu chậu</span>
                  <span className="material-symbols-outlined text-[16px] text-gray-400">shapes</span>
                </span>
                <div className="space-y-2 text-xs text-gray-600">
                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPots.includes('ceramic')}
                      onChange={() => handlePotToggle('ceramic')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Chậu gốm mộc Bát Tràng</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPots.includes('composite')}
                      onChange={() => handlePotToggle('composite')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Chậu composite cao cấp</span>
                  </label>

                  <label className="flex items-center gap-2.5 cursor-pointer p-1 hover:bg-[#f5f3f0] rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedPots.includes('cement')}
                      onChange={() => handlePotToggle('cement')}
                      className="w-4 h-4 accent-[#234729] rounded cursor-pointer"
                    />
                    <span className="text-gray-800">Chậu xi măng đá mài</span>
                  </label>
                </div>
              </div>

              {/* Quick tip */}
              <div className="p-4 bg-[#f5f3f0] rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-[#b02d29]">
                  <span className="material-symbols-outlined text-[18px]">wb_sunny</span>
                  <span className="text-xs font-bold">Lưu ý ánh sáng</span>
                </div>
                <p className="text-xs text-gray-600 leading-relaxed">
                  Cây nội thất chuộng ánh sáng tán xạ dịu nhẹ. Tránh ánh nắng gắt trực tiếp buổi trưa để lá luôn xanh mướt.
                </p>
              </div>
            </div>
          </aside>

          {/* Product Listing Area */}
          <main className="lg:col-span-9 space-y-6">
            <div className="bg-white p-4 rounded-2xl shadow-xs border border-gray-100 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs sm:text-sm">
                <span className="text-gray-500">Hiển thị:</span>
                <span className="font-bold text-gray-900">{filteredProducts.length} sản phẩm ưu tiên</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-500">Sắp xếp:</span>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="bg-[#f5f3f0] text-gray-900 text-xs px-3 py-2 pr-8 rounded-lg focus:outline-none cursor-pointer"
                >
                  <option value="popular">Bán chạy nhất</option>
                  <option value="price-asc">Giá: Thấp đến Cao</option>
                  <option value="price-desc">Giá: Cao đến Thấp</option>
                  <option value="rating">Đánh giá cao nhất</option>
                </select>
              </div>
            </div>

            {/* 8 Interior Product Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {filteredProducts.map((prod) => {
                const isWishlisted = wishlistIds.has(prod.id);
                return (
                  <div
                    key={prod.id}
                    className="group bg-white rounded-2xl shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between overflow-hidden border border-gray-100 relative"
                  >
                    <div className="relative aspect-[4/5] overflow-hidden bg-[#f5f3f0]">
                      <img
                        src={prod.image}
                        alt={prod.name}
                        onClick={() => onSelectProduct(prod)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-pointer"
                      />
                      {prod.badge && (
                        <span className="absolute top-3 left-3 px-2 py-0.5 bg-[#b02d29] text-white text-[10px] font-bold uppercase tracking-wider rounded shadow-xs">
                          {prod.badge}
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(prod);
                        }}
                        className={`absolute top-3 right-3 w-8 h-8 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center transition-colors cursor-pointer ${
                          isWishlisted ? 'text-[#b02d29]' : 'text-gray-500 hover:text-[#b02d29]'
                        }`}
                      >
                        <span
                          className={`material-symbols-outlined text-[18px] ${
                            isWishlisted ? 'material-symbols-fill' : ''
                          }`}
                        >
                          favorite
                        </span>
                      </button>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div
                        onClick={() => onSelectProduct(prod)}
                        className="cursor-pointer"
                      >
                        <span className="text-[11px] text-gray-400 font-medium">
                          {prod.height}
                        </span>
                        <h3 className="font-headline-sm text-sm sm:text-[15px] font-bold text-gray-900 mt-1 group-hover:text-[#b02d29] transition-colors line-clamp-1">
                          {prod.name}
                        </h3>
                        <div className="flex items-center gap-1.5 mt-1 text-xs text-gray-500">
                          <span className="material-symbols-outlined text-amber-500 text-[16px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                            star
                          </span>
                          <span className="font-bold text-gray-900">{prod.rating}</span>
                          <span className="text-gray-400">({prod.reviewsCount} đánh giá)</span>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-baseline gap-2 mb-3">
                          <span className="text-base sm:text-lg font-bold text-[#b02d29]">
                            {prod.price.toLocaleString('vi-VN')}đ
                          </span>
                          {prod.originalPrice && (
                            <span className="text-xs line-through text-gray-400">
                              {prod.originalPrice.toLocaleString('vi-VN')}đ
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => onAddToCart(prod)}
                          style={{ backgroundColor: '#1E4D2B' }}
                          className="w-full py-2.5 px-3 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors hover:opacity-90 cursor-pointer shadow-xs"
                        >
                          <span className="material-symbols-outlined text-[17px]">add_shopping_cart</span>
                          <span>Thêm vào giỏ</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pagination */}
            <div className="pt-6 flex items-center justify-between border-t border-gray-100">
              <span className="text-xs text-gray-500">Hiển thị {filteredProducts.length} trên 28 sản phẩm</span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="w-8 h-8 rounded-lg bg-[#f5f3f0] text-gray-400 flex items-center justify-center disabled:opacity-50 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">chevron_left</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(1)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center cursor-pointer ${
                    currentPage === 1 ? 'bg-[#234729] text-white' : 'bg-[#f5f3f0] text-gray-800'
                  }`}
                >
                  1
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(2)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center cursor-pointer ${
                    currentPage === 2 ? 'bg-[#234729] text-white' : 'bg-[#f5f3f0] text-gray-800'
                  }`}
                >
                  2
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentPage(3)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold flex items-center justify-center cursor-pointer ${
                    currentPage === 3 ? 'bg-[#234729] text-white' : 'bg-[#f5f3f0] text-gray-800'
                  }`}
                >
                  3
                </button>
                <button
                  type="button"
                  disabled={currentPage === 3}
                  onClick={() => setCurrentPage(3)}
                  className="w-8 h-8 rounded-lg bg-[#f5f3f0] text-gray-700 hover:bg-[#eae8e5] flex items-center justify-center transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>
              </div>
            </div>
          </main>
        </div>
      </section>

      {/* 4. Exclusive Services */}
      <section className="w-full bg-white my-6 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-14">
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
            <span className="font-label-category uppercase tracking-widest text-[#b02d29] text-xs font-bold">
              Trải nghiệm an tâm trọn vẹn
            </span>
            <h2 className="font-headline-lg text-2xl sm:text-3xl text-gray-900">
              Đặc Quyền Khách Hàng Khi Mua Cây Cỡ Lớn
            </h2>
            <p className="font-body-md text-gray-600 text-sm sm:text-base leading-relaxed">
              Vườn Xanh không chỉ gửi trao cây cỏ, chúng tôi mang tới dịch vụ set-up trọn gói chuyên nghiệp tại gia đình bạn.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#f5f3f0] hover:bg-[#eae8e5] transition-colors space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#234729] text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[26px]">local_shipping</span>
              </div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">Miễn Phí Vận Chuyển Tận Nhà</h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Xe chuyên dụng bọc lót chống dập lá, bảo hiểm gãy cành 100% trong quá trình bốc dỡ và vận chuyển tới từng tầng căn hộ.
              </p>
              <div className="pt-2 text-xs text-[#b02d29] font-semibold flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Áp dụng cho mọi cây từ 1m2</span>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-[#f5f3f0] hover:bg-[#eae8e5] transition-colors space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#b02d29] text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[26px]">potted_plant</span>
              </div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">Hỗ Trợ Sang Chậu Tại Chỗ</h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Kỹ thuật viên mang theo đất vi sinh tribat, sỏi phủ bề mặt và chậu mới để trồng hoàn thiện, dọn dẹp mặt sàn sạch sẽ trước khi bàn giao.
              </p>
              <div className="pt-2 text-xs text-[#b02d29] font-semibold flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Miễn phí công sang chậu</span>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-[#f5f3f0] hover:bg-[#eae8e5] transition-colors space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#141b2b] text-white flex items-center justify-center shadow-xs">
                <span className="material-symbols-outlined text-[26px]">explore</span>
              </div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">Tư Vấn Vị Trí Chuẩn Phong Thủy</h3>
              <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                Định hướng hướng đón khí tài, cân bằng ngũ hành giữa bản mệnh của gia chủ và đặc tính từng loài cây để tăng năng lượng thịnh vượng.
              </p>
              <div className="pt-2 text-xs text-[#b02d29] font-semibold flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>Cung cấp cẩm nang chăm sóc riêng</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Broadsheet Pull Quote */}
      <section className="w-full max-w-4xl mx-auto px-6 py-10">
        <div className="border-y-2 border-[#234729] py-8 text-center space-y-3">
          <p
            className="text-lg sm:text-xl italic text-gray-900 leading-relaxed"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            “Một chậu cây lớn đặt đúng vị trí không chỉ làm mềm đi những góc cạnh của bê tông cốt thép, mà còn là trái tim nuôi dưỡng nguồn sinh khí bình an cho mỗi tổ ấm.”
          </p>
          <div className="font-label-category uppercase text-[#b02d29] tracking-widest text-xs pt-2 font-bold">
            — Ban Cố Vấn Sinh Thái &amp; Kiến Trúc Vườn Xanh
          </div>
        </div>
      </section>
    </div>
  );
};
