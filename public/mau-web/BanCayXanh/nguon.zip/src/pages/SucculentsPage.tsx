import React, { useState, useMemo } from 'react';
import { PageTab, Product } from '../types';
import { succulentsList } from '../data/mockData';

interface SucculentsPageProps {
  onNavigate: (tab: PageTab) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  wishlistIds: Set<string>;
  onSelectProduct: (product: Product) => void;
  onOpenConsultation: () => void;
}

export const SucculentsPage: React.FC<SucculentsPageProps> = ({
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  wishlistIds,
  onSelectProduct,
  onOpenConsultation,
}) => {
  const [selectedVariety, setSelectedVariety] = useState<string>('all');
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [sortOption, setSortOption] = useState<string>('popular');
  const [currentPage, setCurrentPage] = useState<number>(1);

  const handleResetFilters = () => {
    setSelectedVariety('all');
    setSelectedColor(null);
    setSelectedSize('all');
  };

  const filteredProducts = useMemo(() => {
    return succulentsList.filter((prod) => {
      if (selectedColor && prod.colorTag !== selectedColor) {
        return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-asc') return a.price - b.price;
      if (sortOption === 'price-desc') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      return b.reviewsCount - a.reviewsCount;
    });
  }, [selectedColor, sortOption]);

  return (
    <div className="flex flex-col w-full font-sans">
      {/* 1. Breadcrumbs */}
      <div className="w-full bg-[#f5f3f0]/70 py-3">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center gap-2 text-xs text-gray-500">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-gray-900 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="material-symbols-outlined text-[14px] text-gray-400">chevron_right</span>
          <span className="text-[#b02d29] font-semibold">Sen đá</span>
          <span className="ml-auto hidden md:flex items-center gap-1 text-gray-500 text-[11px]">
            <span className="material-symbols-outlined text-[15px] text-[#b02d29]">verified_user</span>
            <span>100% Cây thuần khí hậu Việt Nam</span>
          </span>
        </div>
      </div>

      {/* 2. Category Editorial Banner */}
      <div className="w-full relative overflow-hidden bg-[#f5f3f0]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          <div className="lg:col-span-7 flex flex-col space-y-4">
            <div className="inline-flex items-center gap-2 self-start px-3.5 py-1 bg-white text-[#b02d29] rounded-full shadow-2xs">
              <span className="material-symbols-outlined text-[16px]">spa</span>
              <span className="font-label-category uppercase tracking-wider text-[11px] font-bold">
                Bộ sưu tập mọng nước 2025
              </span>
            </div>

            <h1 className="font-headline-xl text-3xl sm:text-4xl text-gray-900 tracking-tight leading-tight">
              Thế Giới Sen Đá <br />
              <span className="italic font-normal text-[#b02d29]">Rực Rỡ &amp; Đa Sắc</span>
            </h1>

            <p className="font-body-md text-gray-600 max-w-xl text-sm sm:text-base leading-relaxed">
              Những đóa hoa đá bền bỉ mang biểu tượng tình yêu vĩnh cửu. Tuyển chọn giống khoẻ, rễ thuần, tán dày căng mọng cùng sắc thái đổi màu kỳ ảo theo nắng trời.
            </p>

            {/* Quick Spec Highlights */}
            <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-gray-800 font-medium">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#234729] shadow-2xs">
                  <span className="material-symbols-outlined text-[18px]">wb_sunny</span>
                </span>
                <span>Ưa nắng sớm 4-6h</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#234729] shadow-2xs">
                  <span className="material-symbols-outlined text-[18px]">water_drop</span>
                </span>
                <span>Tưới 1-2 lần/tuần</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#b02d29] shadow-2xs">
                  <span className="material-symbols-outlined text-[18px]">card_giftcard</span>
                </span>
                <span>Tặng sỏi rải mặt + que tưới</span>
              </div>
            </div>
          </div>

          {/* Hero Visual Composition */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="relative w-full max-w-md aspect-[4/3] rounded-2xl overflow-hidden shadow-xl bg-white">
              <img
                className="w-full h-full object-cover"
                data-alt="Succulents garden"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDHfSk4WuLuxzWTZTqwoumbQ6a_sh6JlmtmMMDaEVi8Bg41WRDP0onai1gLq949yCUGf3udBKTQHejiyLQFgpNfZ-5kf-5aVAuqVkg1y-LJtL4fQ7hrDg88S0UZ7WlQYfHAyuOL6H1aE3kopaW-joqn_92BjQqT4B6SnO9P2c05Dd11oCWnnNdbTi7OBHOaEc7HJkvX8y1-yRP_Qkwo5e37W3CJLBo2pO4e03xXmoLYG0u6Szocg55E"
                alt="Bộ sưu tập sen đá đa sắc"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="font-label-category uppercase tracking-wider text-emerald-300 text-[10px] font-bold">
                  Sưu tập quý hiếm
                </span>
                <p className="font-headline-sm text-sm sm:text-base font-bold text-white mt-0.5">
                  Hơn 45+ giống sen đài, rủ &amp; đột biến
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Main Catalog Space: Filter Sidebar + 8 Product Cards */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar */}
          <aside className="lg:col-span-3 space-y-6 bg-white p-6 rounded-2xl shadow-xs border border-gray-100">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[20px] text-gray-900">tune</span>
                <span className="font-headline-sm text-sm font-bold text-gray-900">Bộ Lọc Chọn Sen</span>
              </div>
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-xs text-[#b02d29] hover:underline cursor-pointer font-medium"
              >
                Xoá lọc
              </button>
            </div>

            {/* Dòng sen đá */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700 flex items-center justify-between">
                <span>Dòng Sen Đá</span>
                <span className="material-symbols-outlined text-[16px] text-gray-400">expand_more</span>
              </h3>
              <div className="space-y-2 text-xs text-gray-600">
                {[
                  { id: 'all', label: 'Tất cả giống loài', count: 48 },
                  { id: 'common', label: 'Sen đá phổ thông', count: 24 },
                  { id: 'var', label: 'Sen đá đột biến / Var', count: 8 },
                  { id: 'import', label: 'Sen đá nhập khẩu', count: 10 },
                  { id: 'combo', label: 'Tiểu cảnh sen đá', count: 6 },
                ].map((item) => (
                  <label key={item.id} className="flex items-center gap-2.5 cursor-pointer group p-1">
                    <input
                      type="radio"
                      name="succulent-variety"
                      checked={selectedVariety === item.id}
                      onChange={() => setSelectedVariety(item.id)}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="group-hover:text-[#b02d29] transition-colors">{item.label}</span>
                    <span className="ml-auto text-gray-400">({item.count})</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Sắc thái màu */}
            <div className="space-y-3 pt-3 border-t border-gray-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700">Sắc Thái Màu</h3>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { tag: 'xanh-ngoc', label: 'Xanh ngọc', dot: 'bg-emerald-300' },
                  { tag: 'hong-phot', label: 'Hồng phớt', dot: 'bg-rose-300' },
                  { tag: 'tim-khoi', label: 'Tím khói', dot: 'bg-purple-300' },
                  { tag: 'cam-nau', label: 'Cam nâu', dot: 'bg-amber-600' },
                  { tag: 'trang-phan', label: 'Trắng phấn nhung', dot: 'bg-slate-200 border border-slate-300', span: true },
                ].map((c) => {
                  const isActive = selectedColor === c.tag;
                  return (
                    <button
                      key={c.tag}
                      type="button"
                      onClick={() => setSelectedColor(isActive ? null : c.tag)}
                      className={`flex items-center gap-2 px-2.5 py-2 rounded-xl transition-all cursor-pointer text-left ${
                        c.span ? 'col-span-2' : ''
                      } ${
                        isActive
                          ? 'bg-[#f5f3f0] ring-2 ring-[#b02d29] font-bold text-gray-900'
                          : 'bg-[#f5f3f0] hover:bg-[#eae8e5] text-gray-700'
                      }`}
                    >
                      <span className={`w-3.5 h-3.5 rounded-full ${c.dot} shadow-inner shrink-0`} />
                      <span className="truncate">{c.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Kích thước bầu */}
            <div className="space-y-3 pt-3 border-t border-gray-100">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700">Kích Thước Bầu</h3>
              <div className="space-y-2 text-xs text-gray-600">
                {[
                  { id: 'all', label: 'Tất cả kích cỡ' },
                  { id: 'mini', label: 'Mini để bàn (5cm)' },
                  { id: 'medium', label: 'Vừa chậu gốm (7 - 9cm)' },
                  { id: 'large', label: 'Bụi sum suê (> 12cm)' },
                ].map((sz) => (
                  <label key={sz.id} className="flex items-center gap-2.5 cursor-pointer group p-1">
                    <input
                      type="radio"
                      name="pot-size"
                      checked={selectedSize === sz.id}
                      onChange={() => setSelectedSize(sz.id)}
                      className="w-4 h-4 accent-[#234729] cursor-pointer"
                    />
                    <span className="group-hover:text-[#b02d29] transition-colors">{sz.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Ad for Terracotta Pot */}
            <div className="rounded-xl p-4 bg-[#f5f3f0] space-y-2 border border-[#eae8e5]">
              <div className="flex items-center gap-1.5 text-[#b02d29] text-[11px] font-bold uppercase tracking-wider">
                <span className="material-symbols-outlined text-[16px]">local_offer</span>
                <span>Phụ kiện ghép kèm</span>
              </div>
              <p className="text-xs font-bold text-gray-900">Chậu đất nung thở tự nhiên</p>
              <p className="text-[11px] text-gray-500 leading-relaxed">
                Giúp thoát nước cực tốt, rễ sen đá thở khoẻ chống úng tối đa.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('gio-hang')}
                className="inline-flex items-center gap-1 text-xs font-bold text-[#b02d29] hover:underline pt-1 cursor-pointer"
              >
                <span>Xem chậu sen đá</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </button>
            </div>
          </aside>

          {/* Product Cards Stream */}
          <section className="lg:col-span-9 flex flex-col space-y-6">
            <div className="bg-white p-4 rounded-2xl shadow-xs border border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="text-xs sm:text-sm text-gray-600">
                Tìm thấy <strong className="text-gray-900 font-bold">{filteredProducts.length} giống sen đá tuyển chọn</strong> tại vườn
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                <span className="text-xs text-gray-500">Sắp xếp:</span>
                <select
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="bg-[#f5f3f0] text-gray-900 text-xs px-3 py-2 pr-8 rounded-lg focus:outline-none cursor-pointer"
                >
                  <option value="popular">Phổ biến nhất</option>
                  <option value="price-asc">Giá: Thấp đến Cao</option>
                  <option value="price-desc">Giá: Cao đến Thấp</option>
                  <option value="rating">Đánh giá cao nhất</option>
                </select>
              </div>
            </div>

            {/* 8 Succulent Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
              {filteredProducts.map((prod) => {
                const isWishlisted = wishlistIds.has(prod.id);
                return (
                  <div
                    key={prod.id}
                    className="group bg-white rounded-2xl p-3 shadow-xs hover:shadow-md transition-shadow flex flex-col relative border border-gray-100"
                  >
                    <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-[#f5f3f0] mb-3">
                      <img
                        src={prod.image}
                        alt={prod.name}
                        onClick={() => onSelectProduct(prod)}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                      />
                      {prod.badge && (
                        <span className="absolute top-2 left-2 bg-[#b02d29] text-white px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider shadow-xs">
                          {prod.badge}
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(prod);
                        }}
                        className={`absolute top-2 right-2 w-7 h-7 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center transition-colors cursor-pointer ${
                          isWishlisted ? 'text-[#b02d29]' : 'text-gray-400 hover:text-[#b02d29]'
                        }`}
                      >
                        <span
                          className={`material-symbols-outlined text-[16px] ${
                            isWishlisted ? 'material-symbols-fill' : ''
                          }`}
                        >
                          favorite
                        </span>
                      </button>
                    </div>

                    <div className="flex flex-col flex-1">
                      <h3
                        onClick={() => onSelectProduct(prod)}
                        className="font-headline-sm text-sm font-bold text-gray-900 line-clamp-1 group-hover:text-[#b02d29] transition-colors cursor-pointer"
                      >
                        {prod.name}
                      </h3>
                      <div className="flex items-center gap-1 my-1.5 text-xs text-gray-500">
                        <span className="material-symbols-outlined text-amber-500 text-[15px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                          star
                        </span>
                        <span className="font-bold text-gray-800">{prod.rating}</span>
                        <span className="text-gray-400">({prod.reviewsCount})</span>
                      </div>

                      <div className="mt-auto pt-2 flex items-center justify-between">
                        <span className="text-base font-bold text-[#b02d29]">
                          {prod.price.toLocaleString('vi-VN')}đ
                        </span>
                        <button
                          type="button"
                          onClick={() => onAddToCart(prod)}
                          style={{ backgroundColor: '#1E4D2B' }}
                          className="px-3 py-1.5 rounded-lg text-white text-xs font-semibold flex items-center gap-1 hover:opacity-90 transition-opacity cursor-pointer shadow-xs"
                        >
                          <span className="material-symbols-outlined text-[16px]">shopping_cart</span>
                          <span className="hidden sm:inline">Thêm</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Pagination */}
            <div className="pt-6 flex items-center justify-center gap-2">
              <button
                type="button"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(1)}
                className="w-9 h-9 rounded-xl bg-[#f5f3f0] text-gray-500 flex items-center justify-center hover:bg-[#eae8e5] transition-colors disabled:opacity-40 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">chevron_left</span>
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(1)}
                className={`w-9 h-9 rounded-xl text-xs font-bold cursor-pointer ${
                  currentPage === 1 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                1
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(2)}
                className={`w-9 h-9 rounded-xl text-xs font-bold cursor-pointer ${
                  currentPage === 2 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                2
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage(3)}
                className={`w-9 h-9 rounded-xl text-xs font-bold cursor-pointer ${
                  currentPage === 3 ? 'bg-[#234729] text-white' : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                3
              </button>
              <button
                type="button"
                disabled={currentPage === 3}
                onClick={() => setCurrentPage(3)}
                className="w-9 h-9 rounded-xl bg-white border border-gray-200 text-gray-700 flex items-center justify-center hover:bg-[#f5f3f0] transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">chevron_right</span>
              </button>
            </div>
          </section>
        </div>
      </div>

      {/* 4. Care Tips ("Mẹo Ghim Nhanh: Cách Tưới Nước Chuẩn Cho Sen Đá Không Bị Úng Rễ") */}
      <div className="w-full bg-[#f5f3f0] py-12 border-t border-[#eae8e5]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="bg-white rounded-2xl p-6 lg:p-10 shadow-xs grid grid-cols-1 lg:grid-cols-12 gap-8 items-center border border-gray-100">
            {/* Left: Editorial Guide */}
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 text-[#b02d29] font-label-category uppercase tracking-wider text-xs font-bold">
                <span className="material-symbols-outlined text-[18px]">lightbulb</span>
                <span>Cẩm Nang Chuyên Sâu</span>
              </div>
              <h2 className="font-headline-lg text-2xl sm:text-3xl text-gray-900">
                Mẹo Ghim Nhanh: Cách Tưới Nước Chuẩn Cho Sen Đá Không Bị Úng Rễ
              </h2>
              <p className="font-body-md text-gray-600 text-sm sm:text-base leading-relaxed">
                Sen đá tích trữ nước trong phiến lá dày nên chịu hạn rất cừ, nhưng cực kỳ nhạy cảm với tình trạng ứ nước. Hãy nằm lòng nguyên tắc vàng: <strong className="text-gray-900">"Đất thật khô mới tưới - Tưới đẫm thoát đáy"</strong>.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-[#f5f3f0] space-y-1">
                  <span className="font-headline-sm text-sm font-bold text-[#b02d29] block">
                    01. Thử độ khô
                  </span>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Dùng tăm tre cắm sâu 3cm vào giá thể. Nếu tăm khô ráo hoàn toàn mới tiến hành cấp nước.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#f5f3f0] space-y-1">
                  <span className="font-headline-sm text-sm font-bold text-[#b02d29] block">
                    02. Kỹ thuật ngấm
                  </span>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Nên tưới vào quanh gốc hoặc dùng phương pháp ngâm đáy chậu 5-10 phút. Tuyệt đối không xịt đọng nước lên đọt lá.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#f5f3f0] space-y-1">
                  <span className="font-headline-sm text-sm font-bold text-[#b02d29] block">
                    03. Thời điểm vàng
                  </span>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Tưới vào lúc sáng sớm (6h - 8h) hoặc chiều mát khi mặt trời đã lặn hẳn, tránh sốc nhiệt làm luộc chín lá.
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Callout */}
            <div className="lg:col-span-4 flex flex-col items-center bg-[#f5f3f0] p-6 rounded-2xl text-center space-y-3 border border-[#eae8e5]">
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center text-[#b02d29] shadow-xs">
                <span className="material-symbols-outlined text-[32px]">water_ph</span>
              </div>
              <h3 className="font-headline-sm text-base font-bold text-gray-900">Cần Tư Vấn Đất Trồng?</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Giá thể Vườn Xanh phối sẵn đá Pumice, Perlite và vỏ thông thoát nước đỉnh cao, đảm bảo rễ luôn khô thoáng.
              </p>
              <button
                type="button"
                onClick={onOpenConsultation}
                className="w-full py-2.5 px-4 bg-[#234729] hover:bg-[#1a3820] text-white font-label-ui text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <span className="material-symbols-outlined text-[18px]">support_agent</span>
                <span>Chat với chuyên viên</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
