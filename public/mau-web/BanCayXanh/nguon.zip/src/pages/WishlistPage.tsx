import React from 'react';
import { PageTab, Product } from '../types';

interface WishlistPageProps {
  onNavigate: (tab: PageTab) => void;
  wishlistProducts: Product[];
  onAddToCart: (product: Product) => void;
  onRemoveFromWishlist: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({
  onNavigate,
  wishlistProducts,
  onAddToCart,
  onRemoveFromWishlist,
  onSelectProduct,
}) => {
  return (
    <div className="flex flex-col w-full font-sans">
      {/* Breadcrumb */}
      <div className="w-full bg-[#f5f3f0] py-3.5 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 flex items-center gap-2 text-xs text-gray-500">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-gray-900 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="text-gray-300">/</span>
          <span className="text-gray-900 font-semibold">Danh sách yêu thích ({wishlistProducts.length})</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-10 w-full">
        <div className="flex items-center justify-between pb-6 border-b border-gray-100 mb-8">
          <div>
            <h1 className="font-headline-lg text-2xl font-bold text-gray-900">
              Cây cảnh bạn đã lưu
            </h1>
            <p className="text-xs text-gray-500 mt-1">
              Dễ dàng theo dõi giá và thêm nhanh vào giỏ hàng bất cứ lúc nào
            </p>
          </div>
          <button
            onClick={() => onNavigate('cay-de-ban')}
            className="text-xs font-semibold text-[#234729] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Tiếp tục ngắm cây</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>

        {wishlistProducts.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center space-y-4 shadow-xs border border-gray-100 max-w-md mx-auto">
            <div className="w-16 h-16 rounded-full bg-[#ffdad6] text-[#b02d29] flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-[32px]">favorite_border</span>
            </div>
            <h3 className="font-headline-sm text-base font-bold text-gray-900">
              Danh sách yêu thích đang trống
            </h3>
            <p className="text-xs text-gray-500 leading-relaxed">
              Hãy bấm vào biểu tượng trái tim ở các sản phẩm bạn ưng ý để lưu lại xem sau nhé!
            </p>
            <button
              onClick={() => onNavigate('cay-de-ban')}
              className="px-5 py-2.5 bg-[#234729] text-white text-xs font-semibold rounded-xl hover:opacity-90 shadow-xs cursor-pointer"
            >
              Khám phá cây cảnh
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {wishlistProducts.map((prod) => (
              <div
                key={prod.id}
                className="bg-white rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-shadow border border-gray-100 flex flex-col justify-between group relative"
              >
                <div className="relative aspect-square bg-[#f5f3f0] overflow-hidden">
                  <img
                    src={prod.image}
                    alt={prod.name}
                    onClick={() => onSelectProduct(prod)}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 cursor-pointer"
                  />
                  <button
                    type="button"
                    onClick={() => onRemoveFromWishlist(prod)}
                    className="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 text-[#b02d29] hover:bg-white flex items-center justify-center shadow-xs transition-colors cursor-pointer"
                    title="Bỏ yêu thích"
                  >
                    <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                      favorite
                    </span>
                  </button>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div
                    onClick={() => onSelectProduct(prod)}
                    className="cursor-pointer"
                  >
                    <span className="text-[10px] text-[#b02d29] font-bold uppercase tracking-wider block">
                      {prod.categoryLabel}
                    </span>
                    <h3 className="font-headline-sm text-sm font-bold text-gray-900 group-hover:text-[#b02d29] transition-colors line-clamp-1 mt-0.5">
                      {prod.name}
                    </h3>
                    <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
                      <span className="material-symbols-outlined text-amber-500 text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                        star
                      </span>
                      <span className="font-bold text-gray-900">{prod.rating}</span>
                      <span className="text-gray-400">({prod.reviewsCount})</span>
                    </div>
                  </div>

                  <div>
                    <div className="text-base font-bold text-[#b02d29] mb-2.5">
                      {prod.price.toLocaleString('vi-VN')}đ
                    </div>
                    <button
                      type="button"
                      onClick={() => onAddToCart(prod)}
                      style={{ backgroundColor: '#1E4D2B' }}
                      className="w-full py-2 bg-[#234729] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 hover:opacity-90 transition-opacity shadow-xs cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[16px]">shopping_cart</span>
                      <span>Thêm vào giỏ</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
