export interface Product {
  id: string;
  name: string;
  category: 'cay-de-ban' | 'cay-noi-that' | 'sen-da' | 'xuong-rong' | 'chau-decor' | 'phu-kien';
  categoryLabel: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  badge?: string;
  badgeType?: 'primary' | 'secondary' | 'accent' | 'warm';
  specs?: string;
  height?: string;
  light?: 'shade' | 'partial' | 'full';
  care?: 'easy' | 'normal' | 'careful';
  fengShui?: string;
  potType?: string;
  colorTag?: string;
  description?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  potOption?: string;
}

export interface OrderItem {
  name: string;
  image: string;
  specs: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  status: 'delivering' | 'completed' | 'cancelled';
  statusText: string;
  statusDetail?: string;
  driver?: {
    name: string;
    eta: string;
    phone: string;
    vehicle: string;
  };
  items: OrderItem[];
  total: number;
  warrantyDaysLeft?: number;
}

export interface Voucher {
  code: string;
  badge: string;
  expiry: string;
  title: string;
  desc: string;
  discountPercent?: number;
  maxDiscount?: number;
  minSpend?: number;
  isApplied?: boolean;
}

export interface UserProfile {
  name: string;
  phone: string;
  email: string;
  joinDate: string;
  avatar: string;
  tier: string;
  points: number;
  nextTier: string;
  neededPoints: number;
  address: string;
  deliveryNotes: string;
}

export interface BlogArticle {
  id: string;
  title: string;
  date: string;
  image: string;
  category: string;
  snippet: string;
}

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  avatar: string;
  rating: number;
  content: string;
}

export type PageTab =
  | 'trang-chu'
  | 'cay-de-ban'
  | 'cay-noi-that'
  | 'sen-da'
  | 'xuong-rong'
  | 'tai-khoan'
  | 'gio-hang'
  | 'yeu-thich';
