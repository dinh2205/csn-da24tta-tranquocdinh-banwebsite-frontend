/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider } from './context/AuthContext';
import { ClubProvider } from './context/ClubContext';
import { AppLayout } from './components/AppLayout';

// Pages
import { TrangChu } from './pages/TrangChu';
import { DanhSachCauLacBo } from './pages/DanhSachCauLacBo';
import { ChiTietCauLacBo } from './pages/ChiTietCauLacBo';
import { DangNhapDangKy } from './pages/DangNhapDangKy';
import { TrangCaNhanSinhVien } from './pages/TrangCaNhanSinhVien';
import { ChiTietHoatDong } from './pages/ChiTietHoatDong';
import { DanhSachHoatDong } from './pages/DanhSachHoatDong';
import { QuanLyThanhVien } from './pages/QuanLyThanhVien';
import { QuanLyHoatDong } from './pages/QuanLyHoatDong';
import { DiemDanhHoatDong } from './pages/DiemDanhHoatDong';
import { DuyetHoatDong } from './pages/DuyetHoatDong';
import { BaoCaoToanTruong } from './pages/BaoCaoToanTruong';
import { QuanLyTaiKhoan } from './pages/QuanLyTaiKhoan';

// Extended Pages
import { QuanLyYeuCauGiaNhap } from './pages/QuanLyYeuCauGiaNhap';
import { QuanLyNhiemKy } from './pages/QuanLyNhiemKy';
import { DeXuatThanhLapCLB } from './pages/DeXuatThanhLapCLB';
import { DuyetThanhLapCLB } from './pages/DuyetThanhLapCLB';
import { QuanLyDiemRenLuyen } from './pages/QuanLyDiemRenLuyen';
import { TinTuc } from './pages/TinTuc';
import { GioiThieu } from './pages/GioiThieu';

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <ClubProvider>
          <BrowserRouter>
            <AppLayout>
              <Routes>
                {/* 1. Trang chủ (Khách / Sinh viên) */}
                <Route path="/" element={<TrangChu />} />

                {/* 2. Danh sách câu lạc bộ */}
                <Route path="/cau-lac-bo" element={<DanhSachCauLacBo />} />

                {/* 3. Chi tiết câu lạc bộ */}
                <Route path="/cau-lac-bo/:id" element={<ChiTietCauLacBo />} />

                {/* 4. Đăng nhập / Đăng ký */}
                <Route path="/dang-nhap" element={<DangNhapDangKy />} />
                <Route path="/dang-ky" element={<DangNhapDangKy />} />

                {/* 5. Trang cá nhân sinh viên */}
                <Route path="/sinh-vien" element={<TrangCaNhanSinhVien />} />
                <Route path="/sinh-vien/thong-tin" element={<TrangCaNhanSinhVien />} />
                <Route path="/sinh-vien/cau-lac-bo" element={<TrangCaNhanSinhVien />} />
                <Route path="/sinh-vien/hoat-dong" element={<TrangCaNhanSinhVien />} />
                <Route path="/sinh-vien/diem-ren-luyen" element={<QuanLyDiemRenLuyen />} />
                <Route path="/sinh-vien/de-xuat-clb" element={<DeXuatThanhLapCLB />} />
                <Route path="/sinh-vien/cai-dat" element={<TrangCaNhanSinhVien />} />

                {/* 6. Chi tiết và đăng ký hoạt động */}
                <Route path="/hoat-dong/:id" element={<ChiTietHoatDong />} />
                <Route path="/hoat-dong" element={<DanhSachHoatDong />} />

                {/* 7. Ban chủ nhiệm CLB - Quản lý thành viên */}
                <Route path="/ban-chu-nhiem" element={<Navigate to="/ban-chu-nhiem/thanh-vien" replace />} />
                <Route path="/ban-chu-nhiem/thanh-vien" element={<QuanLyThanhVien />} />
                <Route path="/ban-chu-nhiem/thong-tin" element={<Navigate to="/cau-lac-bo/CLB001" replace />} />

                {/* 8. Ban chủ nhiệm CLB - Quản lý hoạt động */}
                <Route path="/ban-chu-nhiem/hoat-dong" element={<QuanLyHoatDong />} />

                {/* 9. Ban chủ nhiệm CLB - Điểm danh */}
                <Route path="/ban-chu-nhiem/diem-danh/:activityId" element={<DiemDanhHoatDong />} />
                <Route path="/ban-chu-nhiem/diem-danh" element={<DiemDanhHoatDong />} />

                {/* Extended BCN pages */}
                <Route path="/ban-chu-nhiem/yeu-cau" element={<QuanLyYeuCauGiaNhap />} />
                <Route path="/ban-chu-nhiem/nhiem-ky" element={<QuanLyNhiemKy />} />
                <Route path="/ban-chu-nhiem/diem-ren-luyen" element={<QuanLyDiemRenLuyen />} />
                <Route path="/ban-chu-nhiem/tin-tuc" element={<TinTuc />} />
                <Route path="/ban-chu-nhiem/thong-ke" element={<BaoCaoToanTruong />} />

                {/* 10. Ban quản lý cấp trường - Phê duyệt hoạt động */}
                <Route path="/quan-ly-truong" element={<Navigate to="/quan-ly-truong/duyet-hoat-dong" replace />} />
                <Route path="/quan-ly-truong/duyet-hoat-dong" element={<DuyetHoatDong />} />

                {/* 11. Ban quản lý cấp trường - Báo cáo thống kê toàn trường */}
                <Route path="/quan-ly-truong/bao-cao" element={<BaoCaoToanTruong />} />
                <Route path="/quan-ly-truong/duyet-clb" element={<DuyetThanhLapCLB />} />
                <Route path="/quan-ly-truong/xac-nhan-diem-rl" element={<QuanLyDiemRenLuyen />} />
                <Route path="/quan-ly-truong/quan-ly-clb" element={<DanhSachCauLacBo />} />

                {/* 12. Quản trị viên - Quản lý tài khoản và phân quyền */}
                <Route path="/quan-tri" element={<Navigate to="/quan-tri/tai-khoan" replace />} />
                <Route path="/quan-tri/tai-khoan" element={<QuanLyTaiKhoan />} />
                <Route path="/quan-tri/danh-muc" element={<DanhSachCauLacBo />} />
                <Route path="/quan-tri/nhat-ky" element={<QuanLyTaiKhoan />} />

                {/* Shared Public Pages */}
                <Route path="/tin-tuc" element={<TinTuc />} />
                <Route path="/gioi-thieu" element={<GioiThieu />} />

                {/* Catch-all */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AppLayout>
          </BrowserRouter>
        </ClubProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
