import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { RoleSwitcherBar } from './RoleSwitcherBar';
import { Menu, X } from 'lucide-react';

export const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Pages that are designed without left sidebar in the reference:
  // Screen 1: Trang chủ ('/')
  // Screen 4: Đăng nhập / Đăng ký ('/dang-nhap', '/dang-ky')
  const isFullWidthPage =
    location.pathname === '/' ||
    location.pathname === '/dang-nhap' ||
    location.pathname === '/dang-ky';

  return (
    <div className="min-h-screen bg-[#F5F8FC] flex flex-col text-[#172B4D]">
      {/* 1. Sticky Demo Role Switcher Bar */}
      <RoleSwitcherBar />

      {/* 2. University Top Navigation Header */}
      <Header />

      {/* 3. Main Workspace Area */}
      {isFullWidthPage ? (
        <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6">
          {children}
        </main>
      ) : (
        <div className="flex-1 flex w-full max-w-[1440px] mx-auto relative">
          {/* Mobile sidebar toggle button */}
          <div className="md:hidden fixed bottom-4 left-4 z-40">
            <button
              onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
              className="p-3 bg-[#0755D9] text-white rounded-full shadow-lg flex items-center justify-center hover:bg-[#0646B5]"
              title="Menu điều hướng"
            >
              {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Sidebar Desktop */}
          <div className="hidden md:block shrink-0">
            <Sidebar />
          </div>

          {/* Sidebar Mobile Drawer */}
          {mobileSidebarOpen && (
            <div className="md:hidden fixed inset-0 z-50 flex">
              <div
                className="fixed inset-0 bg-black/40 backdrop-blur-xs"
                onClick={() => setMobileSidebarOpen(false)}
              ></div>
              <div className="relative z-10 w-64 max-w-xs bg-white h-full shadow-2xl flex flex-col">
                <div className="p-3 border-b border-gray-100 flex items-center justify-between">
                  <span className="font-bold text-xs text-[#073A68]">MENU HỆ THỐNG</span>
                  <button onClick={() => setMobileSidebarOpen(false)} className="p-1 text-gray-500">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto" onClick={() => setMobileSidebarOpen(false)}>
                  <Sidebar />
                </div>
              </div>
            </div>
          )}

          {/* Main Content on the Right */}
          <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8">
            {children}
          </main>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-[#DCE6F0] py-4 text-center text-xs text-[#64748B] mt-auto">
        <div className="max-w-[1440px] mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            © 2026 <strong>TVU CLUB</strong> - Trường Đại học Trà Vinh. Đề tài Phân tích &amp; Thiết kế Hệ thống Thông tin.
          </span>
          <span className="text-[11px] text-gray-400">
            Hệ thống hỗ trợ 5 vai trò: Khách, Sinh viên, Ban chủ nhiệm, Ban QL trường, Quản trị viên
          </span>
        </div>
      </footer>
    </div>
  );
};
