import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useClub } from '../context/ClubContext';
import {
  Bell,
  Search,
  User,
  LogOut,
  ChevronDown,
  Compass,
  Calendar,
  Layers,
  GraduationCap
} from 'lucide-react';

export const Header: React.FC = () => {
  const { role, currentUser, logout, switchRole } = useAuth();
  const { joinRequests, activities } = useClub();
  const location = useLocation();
  const navigate = useNavigate();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const pendingRequestsCount = joinRequests.filter((r) => r.status === 'pending').length;
  const pendingActivitiesCount = activities.filter((a) => a.status === 'Chờ phê duyệt').length;

  const navLinks = [
    { label: 'Trang chủ', path: '/' },
    { label: 'Câu lạc bộ', path: '/cau-lac-bo' },
    { label: 'Hoạt động', path: '/hoat-dong' },
    { label: 'Tin tức', path: '/tin-tuc' }
  ];

  const getDashboardPath = () => {
    switch (role) {
      case 'student':
        return '/sinh-vien';
      case 'club_manager':
        return '/ban-chu-nhiem/thanh-vien';
      case 'school_manager':
        return '/quan-ly-truong/duyet-hoat-dong';
      case 'admin':
        return '/quan-tri/tai-khoan';
      default:
        return '/';
    }
  };

  return (
    <header className="bg-white border-b border-[#DCE6F0] sticky top-0 z-40 shadow-xs">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Logo matching reference */}
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-[#073A68] to-[#0755D9] flex items-center justify-center text-white shadow-sm ring-1 ring-blue-500/20 group-hover:scale-105 transition-transform">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-xl tracking-tight text-[#0755D9] group-hover:text-[#0646B5] transition-colors leading-tight">
                TVU CLUB
              </span>
              <span className="text-[10px] uppercase tracking-wider text-[#64748B] font-semibold">
                ĐH TRÀ VINH
              </span>
            </div>
          </Link>

          {/* Nav links */}
          <nav className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => {
              const isActive =
                link.path === '/'
                  ? location.pathname === '/'
                  : location.pathname.startsWith(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3.5 py-1.5 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#0755D9] bg-[#EAF3FF] font-semibold'
                      : 'text-[#172B4D] hover:text-[#0755D9] hover:bg-gray-50'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right Action buttons */}
        <div className="flex items-center gap-3">
          {role === 'guest' ? (
            <div className="flex items-center gap-2">
              <Link
                to="/dang-nhap"
                className="px-4 py-2 text-sm font-semibold text-[#0755D9] hover:text-[#0646B5] hover:bg-[#EAF3FF] rounded-md transition-colors"
              >
                Đăng nhập
              </Link>
              <Link
                to="/dang-ky"
                className="px-4 py-2 text-sm font-semibold text-white bg-[#0755D9] hover:bg-[#0646B5] rounded-md shadow-xs transition-colors"
              >
                Đăng ký
              </Link>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              {/* Notifications */}
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 text-gray-500 hover:text-[#0755D9] hover:bg-gray-100 rounded-full transition-colors"
                  title="Thông báo"
                >
                  <Bell className="w-5 h-5" />
                  {(pendingRequestsCount > 0 || pendingActivitiesCount > 0) && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white"></span>
                  )}
                </button>

                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-[#DCE6F0] py-2 z-50 text-xs">
                    <div className="px-4 py-2 border-b border-gray-100 font-bold text-gray-800 flex justify-between items-center">
                      <span>Thông báo hệ thống</span>
                      <span className="text-[11px] text-blue-600 font-normal">Đánh dấu đã đọc</span>
                    </div>
                    <div className="max-h-60 overflow-y-auto divide-y divide-gray-100">
                      {pendingRequestsCount > 0 && (
                        <div
                          onClick={() => {
                            setShowNotifications(false);
                            navigate('/ban-chu-nhiem/yeu-cau');
                          }}
                          className="p-3 hover:bg-blue-50/50 cursor-pointer transition-colors"
                        >
                          <p className="font-semibold text-blue-900">
                            Có {pendingRequestsCount} yêu cầu gia nhập CLB đang chờ duyệt
                          </p>
                          <span className="text-[10px] text-gray-400">Vừa xong</span>
                        </div>
                      )}
                      {pendingActivitiesCount > 0 && (
                        <div
                          onClick={() => {
                            setShowNotifications(false);
                            navigate('/quan-ly-truong/duyet-hoat-dong');
                          }}
                          className="p-3 hover:bg-blue-50/50 cursor-pointer transition-colors"
                        >
                          <p className="font-semibold text-blue-900">
                            Có {pendingActivitiesCount} hoạt động đang chờ Ban QL trường phê duyệt
                          </p>
                          <span className="text-[10px] text-gray-400">10 phút trước</span>
                        </div>
                      )}
                      <div className="p-3 hover:bg-gray-50 text-gray-600">
                        <p className="font-medium text-gray-800">
                          Hệ thống TVU CLUB đã cập nhật quy chế điểm rèn luyện năm học 2026 - 2027
                        </p>
                        <span className="text-[10px] text-gray-400">Hôm nay</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Direct Dashboard button */}
              <Link
                to={getDashboardPath()}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#EAF3FF] hover:bg-blue-100 text-[#0755D9] text-xs font-semibold border border-[#B9D4FC] transition-colors"
              >
                <span>Bàn làm việc</span>
              </Link>

              {/* User profile dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-2 p-1.5 pl-2 rounded-full hover:bg-gray-100 border border-transparent hover:border-[#DCE6F0] transition-colors"
                >
                  <img
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
                    alt={currentUser.fullName}
                    className="w-8 h-8 rounded-full object-cover ring-1 ring-blue-400"
                  />
                  <div className="hidden lg:flex flex-col text-left">
                    <span className="text-xs font-bold text-gray-800 leading-tight">
                      {currentUser.fullName}
                    </span>
                    <span className="text-[11px] text-[#0755D9] font-medium">
                      {currentUser.roleTitle}
                    </span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-[#DCE6F0] py-1.5 z-50 text-xs animate-in fade-in duration-100">
                    <div className="px-4 py-2.5 border-b border-gray-100">
                      <p className="font-bold text-gray-800">{currentUser.fullName}</p>
                      <p className="text-gray-500 text-[11px] truncate">{currentUser.email}</p>
                      <span className="inline-block mt-1 px-2 py-0.5 bg-blue-50 text-[#0755D9] font-medium rounded text-[10px] border border-blue-200">
                        {currentUser.roleTitle}
                      </span>
                    </div>

                    <Link
                      to="/sinh-vien"
                      onClick={() => setShowUserMenu(false)}
                      className="flex items-center gap-2.5 px-4 py-2 hover:bg-blue-50 text-gray-700 hover:text-[#0755D9]"
                    >
                      <User className="w-4 h-4 text-gray-400" />
                      <span>Trang cá nhân sinh viên</span>
                    </Link>

                    {role === 'club_manager' && (
                      <Link
                        to="/ban-chu-nhiem/thanh-vien"
                        onClick={() => setShowUserMenu(false)}
                        className="flex items-center gap-2.5 px-4 py-2 hover:bg-blue-50 text-gray-700 hover:text-[#0755D9]"
                      >
                        <Layers className="w-4 h-4 text-gray-400" />
                        <span>Quản lý CLB</span>
                      </Link>
                    )}

                    {role === 'school_manager' && (
                      <Link
                        to="/quan-ly-truong/duyet-hoat-dong"
                        onClick={() => setShowUserMenu(false)}
                        className="flex items-center gap-2.5 px-4 py-2 hover:bg-blue-50 text-gray-700 hover:text-[#0755D9]"
                      >
                        <Layers className="w-4 h-4 text-gray-400" />
                        <span>BQL cấp trường</span>
                      </Link>
                    )}

                    {role === 'admin' && (
                      <Link
                        to="/quan-tri/tai-khoan"
                        onClick={() => setShowUserMenu(false)}
                        className="flex items-center gap-2.5 px-4 py-2 hover:bg-blue-50 text-gray-700 hover:text-[#0755D9]"
                      >
                        <Layers className="w-4 h-4 text-gray-400" />
                        <span>Trang quản trị</span>
                      </Link>
                    )}

                    <div className="border-t border-gray-100 my-1"></div>

                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        logout();
                        navigate('/');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-red-50 text-red-600 text-left"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Đăng xuất</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
