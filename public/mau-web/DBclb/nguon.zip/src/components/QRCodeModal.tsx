import React, { useState } from 'react';
import { Modal } from './Modal';
import { QrCode, CheckCircle2, Camera, RefreshCw } from 'lucide-react';
import { useToast } from '../context/ToastContext';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  activityName: string;
  onScanSuccess: (studentId: string) => void;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({
  isOpen,
  onClose,
  activityName,
  onScanSuccess
}) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'display' | 'camera'>('display');
  const [simulatedMssv, setSimulatedMssv] = useState('110124021'); // Lê Thị C (chưa điểm danh)
  const [scannedSuccess, setScannedSuccess] = useState(false);

  const handleSimulateScan = () => {
    if (!simulatedMssv.trim()) return;
    setScannedSuccess(true);
    setTimeout(() => {
      onScanSuccess(simulatedMssv.trim());
      setScannedSuccess(false);
      showToast(`Đã nhận diện mã QR của sinh viên ${simulatedMssv}!`, 'success');
      onClose();
    }, 900);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Điểm danh bằng mã QR - TVU CLUB"
      maxWidth="md"
    >
      <div className="space-y-4">
        {/* Tab switch */}
        <div className="flex border-b border-gray-200 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('display')}
            className={`pb-2 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'display'
                ? 'border-[#0755D9] text-[#0755D9]'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <QrCode className="w-4 h-4" />
            Mã QR sự kiện (Chiếu máy chiếu)
          </button>
          <button
            onClick={() => setActiveTab('camera')}
            className={`pb-2 px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'camera'
                ? 'border-[#0755D9] text-[#0755D9]'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            <Camera className="w-4 h-4" />
            Mô phỏng máy quét Camera
          </button>
        </div>

        {activeTab === 'display' ? (
          <div className="flex flex-col items-center text-center p-4 bg-slate-50 rounded-xl border border-dashed border-gray-300">
            <span className="text-xs font-bold text-gray-700 mb-1">{activityName}</span>
            <span className="text-[11px] text-gray-500 mb-3">
              Sinh viên dùng ứng dụng TVU CLUB trên điện thoại quét mã dưới đây để điểm danh:
            </span>

            {/* QR SVG */}
            <div className="p-4 bg-white rounded-xl shadow-md border border-gray-200">
              <svg
                className="w-44 h-44 text-[#073A68]"
                viewBox="0 0 100 100"
                fill="currentColor"
              >
                {/* Visual authentic QR Pattern */}
                <rect x="5" y="5" width="25" height="25" rx="3" fill="#073A68" />
                <rect x="9" y="9" width="17" height="17" fill="#FFFFFF" />
                <rect x="13" y="13" width="9" height="9" fill="#0755D9" />

                <rect x="70" y="5" width="25" height="25" rx="3" fill="#073A68" />
                <rect x="74" y="9" width="17" height="17" fill="#FFFFFF" />
                <rect x="78" y="13" width="9" height="9" fill="#0755D9" />

                <rect x="5" y="70" width="25" height="25" rx="3" fill="#073A68" />
                <rect x="9" y="74" width="17" height="17" fill="#FFFFFF" />
                <rect x="13" y="78" width="9" height="9" fill="#0755D9" />

                {/* QR Data Dots */}
                <rect x="35" y="8" width="6" height="6" />
                <rect x="45" y="8" width="6" height="6" />
                <rect x="55" y="8" width="8" height="5" />
                <rect x="35" y="18" width="6" height="6" />
                <rect x="47" y="18" width="6" height="6" />

                <rect x="8" y="36" width="6" height="6" />
                <rect x="18" y="36" width="6" height="6" />
                <rect x="8" y="48" width="6" height="6" />
                <rect x="18" y="48" width="6" height="6" />

                <rect x="35" y="35" width="30" height="30" rx="4" fill="#0755D9" opacity="0.15" />
                <rect x="40" y="40" width="20" height="20" rx="2" fill="#0755D9" />

                <rect x="72" y="36" width="8" height="6" />
                <rect x="85" y="36" width="6" height="6" />
                <rect x="72" y="48" width="6" height="6" />
                <rect x="85" y="48" width="8" height="6" />

                <rect x="35" y="72" width="6" height="6" />
                <rect x="47" y="72" width="8" height="6" />
                <rect x="35" y="84" width="8" height="6" />
                <rect x="48" y="84" width="6" height="6" />
                <rect x="65" y="72" width="6" height="6" />
                <rect x="77" y="72" width="6" height="6" />
                <rect x="88" y="72" width="6" height="6" />
                <rect x="65" y="84" width="10" height="6" />
                <rect x="80" y="84" width="12" height="6" />
              </svg>
            </div>

            <span className="text-[10px] text-gray-400 mt-3">
              Mã bảo mật: <strong>TVU-HD001-TOKEN-2026</strong> (Làm mới sau mỗi 60 giây)
            </span>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="relative aspect-video bg-slate-900 rounded-lg overflow-hidden flex flex-col items-center justify-center text-white p-4">
              <div className="w-36 h-36 border-2 border-emerald-400 rounded-lg relative flex items-center justify-center animate-pulse">
                <div className="absolute top-0 left-0 right-0 h-0.5 bg-emerald-400 shadow-[0_0_8px_#34D399] animate-bounce"></div>
                {scannedSuccess ? (
                  <CheckCircle2 className="w-12 h-12 text-emerald-400" />
                ) : (
                  <Camera className="w-8 h-8 text-slate-400" />
                )}
              </div>
              <p className="text-xs text-slate-300 mt-2">
                {scannedSuccess ? 'Quét thành công!' : 'Đang quét thẻ sinh viên / QR cá nhân...'}
              </p>
            </div>

            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs space-y-2">
              <label className="font-semibold text-blue-900 block">
                Mô phỏng quét mã sinh viên:
              </label>
              <div className="flex gap-2">
                <select
                  value={simulatedMssv}
                  onChange={(e) => setSimulatedMssv(e.target.value)}
                  className="flex-1 bg-white border border-gray-300 rounded px-2.5 py-1.5 text-xs text-gray-800"
                >
                  <option value="110124021">110124021 - Lê Thị C (Chưa điểm danh)</option>
                  <option value="110124078">110124078 - Võ Thị E (Chưa điểm danh)</option>
                  <option value="110124033">110124033 - Nguyễn Thị A (Đã điểm danh)</option>
                </select>
                <button
                  type="button"
                  onClick={handleSimulateScan}
                  disabled={scannedSuccess}
                  className="px-3 py-1.5 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded font-medium text-xs flex items-center gap-1"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${scannedSuccess ? 'animate-spin' : ''}`} />
                  Quét ngay
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2 border-t border-gray-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md text-xs font-semibold"
          >
            Đóng
          </button>
        </div>
      </div>
    </Modal>
  );
};
