import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useClub } from '../context/ClubContext';
import { UserRole } from '../types';
import { useNavigate } from 'react-router-dom';
import {
  GraduationCap,
  Briefcase,
  Building2,
  ShieldCheck,
  Globe,
  RotateCcw,
  Sparkles,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

export const RoleSwitcherBar: React.FC = () => {
  const { role, switchRole, currentUser } = useAuth();
  const { resetToDefaultData } = useClub();
  const navigate = useNavigate();
  const [showGuide, setShowGuide] = useState(false);

  const rolesConfig: { id: UserRole; label: string; icon: any; targetPath: string; desc: string }[] = [
    {
      id: 'guest',
      label: 'Khách',
      icon: Globe,
      targetPath: '/',
      desc: 'Xem công khai danh sách CLB & hoạt động'
    },
    {
      id: 'student',
      label: 'Sinh viên (A)',
      icon: GraduationCap,
      targetPath: '/sinh-vien',
      desc: 'Nguyễn Thị A - Gửi yêu cầu gia nhập, Đăng ký hoạt động, Xem DRL'
    },
    {
      id: 'club_manager',
      label: 'Ban chủ nhiệm (CNTT)',
      icon: Briefcase,
      targetPath: '/ban-chu-nhiem/thanh-vien',
      desc: 'Quản lý thành viên, Tạo hoạt động, Điểm danh QR & Đề xuất DRL'
    },
    {
      id: 'school_manager',
      label: 'Ban QL cấp trường',
      icon: Building2,
      targetPath: '/quan-ly-truong/duyet-hoat-dong',
      desc: 'Duyệt hoạt động, Duyệt thành lập CLB, Xác nhận DRL & Báo cáo'
    },
    {
      id: 'admin',
      label: 'Quản trị viên',
      icon: ShieldCheck,
      targetPath: '/quan-tri/tai-khoan',
      desc: 'Phân quyền tài khoản, Khóa/mở tài khoản'
    }
  ];

  const handleSelectRole = (newRole: UserRole, path: string) => {
    switchRole(newRole);
    navigate(path);
  };

  const handleReset = () => {
    if (window.confirm('Khôi phục toàn bộ dữ liệu mẫu ban đầu của hệ thống TVU CLUB?')) {
      resetToDefaultData();
    }
  };

  return (
    <div className="bg-[#073A68] text-white border-b border-[#052B50] px-4 py-2 sticky top-0 z-50 shadow-md">
      <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-blue-200">
            <Sparkles className="w-4 h-4 text-amber-300" />
            CHUYỂN VAI TRÒ DEMO:
          </span>
          <div className="flex flex-wrap items-center gap-1.5">
            {rolesConfig.map((r) => {
              const Icon = r.icon;
              const isActive = role === r.id;
              return (
                <button
                  key={r.id}
                  onClick={() => handleSelectRole(r.id, r.targetPath)}
                  title={r.desc}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
                    isActive
                      ? 'bg-[#0755D9] text-white ring-2 ring-blue-300 shadow-sm'
                      : 'bg-[#052B50] hover:bg-[#0646B5]/70 text-gray-200 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{r.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-900/60 text-blue-200 border border-blue-700/50">
            Đang đăng nhập: <strong className="text-white font-semibold ml-0.5">{currentUser.fullName}</strong>
          </span>

          <button
            onClick={() => setShowGuide(!showGuide)}
            className="flex items-center gap-1 text-blue-200 hover:text-white underline decoration-dotted"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Quy trình nghiệp vụ</span>
          </button>

          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-2.5 py-1 bg-red-600/80 hover:bg-red-600 text-white rounded font-medium transition-colors"
            title="Khôi phục lại dữ liệu mẫu gốc"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Khôi phục mẫu</span>
          </button>
        </div>
      </div>

      {showGuide && (
        <div className="bg-[#052B50] border-t border-blue-900/60 p-3 mt-2 rounded text-xs text-blue-100 max-w-[1440px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-3 animate-in fade-in duration-150">
          <div className="p-2 rounded bg-[#073A68]/80 border border-blue-800/40">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5" /> 1. Quy trình Gia nhập CLB
            </h4>
            <p className="text-gray-300">
              Sinh viên vào CLB &rarr; Nhấn &quot;Gửi yêu cầu&quot; &rarr; Đổi vai trò sang <strong>BCN CLB</strong> &rarr; Vào &quot;Yêu cầu gia nhập&quot; để Duyệt &rarr; Thành viên được tự động thêm vào CLB &amp; hiển thị ở Trang cá nhân.
            </p>
          </div>
          <div className="p-2 rounded bg-[#073A68]/80 border border-blue-800/40">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-1">
              <Briefcase className="w-3.5 h-3.5" /> 2. Quy trình Hoạt động &amp; Điểm danh
            </h4>
            <p className="text-gray-300">
              BCN tạo hoạt động &rarr; Đổi sang <strong>Ban QL trường</strong> duyệt &rarr; Đổi sang <strong>Sinh viên</strong> bấm Đăng ký &rarr; Đổi lại BCN để Quét QR / Điểm danh thủ công.
            </p>
          </div>
          <div className="p-2 rounded bg-[#073A68]/80 border border-blue-800/40">
            <h4 className="font-bold text-amber-300 mb-1 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5" /> 3. Điểm rèn luyện &amp; Thống kê
            </h4>
            <p className="text-gray-300">
              Sau khi điểm danh &rarr; BCN gửi đề xuất điểm RL &rarr; BQL trường kiểm tra &amp; duyệt &rarr; Sinh viên xem điểm cộng được phê duyệt trong hồ sơ.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
