import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useClub } from '../context/ClubContext';
import {
  Home,
  Users,
  Calendar,
  Newspaper,
  Info,
  User,
  Award,
  Settings,
  Heart,
  FileCheck2,
  QrCode,
  BarChart3,
  ShieldCheck,
  FolderTree,
  FileText,
  Clock,
  Sparkles,
  Inbox
} from 'lucide-react';

interface SidebarProps {
  customRole?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ customRole }) => {
  const { role } = useAuth();
  const { joinRequests, activities, proposals } = useClub();
  const location = useLocation();

  const currentActiveRole = customRole || role;

  const pendingJoinCount = joinRequests.filter((r) => r.status === 'pending').length;
  const pendingActCount = activities.filter((a) => a.status === 'Chờ phê duyệt').length;
  const pendingPropCount = proposals.filter((p) => p.status === 'pending').length;

  const getMenuItems = () => {
    switch (currentActiveRole) {
      case 'student':
        return {
          title: 'Giao diện Sinh viên',
          items: [
            { label: 'Tổng quan', path: '/sinh-vien', icon: Home },
            { label: 'Thông tin cá nhân', path: '/sinh-vien/thong-tin', icon: User },
            { label: 'Câu lạc bộ của tôi', path: '/sinh-vien/cau-lac-bo', icon: Users },
            { label: 'Hoạt động đã đăng ký', path: '/sinh-vien/hoat-dong', icon: Calendar },
            { label: 'Điểm rèn luyện', path: '/sinh-vien/diem-ren-luyen', icon: Award },
            { label: 'Đề xuất CLB mới', path: '/sinh-vien/de-xuat-clb', icon: Sparkles },
            { label: 'Cài đặt', path: '/sinh-vien/cai-dat', icon: Settings }
          ]
        };

      case 'club_manager':
        return {
          title: 'Quản lý CLB (CNTT)',
          items: [
            { label: 'Thông tin CLB', path: '/ban-chu-nhiem/thong-tin', icon: Info },
            { label: 'Thành viên', path: '/ban-chu-nhiem/thanh-vien', icon: Users },
            { label: 'Yêu cầu gia nhập', path: '/ban-chu-nhiem/yeu-cau', icon: Inbox, badge: pendingJoinCount },
            { label: 'Nhiệm kỳ - Chức vụ', path: '/ban-chu-nhiem/nhiem-ky', icon: Clock },
            { label: 'Hoạt động', path: '/ban-chu-nhiem/hoat-dong', icon: Calendar },
            { label: 'Điểm danh', path: '/ban-chu-nhiem/diem-danh/HD001', icon: QrCode },
            { label: 'Đề xuất điểm RL', path: '/ban-chu-nhiem/diem-ren-luyen', icon: Award },
            { label: 'Tin tức', path: '/ban-chu-nhiem/tin-tuc', icon: Newspaper },
            { label: 'Thống kê', path: '/ban-chu-nhiem/thong-ke', icon: BarChart3 }
          ]
        };

      case 'school_manager':
        return {
          title: 'Ban Quản lý Trường',
          items: [
            { label: 'Duyệt đề xuất CLB', path: '/quan-ly-truong/duyet-clb', icon: Sparkles, badge: pendingPropCount },
            { label: 'Duyệt hoạt động', path: '/quan-ly-truong/duyet-hoat-dong', icon: FileCheck2, badge: pendingActCount },
            { label: 'Xác nhận điểm RL', path: '/quan-ly-truong/xac-nhan-diem-rl', icon: Award },
            { label: 'Quản lý CLB', path: '/quan-ly-truong/quan-ly-clb', icon: Users },
            { label: 'Báo cáo thống kê', path: '/quan-ly-truong/bao-cao', icon: BarChart3 }
          ]
        };

      case 'admin':
        return {
          title: 'Quản trị hệ thống',
          items: [
            { label: 'Quản lý tài khoản', path: '/quan-tri/tai-khoan', icon: ShieldCheck },
            { label: 'Quản lý danh mục', path: '/quan-tri/danh-muc', icon: FolderTree },
            { label: 'Nhật ký hệ thống', path: '/quan-tri/nhat-ky', icon: FileText }
          ]
        };

      case 'guest':
      default:
        return {
          title: 'Danh mục',
          items: [
            { label: 'Trang chủ', path: '/', icon: Home },
            { label: 'Câu lạc bộ', path: '/cau-lac-bo', icon: Users },
            { label: 'Hoạt động', path: '/hoat-dong', icon: Calendar },
            { label: 'Tin tức', path: '/tin-tuc', icon: Newspaper },
            { label: 'Giới thiệu', path: '/gioi-thieu', icon: Info }
          ]
        };
    }
  };

  const menu = getMenuItems();

  return (
    <aside className="w-56 shrink-0 bg-white border-r border-[#DCE6F0] min-h-[calc(100vh-105px)] p-3 flex flex-col justify-between">
      <div>
        <div className="px-3 py-2 mb-2 text-[11px] font-bold uppercase tracking-wider text-[#64748B] flex items-center justify-between">
          <span>{menu.title}</span>
        </div>

        <nav className="space-y-1">
          {menu.items.map((item) => {
            const Icon = item.icon;
            const isActive =
              item.path === '/'
                ? location.pathname === '/'
                : location.pathname === item.path ||
                  (item.path !== '/' && location.pathname.startsWith(item.path));

            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={`flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-[#EAF3FF] text-[#0755D9] font-semibold border-l-3 border-[#0755D9] shadow-2xs'
                    : 'text-[#172B4D] hover:text-[#0755D9] hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-[#0755D9]' : 'text-[#64748B]'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge > 0 && (
                  <span className="ml-2 px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white shrink-0">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* University info footer snippet */}
      <div className="p-3 bg-[#F5F8FC] rounded-lg border border-[#DCE6F0]/70 text-[11px] text-[#64748B]">
        <p className="font-semibold text-[#073A68]">TVU CLUB SYSTEM</p>
        <p className="text-[10px] text-gray-500 mt-0.5">Đại học Trà Vinh</p>
        <div className="mt-1.5 pt-1.5 border-t border-gray-200 flex items-center justify-between text-[10px]">
          <span>Phiên bản v2.6</span>
          <span className="text-emerald-600 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Online
          </span>
        </div>
      </div>
    </aside>
  );
};
