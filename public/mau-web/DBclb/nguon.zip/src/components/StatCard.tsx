import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  colorScheme?: 'blue' | 'emerald' | 'amber' | 'rose' | 'indigo' | 'orange';
  subText?: string;
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  icon: Icon,
  colorScheme = 'blue',
  subText,
  onClick
}) => {
  const colorMap = {
    blue: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-[#EAF3FF]',
      iconColor: 'text-[#0755D9]',
      valueColor: 'text-[#073A68]'
    },
    emerald: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-[#DCFCE7]',
      iconColor: 'text-[#16A34A]',
      valueColor: 'text-[#14532D]'
    },
    amber: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-[#FEF3C7]',
      iconColor: 'text-[#F59E0B]',
      valueColor: 'text-[#92400E]'
    },
    rose: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-[#FEE2E2]',
      iconColor: 'text-[#EF4444]',
      valueColor: 'text-[#991B1B]'
    },
    indigo: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-indigo-50',
      iconColor: 'text-indigo-600',
      valueColor: 'text-indigo-900'
    },
    orange: {
      bg: 'bg-white',
      border: 'border-[#DCE6F0]',
      iconBg: 'bg-orange-50',
      iconColor: 'text-orange-600',
      valueColor: 'text-orange-950'
    }
  };

  const scheme = colorMap[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`${scheme.bg} p-4 rounded-xl border ${scheme.border} shadow-xs flex items-center gap-3.5 transition-all ${
        onClick ? 'cursor-pointer hover:shadow-md hover:border-blue-300' : ''
      }`}
    >
      <div className={`w-12 h-12 rounded-xl ${scheme.iconBg} flex items-center justify-center shrink-0`}>
        <Icon className={`w-6 h-6 ${scheme.iconColor}`} />
      </div>
      <div className="flex-1 min-w-0">
        <span className="block text-xs font-medium text-gray-500 truncate">{label}</span>
        <span className={`text-2xl font-extrabold ${scheme.valueColor} tracking-tight leading-tight`}>
          {value}
        </span>
        {subText && <span className="block text-[11px] text-gray-400 mt-0.5">{subText}</span>}
      </div>
    </div>
  );
};
