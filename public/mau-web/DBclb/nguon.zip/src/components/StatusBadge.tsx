import React from 'react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  let colorStyles = 'bg-gray-100 text-gray-700 border-gray-200';

  const normalized = status.toLowerCase();

  if (
    normalized.includes('đang hoạt động') ||
    normalized.includes('đã phê duyệt') ||
    normalized.includes('đã điểm danh') ||
    normalized.includes('hoạt động') ||
    normalized.includes('thành viên') ||
    normalized.includes('approved') ||
    normalized.includes('active')
  ) {
    colorStyles = 'bg-[#DCFCE7] text-[#15803D] border-[#86EFAC]/50';
  } else if (
    normalized.includes('chờ phê duyệt') ||
    normalized.includes('chưa điểm danh') ||
    normalized.includes('tạm dừng') ||
    normalized.includes('chờ duyệt') ||
    normalized.includes('pending') ||
    normalized.includes('đề xuất')
  ) {
    colorStyles = 'bg-[#FEF3C7] text-[#B45309] border-[#FCD34D]/50';
  } else if (
    normalized.includes('từ chối') ||
    normalized.includes('khóa') ||
    normalized.includes('đã rời') ||
    normalized.includes('hủy') ||
    normalized.includes('rejected') ||
    normalized.includes('locked')
  ) {
    colorStyles = 'bg-[#FEE2E2] text-[#B91C1C] border-[#FCA5A5]/50';
  } else if (
    normalized.includes('đang diễn ra') ||
    normalized.includes('xử lý') ||
    normalized.includes('processing')
  ) {
    colorStyles = 'bg-[#EAF3FF] text-[#0755D9] border-[#B9D4FC]';
  } else if (
    normalized.includes('đã kết thúc') ||
    normalized.includes('hoàn thành') ||
    normalized.includes('completed')
  ) {
    colorStyles = 'bg-[#F1F5F9] text-[#64748B] border-[#CBD5E1]';
  }

  const padding = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full border ${padding} ${colorStyles} whitespace-nowrap`}
    >
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-70"></span>
      {status}
    </span>
  );
};
