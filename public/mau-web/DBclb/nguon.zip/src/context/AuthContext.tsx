import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserRole, UserAccount } from '../types';
import { INITIAL_ACCOUNTS } from '../data/initialData';
import { useToast } from './ToastContext';

interface AuthContextType {
  role: UserRole;
  currentUser: UserAccount;
  switchRole: (newRole: UserRole) => void;
  login: (username: string, password?: string) => boolean;
  logout: () => void;
  updateStudentProfile: (updatedData: Partial<UserAccount>) => void;
  allAccounts: UserAccount[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const ROLE_PROFILES: Record<UserRole, UserAccount> = {
  guest: {
    id: 'GUEST',
    username: 'khach',
    fullName: 'Khách tham quan',
    email: 'khach@tvu.edu.vn',
    role: 'guest',
    roleTitle: 'Khách',
    status: 'active',
    createdAt: '2026-01-01'
  },
  student: INITIAL_ACCOUNTS[0], // Nguyễn Thị A (110124033, DA24TTA)
  club_manager: INITIAL_ACCOUNTS[2], // Trần Minh Quân (CLB001 - CNTT)
  school_manager: INITIAL_ACCOUNTS[3], // ThS. Nguyễn Văn Đoàn (BQL cấp trường)
  admin: INITIAL_ACCOUNTS[4] // Quản trị viên
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { showToast } = useToast();
  const [role, setRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem('tvu_club_demo_role');
    return (saved as UserRole) || 'student';
  });

  const [currentUser, setCurrentUser] = useState<UserAccount>(() => {
    const savedRole = (localStorage.getItem('tvu_club_demo_role') as UserRole) || 'student';
    const savedUser = localStorage.getItem('tvu_club_demo_user');
    if (savedUser) {
      try {
        return JSON.parse(savedUser);
      } catch {
        return ROLE_PROFILES[savedRole];
      }
    }
    return ROLE_PROFILES[savedRole];
  });

  useEffect(() => {
    localStorage.setItem('tvu_club_demo_role', role);
    localStorage.setItem('tvu_club_demo_user', JSON.stringify(currentUser));
  }, [role, currentUser]);

  const switchRole = (newRole: UserRole) => {
    setRole(newRole);
    const targetUser = ROLE_PROFILES[newRole];
    setCurrentUser(targetUser);
    showToast(`Đã chuyển vai trò demo sang: ${targetUser.roleTitle} (${targetUser.fullName})`, 'info');
  };

  const login = (username: string): boolean => {
    const found = INITIAL_ACCOUNTS.find(
      (a) => a.username.toLowerCase() === username.trim().toLowerCase() || a.email.toLowerCase() === username.trim().toLowerCase()
    );
    if (found) {
      setRole(found.role);
      setCurrentUser(found);
      showToast(`Đăng nhập thành công! Xin chào ${found.fullName}`, 'success');
      return true;
    }
    // Default fallback to student demo
    const defaultStudent = ROLE_PROFILES.student;
    setRole('student');
    setCurrentUser(defaultStudent);
    showToast(`Đăng nhập với vai trò Sinh viên: ${defaultStudent.fullName}`, 'success');
    return true;
  };

  const logout = () => {
    setRole('guest');
    setCurrentUser(ROLE_PROFILES.guest);
    showToast('Đã đăng xuất tài khoản', 'info');
  };

  const updateStudentProfile = (updatedData: Partial<UserAccount>) => {
    setCurrentUser((prev) => {
      const updated = { ...prev, ...updatedData };
      return updated;
    });
    showToast('Cập nhật hồ sơ sinh viên thành công!', 'success');
  };

  return (
    <AuthContext.Provider
      value={{
        role,
        currentUser,
        switchRole,
        login,
        logout,
        updateStudentProfile,
        allAccounts: INITIAL_ACCOUNTS
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
