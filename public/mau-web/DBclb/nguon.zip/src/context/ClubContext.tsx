import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Club,
  ClubMember,
  Activity,
  ActivityRegistration,
  JoinRequest,
  TrainingPointRecord,
  UserAccount,
  ClubTerm,
  ClubProposal,
  NewsArticle
} from '../types';
import {
  INITIAL_CLUBS,
  INITIAL_MEMBERS,
  INITIAL_ACTIVITIES,
  INITIAL_REGISTRATIONS,
  INITIAL_JOIN_REQUESTS,
  INITIAL_TRAINING_POINTS,
  INITIAL_ACCOUNTS,
  INITIAL_TERMS,
  INITIAL_CLUB_PROPOSALS,
  INITIAL_NEWS
} from '../data/initialData';
import { useToast } from './ToastContext';

interface ClubContextType {
  clubs: Club[];
  members: ClubMember[];
  activities: Activity[];
  registrations: ActivityRegistration[];
  joinRequests: JoinRequest[];
  trainingPoints: TrainingPointRecord[];
  accounts: UserAccount[];
  terms: ClubTerm[];
  proposals: ClubProposal[];
  news: NewsArticle[];

  // Join club workflow
  requestJoinClub: (clubId: string, studentId: string, fullName: string, className: string, email: string, phone: string, message: string, desiredDepartment: string) => boolean;
  approveJoinRequest: (requestId: string) => void;
  rejectJoinRequest: (requestId: string, reason: string) => void;
  leaveClub: (clubId: string, studentId: string) => void;
  hasUserRequestedJoin: (clubId: string, studentId: string) => JoinRequest | undefined;
  isUserMember: (clubId: string, studentId: string) => boolean;

  // Activities workflow
  createActivity: (activityData: Omit<Activity, 'id' | 'registeredCount' | 'submittedDate'>) => void;
  approveActivity: (activityId: string, approverName: string) => void;
  rejectActivity: (activityId: string, reason: string) => void;
  registerActivity: (activityId: string, studentId: string, fullName: string, className: string, email: string) => boolean;
  cancelActivityRegistration: (activityId: string, studentId: string) => void;
  isRegisteredForActivity: (activityId: string, studentId: string) => boolean;

  // Attendance workflow
  recordAttendance: (registrationId: string, method?: 'manual' | 'qr', recorderName?: string) => void;
  cancelAttendance: (registrationId: string) => void;

  // Training points workflow
  proposeTrainingPoints: (activityId: string, studentId: string, fullName: string, className: string, points: number) => void;
  approveTrainingPoints: (pointId: string, approverName: string) => void;
  rejectTrainingPoints: (pointId: string) => void;

  // Members management
  addMember: (member: Omit<ClubMember, 'id'>) => void;
  updateMemberStatus: (memberId: string, status: 'Đang hoạt động' | 'Tạm dừng' | 'Đã rời') => void;
  removeMember: (memberId: string) => void;

  // Club proposal workflow
  proposeNewClub: (proposalData: Omit<ClubProposal, 'id' | 'submittedDate' | 'status'>) => void;
  approveClubProposal: (proposalId: string, reviewerName: string) => void;
  rejectClubProposal: (proposalId: string, reason: string) => void;

  // Accounts management
  updateAccount: (accountId: string, data: Partial<UserAccount>) => void;
  addAccount: (accountData: Omit<UserAccount, 'id' | 'createdAt'>) => void;
  toggleAccountStatus: (accountId: string) => void;

  // Reset demo
  resetToDefaultData: () => void;
}

const ClubContext = createContext<ClubContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CLUBS: 'tvu_club_v1_clubs',
  MEMBERS: 'tvu_club_v1_members',
  ACTIVITIES: 'tvu_club_v1_activities',
  REGISTRATIONS: 'tvu_club_v1_registrations',
  JOIN_REQUESTS: 'tvu_club_v1_join_requests',
  TRAINING_POINTS: 'tvu_club_v1_training_points',
  ACCOUNTS: 'tvu_club_v1_accounts',
  TERMS: 'tvu_club_v1_terms',
  PROPOSALS: 'tvu_club_v1_proposals',
  NEWS: 'tvu_club_v1_news'
};

function getStorage<T>(key: string, fallback: T): T {
  const item = localStorage.getItem(key);
  if (!item) return fallback;
  try {
    return JSON.parse(item);
  } catch {
    return fallback;
  }
}

export const ClubProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { showToast } = useToast();

  const [clubs, setClubs] = useState<Club[]>(() => getStorage(STORAGE_KEYS.CLUBS, INITIAL_CLUBS));
  const [members, setMembers] = useState<ClubMember[]>(() => getStorage(STORAGE_KEYS.MEMBERS, INITIAL_MEMBERS));
  const [activities, setActivities] = useState<Activity[]>(() => getStorage(STORAGE_KEYS.ACTIVITIES, INITIAL_ACTIVITIES));
  const [registrations, setRegistrations] = useState<ActivityRegistration[]>(() => getStorage(STORAGE_KEYS.REGISTRATIONS, INITIAL_REGISTRATIONS));
  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>(() => getStorage(STORAGE_KEYS.JOIN_REQUESTS, INITIAL_JOIN_REQUESTS));
  const [trainingPoints, setTrainingPoints] = useState<TrainingPointRecord[]>(() => getStorage(STORAGE_KEYS.TRAINING_POINTS, INITIAL_TRAINING_POINTS));
  const [accounts, setAccounts] = useState<UserAccount[]>(() => getStorage(STORAGE_KEYS.ACCOUNTS, INITIAL_ACCOUNTS));
  const [terms, setTerms] = useState<ClubTerm[]>(() => getStorage(STORAGE_KEYS.TERMS, INITIAL_TERMS));
  const [proposals, setProposals] = useState<ClubProposal[]>(() => getStorage(STORAGE_KEYS.PROPOSALS, INITIAL_CLUB_PROPOSALS));
  const [news] = useState<NewsArticle[]>(() => getStorage(STORAGE_KEYS.NEWS, INITIAL_NEWS));

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CLUBS, JSON.stringify(clubs));
  }, [clubs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(activities));
  }, [activities]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REGISTRATIONS, JSON.stringify(registrations));
  }, [registrations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.JOIN_REQUESTS, JSON.stringify(joinRequests));
  }, [joinRequests]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRAINING_POINTS, JSON.stringify(trainingPoints));
  }, [trainingPoints]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROPOSALS, JSON.stringify(proposals));
  }, [proposals]);

  // Join club workflow
  const requestJoinClub = (
    clubId: string,
    studentId: string,
    fullName: string,
    className: string,
    email: string,
    phone: string,
    message: string,
    desiredDepartment: string
  ): boolean => {
    // Check if already a member
    if (members.some((m) => m.clubId === clubId && m.studentId === studentId && m.status === 'Đang hoạt động')) {
      showToast('Bạn đã là thành viên chính thức của câu lạc bộ này!', 'warning');
      return false;
    }
    // Check if pending request exists
    if (joinRequests.some((r) => r.clubId === clubId && r.studentId === studentId && r.status === 'pending')) {
      showToast('Bạn đã có yêu cầu đang chờ Ban chủ nhiệm xét duyệt!', 'warning');
      return false;
    }

    const club = clubs.find((c) => c.id === clubId);
    const newRequest: JoinRequest = {
      id: `REQ${Date.now()}`,
      clubId,
      clubName: club?.name || 'Câu lạc bộ',
      studentId,
      fullName,
      className,
      email,
      phone,
      requestDate: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      message,
      desiredDepartment: desiredDepartment || 'Ban Nội dung',
      status: 'pending'
    };

    setJoinRequests((prev) => [newRequest, ...prev]);
    showToast('Đã gửi yêu cầu tham gia CLB thành công! Vui lòng chờ BCN duyệt.', 'success');
    return true;
  };

  const approveJoinRequest = (requestId: string) => {
    const req = joinRequests.find((r) => r.id === requestId);
    if (!req) return;

    // Update request status
    setJoinRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? { ...r, status: 'approved', processedDate: new Date().toLocaleDateString('vi-VN') }
          : r
      )
    );

    // Add to members list
    const newMember: ClubMember = {
      id: `MB${Date.now()}`,
      clubId: req.clubId,
      studentId: req.studentId,
      fullName: req.fullName,
      className: req.className,
      department: req.desiredDepartment || 'Ban Thành viên',
      role: 'Thành viên',
      joinedDate: new Date().toLocaleDateString('vi-VN'),
      status: 'Đang hoạt động',
      email: req.email,
      phone: req.phone
    };

    setMembers((prev) => [...prev, newMember]);
    showToast(`Đã duyệt yêu cầu của sinh viên ${req.fullName} thành công!`, 'success');
  };

  const rejectJoinRequest = (requestId: string, reason: string) => {
    setJoinRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'rejected',
              rejectionReason: reason || 'Chưa phù hợp với đợt tuyển hiện tại',
              processedDate: new Date().toLocaleDateString('vi-VN')
            }
          : r
      )
    );
    showToast('Đã từ chối yêu cầu tham gia', 'info');
  };

  const leaveClub = (clubId: string, studentId: string) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.clubId === clubId && m.studentId === studentId ? { ...m, status: 'Đã rời' } : m
      )
    );
    showToast('Đã rời khỏi câu lạc bộ', 'info');
  };

  const hasUserRequestedJoin = (clubId: string, studentId: string) => {
    return joinRequests.find((r) => r.clubId === clubId && r.studentId === studentId && r.status === 'pending');
  };

  const isUserMember = (clubId: string, studentId: string) => {
    return members.some((m) => m.clubId === clubId && m.studentId === studentId && m.status === 'Đang hoạt động');
  };

  // Activities workflow
  const createActivity = (activityData: Omit<Activity, 'id' | 'registeredCount' | 'submittedDate'>) => {
    const newId = `HD00${activities.length + 1}`;
    const newActivity: Activity = {
      ...activityData,
      id: newId,
      registeredCount: 0,
      submittedDate: new Date().toLocaleDateString('vi-VN')
    };
    setActivities((prev) => [newActivity, ...prev]);
    showToast(`Đã tạo đề xuất hoạt động "${newActivity.name}". Đang chờ BQL cấp trường duyệt!`, 'success');
  };

  const approveActivity = (activityId: string, approverName: string) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === activityId
          ? {
              ...a,
              status: 'Đã phê duyệt',
              approvalDate: new Date().toLocaleDateString('vi-VN'),
              approvedBy: approverName || 'Ban Quản lý cấp trường'
            }
          : a
      )
    );
    showToast('Đã phê duyệt hoạt động! Hoạt động hiện đã mở đăng ký cho sinh viên.', 'success');
  };

  const rejectActivity = (activityId: string, reason: string) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === activityId
          ? {
              ...a,
              status: 'Từ chối',
              rejectionReason: reason || 'Nội dung chưa phù hợp'
            }
          : a
      )
    );
    showToast('Đã từ chối hoạt động đề xuất', 'info');
  };

  const registerActivity = (
    activityId: string,
    studentId: string,
    fullName: string,
    className: string,
    email: string
  ): boolean => {
    const act = activities.find((a) => a.id === activityId);
    if (!act) {
      showToast('Hoạt động không tồn tại!', 'error');
      return false;
    }
    if (act.status !== 'Đã phê duyệt' && act.status !== 'Đang diễn ra') {
      showToast('Hoạt động chưa được phê duyệt hoặc đã kết thúc!', 'warning');
      return false;
    }
    if (act.registeredCount >= act.maxCapacity) {
      showToast('Hoạt động đã đủ số lượng đăng ký tối đa!', 'warning');
      return false;
    }
    const already = registrations.find(
      (r) => r.activityId === activityId && r.studentId === studentId && r.status === 'registered'
    );
    if (already) {
      showToast('Bạn đã đăng ký tham gia hoạt động này rồi!', 'warning');
      return false;
    }

    const newReg: ActivityRegistration = {
      id: `REG${Date.now()}`,
      activityId,
      activityName: act.name,
      clubName: act.clubName,
      studentId,
      fullName,
      className,
      email,
      registeredAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      status: 'registered',
      attended: false
    };

    setRegistrations((prev) => [newReg, ...prev]);
    setActivities((prev) =>
      prev.map((a) => (a.id === activityId ? { ...a, registeredCount: a.registeredCount + 1 } : a))
    );
    showToast(`Đăng ký thành công hoạt động "${act.name}"!`, 'success');
    return true;
  };

  const cancelActivityRegistration = (activityId: string, studentId: string) => {
    setRegistrations((prev) =>
      prev.map((r) =>
        r.activityId === activityId && r.studentId === studentId
          ? { ...r, status: 'cancelled' }
          : r
      )
    );
    setActivities((prev) =>
      prev.map((a) =>
        a.id === activityId && a.registeredCount > 0
          ? { ...a, registeredCount: a.registeredCount - 1 }
          : a
      )
    );
    showToast('Đã hủy đăng ký hoạt động', 'info');
  };

  const isRegisteredForActivity = (activityId: string, studentId: string) => {
    return registrations.some(
      (r) => r.activityId === activityId && r.studentId === studentId && r.status === 'registered'
    );
  };

  // Attendance workflow
  const recordAttendance = (
    registrationId: string,
    method: 'manual' | 'qr' = 'manual',
    recorderName: string = 'Ban chủ nhiệm CLB'
  ) => {
    const nowTime = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    setRegistrations((prev) =>
      prev.map((r) =>
        r.id === registrationId
          ? {
              ...r,
              attended: true,
              attendedAt: nowTime,
              attendanceMethod: method,
              attendedBy: recorderName
            }
          : r
      )
    );
    showToast(`Điểm danh thành công (${method === 'qr' ? 'Quét QR' : 'Thủ công'})`, 'success');
  };

  const cancelAttendance = (registrationId: string) => {
    setRegistrations((prev) =>
      prev.map((r) =>
        r.id === registrationId
          ? { ...r, attended: false, attendedAt: undefined, attendanceMethod: undefined, attendedBy: undefined }
          : r
      )
    );
    showToast('Đã hủy điểm danh', 'info');
  };

  // Training points workflow
  const proposeTrainingPoints = (
    activityId: string,
    studentId: string,
    fullName: string,
    className: string,
    points: number
  ) => {
    const act = activities.find((a) => a.id === activityId);
    const newRecord: TrainingPointRecord = {
      id: `DRL${Date.now()}`,
      studentId,
      fullName,
      className,
      activityId,
      activityName: act?.name || 'Hoạt động CLB',
      clubName: act?.clubName || 'CLB TVU',
      semester: 'Học kỳ 1',
      academicYear: '2026 - 2027',
      points,
      status: 'proposed',
      proposedDate: new Date().toLocaleDateString('vi-VN')
    };

    setTrainingPoints((prev) => [newRecord, ...prev]);
    showToast(`Đã đề xuất ${points} điểm rèn luyện cho sinh viên ${fullName}! Chờ BQL duyệt.`, 'success');
  };

  const approveTrainingPoints = (pointId: string, approverName: string) => {
    setTrainingPoints((prev) =>
      prev.map((tp) =>
        tp.id === pointId
          ? {
              ...tp,
              status: 'approved',
              approvedDate: new Date().toLocaleDateString('vi-VN'),
              approvedBy: approverName || 'Ban Quản lý cấp trường'
            }
          : tp
      )
    );
    showToast('Đã phê duyệt cộng điểm rèn luyện cho sinh viên!', 'success');
  };

  const rejectTrainingPoints = (pointId: string) => {
    setTrainingPoints((prev) =>
      prev.map((tp) => (tp.id === pointId ? { ...tp, status: 'rejected' } : tp))
    );
    showToast('Đã từ chối điểm rèn luyện đề xuất', 'info');
  };

  // Member management
  const addMember = (member: Omit<ClubMember, 'id'>) => {
    const newMember: ClubMember = {
      ...member,
      id: `MB${Date.now()}`
    };
    setMembers((prev) => [...prev, newMember]);
    showToast(`Đã thêm thành viên ${member.fullName} vào CLB`, 'success');
  };

  const updateMemberStatus = (memberId: string, status: 'Đang hoạt động' | 'Tạm dừng' | 'Đã rời') => {
    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, status } : m))
    );
    showToast(`Đã cập nhật trạng thái thành viên: ${status}`, 'info');
  };

  const removeMember = (memberId: string) => {
    setMembers((prev) => prev.filter((m) => m.id !== memberId));
    showToast('Đã xóa thành viên khỏi danh sách', 'info');
  };

  // Club proposal
  const proposeNewClub = (proposalData: Omit<ClubProposal, 'id' | 'submittedDate' | 'status'>) => {
    const newProp: ClubProposal = {
      ...proposalData,
      id: `PROP${Date.now()}`,
      submittedDate: new Date().toLocaleDateString('vi-VN'),
      status: 'pending'
    };
    setProposals((prev) => [newProp, ...prev]);
    showToast('Đã gửi đề xuất thành lập CLB mới đến Ban Quản lý cấp trường!', 'success');
  };

  const approveClubProposal = (proposalId: string, reviewerName: string) => {
    const prop = proposals.find((p) => p.id === proposalId);
    if (!prop) return;

    setProposals((prev) =>
      prev.map((p) =>
        p.id === proposalId
          ? { ...p, status: 'approved', reviewedBy: reviewerName, reviewNote: 'Đồng ý chủ trương thành lập' }
          : p
      )
    );

    // Create new club entry
    const newClubId = `CLB00${clubs.length + 1}`;
    const newClub: Club = {
      id: newClubId,
      name: prop.clubName,
      code: newClubId,
      category: prop.category as any,
      type: 'CLB Sinh viên',
      establishedDate: new Date().toLocaleDateString('vi-VN'),
      status: 'Đang hoạt động',
      email: `${newClubId.toLowerCase()}@tvu.edu.vn`,
      phone: '0294.3855.200',
      description: prop.goal,
      coverImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
      yearsOperating: 1,
      leaderName: prop.proposerName,
      leaderStudentId: prop.proposedByStudentId
    };

    setClubs((prev) => [...prev, newClub]);
    showToast(`Đã duyệt thành lập CLB "${prop.clubName}" thành công!`, 'success');
  };

  const rejectClubProposal = (proposalId: string, reason: string) => {
    setProposals((prev) =>
      prev.map((p) =>
        p.id === proposalId
          ? { ...p, status: 'rejected', reviewNote: reason || 'Chưa đủ điều kiện thành lập' }
          : p
      )
    );
    showToast('Đã từ chối đề xuất thành lập CLB', 'info');
  };

  // Accounts management
  const updateAccount = (accountId: string, data: Partial<UserAccount>) => {
    setAccounts((prev) =>
      prev.map((acc) => (acc.id === accountId ? { ...acc, ...data } : acc))
    );
    showToast('Cập nhật tài khoản thành công', 'success');
  };

  const toggleAccountStatus = (accountId: string) => {
    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === accountId
          ? { ...acc, status: acc.status === 'active' ? 'locked' : 'active' }
          : acc
      )
    );
    showToast('Đã thay đổi trạng thái kích hoạt tài khoản', 'info');
  };

  const addAccount = (accountData: Omit<UserAccount, 'id' | 'createdAt'>) => {
    const newAcc: UserAccount = {
      ...accountData,
      id: `ACC00${accounts.length + 1}`,
      createdAt: new Date().toLocaleDateString('vi-VN')
    };
    setAccounts((prev) => [...prev, newAcc]);
    showToast(`Đã tạo tài khoản mới: ${newAcc.username}`, 'success');
  };

  // Reset to default data
  const resetToDefaultData = () => {
    setClubs(INITIAL_CLUBS);
    setMembers(INITIAL_MEMBERS);
    setActivities(INITIAL_ACTIVITIES);
    setRegistrations(INITIAL_REGISTRATIONS);
    setJoinRequests(INITIAL_JOIN_REQUESTS);
    setTrainingPoints(INITIAL_TRAINING_POINTS);
    setAccounts(INITIAL_ACCOUNTS);
    setTerms(INITIAL_TERMS);
    setProposals(INITIAL_CLUB_PROPOSALS);

    localStorage.removeItem(STORAGE_KEYS.CLUBS);
    localStorage.removeItem(STORAGE_KEYS.MEMBERS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVITIES);
    localStorage.removeItem(STORAGE_KEYS.REGISTRATIONS);
    localStorage.removeItem(STORAGE_KEYS.JOIN_REQUESTS);
    localStorage.removeItem(STORAGE_KEYS.TRAINING_POINTS);
    localStorage.removeItem(STORAGE_KEYS.ACCOUNTS);
    localStorage.removeItem(STORAGE_KEYS.TERMS);
    localStorage.removeItem(STORAGE_KEYS.PROPOSALS);

    showToast('Đã khôi phục dữ liệu mẫu hệ thống ban đầu!', 'info');
  };

  return (
    <ClubContext.Provider
      value={{
        clubs,
        members,
        activities,
        registrations,
        joinRequests,
        trainingPoints,
        accounts,
        terms,
        proposals,
        news,
        requestJoinClub,
        approveJoinRequest,
        rejectJoinRequest,
        leaveClub,
        hasUserRequestedJoin,
        isUserMember,
        createActivity,
        approveActivity,
        rejectActivity,
        registerActivity,
        cancelActivityRegistration,
        isRegisteredForActivity,
        recordAttendance,
        cancelAttendance,
        proposeTrainingPoints,
        approveTrainingPoints,
        rejectTrainingPoints,
        addMember,
        updateMemberStatus,
        removeMember,
        proposeNewClub,
        approveClubProposal,
        rejectClubProposal,
        updateAccount,
        addAccount,
        toggleAccountStatus,
        resetToDefaultData
      }}
    >
      {children}
    </ClubContext.Provider>
  );
};

export const useClub = () => {
  const context = useContext(ClubContext);
  if (!context) {
    throw new Error('useClub must be used within a ClubProvider');
  }
  return context;
};
