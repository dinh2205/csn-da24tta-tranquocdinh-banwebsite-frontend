import React, { useState } from 'react';
import { StatCard } from '../components/StatCard';
import { useToast } from '../context/ToastContext';
import {
  Users,
  Calendar,
  Award,
  Layers,
  Download,
  Filter,
  TrendingUp,
  FileSpreadsheet
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';

export const BaoCaoToanTruong: React.FC = () => {
  const { showToast } = useToast();

  const [selectedYear, setSelectedYear] = useState('2026 - 2027');
  const [selectedSemester, setSelectedSemester] = useState('Học kỳ 1');
  const [selectedField, setSelectedField] = useState('Tất cả');

  // Chart 1: Số lượng hoạt động theo tháng matching Screen 11
  const monthlyActivityData = [
    { month: 'T1', count: 8 },
    { month: 'T2', count: 6 },
    { month: 'T3', count: 14 },
    { month: 'T4', count: 18 },
    { month: 'T5', count: 12 },
    { month: 'T6', count: 9 },
    { month: 'T7', count: 5 },
    { month: 'T8', count: 11 },
    { month: 'T9', count: 24 },
    { month: 'T10', count: 28 },
    { month: 'T11', count: 20 },
    { month: 'T12', count: 15 }
  ];

  // Chart 2: Tỷ lệ câu lạc bộ theo lĩnh vực matching Screen 11
  const categoryPieData = [
    { name: 'Học thuật', value: 35, color: '#0755D9' },
    { name: 'Văn hóa - Nghệ thuật', value: 20, color: '#F59E0B' },
    { name: 'Tình nguyện', value: 20, color: '#16A34A' },
    { name: 'Thể thao', value: 15, color: '#9333EA' },
    { name: 'Truyền thông', value: 10, color: '#0284C7' }
  ];

  const handleExportExcel = () => {
    const csv =
      'BÁO CÁO THỐNG KÊ HOẠT ĐỘNG CLB SINH VIÊN ĐẠI HỌC TRÀ VINH\n' +
      `Năm học: ${selectedYear} - ${selectedSemester}\n\n` +
      'Chỉ số,Số lượng\n' +
      'Tổng số câu lạc bộ,28\n' +
      'Tổng số thành viên,3256\n' +
      'Tổng số hoạt động đã tổ chức,150\n' +
      'Tổng lượt sinh viên tham gia,1240\n\n' +
      'Tháng,Số lượng hoạt động\n' +
      monthlyActivityData.map((d) => `${d.month},${d.count}`).join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Bao_cao_TVU_CLUB_${selectedSemester.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Đã xuất báo cáo thống kê Excel thành công!', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Filters matching Screen 11 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Báo cáo thống kê toàn trường
          </h1>
          <p className="text-xs text-gray-500">
            Dữ liệu tổng hợp tình hình hoạt động câu lạc bộ Trường Đại học Trà Vinh
          </p>
        </div>

        {/* Toolbar filters + Xuất Excel */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="bg-white border border-[#DCE6F0] rounded-lg px-2.5 py-1.5 text-xs text-gray-800 font-medium shadow-2xs"
          >
            <option value="2026 - 2027">Năm học 2026 - 2027</option>
            <option value="2025 - 2026">Năm học 2025 - 2026</option>
          </select>

          <select
            value={selectedSemester}
            onChange={(e) => setSelectedSemester(e.target.value)}
            className="bg-white border border-[#DCE6F0] rounded-lg px-2.5 py-1.5 text-xs text-gray-800 font-medium shadow-2xs"
          >
            <option value="Học kỳ 1">Học kỳ 1</option>
            <option value="Học kỳ 2">Học kỳ 2</option>
            <option value="Cả năm">Cả năm học</option>
          </select>

          <button
            onClick={handleExportExcel}
            className="px-3.5 py-1.5 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* 4 Metric Cards matching Screen 11: 28 CLB, 3.256 Thành viên, 150 Hoạt động, 1.240 Lượt tham gia */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Câu lạc bộ"
          value="28"
          icon={Layers}
          colorScheme="amber"
          subText="+3 CLB mới năm nay"
        />
        <StatCard
          label="Thành viên"
          value="3.256"
          icon={Users}
          colorScheme="blue"
          subText="Sinh viên đang sinh hoạt"
        />
        <StatCard
          label="Hoạt động"
          value="150"
          icon={Calendar}
          colorScheme="rose"
          subText="Đã được phê duyệt"
        />
        <StatCard
          label="Lượt tham gia"
          value="1.240"
          icon={Award}
          colorScheme="orange"
          subText="Điểm danh hợp lệ"
        />
      </div>

      {/* Charts Section matching Screen 11 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar Chart: Số lượng hoạt động theo tháng */}
        <div className="bg-white p-5 rounded-xl border border-[#DCE6F0] shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <div>
              <h3 className="font-bold text-sm text-[#073A68]">
                Số lượng hoạt động theo tháng
              </h3>
              <p className="text-[11px] text-gray-500">Thống kê hoạt động sinh viên trong 12 tháng</p>
            </div>
            <span className="text-xs font-semibold text-[#0755D9] bg-blue-50 px-2 py-0.5 rounded">
              Tổng: 150
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyActivityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5EDF5" />
                <XAxis dataKey="month" tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748B' }} />
                <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 11, fill: '#64748B' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #DCE6F0',
                    fontSize: '12px'
                  }}
                  formatter={(val: any) => [`${val} hoạt động`, 'Số lượng']}
                />
                <Bar dataKey="count" fill="#0755D9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Doughnut Chart: Tỷ lệ câu lạc bộ theo lĩnh vực */}
        <div className="bg-white p-5 rounded-xl border border-[#DCE6F0] shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <div>
              <h3 className="font-bold text-sm text-[#073A68]">
                Tỷ lệ câu lạc bộ theo lĩnh vực
              </h3>
              <p className="text-[11px] text-gray-500">Phân bố 28 CLB theo nhóm chuyên môn</p>
            </div>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              28 CLB
            </span>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {categoryPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Tỷ lệ']}
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: '8px',
                    border: '1px solid #DCE6F0',
                    fontSize: '12px'
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  formatter={(val) => <span className="text-xs text-gray-700">{val}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Summary Table: Top CLB xuất sắc */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] p-5 shadow-xs space-y-3">
        <h3 className="font-bold text-sm text-[#073A68]">
          Bảng xếp hạng hoạt động câu lạc bộ xuất sắc
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Hạng</th>
                <th className="py-2.5 px-3">Tên câu lạc bộ</th>
                <th className="py-2.5 px-3">Lĩnh vực</th>
                <th className="py-2.5 px-3 text-center">Số thành viên</th>
                <th className="py-2.5 px-3 text-center">Hoạt động tổ chức</th>
                <th className="py-2.5 px-3 text-center">Điểm thi đua</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <tr className="hover:bg-gray-50">
                <td className="py-2.5 px-3 font-bold text-amber-600">#1</td>
                <td className="py-2.5 px-3 font-bold text-gray-900">CLB Công nghệ thông tin</td>
                <td className="py-2.5 px-3 text-gray-600">Học thuật</td>
                <td className="py-2.5 px-3 text-center font-medium">120</td>
                <td className="py-2.5 px-3 text-center font-medium">15</td>
                <td className="py-2.5 px-3 text-center font-bold text-[#0755D9]">98/100</td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="py-2.5 px-3 font-bold text-slate-500">#2</td>
                <td className="py-2.5 px-3 font-bold text-gray-900">CLB Tình nguyện</td>
                <td className="py-2.5 px-3 text-gray-600">Tình nguyện</td>
                <td className="py-2.5 px-3 text-center font-medium">98</td>
                <td className="py-2.5 px-3 text-center font-medium">12</td>
                <td className="py-2.5 px-3 text-center font-bold text-[#0755D9]">95/100</td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="py-2.5 px-3 font-bold text-amber-700">#3</td>
                <td className="py-2.5 px-3 font-bold text-gray-900">CLB Âm nhạc</td>
                <td className="py-2.5 px-3 text-gray-600">Văn hóa - Nghệ thuật</td>
                <td className="py-2.5 px-3 text-center font-medium">85</td>
                <td className="py-2.5 px-3 text-center font-medium">10</td>
                <td className="py-2.5 px-3 text-center font-bold text-[#0755D9]">92/100</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
