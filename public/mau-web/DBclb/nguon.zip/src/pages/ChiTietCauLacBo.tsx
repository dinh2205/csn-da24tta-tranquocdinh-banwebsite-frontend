import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import {
  Users,
  Calendar,
  Clock,
  Mail,
  Phone,
  CheckCircle2,
  Code2,
  Music,
  HeartHandshake,
  Camera,
  Trophy,
  Lightbulb,
  Send,
  LogOut,
  Sparkles
} from 'lucide-react';

export const ChiTietCauLacBo: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    clubs,
    members,
    activities,
    news,
    requestJoinClub,
    hasUserRequestedJoin,
    isUserMember,
    leaveClub
  } = useClub();
  const { role, currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'intro' | 'activities' | 'members' | 'news'>('intro');
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);

  // Form states for join request
  const [studentId, setStudentId] = useState(currentUser.studentId || '110124033');
  const [fullName, setFullName] = useState(currentUser.fullName || 'Nguyễn Thị A');
  const [className, setClassName] = useState(currentUser.class || 'DA24TTA');
  const [email, setEmail] = useState(currentUser.email || '110124033@tvu.edu.vn');
  const [phone, setPhone] = useState('0912345601');
  const [desiredDepartment, setDesiredDepartment] = useState('Ban Kỹ thuật');
  const [message, setMessage] = useState('Em rất mong muốn được học hỏi và cống hiến cho các dự án của câu lạc bộ.');

  const club = clubs.find((c) => c.id === id) || clubs[0];

  const clubMembers = members.filter((m) => m.clubId === club.id && m.status === 'Đang hoạt động');
  const clubActivities = activities.filter((a) => a.clubId === club.id);
  const clubNews = news.filter((n) => n.clubId === club.id || n.clubName.includes(club.name));

  const userHasJoined = isUserMember(club.id, currentUser.studentId || '');
  const pendingRequest = hasUserRequestedJoin(club.id, currentUser.studentId || '');

  const getClubIcon = (clubId: string) => {
    switch (clubId) {
      case 'CLB001':
        return Code2;
      case 'CLB002':
        return Music;
      case 'CLB003':
        return HeartHandshake;
      case 'CLB004':
        return Camera;
      case 'CLB005':
        return Trophy;
      default:
        return Lightbulb;
    }
  };

  const Icon = getClubIcon(club.id);

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = requestJoinClub(
      club.id,
      studentId,
      fullName,
      className,
      email,
      phone,
      message,
      desiredDepartment
    );
    if (success) {
      setIsJoinModalOpen(false);
    }
  };

  const handleLeaveClub = () => {
    if (window.confirm(`Bạn có chắc chắn muốn rời khỏi ${club.name}?`)) {
      leaveClub(club.id, currentUser.studentId || '');
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Club Cover & Header Card matching Screen 3 */}
      <div className="bg-white rounded-2xl border border-[#DCE6F0] overflow-hidden shadow-xs">
        {/* Cover Photo */}
        <div className="relative h-48 md:h-64 overflow-hidden bg-slate-800">
          <img
            src={club.coverImage}
            alt={club.name}
            className="w-full h-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        </div>

        {/* Profile Overlay Card */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 -mt-12 md:-mt-14 mb-4">
            <div className="flex items-end gap-4">
              {/* Circular Avatar matching Screen 3 */}
              <div className="w-24 h-24 md:w-28 md:h-28 rounded-2xl bg-white p-2 shadow-lg ring-4 ring-white shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-xl bg-gradient-to-br from-[#073A68] to-[#0755D9] text-white flex items-center justify-center">
                  <Icon className="w-12 h-12" />
                </div>
              </div>

              {/* Title & Badges */}
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-xl md:text-2xl font-extrabold text-[#073A68]">
                    {club.name}
                  </h1>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-[#EAF3FF] text-[#0755D9] border border-[#B9D4FC]">
                    {club.category}
                  </span>
                  <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">
                    {club.type}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Button: Gửi yêu cầu tham gia */}
            <div className="flex items-center gap-3">
              {userHasJoined ? (
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Thành viên chính thức
                  </span>
                  <button
                    onClick={handleLeaveClub}
                    className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-xs font-semibold border border-red-200 transition-colors flex items-center gap-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Rời CLB
                  </button>
                </div>
              ) : pendingRequest ? (
                <div className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-50 text-amber-800 border border-amber-300 text-xs font-bold shadow-xs">
                  <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
                  Đang chờ BCN xét duyệt yêu cầu
                </div>
              ) : (
                <button
                  onClick={() => {
                    if (role === 'guest') {
                      navigate('/dang-nhap');
                    } else {
                      setIsJoinModalOpen(true);
                    }
                  }}
                  className="px-5 py-2.5 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs md:text-sm font-bold shadow-md transition-all flex items-center gap-2 hover:scale-[1.02]"
                >
                  <Send className="w-4 h-4" />
                  <span>Gửi yêu cầu tham gia</span>
                </button>
              )}
            </div>
          </div>

          {/* Stats Bar matching Screen 3 (120 thành viên, 15 hoạt động, 3 năm hoạt động) */}
          <div className="flex items-center gap-8 pt-4 border-t border-gray-100 text-xs text-gray-600">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#0755D9]" />
              <span className="font-bold text-gray-900 text-sm">
                {club.id === 'CLB001' ? '120' : clubMembers.length}
              </span>
              <span>thành viên</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#0755D9]" />
              <span className="font-bold text-gray-900 text-sm">
                {club.id === 'CLB001' ? '15' : clubActivities.length}
              </span>
              <span>hoạt động</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#0755D9]" />
              <span className="font-bold text-gray-900 text-sm">{club.yearsOperating} năm</span>
              <span>hoạt động</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Navigation Tabs matching Screen 3: Giới thiệu, Hoạt động, Thành viên, Tin tức */}
      <div className="border-b border-[#DCE6F0] flex gap-2">
        <button
          onClick={() => setActiveTab('intro')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'intro'
              ? 'border-[#0755D9] text-[#0755D9]'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Giới thiệu
        </button>
        <button
          onClick={() => setActiveTab('activities')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'activities'
              ? 'border-[#0755D9] text-[#0755D9]'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Hoạt động ({clubActivities.length})
        </button>
        <button
          onClick={() => setActiveTab('members')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'members'
              ? 'border-[#0755D9] text-[#0755D9]'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Thành viên ({clubMembers.length})
        </button>
        <button
          onClick={() => setActiveTab('news')}
          className={`pb-3 px-4 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'news'
              ? 'border-[#0755D9] text-[#0755D9]'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Tin tức ({clubNews.length})
        </button>
      </div>

      {/* 3. Tab Contents */}
      {activeTab === 'intro' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Giới thiệu matching Screen 3 */}
          <div className="lg:col-span-2 space-y-5 bg-white p-6 rounded-xl border border-[#DCE6F0] shadow-xs">
            <div>
              <h3 className="text-base font-bold text-[#073A68] mb-2">Giới thiệu</h3>
              <p className="text-xs text-gray-700 leading-relaxed font-normal">
                {club.description}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-2">
                Mục tiêu hoạt động
              </h4>
              <ul className="text-xs text-gray-600 space-y-2 list-disc list-inside">
                <li>Tạo sân chơi học thuật và phát triển kỹ năng thực chiến cho sinh viên ĐH Trà Vinh.</li>
                <li>Tổ chức các buổi chia sẻ công nghệ định kỳ hàng tháng, giải đáp thắc mắc đồ án.</li>
                <li>Xây dựng các đội tuyển tham dự cuộc thi học thuật, sáng tạo cấp Tỉnh và Toàn quốc.</li>
                <li>Kết nối mạng lưới cựu sinh viên thành đạt và các doanh nghiệp tài trợ.</li>
              </ul>
            </div>

            <div className="pt-2">
              <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-2">
                Cơ cấu các ban chuyên môn
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
                  <span className="font-bold text-blue-900 block">Ban Kỹ thuật - Chuyên môn</span>
                  <span className="text-gray-500 text-[11px]">Nghiên cứu dự án, tổ chức workshop và hướng dẫn kỹ năng.</span>
                </div>
                <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
                  <span className="font-bold text-blue-900 block">Ban Truyền thông - Sự kiện</span>
                  <span className="text-gray-500 text-[11px]">Thiết kế ấn phẩm, quay chụp hình ảnh và quản lý fanpage.</span>
                </div>
                <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
                  <span className="font-bold text-blue-900 block">Ban Nội dung &amp; Hậu cần</span>
                  <span className="text-gray-500 text-[11px]">Biên soạn kịch bản chương trình, chuẩn bị tài liệu và phòng ốc.</span>
                </div>
                <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
                  <span className="font-bold text-blue-900 block">Ban Đối ngoại</span>
                  <span className="text-gray-500 text-[11px]">Liên hệ diễn giả, doanh nghiệp tài trợ và giao lưu các CLB bạn.</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Box: Thông tin chung matching Screen 3 */}
          <div className="space-y-4">
            <div className="bg-white p-5 rounded-xl border border-[#DCE6F0] shadow-xs space-y-3.5">
              <h3 className="font-bold text-sm text-[#073A68] border-b border-gray-100 pb-2.5">
                Thông tin chung
              </h3>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-gray-50">
                  <span className="text-gray-500">Mã CLB:</span>
                  <span className="font-semibold text-gray-900">{club.code}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-50">
                  <span className="text-gray-500">Ngày thành lập:</span>
                  <span className="font-semibold text-gray-900">{club.establishedDate}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-50">
                  <span className="text-gray-500">Trạng thái:</span>
                  <StatusBadge status={club.status} size="sm" />
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-50">
                  <span className="text-gray-500">Chủ nhiệm CLB:</span>
                  <span className="font-semibold text-gray-900">{club.leaderName}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-gray-50">
                  <span className="text-gray-500">Email liên hệ:</span>
                  <a href={`mailto:${club.email}`} className="font-medium text-[#0755D9] hover:underline">
                    {club.email}
                  </a>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="text-gray-500">Số điện thoại:</span>
                  <span className="font-semibold text-gray-900">{club.phone || '0294.3855.246'}</span>
                </div>
              </div>
            </div>

            {/* University affiliation stamp */}
            <div className="p-4 bg-gradient-to-br from-[#EAF3FF] to-[#D5E6FA] rounded-xl border border-[#B9D4FC] text-xs text-[#073A68] space-y-1.5">
              <span className="font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#0755D9]" />
                Đoàn TNCS - Hội Sinh viên TVU
              </span>
              <p className="text-[11px] text-gray-600 leading-relaxed">
                Câu lạc bộ được công nhận chính thức trực thuộc quản lý của Trường Đại học Trà Vinh.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'activities' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {clubActivities.map((act) => (
              <div
                key={act.id}
                className="bg-white rounded-xl border border-[#DCE6F0] overflow-hidden hover:shadow-md transition-all flex flex-col"
              >
                <div className="h-36 relative">
                  <img
                    src={act.bannerImage}
                    alt={act.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <StatusBadge status={act.status} size="sm" />
                  </div>
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between space-y-2">
                  <div>
                    <h4 className="font-bold text-xs text-gray-900 line-clamp-1">{act.name}</h4>
                    <p className="text-[11px] text-gray-500 mt-1 line-clamp-2">{act.description}</p>
                  </div>
                  <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-[11px]">
                    <span className="text-gray-500">{act.startDate}</span>
                    <Link
                      to={`/hoat-dong/${act.id}`}
                      className="text-[#0755D9] font-bold hover:underline"
                    >
                      Chi tiết &rarr;
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'members' && (
        <div className="bg-white rounded-xl border border-[#DCE6F0] p-4 shadow-xs">
          <h3 className="font-bold text-sm text-[#073A68] mb-3">
            Danh sách thành viên nòng cốt
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">MSSV</th>
                  <th className="py-2.5 px-3">Họ và tên</th>
                  <th className="py-2.5 px-3">Lớp</th>
                  <th className="py-2.5 px-3">Ban/Nhóm</th>
                  <th className="py-2.5 px-3">Chức vụ</th>
                  <th className="py-2.5 px-3">Trạng thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {clubMembers.map((m, idx) => (
                  <tr key={m.id} className="hover:bg-[#F8FAFF]">
                    <td className="py-2.5 px-3 text-gray-500">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-900">{m.studentId}</td>
                    <td className="py-2.5 px-3 font-semibold text-[#0755D9]">{m.fullName}</td>
                    <td className="py-2.5 px-3 text-gray-600">{m.className}</td>
                    <td className="py-2.5 px-3 text-gray-600">{m.department}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-800">{m.role}</td>
                    <td className="py-2.5 px-3">
                      <StatusBadge status={m.status} size="sm" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'news' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {clubNews.map((n) => (
            <div
              key={n.id}
              className="bg-white rounded-xl border border-[#DCE6F0] overflow-hidden p-4 flex gap-4 hover:shadow-md transition-shadow"
            >
              <img
                src={n.image}
                alt={n.title}
                className="w-28 h-24 object-cover rounded-lg shrink-0"
              />
              <div className="flex-1 space-y-1">
                <span className="text-[10px] font-bold text-[#0755D9] uppercase tracking-wider">
                  {n.category}
                </span>
                <h4 className="font-bold text-xs text-gray-900 line-clamp-2">{n.title}</h4>
                <p className="text-[11px] text-gray-500 line-clamp-2">{n.summary}</p>
                <span className="text-[10px] text-gray-400 block pt-1">{n.publishDate}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Gửi yêu cầu gia nhập CLB */}
      <Modal
        isOpen={isJoinModalOpen}
        onClose={() => setIsJoinModalOpen(false)}
        title={`Gửi yêu cầu tham gia ${club.name}`}
        maxWidth="md"
      >
        <form onSubmit={handleJoinSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Mã sinh viên *</label>
              <input
                type="text"
                required
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Lớp *</label>
              <input
                type="text"
                required
                value={className}
                onChange={(e) => setClassName(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên *</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Email trường *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Số điện thoại *</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Ban/Nhóm mong muốn tham gia *
            </label>
            <select
              value={desiredDepartment}
              onChange={(e) => setDesiredDepartment(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            >
              <option value="Ban Kỹ thuật">Ban Kỹ thuật - Chuyên môn</option>
              <option value="Ban Truyền thông">Ban Truyền thông - Sự kiện</option>
              <option value="Ban Nội dung">Ban Nội dung &amp; Hậu cần</option>
              <option value="Ban Đối ngoại">Ban Đối ngoại &amp; Tài chính</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Lời nhắn gửi Ban chủ nhiệm / Giới thiệu bản thân
            </label>
            <textarea
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Chia sẻ lý do bạn muốn tham gia CLB..."
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsJoinModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              Gửi yêu cầu
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
