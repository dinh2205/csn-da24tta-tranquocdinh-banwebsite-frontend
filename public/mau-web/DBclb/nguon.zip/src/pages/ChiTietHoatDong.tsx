import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import {
  Calendar,
  MapPin,
  Users,
  Award,
  Clock,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Building2,
  Share2,
  CalendarDays
} from 'lucide-react';

export const ChiTietHoatDong: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { activities, registerActivity, cancelActivityRegistration, isRegisteredForActivity } = useClub();
  const { role, currentUser } = useAuth();

  const activity = activities.find((a) => a.id === id) || activities[0];
  const isRegistered = isRegisteredForActivity(activity.id, currentUser.studentId || '110124033');

  const handleRegister = () => {
    if (role === 'guest') {
      navigate('/dang-nhap');
      return;
    }
    registerActivity(
      activity.id,
      currentUser.studentId || '110124033',
      currentUser.fullName || 'Nguyễn Thị A',
      currentUser.class || 'DA24TTA',
      currentUser.email || '110124033@tvu.edu.vn'
    );
  };

  const handleCancel = () => {
    if (window.confirm('Bạn có chắc chắn muốn hủy đăng ký tham gia hoạt động này?')) {
      cancelActivityRegistration(activity.id, currentUser.studentId || '110124033');
    }
  };

  const isFull = activity.registeredCount >= activity.maxCapacity;
  const isApproved = activity.status === 'Đã phê duyệt' || activity.status === 'Đang diễn ra';

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Bar with back button matching Screen 6 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Chi tiết hoạt động
          </h1>
          <p className="text-xs text-gray-500">Thông tin chương trình và điều kiện tham gia</p>
        </div>
        <button
          onClick={() => navigate(-1)}
          className="px-3.5 py-1.5 bg-white hover:bg-gray-100 text-[#172B4D] border border-[#DCE6F0] rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Quay lại</span>
        </button>
      </div>

      {/* Main Container Card matching Screen 6 */}
      <div className="bg-white rounded-2xl border border-[#DCE6F0] overflow-hidden shadow-xs">
        {/* Event Banner Photo */}
        <div className="relative h-60 md:h-72 overflow-hidden bg-slate-800">
          <img
            src={activity.bannerImage}
            alt={activity.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute top-4 left-4 flex gap-2">
            <StatusBadge status={activity.status} />
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#0755D9] text-white shadow-sm">
              +{activity.proposedTrainingPoints} Điểm rèn luyện
            </span>
          </div>
        </div>

        {/* Content body matching Screen 6 */}
        <div className="p-6 md:p-8 space-y-6">
          {/* Title and category badges */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-[#EAF3FF] text-[#0755D9] border border-[#B9D4FC]">
                {activity.clubName}
              </span>
              <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">
                {activity.category}
              </span>
              <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                {activity.typeTag}
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-extrabold text-[#172B4D]">
              {activity.name}
            </h2>
          </div>

          {/* Metadata Grid matching Screen 6: Ngày, Địa điểm, Số lượng tối đa, Điểm RL */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-[#F8FAFC] border border-[#DCE6F0]">
            <div className="space-y-1">
              <span className="text-[11px] font-medium text-gray-500 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#0755D9]" /> Thời gian
              </span>
              <p className="font-bold text-xs sm:text-sm text-gray-900">{activity.startDate}</p>
            </div>

            <div className="space-y-1">
              <span className="text-[11px] font-medium text-gray-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#0755D9]" /> Địa điểm
              </span>
              <p className="font-bold text-xs sm:text-sm text-gray-900">{activity.location}</p>
            </div>

            <div className="space-y-1">
              <span className="text-[11px] font-medium text-gray-500 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-[#0755D9]" /> Số lượng tối đa
              </span>
              <p className="font-bold text-xs sm:text-sm text-gray-900">
                {activity.maxCapacity} sinh viên
              </p>
            </div>

            <div className="space-y-1">
              <span className="text-[11px] font-medium text-gray-500 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-600" /> Điểm rèn luyện (đề xuất)
              </span>
              <p className="font-bold text-xs sm:text-sm text-amber-600">
                {activity.proposedTrainingPoints} điểm
              </p>
            </div>
          </div>

          {/* Details split: Description left, rules and status right */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              <h3 className="text-base font-bold text-[#073A68]">Mô tả hoạt động</h3>
              <p className="text-xs sm:text-sm text-gray-700 leading-relaxed font-normal whitespace-pre-line">
                {activity.description}
              </p>

              <div className="p-4 rounded-xl bg-[#F5F8FC] border border-blue-200/80 space-y-2">
                <h4 className="text-xs font-bold text-[#073A68] uppercase tracking-wider">
                  Nội dung trọng tâm chương trình
                </h4>
                <ul className="text-xs text-gray-600 space-y-1.5 list-disc list-inside">
                  <li>Giới thiệu xu hướng phát triển ứng dụng web hiện đại.</li>
                  <li>Thực hành trực tiếp trên máy tính cá nhân dưới sự hướng dẫn của BCN CLB.</li>
                  <li>Hỏi đáp giao lưu và chia sẻ định hướng nghề nghiệp cùng khách mời doanh nghiệp.</li>
                  <li>Điểm danh cuối buổi để được xét duyệt điểm rèn luyện chính thức.</li>
                </ul>
              </div>
            </div>

            {/* Right Side: Eligibility and Registration Info matching Screen 6 */}
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-[#F8FAFC] border border-[#DCE6F0] space-y-3 text-xs">
                <h4 className="font-bold text-gray-900 border-b border-gray-200 pb-2">
                  Thông tin đăng ký
                </h4>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">Hạn đăng ký:</span>
                    <span className="font-semibold text-gray-900">{activity.registrationDeadline}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">Đối tượng:</span>
                    <span className="font-semibold text-gray-900">{activity.targetAudience}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">Số lượng đã đăng ký:</span>
                    <span className="font-bold text-[#0755D9]">
                      {activity.registeredCount} / {activity.maxCapacity}
                    </span>
                  </div>
                </div>

                {/* Capacity Progress Bar */}
                <div className="space-y-1 pt-1">
                  <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0755D9] transition-all"
                      style={{
                        width: `${Math.min(
                          100,
                          (activity.registeredCount / activity.maxCapacity) * 100
                        )}%`
                      }}
                    ></div>
                  </div>
                  <span className="text-[10px] text-gray-400">
                    Còn lại {Math.max(0, activity.maxCapacity - activity.registeredCount)} chỗ
                  </span>
                </div>
              </div>

              {/* Action Buttons matching Screen 6 */}
              <div className="space-y-2">
                {!isApproved ? (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 text-center font-medium">
                    Hoạt động đang ở trạng thái &quot;{activity.status}&quot;, chưa mở đăng ký cho sinh viên.
                  </div>
                ) : isRegistered ? (
                  <div className="space-y-2">
                    <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-lg text-xs text-emerald-800 flex items-center justify-center gap-1.5 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Bạn đã đăng ký tham gia hoạt động này!
                    </div>
                    <button
                      onClick={handleCancel}
                      className="w-full py-2.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg text-xs font-bold transition-colors"
                    >
                      Hủy đăng ký
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleRegister}
                    disabled={isFull}
                    className={`w-full py-3 rounded-lg text-xs sm:text-sm font-bold shadow-md transition-all flex items-center justify-center gap-2 ${
                      isFull
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-[#0755D9] hover:bg-[#0646B5] text-white hover:scale-[1.01]'
                    }`}
                  >
                    <span>{isFull ? 'Đã hết vị trí' : 'Đăng ký tham gia'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
