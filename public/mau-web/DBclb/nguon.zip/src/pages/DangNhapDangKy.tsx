import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { GraduationCap, Eye, EyeOff, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

export const DangNhapDangKy: React.FC = () => {
  const { login, switchRole } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  // Login states
  const [loginUsername, setLoginUsername] = useState('110124033');
  const [loginPassword, setLoginPassword] = useState('••••••••');
  const [rememberMe, setRememberMe] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Register states
  const [regStudentId, setRegStudentId] = useState('');
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regError, setRegError] = useState('');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsername.trim()) {
      showToast('Vui lòng nhập tên đăng nhập hoặc email!', 'warning');
      return;
    }
    const success = login(loginUsername.trim(), loginPassword);
    if (success) {
      if (loginUsername.includes('clb')) {
        navigate('/ban-chu-nhiem/thanh-vien');
      } else if (loginUsername.includes('doan') || loginUsername.includes('quan')) {
        navigate('/quan-ly-truong/duyet-hoat-dong');
      } else if (loginUsername.includes('admin')) {
        navigate('/quan-tri/tai-khoan');
      } else {
        navigate('/sinh-vien');
      }
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regStudentId || !regFullName || !regEmail || !regPhone || !regPassword) {
      setRegError('Vui lòng điền đầy đủ các thông tin bắt buộc.');
      return;
    }

    if (!regEmail.endsWith('tvu.edu.vn') && !regEmail.includes('@')) {
      setRegError('Vui lòng sử dụng địa chỉ email hợp lệ (khuyến khích @tvu.edu.vn).');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Mật khẩu xác nhận không khớp. Vui lòng kiểm tra lại.');
      return;
    }

    // Register success simulated
    showToast(`Đăng ký tài khoản sinh viên thành công cho ${regFullName}! Đang đăng nhập...`, 'success');
    login(regStudentId);
    navigate('/sinh-vien');
  };

  const handleQuickLogin = (roleType: 'student' | 'club_manager' | 'school_manager' | 'admin') => {
    switchRole(roleType);
    if (roleType === 'student') navigate('/sinh-vien');
    else if (roleType === 'club_manager') navigate('/ban-chu-nhiem/thanh-vien');
    else if (roleType === 'school_manager') navigate('/quan-ly-truong/duyet-hoat-dong');
    else navigate('/quan-tri/tai-khoan');
  };

  return (
    <div className="py-6 space-y-6">
      <div className="text-center max-w-xl mx-auto space-y-1">
        <h1 className="text-2xl font-extrabold text-[#073A68]">
          Cổng xác thực TVU CLUB
        </h1>
        <p className="text-xs text-gray-500">
          Đăng nhập hoặc đăng ký tài khoản sinh viên để sử dụng toàn bộ tính năng
        </p>
      </div>

      {/* Two white cards side by side matching Screen 4 layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* LEFT CARD: ĐĂNG NHẬP */}
        <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 sm:p-8 shadow-sm flex flex-col justify-between">
          <div>
            {/* Header with TVU CLUB Logo */}
            <div className="flex flex-col items-center text-center mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#073A68] to-[#0755D9] flex items-center justify-center text-white mb-2 shadow-xs">
                <GraduationCap className="w-7 h-7" />
              </div>
              <span className="font-extrabold text-[#0755D9] text-sm tracking-tight">TVU CLUB</span>
              <h2 className="text-xl font-extrabold text-[#172B4D] mt-1">Đăng nhập</h2>
            </div>

            {/* Login form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-gray-700 block mb-1">
                  Tên đăng nhập / Email
                </label>
                <input
                  type="text"
                  placeholder="Nhập MSSV hoặc email..."
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
                />
              </div>

              <div>
                <label className="font-semibold text-gray-700 block mb-1">Mật khẩu</label>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    placeholder="Nhập mật khẩu..."
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-3.5 pr-10 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-gray-600">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded text-[#0755D9] focus:ring-0"
                  />
                  <span>Ghi nhớ đăng nhập</span>
                </label>
                <a href="#quen-mat-khau" onClick={(e) => { e.preventDefault(); showToast('Vui lòng liên hệ ban quản trị để cấp lại mật khẩu.', 'info'); }} className="text-[#0755D9] hover:underline font-medium">
                  Quên mật khẩu?
                </a>
              </div>

              {/* Submit button */}
              <button
                type="submit"
                className="w-full py-2.5 bg-[#0755D9] hover:bg-[#0646B5] text-white font-bold rounded-lg shadow-sm transition-colors text-xs sm:text-sm mt-2"
              >
                Đăng nhập
              </button>
            </form>
          </div>

          {/* Quick role presets for demo evaluation */}
          <div className="pt-6 mt-6 border-t border-gray-100">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block mb-2 text-center">
              Đăng nhập nhanh (Tài khoản mẫu)
            </span>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => handleQuickLogin('student')}
                className="p-2 rounded bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-left font-medium transition-colors"
              >
                🎓 Sinh viên A
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('club_manager')}
                className="p-2 rounded bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-left font-medium transition-colors"
              >
                💼 BCN CLB (CNTT)
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('school_manager')}
                className="p-2 rounded bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-left font-medium transition-colors"
              >
                🏛️ Ban QL Trường
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('admin')}
                className="p-2 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 text-left font-medium transition-colors"
              >
                ⚙️ Quản trị viên
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT CARD: ĐĂNG KÝ */}
        <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 sm:p-8 shadow-sm">
          {/* Header with TVU CLUB Logo */}
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#073A68] to-[#0755D9] flex items-center justify-center text-white mb-2 shadow-xs">
              <GraduationCap className="w-7 h-7" />
            </div>
            <span className="font-extrabold text-[#0755D9] text-sm tracking-tight">TVU CLUB</span>
            <h2 className="text-xl font-extrabold text-[#172B4D] mt-1">Đăng ký tài khoản sinh viên</h2>
          </div>

          {regError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{regError}</span>
            </div>
          )}

          {/* Register form matching Screen 4 fields */}
          <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Mã sinh viên *</label>
              <input
                type="text"
                placeholder="Nhập mã sinh viên (VD: 110124088)..."
                value={regStudentId}
                onChange={(e) => setRegStudentId(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
              />
            </div>

            <div>
              <label className="font-semibold text-gray-700 block mb-1">Họ và tên *</label>
              <input
                type="text"
                placeholder="Nhập họ và tên..."
                value={regFullName}
                onChange={(e) => setRegFullName(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
              />
            </div>

            <div>
              <label className="font-semibold text-gray-700 block mb-1">Email trường *</label>
              <input
                type="email"
                placeholder="Nhập email @tvu.edu.vn..."
                value={regEmail}
                onChange={(e) => setRegEmail(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
              />
            </div>

            <div>
              <label className="font-semibold text-gray-700 block mb-1">Số điện thoại *</label>
              <input
                type="tel"
                placeholder="Nhập số điện thoại..."
                value={regPhone}
                onChange={(e) => setRegPhone(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="font-semibold text-gray-700 block mb-1">Mật khẩu *</label>
                <input
                  type="password"
                  placeholder="Mật khẩu..."
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3 py-2 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
                />
              </div>
              <div>
                <label className="font-semibold text-gray-700 block mb-1">Xác nhận *</label>
                <input
                  type="password"
                  placeholder="Xác nhận..."
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3 py-2 text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-[#0755D9] hover:bg-[#0646B5] text-white font-bold rounded-lg shadow-sm transition-colors text-xs sm:text-sm mt-3"
            >
              Đăng ký
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
