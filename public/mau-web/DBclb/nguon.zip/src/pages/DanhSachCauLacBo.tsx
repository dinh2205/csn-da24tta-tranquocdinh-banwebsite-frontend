import React, { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { Search, Users, Filter, ArrowUpDown } from 'lucide-react';

export const DanhSachCauLacBo: React.FC = () => {
  const { clubs } = useClub();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('Tất cả');
  const [sortOption, setSortOption] = useState<string>('Mới nhất');

  const categories = [
    'Tất cả',
    'Công nghệ',
    'Văn hóa - Nghệ thuật',
    'Tình nguyện',
    'Truyền thông',
    'Thể thao',
    'Học thuật'
  ];

  const sortOptions = ['Mới nhất', 'Tên A-Z', 'Tên Z-A', 'Nhiều thành viên'];

  const filteredClubs = useMemo(() => {
    let result = [...clubs];

    // Filter by search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.code.toLowerCase().includes(q) ||
          c.category.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q)
      );
    }

    // Filter by category
    if (selectedCategory !== 'Tất cả') {
      result = result.filter((c) => c.category === selectedCategory);
    }

    // Sort
    if (sortOption === 'Tên A-Z') {
      result.sort((a, b) => a.name.localeCompare(b.name, 'vi'));
    } else if (sortOption === 'Tên Z-A') {
      result.sort((a, b) => b.name.localeCompare(a.name, 'vi'));
    } else if (sortOption === 'Nhiều thành viên') {
      const getCount = (id: string) => {
        if (id === 'CLB001') return 120;
        if (id === 'CLB002') return 85;
        if (id === 'CLB003') return 98;
        if (id === 'CLB004') return 75;
        if (id === 'CLB005') return 63;
        return 55;
      };
      result.sort((a, b) => getCount(b.id) - getCount(a.id));
    }

    return result;
  }, [clubs, searchTerm, selectedCategory, sortOption]);

  const getMemberCount = (id: string) => {
    if (id === 'CLB001') return 120;
    if (id === 'CLB002') return 85;
    if (id === 'CLB003') return 98;
    if (id === 'CLB004') return 75;
    if (id === 'CLB005') return 63;
    if (id === 'CLB006') return 55;
    return 40;
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Công nghệ':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Văn hóa - Nghệ thuật':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Tình nguyện':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Truyền thông':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Thể thao':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-sky-50 text-sky-700 border-sky-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search bar matching Screen 2 */}
      <div className="space-y-4">
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Danh sách câu lạc bộ
        </h1>

        <div className="bg-white p-3.5 rounded-xl border border-[#DCE6F0] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search box with button */}
          <div className="flex-1 flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Tìm kiếm câu lạc bộ..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
            <button
              onClick={() => {}}
              className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0"
            >
              Tìm kiếm
            </button>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2">
            {/* Category filter */}
            <div className="flex items-center gap-1.5 text-xs text-gray-600">
              <span className="shrink-0 text-gray-500 font-medium">Lĩnh vực:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort filter */}
            <div className="flex items-center gap-1.5 text-xs text-gray-600">
              <span className="shrink-0 text-gray-500 font-medium">Sắp xếp:</span>
              <select
                value={sortOption}
                onChange={(e) => setSortOption(e.target.value)}
                className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
              >
                {sortOptions.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Club Section Count matching Screen 2 */}
      <div>
        <h2 className="text-base font-bold text-[#073A68] mb-4">
          Danh sách câu lạc bộ ({filteredClubs.length})
        </h2>

        {filteredClubs.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-xl border border-[#DCE6F0] text-gray-500 text-xs">
            Không tìm thấy câu lạc bộ nào phù hợp với từ khóa &quot;{searchTerm}&quot;
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredClubs.map((club) => {
              const memberCount = getMemberCount(club.id);
              const tagStyle = getCategoryColor(club.category);

              return (
                <Link
                  key={club.id}
                  to={`/cau-lac-bo/${club.id}`}
                  className="group bg-white rounded-xl border border-[#DCE6F0] overflow-hidden hover:shadow-lg hover:border-[#0755D9]/50 transition-all flex flex-col"
                >
                  {/* Club Image matching Screen 2 */}
                  <div className="relative h-44 overflow-hidden bg-slate-100">
                    <img
                      src={club.coverImage}
                      alt={club.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>

                  {/* Club Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h3 className="font-bold text-sm text-[#172B4D] group-hover:text-[#0755D9] transition-colors leading-snug">
                        {club.name}
                      </h3>
                      <p className="text-xs text-gray-500 mt-1 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-gray-400" />
                        <span>{memberCount} thành viên</span>
                      </p>
                    </div>

                    {/* Tag badge matching Screen 2 */}
                    <div className="pt-2">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-semibold border ${tagStyle}`}
                      >
                        {club.category}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
