import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { StatusBadge } from '../components/StatusBadge';
import { Search, Calendar, MapPin, Users, Award, ArrowRight } from 'lucide-react';

export const DanhSachHoatDong: React.FC = () => {
  const { activities } = useClub();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');

  const filteredActivities = useMemo(() => {
    let result = [...activities];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.clubName.toLowerCase().includes(q) ||
          a.location.toLowerCase().includes(q)
      );
    }

    if (selectedCategory !== 'Tất cả') {
      result = result.filter((a) => a.category === selectedCategory || a.typeTag === selectedCategory);
    }

    return result;
  }, [activities, searchTerm, selectedCategory]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Danh sách hoạt động &amp; sự kiện TVU
        </h1>
        <p className="text-xs text-gray-500">
          Các chương trình hội thảo, workshop, cuộc thi và hoạt động tình nguyện mở đăng ký cho sinh viên
        </p>
      </div>

      {/* Toolbar */}
      <div className="bg-white p-3.5 rounded-xl border border-[#DCE6F0] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Tìm kiếm hoạt động theo tên, địa điểm, CLB..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          >
            <option value="Tất cả">Tất cả hình thức</option>
            <option value="Workshop">Workshop</option>
            <option value="Talkshow">Talkshow</option>
            <option value="Cuộc thi">Cuộc thi</option>
            <option value="Tình nguyện">Tình nguyện</option>
            <option value="Lễ hội">Lễ hội</option>
          </select>
        </div>
      </div>

      {/* Activities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredActivities.map((act) => (
          <div
            key={act.id}
            className="bg-white rounded-xl border border-[#DCE6F0] overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="relative h-44 overflow-hidden bg-slate-100">
                <img
                  src={act.bannerImage}
                  alt={act.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2.5 left-2.5 flex gap-1.5">
                  <StatusBadge status={act.status} size="sm" />
                </div>
                <div className="absolute top-2.5 right-2.5">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-white">
                    +{act.proposedTrainingPoints} Điểm RL
                  </span>
                </div>
              </div>

              <div className="p-4 space-y-2.5">
                <span className="text-[11px] font-semibold text-[#0755D9] block">{act.clubName}</span>
                <h3 className="font-bold text-sm text-gray-900 line-clamp-1 hover:text-[#0755D9]">
                  <Link to={`/hoat-dong/${act.id}`}>{act.name}</Link>
                </h3>
                <p className="text-xs text-gray-500 line-clamp-2">{act.description}</p>

                <div className="space-y-1 pt-1 text-xs text-gray-600">
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <Calendar className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{act.startDate}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span className="truncate">{act.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px]">
                    <Users className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>Đã đăng ký: <strong>{act.registeredCount}</strong> / {act.maxCapacity}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 pt-0">
              <Link
                to={`/hoat-dong/${act.id}`}
                className="w-full py-2 bg-[#EAF3FF] hover:bg-blue-100 text-[#0755D9] font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Xem chi tiết &amp; Đăng ký</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
