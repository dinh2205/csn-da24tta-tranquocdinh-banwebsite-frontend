import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { Sparkles, Send, CheckCircle2, Clock, FileText } from 'lucide-react';

export const DeXuatThanhLapCLB: React.FC = () => {
  const { proposals, proposeNewClub } = useClub();
  const { currentUser } = useAuth();

  const [clubName, setClubName] = useState('');
  const [category, setCategory] = useState('Công nghệ');
  const [goal, setGoal] = useState('');
  const [actionPlan, setActionPlan] = useState('');
  const [initialMemberCount, setInitialMemberCount] = useState(15);
  const [proposerPhone, setProposerPhone] = useState('0912345601');

  const myProposals = proposals.filter(
    (p) => p.proposedByStudentId === (currentUser.studentId || '110124033')
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    proposeNewClub({
      clubName,
      category,
      proposedByStudentId: currentUser.studentId || '110124033',
      proposerName: currentUser.fullName || 'Nguyễn Thị A',
      proposerEmail: currentUser.email || '110124033@tvu.edu.vn',
      proposerPhone,
      goal,
      actionPlan,
      initialMemberCount: Number(initialMemberCount)
    });

    setClubName('');
    setGoal('');
    setActionPlan('');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Đề xuất thành lập câu lạc bộ mới
        </h1>
        <p className="text-xs text-gray-500">
          Sinh viên Trường Đại học Trà Vinh có nguyện vọng thành lập CLB mới gửi đề án đến Ban Quản lý cấp trường
        </p>
      </div>

      {/* Form Card */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#DCE6F0] shadow-xs space-y-5">
        <div className="flex items-center gap-2.5 text-[#0755D9] font-bold text-sm border-b border-gray-100 pb-3">
          <Sparkles className="w-5 h-5 text-amber-500" />
          <span>Biểu mẫu đăng ký thành lập CLB sinh viên</span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Tên câu lạc bộ đề xuất *
            </label>
            <input
              type="text"
              required
              placeholder="VD: Câu lạc bộ Thiết kế đồ họa & Đa phương tiện TVU..."
              value={clubName}
              onChange={(e) => setClubName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Lĩnh vực hoạt động</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3 py-2 text-gray-800"
              >
                <option value="Công nghệ">Công nghệ &amp; Kỹ thuật</option>
                <option value="Học thuật">Học thuật &amp; Nghiên cứu</option>
                <option value="Văn hóa - Nghệ thuật">Văn hóa - Nghệ thuật</option>
                <option value="Tình nguyện">Tình nguyện &amp; Vì cộng đồng</option>
                <option value="Truyền thông">Truyền thông &amp; Kỹ năng số</option>
                <option value="Thể thao">Thể dục - Thể thao</option>
              </select>
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Số lượng thành viên dự kiến ban đầu (tối thiểu 10)
              </label>
              <input
                type="number"
                min="10"
                max="200"
                value={initialMemberCount}
                onChange={(e) => setInitialMemberCount(Number(e.target.value))}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Mục đích và tôn chỉ hoạt động *
            </label>
            <textarea
              required
              rows={3}
              placeholder="Mô tả mục tiêu của CLB đối với sinh viên TVU..."
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800"
            />
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Kế hoạch sinh hoạt và phương hướng trong năm đầu tiên *
            </label>
            <textarea
              required
              rows={3}
              placeholder="Dự kiến tần suất sinh hoạt, các chương trình điểm nhấn, workshop..."
              value={actionPlan}
              onChange={(e) => setActionPlan(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-3.5 py-2.5 text-gray-800"
            />
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-[11px] text-blue-900 leading-relaxed">
            * Sau khi gửi, hồ sơ sẽ được Hội đồng Quản lý CLB cấp trường (Đoàn Thanh niên - Hội Sinh viên TVU) thẩm định trong vòng 5 ngày làm việc.
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 bg-[#0755D9] hover:bg-[#0646B5] text-white font-bold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Gửi hồ sơ đề xuất</span>
          </button>
        </form>
      </div>

      {/* History of Proposals */}
      {myProposals.length > 0 && (
        <div className="bg-white p-6 rounded-2xl border border-[#DCE6F0] shadow-xs space-y-3">
          <h2 className="text-sm font-bold text-[#073A68]">
            Đề án bạn đã gửi ({myProposals.length})
          </h2>
          <div className="divide-y divide-gray-100 text-xs">
            {myProposals.map((p) => (
              <div key={p.id} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <h3 className="font-bold text-gray-900">{p.clubName}</h3>
                  <p className="text-[11px] text-gray-500">
                    Lĩnh vực: {p.category} • Ngày gửi: {p.submittedDate} • Thành viên khởi đầu: {p.initialMemberCount}
                  </p>
                  {p.reviewNote && (
                    <p className="text-[11px] text-blue-800 mt-1 italic">
                      Ý kiến thẩm định: {p.reviewNote}
                    </p>
                  )}
                </div>
                <StatusBadge
                  status={
                    p.status === 'pending'
                      ? 'Chờ duyệt'
                      : p.status === 'approved'
                      ? 'Đã phê duyệt'
                      : 'Từ chối'
                  }
                  size="sm"
                />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
