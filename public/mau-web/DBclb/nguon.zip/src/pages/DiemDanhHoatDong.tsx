import React, { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { useToast } from '../context/ToastContext';
import { StatusBadge } from '../components/StatusBadge';
import { QRCodeModal } from '../components/QRCodeModal';
import {
  QrCode,
  Download,
  ArrowLeft,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  UserCheck,
  FileSpreadsheet
} from 'lucide-react';

export const DiemDanhHoatDong: React.FC = () => {
  const { activityId } = useParams<{ activityId: string }>();
  const navigate = useNavigate();
  const { activities, registrations, recordAttendance, cancelAttendance } = useClub();
  const { showToast } = useToast();

  const [activeTab, setActiveTab] = useState<'all' | 'attended' | 'not_attended'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);

  // Find target activity
  const targetId = activityId || 'HD001';
  const activity = activities.find((a) => a.id === targetId) || activities[0];

  // Target registrations
  const activityRegistrations = useMemo(() => {
    return registrations.filter((r) => r.activityId === activity.id && r.status === 'registered');
  }, [registrations, activity.id]);

  const attendedCount = activityRegistrations.filter((r) => r.attended).length;
  const notAttendedCount = activityRegistrations.filter((r) => !r.attended).length;

  const filteredRegistrations = useMemo(() => {
    let result = [...activityRegistrations];

    if (activeTab === 'attended') {
      result = result.filter((r) => r.attended);
    } else if (activeTab === 'not_attended') {
      result = result.filter((r) => !r.attended);
    }

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (r) =>
          r.fullName.toLowerCase().includes(q) ||
          r.studentId.toLowerCase().includes(q) ||
          r.className.toLowerCase().includes(q)
      );
    }

    return result;
  }, [activityRegistrations, activeTab, searchTerm]);

  const handleToggleAttendance = (regId: string, currentStatus: boolean) => {
    if (currentStatus) {
      cancelAttendance(regId);
    } else {
      recordAttendance(regId, 'manual', 'Ban chủ nhiệm CLB');
    }
  };

  const handleQrScanSuccess = (studentId: string) => {
    const reg = activityRegistrations.find((r) => r.studentId === studentId);
    if (reg) {
      recordAttendance(reg.id, 'qr', 'Hệ thống Quét QR TVU');
    } else {
      showToast(`Sinh viên ${studentId} chưa đăng ký hoạt động này!`, 'warning');
    }
  };

  const handleExportList = () => {
    const csvContent =
      'STT,MSSV,Họ và tên,Lớp,Thời gian điểm danh,Trạng thái\n' +
      activityRegistrations
        .map(
          (r, idx) =>
            `${idx + 1},${r.studentId},"${r.fullName}",${r.className},${
              r.attendedAt || '-'
            },${r.attended ? 'Đã điểm danh' : 'Chưa điểm danh'}`
        )
        .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Diem_danh_${activity.name.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Đã xuất file danh sách điểm danh thành công!', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching Screen 9: Điểm danh: Workshop React + Buttons: Quét QR, Xuất danh sách, Quay lại */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Điểm danh: {activity.name}
          </h1>
          <p className="text-xs text-gray-500">
            {activity.startDate} • {activity.location} • {activity.clubName}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsQrModalOpen(true)}
            className="px-3.5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <QrCode className="w-4 h-4" />
            <span>Quét QR</span>
          </button>

          <button
            onClick={handleExportList}
            className="px-3.5 py-2 bg-white hover:bg-gray-50 text-[#0755D9] border border-[#B9D4FC] rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Xuất danh sách</span>
          </button>

          <button
            onClick={() => navigate(-1)}
            className="px-3 py-2 bg-white hover:bg-gray-100 text-gray-700 border border-[#DCE6F0] rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Quay lại</span>
          </button>
        </div>
      </div>

      {/* Tabs Filter matching Screen 9: Danh sách đăng ký (56), Đã điểm danh (48), Chưa điểm danh (8) */}
      <div className="border-b border-[#DCE6F0] flex flex-wrap gap-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('all')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'all'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Danh sách đăng ký ({activity.id === 'HD001' ? 56 : activityRegistrations.length})
        </button>
        <button
          onClick={() => setActiveTab('attended')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'attended'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã điểm danh ({activity.id === 'HD001' ? 48 : attendedCount})
        </button>
        <button
          onClick={() => setActiveTab('not_attended')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'not_attended'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Chưa điểm danh ({activity.id === 'HD001' ? 8 : notAttendedCount})
        </button>
      </div>

      {/* Search Bar matching Screen 9 */}
      <div className="bg-white p-3.5 rounded-xl border border-[#DCE6F0] shadow-xs flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder="Tìm kiếm sinh viên theo tên, MSSV, lớp..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="text-xs text-gray-500">
          Tỷ lệ tham gia: <strong className="text-[#0755D9] font-bold">{Math.round((attendedCount / (activityRegistrations.length || 1)) * 100)}%</strong>
        </div>
      </div>

      {/* Attendance Data Table matching Screen 9 */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">MSSV</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3.5">Lớp</th>
                <th className="py-3 px-3.5">Thời gian điểm danh</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                <th className="py-3 px-3.5 text-center w-36">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredRegistrations.map((reg, index) => (
                <tr key={reg.id} className="hover:bg-[#F8FAFF] transition-colors">
                  <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                    {index + 1}
                  </td>
                  <td className="py-3 px-3.5 font-semibold text-gray-900">
                    {reg.studentId}
                  </td>
                  <td className="py-3 px-3.5 font-bold text-[#0755D9]">
                    {reg.fullName}
                  </td>
                  <td className="py-3 px-3.5 text-gray-600">{reg.className}</td>
                  <td className="py-3 px-3.5 text-gray-700 font-medium">
                    {reg.attendedAt ? (
                      <span className="flex items-center gap-1 text-emerald-700">
                        <Clock className="w-3.5 h-3.5" />
                        {reg.attendedAt}
                        {reg.attendanceMethod === 'qr' && (
                          <span className="text-[10px] px-1 py-0.2 bg-blue-100 text-blue-800 rounded font-bold">
                            QR
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="py-3 px-3.5">
                    {reg.attended ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#DCFCE7] text-[#15803D] border border-green-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Đã điểm danh
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#FEF3C7] text-[#B45309] border border-amber-200">
                        <XCircle className="w-3.5 h-3.5" />
                        Chưa điểm danh
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <button
                      onClick={() => handleToggleAttendance(reg.id, reg.attended)}
                      className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors ${
                        reg.attended
                          ? 'bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200'
                          : 'bg-[#0755D9] hover:bg-[#0646B5] text-white shadow-2xs'
                      }`}
                    >
                      {reg.attended ? 'Hủy điểm danh' : 'Điểm danh ngay'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* QR Code scanning dialog modal */}
      <QRCodeModal
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
        activityName={activity.name}
        onScanSuccess={handleQrScanSuccess}
      />
    </div>
  );
};
