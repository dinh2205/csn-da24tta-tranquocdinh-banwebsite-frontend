import React, { useState, useMemo } from 'react';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Check, X, Eye, FileText, AlertTriangle, Calendar, MapPin, Award } from 'lucide-react';

export const DuyetHoatDong: React.FC = () => {
  const { activities, approveActivity, rejectActivity } = useClub();
  const { currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [rejectingActivity, setRejectingActivity] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [viewingActivity, setViewingActivity] = useState<any>(null);

  const pendingList = useMemo(() => {
    return activities.filter((a) => a.status === 'Chờ phê duyệt');
  }, [activities]);

  const approvedList = useMemo(() => {
    return activities.filter((a) => a.status === 'Đã phê duyệt' || a.status === 'Đang diễn ra');
  }, [activities]);

  const rejectedList = useMemo(() => {
    return activities.filter((a) => a.status === 'Từ chối');
  }, [activities]);

  const currentList =
    activeTab === 'pending'
      ? pendingList
      : activeTab === 'approved'
      ? approvedList
      : rejectedList;

  const handleApprove = (id: string) => {
    approveActivity(id, currentUser.fullName || 'Ban Quản lý cấp trường');
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (rejectingActivity) {
      rejectActivity(rejectingActivity.id, rejectReason);
      setRejectingActivity(null);
      setRejectReason('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching Screen 10 */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Danh sách hoạt động chờ phê duyệt ({pendingList.length})
        </h1>
        <p className="text-xs text-gray-500">
          Ban Quản lý CLB cấp trường (Đoàn Thanh niên - Hội Sinh viên TVU) xem xét và phê duyệt kế hoạch
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#DCE6F0] flex gap-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('pending')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'pending'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Chờ phê duyệt ({pendingList.length})
        </button>
        <button
          onClick={() => setActiveTab('approved')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'approved'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã phê duyệt ({approvedList.length})
        </button>
        <button
          onClick={() => setActiveTab('rejected')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'rejected'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã từ chối ({rejectedList.length})
        </button>
      </div>

      {/* Data Table matching Screen 10: Columns: #, Tên hoạt động, CLB, Ngày đề xuất, Thời gian tổ chức, Trạng thái, Thao tác */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">Tên hoạt động</th>
                <th className="py-3 px-3.5">CLB</th>
                <th className="py-3 px-3.5">Ngày đề xuất</th>
                <th className="py-3 px-3.5">Thời gian tổ chức</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                <th className="py-3 px-3.5 text-center w-36">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {currentList.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-gray-500">
                    Không có hoạt động nào trong danh sách này.
                  </td>
                </tr>
              ) : (
                currentList.map((act, index) => (
                  <tr key={act.id} className="hover:bg-[#F8FAFF] transition-colors">
                    <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                      {index + 1}
                    </td>
                    <td className="py-3 px-3.5 font-bold text-gray-900 max-w-xs">
                      <button
                        onClick={() => setViewingActivity(act)}
                        className="text-left hover:text-[#0755D9] transition-colors underline decoration-dotted"
                      >
                        {act.name}
                      </button>
                    </td>
                    <td className="py-3 px-3.5 text-gray-700 font-medium">{act.clubName}</td>
                    <td className="py-3 px-3.5 text-gray-500">{act.submittedDate}</td>
                    <td className="py-3 px-3.5 text-gray-600 font-medium">
                      {act.startDate.split(' ')[0]}
                    </td>
                    <td className="py-3 px-3.5">
                      <StatusBadge status={act.status} size="sm" />
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      {act.status === 'Chờ phê duyệt' ? (
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Button Duyệt matching Screen 10 */}
                          <button
                            onClick={() => handleApprove(act.id)}
                            className="px-3 py-1 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded font-bold text-xs shadow-2xs transition-colors flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            Duyệt
                          </button>
                          {/* Button Từ chối matching Screen 10 */}
                          <button
                            onClick={() => setRejectingActivity(act)}
                            className="px-2.5 py-1 bg-[#EF4444] hover:bg-red-600 text-white rounded font-bold text-xs shadow-2xs transition-colors flex items-center gap-1"
                          >
                            <X className="w-3.5 h-3.5" />
                            Từ chối
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setViewingActivity(act)}
                          className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-xs font-semibold"
                        >
                          Xem chi tiết
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reject Reason Modal */}
      {rejectingActivity && (
        <Modal
          isOpen={true}
          onClose={() => setRejectingActivity(null)}
          title={`Từ chối hoạt động: ${rejectingActivity.name}`}
          maxWidth="sm"
        >
          <form onSubmit={handleConfirmReject} className="space-y-3.5 text-xs">
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>
                Vui lòng cung cấp lý do từ chối để Ban chủ nhiệm {rejectingActivity.clubName} có thể điều chỉnh và gửi lại đề xuất.
              </span>
            </div>

            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Lý do từ chối *
              </label>
              <textarea
                required
                rows={3}
                placeholder="VD: Trùng lịch với sự kiện toàn trường / Kế hoạch kinh phí chưa rõ ràng..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setRejectingActivity(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-[#EF4444] hover:bg-red-600 text-white rounded-md font-semibold"
              >
                Xác nhận từ chối
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* View Activity Detail Modal */}
      {viewingActivity && (
        <Modal
          isOpen={true}
          onClose={() => setViewingActivity(null)}
          title="Thông tin chi tiết đề xuất hoạt động"
          maxWidth="md"
        >
          <div className="space-y-3.5 text-xs">
            <div>
              <span className="text-gray-500 font-semibold block text-[11px]">Tên hoạt động:</span>
              <h3 className="font-extrabold text-sm text-[#073A68] mt-0.5">{viewingActivity.name}</h3>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-gray-50 rounded-lg">
              <div>
                <span className="text-gray-500">CLB đề xuất:</span>
                <p className="font-bold text-gray-800">{viewingActivity.clubName}</p>
              </div>
              <div>
                <span className="text-gray-500">Trạng thái:</span>
                <div className="mt-0.5"><StatusBadge status={viewingActivity.status} size="sm" /></div>
              </div>
              <div>
                <span className="text-gray-500">Thời gian:</span>
                <p className="font-medium text-gray-800">{viewingActivity.startDate}</p>
              </div>
              <div>
                <span className="text-gray-500">Địa điểm:</span>
                <p className="font-medium text-gray-800">{viewingActivity.location}</p>
              </div>
              <div>
                <span className="text-gray-500">Dự kiến tham gia:</span>
                <p className="font-medium text-gray-800">{viewingActivity.maxCapacity} sinh viên</p>
              </div>
              <div>
                <span className="text-gray-500">Điểm RL đề xuất:</span>
                <p className="font-bold text-amber-600">+{viewingActivity.proposedTrainingPoints} điểm</p>
              </div>
            </div>

            <div>
              <span className="text-gray-500 font-semibold block mb-1">Mô tả kế hoạch:</span>
              <p className="text-gray-700 leading-relaxed bg-[#F8FAFC] p-3 rounded border border-gray-200">
                {viewingActivity.description}
              </p>
            </div>

            {viewingActivity.rejectionReason && (
              <div className="p-3 bg-red-50 border border-red-200 rounded text-red-800">
                <span className="font-bold block">Lý do từ chối:</span>
                <p>{viewingActivity.rejectionReason}</p>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
              {viewingActivity.status === 'Chờ phê duyệt' && (
                <button
                  type="button"
                  onClick={() => {
                    handleApprove(viewingActivity.id);
                    setViewingActivity(null);
                  }}
                  className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded font-bold"
                >
                  Phê duyệt ngay
                </button>
              )}
              <button
                type="button"
                onClick={() => setViewingActivity(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
