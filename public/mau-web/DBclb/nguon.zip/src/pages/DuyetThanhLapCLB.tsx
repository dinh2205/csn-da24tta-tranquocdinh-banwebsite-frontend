import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Check, X, Sparkles, User, Mail, FileText, CheckCircle2 } from 'lucide-react';

export const DuyetThanhLapCLB: React.FC = () => {
  const { proposals, approveClubProposal, rejectClubProposal } = useClub();
  const { currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'pending' | 'reviewed'>('pending');
  const [rejectingProposal, setRejectingProposal] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');

  const pendingList = proposals.filter((p) => p.status === 'pending');
  const reviewedList = proposals.filter((p) => p.status !== 'pending');

  const handleApprove = (id: string) => {
    approveClubProposal(id, currentUser.fullName || 'Ban Quản lý cấp trường');
  };

  const handleRejectConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (rejectingProposal) {
      rejectClubProposal(rejectingProposal.id, rejectReason);
      setRejectingProposal(null);
      setRejectReason('');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Thẩm định &amp; Phê duyệt thành lập CLB mới ({pendingList.length})
        </h1>
        <p className="text-xs text-gray-500">
          Ban Quản lý CLB cấp trường xem xét đề án thành lập các câu lạc bộ sinh viên mới tại Đại học Trà Vinh
        </p>
      </div>

      <div className="border-b border-[#DCE6F0] flex gap-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('pending')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'pending'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Hồ sơ chờ thẩm định ({pendingList.length})
        </button>
        <button
          onClick={() => setActiveTab('reviewed')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'reviewed'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã thẩm định ({reviewedList.length})
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {activeTab === 'pending' ? (
          pendingList.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-xl border border-[#DCE6F0] text-gray-500 text-xs">
              Hiện tại không có đề xuất thành lập CLB nào chờ thẩm định.
            </div>
          ) : (
            pendingList.map((p) => (
              <div
                key={p.id}
                className="bg-white p-6 rounded-2xl border border-[#DCE6F0] shadow-xs space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base font-bold text-[#073A68]">{p.clubName}</h2>
                      <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-blue-50 text-[#0755D9] border border-blue-200">
                        {p.category}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Người đề xuất: <strong>{p.proposerName}</strong> (MSSV: {p.proposedByStudentId}) • Email: {p.proposerEmail} • SĐT: {p.proposerPhone}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleApprove(p.id)}
                      className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs"
                    >
                      <Check className="w-4 h-4" />
                      Phê duyệt thành lập
                    </button>
                    <button
                      onClick={() => setRejectingProposal(p)}
                      className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg text-xs font-bold flex items-center gap-1"
                    >
                      <X className="w-4 h-4" />
                      Từ chối
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-gray-50 p-4 rounded-xl border border-gray-200">
                  <div className="space-y-1">
                    <span className="font-bold text-gray-800 block">Tôn chỉ &amp; Mục đích:</span>
                    <p className="text-gray-600 leading-relaxed">{p.goal}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="font-bold text-gray-800 block">Kế hoạch hoạt động:</span>
                    <p className="text-gray-600 leading-relaxed">{p.actionPlan}</p>
                  </div>
                </div>
              </div>
            ))
          )
        ) : (
          reviewedList.map((p) => (
            <div
              key={p.id}
              className="bg-white p-5 rounded-xl border border-[#DCE6F0] flex items-center justify-between gap-4 text-xs"
            >
              <div>
                <h3 className="font-bold text-gray-900 text-sm">{p.clubName}</h3>
                <p className="text-gray-500">Người đề xuất: {p.proposerName} • Lĩnh vực: {p.category}</p>
                {p.reviewNote && (
                  <p className="text-gray-700 italic mt-1">Ghi chú: {p.reviewNote}</p>
                )}
              </div>
              <StatusBadge
                status={p.status === 'approved' ? 'Đã phê duyệt' : 'Từ chối'}
                size="sm"
              />
            </div>
          ))
        )}
      </div>

      {rejectingProposal && (
        <Modal
          isOpen={true}
          onClose={() => setRejectingProposal(null)}
          title={`Từ chối đề xuất: ${rejectingProposal.clubName}`}
          maxWidth="sm"
        >
          <form onSubmit={handleRejectConfirm} className="space-y-3.5 text-xs">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Lý do không chấp thuận *
              </label>
              <textarea
                required
                rows={3}
                placeholder="VD: Định hướng hoạt động trùng lặp với CLB hiện có..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setRejectingProposal(null)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md font-semibold"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white rounded-md font-semibold"
              >
                Xác nhận từ chối
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
