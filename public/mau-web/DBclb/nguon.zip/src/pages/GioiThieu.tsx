import React from 'react';
import { GraduationCap, Award, ShieldCheck, HeartHandshake, BookOpen, Layers } from 'lucide-react';

export const GioiThieu: React.FC = () => {
  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#0755D9] text-white shadow-md mx-auto mb-2">
          <GraduationCap className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#073A68]">
          Hệ thống TVU CLUB - Đại học Trà Vinh
        </h1>
        <p className="text-xs sm:text-sm text-gray-500 max-w-2xl mx-auto">
          Nền tảng quản lý toàn diện mạng lưới câu lạc bộ sinh viên, hỗ trợ học tập, nghiên cứu và rèn luyện kỹ năng thực chiến
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 sm:p-8 shadow-xs space-y-6 text-xs text-gray-700 leading-relaxed">
        <div>
          <h2 className="text-base font-bold text-[#073A68] mb-2 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-[#0755D9]" />
            1. Mục tiêu &amp; Tầm nhìn
          </h2>
          <p>
            Hệ thống Quản lý Câu lạc bộ Sinh viên Trường Đại học Trà Vinh (TVU CLUB) được phát triển nhằm chuẩn hóa quy trình quản trị, số hóa toàn bộ dữ liệu thành viên, kế hoạch hoạt động và đánh giá điểm rèn luyện của sinh viên TVU.
          </p>
        </div>

        <div>
          <h2 className="text-base font-bold text-[#073A68] mb-2 flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#0755D9]" />
            2. Các phân hệ chức năng chính
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
            <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
              <strong className="text-blue-900 block mb-1">Cổng thông tin sinh viên</strong>
              <p className="text-gray-600 text-[11px]">Tìm kiếm câu lạc bộ, gửi yêu cầu gia nhập, đăng ký tham gia sự kiện và theo dõi điểm rèn luyện cá nhân.</p>
            </div>
            <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
              <strong className="text-blue-900 block mb-1">Bàn làm việc Ban chủ nhiệm</strong>
              <p className="text-gray-600 text-[11px]">Quản trị thành viên, tạo kế hoạch hoạt động, điểm danh QR và đề xuất điểm rèn luyện.</p>
            </div>
            <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
              <strong className="text-blue-900 block mb-1">Ban Quản lý cấp trường</strong>
              <p className="text-gray-600 text-[11px]">Thẩm định đề án thành lập CLB mới, phê duyệt kế hoạch hoạt động và báo cáo số liệu toàn trường.</p>
            </div>
            <div className="p-3 bg-[#F8FAFC] rounded-lg border border-gray-200">
              <strong className="text-blue-900 block mb-1">Hệ thống Quản trị viên</strong>
              <p className="text-gray-600 text-[11px]">Quản lý danh sách tài khoản, phân quyền bảo mật và giám sát nhật ký vận hành.</p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-base font-bold text-[#073A68] mb-2 flex items-center gap-2">
            <Award className="w-5 h-5 text-[#0755D9]" />
            3. Quy chuẩn Điểm rèn luyện
          </h2>
          <p>
            Mỗi hoạt động hợp lệ tổ chức bởi các CLB được Đoàn trường phân bổ từ 5 đến 25 điểm rèn luyện. Điểm số chỉ được ghi nhận chính thức sau khi sinh viên được điểm danh tại sự kiện và Ban Quản lý cấp trường phê duyệt biên bản nghiệm thu.
          </p>
        </div>
      </div>
    </div>
  );
};
