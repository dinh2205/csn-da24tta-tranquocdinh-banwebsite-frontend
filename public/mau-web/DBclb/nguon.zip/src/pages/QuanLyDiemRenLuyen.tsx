import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Award, Check, X, Plus, CheckCircle2, Clock, AlertCircle } from 'lucide-react';

export const QuanLyDiemRenLuyen: React.FC = () => {
  const { trainingPoints, activities, members, proposeTrainingPoints, approveTrainingPoints, rejectTrainingPoints } = useClub();
  const { role, currentUser } = useAuth();

  const [isProposeModalOpen, setIsProposeModalOpen] = useState(false);
  const [selectedActivityId, setSelectedActivityId] = useState('HD001');
  const [targetStudentId, setTargetStudentId] = useState('110124033');
  const [targetFullName, setTargetFullName] = useState('Nguyễn Thị A');
  const [targetClass, setTargetClass] = useState('DA24TTA');
  const [pointValue, setPointValue] = useState(15);

  const isStudent = role === 'student';
  const isClubManager = role === 'club_manager';
  const isSchoolManager = role === 'school_manager' || role === 'admin';

  // Filter based on role
  const displayList = isStudent
    ? trainingPoints.filter((tp) => tp.studentId === (currentUser.studentId || '110124033'))
    : trainingPoints;

  const totalApprovedPoints = displayList
    .filter((tp) => tp.status === 'approved')
    .reduce((sum, item) => sum + item.points, 0);

  const handleProposeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    proposeTrainingPoints(selectedActivityId, targetStudentId, targetFullName, targetClass, Number(pointValue));
    setIsProposeModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            {isStudent
              ? 'Điểm rèn luyện của tôi'
              : isClubManager
              ? 'Đề xuất Điểm rèn luyện hoạt động CLB'
              : 'Xác nhận & Phê duyệt Điểm rèn luyện'}
          </h1>
          <p className="text-xs text-gray-500">
            Quy trình đề xuất và phê duyệt điểm rèn luyện minh bạch theo kết quả điểm danh thực tế
          </p>
        </div>

        {isClubManager && (
          <button
            onClick={() => setIsProposeModalOpen(true)}
            className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Đề xuất điểm RL cho sinh viên</span>
          </button>
        )}
      </div>

      {/* Metric banner */}
      <div className="bg-gradient-to-r from-[#073A68] to-[#0755D9] text-white p-5 rounded-2xl shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-amber-300">
            <Award className="w-7 h-7" />
          </div>
          <div>
            <span className="text-xs text-blue-200">
              {isStudent ? 'Tổng điểm rèn luyện đã được duyệt:' : 'Tổng số bản ghi điểm rèn luyện:'}
            </span>
            <h2 className="text-2xl font-extrabold text-white">
              {isStudent ? `${totalApprovedPoints} điểm` : `${trainingPoints.length} bản ghi`}
            </h2>
          </div>
        </div>

        <div className="text-right text-xs text-blue-200">
          <p>Học kỳ: <strong>Học kỳ 1 / 2026 - 2027</strong></p>
          <p>Trường Đại học Trà Vinh</p>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">MSSV</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3.5">Hoạt động tham gia</th>
                <th className="py-3 px-3.5">CLB tổ chức</th>
                <th className="py-3 px-3.5 text-center">Số điểm</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                {isSchoolManager && <th className="py-3 px-3.5 text-center w-28">Thao tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {displayList.map((item, idx) => (
                <tr key={item.id} className="hover:bg-[#F8FAFF]">
                  <td className="py-3 px-3.5 text-center font-medium text-gray-500">{idx + 1}</td>
                  <td className="py-3 px-3.5 font-semibold text-gray-900">{item.studentId}</td>
                  <td className="py-3 px-3.5 font-bold text-[#0755D9]">{item.fullName}</td>
                  <td className="py-3 px-3.5 text-gray-800 font-medium">{item.activityName}</td>
                  <td className="py-3 px-3.5 text-gray-600">{item.clubName}</td>
                  <td className="py-3 px-3.5 text-center font-bold text-amber-600">
                    +{item.points} điểm
                  </td>
                  <td className="py-3 px-3.5">
                    <StatusBadge
                      status={
                        item.status === 'approved'
                          ? 'Đã phê duyệt'
                          : item.status === 'proposed'
                          ? 'Chờ phê duyệt'
                          : 'Từ chối'
                      }
                      size="sm"
                    />
                  </td>
                  {isSchoolManager && (
                    <td className="py-3 px-3.5 text-center">
                      {item.status === 'proposed' ? (
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => approveTrainingPoints(item.id, currentUser.fullName)}
                            className="px-2.5 py-1 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded text-xs font-bold"
                          >
                            Duyệt
                          </button>
                          <button
                            onClick={() => rejectTrainingPoints(item.id)}
                            className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-bold"
                          >
                            Từ chối
                          </button>
                        </div>
                      ) : (
                        <span className="text-gray-400 text-[11px]">-</span>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Propose Modal */}
      <Modal
        isOpen={isProposeModalOpen}
        onClose={() => setIsProposeModalOpen(false)}
        title="Đề xuất cộng Điểm rèn luyện hoạt động"
        maxWidth="md"
      >
        <form onSubmit={handleProposeSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-gray-700 block mb-1">Chọn hoạt động *</label>
            <select
              value={selectedActivityId}
              onChange={(e) => setSelectedActivityId(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            >
              {activities.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.startDate.split(' ')[0]})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Mã sinh viên *</label>
              <input
                type="text"
                required
                value={targetStudentId}
                onChange={(e) => setTargetStudentId(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Lớp *</label>
              <input
                type="text"
                required
                value={targetClass}
                onChange={(e) => setTargetClass(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên sinh viên *</label>
            <input
              type="text"
              required
              value={targetFullName}
              onChange={(e) => setTargetFullName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Số điểm đề xuất</label>
            <input
              type="number"
              min="5"
              max="25"
              value={pointValue}
              onChange={(e) => setPointValue(Number(e.target.value))}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsProposeModalOpen(false)}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold"
            >
              Gửi đề xuất
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
