import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import {
  CalendarPlus,
  QrCode,
  Eye,
  CheckCircle2,
  Clock,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Send,
  Calendar
} from 'lucide-react';

export const QuanLyHoatDong: React.FC = () => {
  const { activities, createActivity } = useClub();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'approved' | 'ongoing' | 'finished'>('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedActivity, setSelectedActivity] = useState<any>(null);

  // Form states for new activity
  const [name, setName] = useState('');
  const [typeTag, setTypeTag] = useState('Workshop');
  const [category, setCategory] = useState('Học thuật');
  const [startDate, setStartDate] = useState('15/11/2026 08:00');
  const [endDate, setEndDate] = useState('15/11/2026 11:30');
  const [location, setLocation] = useState('Hội trường A - Đại học Trà Vinh');
  const [maxCapacity, setMaxCapacity] = useState(100);
  const [registrationDeadline, setRegistrationDeadline] = useState('12/11/2026');
  const [proposedTrainingPoints, setProposedTrainingPoints] = useState(15);
  const [targetAudience, setTargetAudience] = useState('Sinh viên toàn trường');
  const [description, setDescription] = useState('');

  const filterCounts = useMemo(() => {
    return {
      all: activities.length,
      pending: activities.filter((a) => a.status === 'Chờ phê duyệt').length,
      approved: activities.filter((a) => a.status === 'Đã phê duyệt').length,
      ongoing: activities.filter((a) => a.status === 'Đang diễn ra').length,
      finished: activities.filter((a) => a.status === 'Đã kết thúc').length
    };
  }, [activities]);

  const filteredActivities = useMemo(() => {
    switch (activeTab) {
      case 'pending':
        return activities.filter((a) => a.status === 'Chờ phê duyệt');
      case 'approved':
        return activities.filter((a) => a.status === 'Đã phê duyệt');
      case 'ongoing':
        return activities.filter((a) => a.status === 'Đang diễn ra');
      case 'finished':
        return activities.filter((a) => a.status === 'Đã kết thúc');
      default:
        return activities;
    }
  }, [activities, activeTab]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createActivity({
      clubId: 'CLB001',
      clubName: 'CLB Công nghệ thông tin',
      name,
      typeTag,
      category,
      startDate,
      endDate,
      location,
      maxCapacity: Number(maxCapacity),
      registrationDeadline,
      proposedTrainingPoints: Number(proposedTrainingPoints),
      targetAudience,
      description: description || 'Hoạt động nâng cao kỹ năng cho sinh viên Đại học Trà Vinh.',
      bannerImage: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1000&q=80',
      status: 'Chờ phê duyệt'
    });
    setIsCreateModalOpen(false);
    setName('');
    setDescription('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching Screen 8: Danh sách hoạt động (15) + button Tạo hoạt động */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Danh sách hoạt động ({activities.length})
          </h1>
          <p className="text-xs text-gray-500">
            Quản lý kế hoạch, đề xuất phê duyệt và danh sách sinh viên đăng ký tham gia
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <CalendarPlus className="w-4 h-4" />
          <span>Tạo hoạt động</span>
        </button>
      </div>

      {/* Tabs Filter matching Screen 8: Tất cả (15), Chờ phê duyệt (3), Đã phê duyệt (10), Đang diễn ra (2), Đã kết thúc */}
      <div className="border-b border-[#DCE6F0] flex flex-wrap gap-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('all')}
          className={`pb-2.5 px-3 border-b-2 transition-all ${
            activeTab === 'all'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Tất cả ({filterCounts.all})
        </button>
        <button
          onClick={() => setActiveTab('pending')}
          className={`pb-2.5 px-3 border-b-2 transition-all ${
            activeTab === 'pending'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Chờ phê duyệt ({filterCounts.pending})
        </button>
        <button
          onClick={() => setActiveTab('approved')}
          className={`pb-2.5 px-3 border-b-2 transition-all ${
            activeTab === 'approved'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã phê duyệt ({filterCounts.approved})
        </button>
        <button
          onClick={() => setActiveTab('ongoing')}
          className={`pb-2.5 px-3 border-b-2 transition-all ${
            activeTab === 'ongoing'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đang diễn ra ({filterCounts.ongoing})
        </button>
        <button
          onClick={() => setActiveTab('finished')}
          className={`pb-2.5 px-3 border-b-2 transition-all ${
            activeTab === 'finished'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã kết thúc ({filterCounts.finished})
        </button>
      </div>

      {/* Data Table matching Screen 8: Columns: #, Tên hoạt động, Ngày tổ chức, Địa điểm, Trạng thái, Số đăng ký, Thao tác */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">Tên hoạt động</th>
                <th className="py-3 px-3.5">Ngày tổ chức</th>
                <th className="py-3 px-3.5">Địa điểm</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                <th className="py-3 px-3.5 text-center">Số đăng ký</th>
                <th className="py-3 px-3.5 text-center w-28">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredActivities.map((act, index) => (
                <tr key={act.id} className="hover:bg-[#F8FAFF] transition-colors">
                  <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                    {index + 1}
                  </td>
                  <td className="py-3 px-3.5 font-bold text-gray-900 max-w-xs">
                    <div className="flex items-center gap-2">
                      <span className="truncate">{act.name}</span>
                      {act.id === 'HD001' && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-blue-100 text-[#0755D9] font-bold shrink-0">
                          Thành viên
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-3.5 text-gray-600 font-medium">
                    {act.startDate.split(' ')[0]}
                  </td>
                  <td className="py-3 px-3.5 text-gray-600">{act.location}</td>
                  <td className="py-3 px-3.5">
                    <StatusBadge status={act.status} size="sm" />
                  </td>
                  <td className="py-3 px-3.5 text-center font-semibold text-gray-800">
                    {act.registeredCount}/{act.maxCapacity}
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {/* Direct button to Điểm danh if approved or ongoing */}
                      {(act.status === 'Đã phê duyệt' || act.status === 'Đang diễn ra') && (
                        <Link
                          to={`/ban-chu-nhiem/diem-danh/${act.id}`}
                          className="p-1 px-2 rounded bg-[#EAF3FF] text-[#0755D9] hover:bg-blue-100 font-semibold text-[11px] flex items-center gap-1"
                          title="Điểm danh sinh viên"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>Điểm danh</span>
                        </Link>
                      )}
                      <Link
                        to={`/hoat-dong/${act.id}`}
                        className="p-1 hover:bg-gray-100 text-gray-500 hover:text-[#0755D9] rounded"
                        title="Xem chi tiết"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination at bottom matching Screen 8 */}
        <div className="px-4 py-3 border-t border-[#DCE6F0] flex items-center justify-between text-xs text-gray-500 bg-[#F8FAFC]">
          <span>Hiển thị 5 / 15 hoạt động</span>
          <div className="flex items-center gap-1">
            <button className="p-1 rounded border border-gray-300 text-gray-400">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button className="w-6 h-6 rounded bg-[#0755D9] text-white font-bold flex items-center justify-center">
              1
            </button>
            <button className="w-6 h-6 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              2
            </button>
            <button className="w-6 h-6 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              3
            </button>
            <button className="w-6 h-6 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              4
            </button>
            <button className="p-1 rounded border border-gray-300 hover:bg-gray-100 text-gray-600">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal Tạo hoạt động mới */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Tạo đề xuất hoạt động câu lạc bộ mới"
        maxWidth="lg"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-gray-700 block mb-1">
              Tên hoạt động *
            </label>
            <input
              type="text"
              required
              placeholder="VD: Workshop: Lập trình di động Flutter..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Loại hình</label>
              <select
                value={typeTag}
                onChange={(e) => setTypeTag(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              >
                <option value="Workshop">Workshop thực hành</option>
                <option value="Talkshow">Talkshow tọa đàm</option>
                <option value="Cuộc thi">Cuộc thi học thuật</option>
                <option value="Tình nguyện">Hoạt động tình nguyện</option>
                <option value="Giao lưu">Giao lưu văn nghệ</option>
              </select>
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Lĩnh vực</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              >
                <option value="Học thuật">Học thuật</option>
                <option value="Công nghệ">Công nghệ</option>
                <option value="Văn hóa">Văn hóa</option>
                <option value="Thể thao">Thể thao</option>
                <option value="Tình nguyện">Tình nguyện</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Thời gian bắt đầu *
              </label>
              <input
                type="text"
                placeholder="15/11/2026 08:00"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Thời gian kết thúc
              </label>
              <input
                type="text"
                placeholder="15/11/2026 11:30"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="font-semibold text-gray-700 block mb-1">Địa điểm *</label>
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Số lượng tối đa</label>
              <input
                type="number"
                min="10"
                max="500"
                value={maxCapacity}
                onChange={(e) => setMaxCapacity(Number(e.target.value))}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Hạn chót đăng ký
              </label>
              <input
                type="text"
                value={registrationDeadline}
                onChange={(e) => setRegistrationDeadline(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Điểm rèn luyện đề xuất (ĐRL)
              </label>
              <input
                type="number"
                min="5"
                max="30"
                value={proposedTrainingPoints}
                onChange={(e) => setProposedTrainingPoints(Number(e.target.value))}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Mô tả kế hoạch</label>
            <textarea
              rows={3}
              placeholder="Chi tiết kế hoạch tổ chức hoạt động, diễn giả, nội dung chương trình..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded text-[11px] text-blue-900">
            * Sau khi nhấn gửi, đề xuất sẽ chuyển tới Ban Quản lý cấp trường (Đoàn trường) xét duyệt trước khi công bố cho sinh viên toàn trường đăng ký.
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              Gửi đề xuất phê duyệt
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
