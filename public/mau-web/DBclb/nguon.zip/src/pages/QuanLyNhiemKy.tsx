import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { useToast } from '../context/ToastContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Clock, UserCheck, Plus, Award, Calendar, ShieldCheck } from 'lucide-react';

export const QuanLyNhiemKy: React.FC = () => {
  const { terms } = useClub();
  const { showToast } = useToast();

  const [activeTermIndex, setActiveTermIndex] = useState(0);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [newAssignMssv, setNewAssignMssv] = useState('');
  const [newAssignName, setNewAssignName] = useState('');
  const [newAssignPosition, setNewAssignPosition] = useState('Phó chủ nhiệm');

  const currentTerm = terms[activeTermIndex] || terms[0];

  const handleAssignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    showToast(`Đã bổ nhiệm ${newAssignName} giữ chức vụ ${newAssignPosition}!`, 'success');
    setIsAssignModalOpen(false);
    setNewAssignMssv('');
    setNewAssignName('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Nhiệm kỳ và Phân công chức vụ
          </h1>
          <p className="text-xs text-gray-500">
            Quản lý cơ cấu Ban chủ nhiệm, các chức vụ lãnh đạo theo từng nhiệm kỳ hoạt động
          </p>
        </div>

        <button
          onClick={() => setIsAssignModalOpen(true)}
          className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Bổ nhiệm chức vụ mới</span>
        </button>
      </div>

      {/* Term Selector Card */}
      <div className="bg-white p-5 rounded-2xl border border-[#DCE6F0] shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#EAF3FF] text-[#0755D9] flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-gray-900">
                {currentTerm.termName}
              </h2>
              <span className="text-xs text-gray-500">
                {currentTerm.startDate} đến {currentTerm.endDate}
              </span>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#DCFCE7] text-[#15803D] border border-green-200">
            Nhiệm kỳ đương nhiệm
          </span>
        </div>

        {/* Assignments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold">
              <tr>
                <th className="py-2.5 px-3">#</th>
                <th className="py-2.5 px-3">MSSV</th>
                <th className="py-2.5 px-3">Họ và tên</th>
                <th className="py-2.5 px-3">Chức vụ đảm nhiệm</th>
                <th className="py-2.5 px-3">Ngày nhận chức</th>
                <th className="py-2.5 px-3">Trạng thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {currentTerm.assignments.map((item, index) => (
                <tr key={item.studentId} className="hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-medium text-gray-500">{index + 1}</td>
                  <td className="py-2.5 px-3 font-semibold text-gray-900">{item.studentId}</td>
                  <td className="py-2.5 px-3 font-bold text-[#0755D9]">{item.fullName}</td>
                  <td className="py-2.5 px-3 font-semibold text-amber-700">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-50 border border-amber-200">
                      {item.position}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-gray-500">{item.appointedDate}</td>
                  <td className="py-2.5 px-3">
                    <StatusBadge status="Đang hoạt động" size="sm" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Roles & Responsibilities Guidelines */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="bg-white p-4 rounded-xl border border-[#DCE6F0] space-y-1.5 shadow-2xs">
          <span className="font-bold text-[#073A68] block">Chủ nhiệm CLB</span>
          <p className="text-gray-600 leading-relaxed text-[11px]">
            Chịu trách nhiệm toàn diện trước Ban Quản lý cấp trường về hoạt động, tài chính và nhân sự của CLB.
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-[#DCE6F0] space-y-1.5 shadow-2xs">
          <span className="font-bold text-[#073A68] block">Phó chủ nhiệm CLB</span>
          <p className="text-gray-600 leading-relaxed text-[11px]">
            Phụ trách chuyên môn kỹ thuật hoặc phong trào truyền thông, hỗ trợ Chủ nhiệm điều phối công tác.
          </p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-[#DCE6F0] space-y-1.5 shadow-2xs">
          <span className="font-bold text-[#073A68] block">Trưởng các ban chuyên môn</span>
          <p className="text-gray-600 leading-relaxed text-[11px]">
            Điều hành trực tiếp các thành viên thực hiện nhiệm vụ theo từng dự án và workshop của CLB.
          </p>
        </div>
      </div>

      {/* Modal Bổ nhiệm */}
      <Modal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        title="Quyết định phân công chức vụ BCN CLB"
        maxWidth="md"
      >
        <form onSubmit={handleAssignSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Mã sinh viên *</label>
              <input
                type="text"
                required
                placeholder="110124..."
                value={newAssignMssv}
                onChange={(e) => setNewAssignMssv(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Chức vụ bổ nhiệm *</label>
              <select
                value={newAssignPosition}
                onChange={(e) => setNewAssignPosition(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800 font-semibold"
              >
                <option value="Phó chủ nhiệm">Phó chủ nhiệm</option>
                <option value="Trưởng ban Kỹ thuật">Trưởng ban Kỹ thuật</option>
                <option value="Trưởng ban Truyền thông">Trưởng ban Truyền thông</option>
                <option value="Trưởng ban Nội dung">Trưởng ban Nội dung</option>
                <option value="Thư ký CLB">Thư ký CLB</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên *</label>
            <input
              type="text"
              required
              placeholder="Nhập họ và tên sinh viên..."
              value={newAssignName}
              onChange={(e) => setNewAssignName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="p-2.5 bg-blue-50 border border-blue-200 rounded text-[11px] text-blue-900">
            * Sau khi lưu, thông tin phân công chức vụ sẽ được ghi nhận vào biên bản nhiệm kỳ của CLB và đồng bộ sang hồ sơ sinh viên.
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsAssignModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold"
            >
              Lưu phân công
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
