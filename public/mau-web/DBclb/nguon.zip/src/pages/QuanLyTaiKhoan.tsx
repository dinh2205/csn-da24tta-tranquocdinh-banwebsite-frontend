import React, { useState, useMemo } from 'react';
import { useClub } from '../context/ClubContext';
import { useToast } from '../context/ToastContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { UserAccount, UserRole } from '../types';
import {
  UserPlus,
  Search,
  MoreHorizontal,
  Shield,
  Lock,
  Unlock,
  KeyRound,
  Edit,
  Trash2
} from 'lucide-react';

export const QuanLyTaiKhoan: React.FC = () => {
  const { accounts, addAccount, updateAccount, toggleAccountStatus } = useClub();
  const { showToast } = useToast();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('Tất cả');
  const [filterStatus, setFilterStatus] = useState('Tất cả');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<UserAccount | null>(null);
  const [isActionModalOpen, setIsActionModalOpen] = useState(false);

  // Form states for new account
  const [newUsername, setNewUsername] = useState('');
  const [newFullName, setNewFullName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('student');
  const [newPassword, setNewPassword] = useState('tvu@2026');

  const filteredAccounts = useMemo(() => {
    let result = [...accounts];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (a) =>
          a.username.toLowerCase().includes(q) ||
          a.fullName.toLowerCase().includes(q) ||
          a.email.toLowerCase().includes(q)
      );
    }

    if (filterRole !== 'Tất cả') {
      result = result.filter((a) => a.role === filterRole || a.roleTitle.includes(filterRole));
    }

    if (filterStatus !== 'Tất cả') {
      const statusKey = filterStatus === 'Hoạt động' ? 'active' : 'locked';
      result = result.filter((a) => a.status === statusKey);
    }

    return result;
  }, [accounts, searchTerm, filterRole, filterStatus]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const roleTitles: Record<UserRole, string> = {
      guest: 'Khách',
      student: 'Sinh viên',
      club_manager: 'Ban chủ nhiệm CLB',
      school_manager: 'Ban Quản lý cấp trường',
      admin: 'Quản trị viên'
    };

    addAccount({
      username: newUsername,
      fullName: newFullName,
      email: newEmail,
      role: newRole,
      roleTitle: roleTitles[newRole],
      status: 'active'
    });

    setIsAddModalOpen(false);
    setNewUsername('');
    setNewFullName('');
    setNewEmail('');
  };

  const handleChangeRole = (role: UserRole) => {
    if (!selectedAccount) return;
    const roleTitles: Record<UserRole, string> = {
      guest: 'Khách',
      student: 'Sinh viên',
      club_manager: 'Ban chủ nhiệm CLB',
      school_manager: 'Ban Quản lý cấp trường',
      admin: 'Quản trị viên'
    };
    updateAccount(selectedAccount.id, {
      role,
      roleTitle: roleTitles[role]
    });
    setIsActionModalOpen(false);
  };

  const handleToggleLock = () => {
    if (!selectedAccount) return;
    toggleAccountStatus(selectedAccount.id);
    setIsActionModalOpen(false);
  };

  const handleResetPassword = () => {
    if (!selectedAccount) return;
    showToast(`Đã đặt lại mật khẩu mặc định cho tài khoản ${selectedAccount.username}!`, 'success');
    setIsActionModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching Screen 12: Danh sách tài khoản (250) + Button Thêm tài khoản */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Danh sách tài khoản (250)
          </h1>
          <p className="text-xs text-gray-500">
            Quản lý tài khoản người dùng, phân quyền vai trò và bảo mật hệ thống TVU CLUB
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Thêm tài khoản</span>
        </button>
      </div>

      {/* Toolbar Filters matching Screen 12: Tìm kiếm theo tên/email, Vai trò, Trạng thái */}
      <div className="bg-white p-3.5 rounded-xl border border-[#DCE6F0] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Tìm kiếm theo tên, email, tên đăng nhập..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-gray-600">
            <span className="shrink-0 text-gray-500 font-medium">Vai trò:</span>
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
            >
              <option value="Tất cả">Tất cả</option>
              <option value="student">Sinh viên</option>
              <option value="club_manager">Chủ nhiệm CLB</option>
              <option value="school_manager">Ban quản lý cấp trường</option>
              <option value="admin">Quản trị viên</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-gray-600">
            <span className="shrink-0 text-gray-500 font-medium">Trạng thái:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
            >
              <option value="Tất cả">Tất cả</option>
              <option value="Hoạt động">Hoạt động</option>
              <option value="Khóa">Khóa</option>
            </select>
          </div>
        </div>
      </div>

      {/* Account Table matching Screen 12: Columns: #, Tên đăng nhập, Họ và tên, Vai trò, Trạng thái, Thao tác */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">Tên đăng nhập</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3.5">Vai trò</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                <th className="py-3 px-3.5 text-center w-24">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredAccounts.map((acc, index) => (
                <tr key={acc.id} className="hover:bg-[#F8FAFF] transition-colors">
                  <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                    {index + 1}
                  </td>
                  <td className="py-3 px-3.5 font-semibold text-gray-900 font-mono text-xs">
                    {acc.username}
                  </td>
                  <td className="py-3 px-3.5 font-bold text-[#0755D9]">{acc.fullName}</td>
                  <td className="py-3 px-3.5 font-medium text-gray-700">
                    <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-[#0755D9] border border-blue-200">
                      {acc.roleTitle}
                    </span>
                  </td>
                  <td className="py-3 px-3.5">
                    <StatusBadge
                      status={acc.status === 'active' ? 'Hoạt động' : 'Khóa'}
                      size="sm"
                    />
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <button
                      onClick={() => {
                        setSelectedAccount(acc);
                        setIsActionModalOpen(true);
                      }}
                      className="p-1 hover:bg-gray-100 text-gray-500 hover:text-[#0755D9] rounded transition-colors"
                      title="Quản lý tài khoản"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Thêm tài khoản mới */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Thêm tài khoản người dùng mới"
        maxWidth="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Tên đăng nhập (MSSV / Username) *
              </label>
              <input
                type="text"
                required
                placeholder="VD: 110124099..."
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Vai trò hệ thống</label>
              <select
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as UserRole)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800 font-medium"
              >
                <option value="student">Sinh viên</option>
                <option value="club_manager">Ban chủ nhiệm CLB</option>
                <option value="school_manager">Ban Quản lý cấp trường</option>
                <option value="admin">Quản trị viên</option>
              </select>
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên *</label>
            <input
              type="text"
              required
              placeholder="VD: Nguyễn Văn Nam..."
              value={newFullName}
              onChange={(e) => setNewFullName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Email *</label>
            <input
              type="email"
              required
              placeholder="email@tvu.edu.vn..."
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Mật khẩu mặc định</label>
            <input
              type="text"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800 font-mono"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold"
            >
              Tạo tài khoản
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Actions on Account: Đổi vai trò, Khóa/Mở khóa, Reset mật khẩu */}
      {selectedAccount && (
        <Modal
          isOpen={isActionModalOpen}
          onClose={() => setIsActionModalOpen(false)}
          title={`Phân quyền & Quản lý: ${selectedAccount.username}`}
          maxWidth="sm"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-gray-50 rounded-lg space-y-1">
              <p>Họ tên: <strong>{selectedAccount.fullName}</strong></p>
              <p>Email: <strong>{selectedAccount.email}</strong></p>
              <p>Vai trò hiện tại: <strong>{selectedAccount.roleTitle}</strong></p>
              <p>Trạng thái: <StatusBadge status={selectedAccount.status === 'active' ? 'Hoạt động' : 'Khóa'} size="sm" /></p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-gray-800 block">Đổi vai trò:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleChangeRole('student')}
                  className="p-2 rounded bg-blue-50 hover:bg-blue-100 text-[#0755D9] border border-blue-200 font-semibold text-left"
                >
                  🎓 Sinh viên
                </button>
                <button
                  type="button"
                  onClick={() => handleChangeRole('club_manager')}
                  className="p-2 rounded bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 font-semibold text-left"
                >
                  💼 BCN CLB
                </button>
                <button
                  type="button"
                  onClick={() => handleChangeRole('school_manager')}
                  className="p-2 rounded bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-semibold text-left"
                >
                  🏛️ Ban QL Trường
                </button>
                <button
                  type="button"
                  onClick={() => handleChangeRole('admin')}
                  className="p-2 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold text-left"
                >
                  ⚙️ Quản trị viên
                </button>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-gray-100">
              <span className="font-bold text-gray-800 block">Thao tác tài khoản:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleToggleLock}
                  className={`flex-1 py-2 rounded font-semibold flex items-center justify-center gap-1.5 border ${
                    selectedAccount.status === 'active'
                      ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                      : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                  }`}
                >
                  {selectedAccount.status === 'active' ? (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      <span>Khóa tài khoản</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-3.5 h-3.5" />
                      <span>Mở khóa tài khoản</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleResetPassword}
                  className="flex-1 py-2 rounded bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold flex items-center justify-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Đặt lại mật khẩu</span>
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setIsActionModalOpen(false)}
                className="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
