import React, { useState, useMemo } from 'react';
import { useClub } from '../context/ClubContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Search, UserPlus, MoreHorizontal, Filter, ChevronLeft, ChevronRight, Edit2, Trash2 } from 'lucide-react';

export const QuanLyThanhVien: React.FC = () => {
  const { members, addMember, updateMemberStatus, removeMember } = useClub();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('Tất cả');
  const [filterStatus, setFilterStatus] = useState('Tất cả');
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Form states for new member
  const [newStudentId, setNewStudentId] = useState('');
  const [newFullName, setNewFullName] = useState('');
  const [newClassName, setNewClassName] = useState('DA24TTA');
  const [newDepartment, setNewDepartment] = useState('Ban Kỹ thuật');
  const [newRole, setNewRole] = useState<'Thành viên' | 'Trưởng ban' | 'Phó ban' | 'Chủ nhiệm' | 'Phó chủ nhiệm'>('Thành viên');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');

  // CLB001 (CNTT) members
  const cnttMembers = useMemo(() => {
    return members.filter((m) => m.clubId === 'CLB001');
  }, [members]);

  const filteredMembers = useMemo(() => {
    let result = [...cnttMembers];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (m) =>
          m.fullName.toLowerCase().includes(q) ||
          m.studentId.toLowerCase().includes(q) ||
          m.className.toLowerCase().includes(q)
      );
    }

    if (filterDepartment !== 'Tất cả') {
      result = result.filter((m) => m.department === filterDepartment);
    }

    if (filterStatus !== 'Tất cả') {
      result = result.filter((m) => m.status === filterStatus);
    }

    return result;
  }, [cnttMembers, searchTerm, filterDepartment, filterStatus]);

  const pageSize = 5;
  const totalPages = Math.ceil(filteredMembers.length / pageSize) || 1;
  const paginatedMembers = filteredMembers.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addMember({
      clubId: 'CLB001',
      studentId: newStudentId,
      fullName: newFullName,
      className: newClassName,
      department: newDepartment,
      role: newRole,
      joinedDate: new Date().toLocaleDateString('vi-VN'),
      status: 'Đang hoạt động',
      email: newEmail || `${newStudentId}@tvu.edu.vn`,
      phone: newPhone || '0912345678'
    });
    setIsAddModalOpen(false);
    // Reset form
    setNewStudentId('');
    setNewFullName('');
  };

  const handleUpdateStatus = (newStatus: 'Đang hoạt động' | 'Tạm dừng' | 'Đã rời') => {
    if (selectedMember) {
      updateMemberStatus(selectedMember.id, newStatus);
      setIsEditModalOpen(false);
    }
  };

  const handleDeleteMember = () => {
    if (selectedMember && window.confirm(`Bạn có chắc chắn muốn xóa thành viên ${selectedMember.fullName}?`)) {
      removeMember(selectedMember.id);
      setIsEditModalOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header matching Screen 7: Danh sách thành viên (120) + button Thêm thành viên */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
            Danh sách thành viên (120)
          </h1>
          <p className="text-xs text-gray-500">
            Quản lý danh sách thành viên chính thức CLB Công nghệ thông tin
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-lg text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>Thêm thành viên</span>
        </button>
      </div>

      {/* Toolbar Search & Filters matching Screen 7 */}
      <div className="bg-white p-3.5 rounded-xl border border-[#DCE6F0] shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Tìm kiếm thành viên theo họ tên, MSSV, lớp..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg pl-9 pr-3 py-2 text-xs text-gray-800 placeholder-gray-400 focus:bg-white focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          />
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2">
          <select
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
            className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          >
            <option value="Tất cả">Tất cả Ban/Nhóm</option>
            <option value="Ban Kỹ thuật">Ban Kỹ thuật</option>
            <option value="Ban Truyền thông">Ban Truyền thông</option>
            <option value="Ban Nội dung">Ban Nội dung</option>
            <option value="Ban Sự kiện">Ban Sự kiện</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-[#F8FAFC] border border-[#DCE6F0] rounded-lg px-2.5 py-2 text-xs text-gray-800 focus:outline-hidden focus:ring-1 focus:ring-[#0755D9]"
          >
            <option value="Tất cả">Tất cả trạng thái</option>
            <option value="Đang hoạt động">Đang hoạt động</option>
            <option value="Tạm dừng">Tạm dừng</option>
            <option value="Đã rời">Đã rời</option>
          </select>
        </div>
      </div>

      {/* Data Table matching Screen 7 Columns: #, MSSV, Họ và tên, Lớp, Ban/Nhóm, Ngày gia nhập, Trạng thái, Thao tác */}
      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">MSSV</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3.5">Lớp</th>
                <th className="py-3 px-3.5">Ban/Nhóm</th>
                <th className="py-3 px-3.5">Ngày gia nhập</th>
                <th className="py-3 px-3.5">Trạng thái</th>
                <th className="py-3 px-3.5 text-center w-20">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {paginatedMembers.map((member, index) => (
                <tr key={member.id} className="hover:bg-[#F8FAFF] transition-colors">
                  <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                    {(currentPage - 1) * pageSize + index + 1}
                  </td>
                  <td className="py-3 px-3.5 font-semibold text-gray-900">
                    {member.studentId}
                  </td>
                  <td className="py-3 px-3.5 font-bold text-[#0755D9]">
                    {member.fullName}
                  </td>
                  <td className="py-3 px-3.5 text-gray-600">{member.className}</td>
                  <td className="py-3 px-3.5 text-gray-700">{member.department}</td>
                  <td className="py-3 px-3.5 text-gray-500">{member.joinedDate}</td>
                  <td className="py-3 px-3.5">
                    <StatusBadge status={member.status} size="sm" />
                  </td>
                  <td className="py-3 px-3.5 text-center">
                    <button
                      onClick={() => {
                        setSelectedMember(member);
                        setIsEditModalOpen(true);
                      }}
                      className="p-1 hover:bg-gray-100 text-gray-500 hover:text-[#0755D9] rounded transition-colors"
                      title="Chỉnh sửa / Cập nhật"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination at bottom matching Screen 7 */}
        <div className="px-4 py-3 border-t border-[#DCE6F0] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500 bg-[#F8FAFC]">
          <div>
            Hiển thị <strong className="text-gray-800">{paginatedMembers.length}</strong> / 120 thành viên
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded border border-gray-300 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button className="w-7 h-7 rounded bg-[#0755D9] text-white font-bold flex items-center justify-center">
              1
            </button>
            <button className="w-7 h-7 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              2
            </button>
            <button className="w-7 h-7 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              3
            </button>
            <button className="w-7 h-7 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              4
            </button>
            <button className="w-7 h-7 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              5
            </button>
            <span className="px-1 text-gray-400">...</span>
            <button className="w-7 h-7 rounded hover:bg-gray-200 text-gray-700 flex items-center justify-center">
              24
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded border border-gray-300 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal Thêm thành viên */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Thêm thành viên vào CLB Công nghệ thông tin"
        maxWidth="md"
      >
        <form onSubmit={handleAddSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Mã sinh viên *</label>
              <input
                type="text"
                required
                placeholder="110124..."
                value={newStudentId}
                onChange={(e) => setNewStudentId(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Lớp *</label>
              <input
                type="text"
                required
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên *</label>
            <input
              type="text"
              required
              placeholder="Nguyễn Văn..."
              value={newFullName}
              onChange={(e) => setNewFullName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Ban/Nhóm *</label>
              <select
                value={newDepartment}
                onChange={(e) => setNewDepartment(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              >
                <option value="Ban Kỹ thuật">Ban Kỹ thuật</option>
                <option value="Ban Truyền thông">Ban Truyền thông</option>
                <option value="Ban Nội dung">Ban Nội dung</option>
                <option value="Ban Sự kiện">Ban Sự kiện</option>
              </select>
            </div>
            <div>
              <label className="font-semibold text-gray-700 block mb-1">Chức vụ</label>
              <select
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as any)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              >
                <option value="Thành viên">Thành viên</option>
                <option value="Trưởng ban">Trưởng ban</option>
                <option value="Phó ban">Phó ban</option>
                <option value="Phó chủ nhiệm">Phó chủ nhiệm</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold"
            >
              Thêm thành viên
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Update member status / role */}
      {selectedMember && (
        <Modal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          title={`Thao tác thành viên: ${selectedMember.fullName}`}
          maxWidth="sm"
        >
          <div className="space-y-4 text-xs">
            <div className="p-3 bg-gray-50 rounded-lg space-y-1">
              <p>MSSV: <strong>{selectedMember.studentId}</strong></p>
              <p>Lớp: <strong>{selectedMember.className}</strong></p>
              <p>Ban hiện tại: <strong>{selectedMember.department}</strong></p>
              <p>Trạng thái hiện tại: <StatusBadge status={selectedMember.status} size="sm" /></p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-gray-700 block">Cập nhật trạng thái:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleUpdateStatus('Đang hoạt động')}
                  className="p-2 rounded bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 font-semibold"
                >
                  Đang hoạt động
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateStatus('Tạm dừng')}
                  className="p-2 rounded bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 font-semibold"
                >
                  Tạm dừng
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-gray-100 flex justify-between items-center">
              <button
                type="button"
                onClick={handleDeleteMember}
                className="text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Xóa khỏi CLB
              </button>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="px-4 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
