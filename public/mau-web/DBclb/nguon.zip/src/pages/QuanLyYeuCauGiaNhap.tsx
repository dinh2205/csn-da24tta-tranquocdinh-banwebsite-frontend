import React, { useState } from 'react';
import { useClub } from '../context/ClubContext';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import { Check, X, Inbox, Clock, Phone, Mail, UserCheck, AlertCircle } from 'lucide-react';

export const QuanLyYeuCauGiaNhap: React.FC = () => {
  const { joinRequests, approveJoinRequest, rejectJoinRequest } = useClub();

  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [rejectingRequest, setRejectingRequest] = useState<any>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  // CNTT join requests
  const cnttRequests = joinRequests.filter((r) => r.clubId === 'CLB001');
  const pendingRequests = cnttRequests.filter((r) => r.status === 'pending');
  const approvedRequests = cnttRequests.filter((r) => r.status === 'approved');
  const rejectedRequests = cnttRequests.filter((r) => r.status === 'rejected');

  const currentList =
    activeTab === 'pending'
      ? pendingRequests
      : activeTab === 'approved'
      ? approvedRequests
      : rejectedRequests;

  const handleApprove = (id: string) => {
    approveJoinRequest(id);
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (rejectingRequest) {
      rejectJoinRequest(rejectingRequest.id, rejectionReason);
      setRejectingRequest(null);
      setRejectionReason('');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Quản lý yêu cầu gia nhập CLB ({pendingRequests.length} chờ duyệt)
        </h1>
        <p className="text-xs text-gray-500">
          Xét duyệt đơn đăng ký tham gia từ sinh viên vào CLB Công nghệ thông tin
        </p>
      </div>

      <div className="border-b border-[#DCE6F0] flex gap-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('pending')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'pending'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Chờ duyệt ({pendingRequests.length})
        </button>
        <button
          onClick={() => setActiveTab('approved')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'approved'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã chấp thuận ({approvedRequests.length})
        </button>
        <button
          onClick={() => setActiveTab('rejected')}
          className={`pb-2.5 px-3.5 border-b-2 transition-all ${
            activeTab === 'rejected'
              ? 'border-[#0755D9] text-[#0755D9] font-bold'
              : 'border-transparent text-gray-500 hover:text-gray-800'
          }`}
        >
          Đã từ chối ({rejectedRequests.length})
        </button>
      </div>

      <div className="bg-white rounded-xl border border-[#DCE6F0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px] font-bold border-b border-[#DCE6F0]">
              <tr>
                <th className="py-3 px-3.5 w-12 text-center">#</th>
                <th className="py-3 px-3.5">MSSV</th>
                <th className="py-3 px-3.5">Họ và tên</th>
                <th className="py-3 px-3.5">Lớp</th>
                <th className="py-3 px-3.5">Ban đăng ký</th>
                <th className="py-3 px-3.5">Lời nhắn / Lý do</th>
                <th className="py-3 px-3.5">Ngày gửi</th>
                <th className="py-3 px-3.5 text-center w-36">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {currentList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-gray-500">
                    Không có yêu cầu nào trong danh sách.
                  </td>
                </tr>
              ) : (
                currentList.map((req, idx) => (
                  <tr key={req.id} className="hover:bg-[#F8FAFF] transition-colors">
                    <td className="py-3 px-3.5 text-center font-medium text-gray-500">
                      {idx + 1}
                    </td>
                    <td className="py-3 px-3.5 font-semibold text-gray-900">{req.studentId}</td>
                    <td className="py-3 px-3.5 font-bold text-[#0755D9]">
                      <div>{req.fullName}</div>
                      <div className="text-[10px] text-gray-400 font-normal">{req.email}</div>
                    </td>
                    <td className="py-3 px-3.5 text-gray-600">{req.className}</td>
                    <td className="py-3 px-3.5 font-medium text-blue-900">
                      {req.desiredDepartment}
                    </td>
                    <td className="py-3 px-3.5 text-gray-600 max-w-xs italic line-clamp-2">
                      &quot;{req.message}&quot;
                    </td>
                    <td className="py-3 px-3.5 text-gray-500">{req.requestDate}</td>
                    <td className="py-3 px-3.5 text-center">
                      {req.status === 'pending' ? (
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleApprove(req.id)}
                            className="px-3 py-1 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded font-bold text-xs flex items-center gap-1 shadow-2xs"
                          >
                            <Check className="w-3.5 h-3.5" />
                            Duyệt
                          </button>
                          <button
                            onClick={() => setRejectingRequest(req)}
                            className="px-2.5 py-1 bg-[#EF4444] hover:bg-red-600 text-white rounded font-bold text-xs flex items-center gap-1 shadow-2xs"
                          >
                            <X className="w-3.5 h-3.5" />
                            Từ chối
                          </button>
                        </div>
                      ) : (
                        <StatusBadge
                          status={req.status === 'approved' ? 'Đã chấp thuận' : 'Từ chối'}
                          size="sm"
                        />
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reject Modal */}
      {rejectingRequest && (
        <Modal
          isOpen={true}
          onClose={() => setRejectingRequest(null)}
          title={`Từ chối yêu cầu của sinh viên: ${rejectingRequest.fullName}`}
          maxWidth="sm"
        >
          <form onSubmit={handleConfirmReject} className="space-y-3.5 text-xs">
            <div>
              <label className="font-semibold text-gray-700 block mb-1">
                Lý do từ chối *
              </label>
              <textarea
                required
                rows={3}
                placeholder="VD: Ban đăng ký đã đủ số lượng tuyển đợt này..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setRejectingRequest(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-[#EF4444] hover:bg-red-600 text-white rounded-md font-semibold"
              >
                Xác nhận từ chối
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
