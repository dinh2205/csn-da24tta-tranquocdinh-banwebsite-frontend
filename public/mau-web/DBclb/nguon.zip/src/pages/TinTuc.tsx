import React from 'react';
import { useClub } from '../context/ClubContext';
import { Newspaper, Calendar, Eye, Pin, ArrowRight } from 'lucide-react';

export const TinTuc: React.FC = () => {
  const { news } = useClub();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
          Tin tức &amp; Thông báo CLB
        </h1>
        <p className="text-xs text-gray-500">
          Cập nhật tin tức sự kiện, phóng sự hình ảnh và thông báo chính thức từ các câu lạc bộ TVU
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {news.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-[#DCE6F0] overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col"
          >
            <div className="relative h-48 overflow-hidden bg-slate-100">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3 flex gap-2">
                <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-[#0755D9] text-white">
                  {item.category}
                </span>
                {item.isPinned && (
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500 text-white flex items-center gap-1">
                    <Pin className="w-3 h-3" /> Ghim
                  </span>
                )}
              </div>
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <span className="text-xs font-semibold text-[#0755D9]">{item.clubName}</span>
                <h2 className="text-base font-bold text-gray-900 leading-snug hover:text-[#0755D9] transition-colors">
                  {item.title}
                </h2>
                <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
                  {item.summary}
                </p>
              </div>

              <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center gap-1 text-[11px]">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  {item.publishDate}
                </span>
                <span className="flex items-center gap-1 text-[11px]">
                  <Eye className="w-3.5 h-3.5 text-gray-400" />
                  {item.views} lượt xem
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
