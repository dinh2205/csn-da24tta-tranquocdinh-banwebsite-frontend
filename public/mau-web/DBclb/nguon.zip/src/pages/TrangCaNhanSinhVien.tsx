import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useClub } from '../context/ClubContext';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { Modal } from '../components/Modal';
import {
  Users,
  Calendar,
  Award,
  Scroll,
  Edit3,
  Mail,
  GraduationCap,
  ExternalLink,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const TrangCaNhanSinhVien: React.FC = () => {
  const { currentUser, updateStudentProfile } = useAuth();
  const { clubs, members, registrations, trainingPoints, joinRequests } = useClub();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editName, setEditName] = useState(currentUser.fullName);
  const [editEmail, setEditEmail] = useState(currentUser.email);
  const [editClass, setEditClass] = useState(currentUser.class || 'DA24TTA');

  // Find joined clubs for this student
  const studentMemberships = members.filter(
    (m) => m.studentId === (currentUser.studentId || '110124033') && m.status === 'Đang hoạt động'
  );

  const studentRegistrations = registrations.filter(
    (r) => r.studentId === (currentUser.studentId || '110124033')
  );

  const studentTrainingPoints = trainingPoints.filter(
    (tp) => tp.studentId === (currentUser.studentId || '110124033') && tp.status === 'approved'
  );

  const totalPoints = studentTrainingPoints.reduce((sum, item) => sum + item.points, 0);

  const studentPendingRequests = joinRequests.filter(
    (req) => req.studentId === (currentUser.studentId || '110124033') && req.status === 'pending'
  );

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateStudentProfile({
      fullName: editName,
      email: editEmail,
      class: editClass
    });
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* 1. Profile Header Card matching Screen 5 */}
      <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          {/* Avatar photo */}
          <div className="relative">
            <img
              src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'}
              alt={currentUser.fullName}
              className="w-24 h-24 rounded-full object-cover ring-4 ring-[#EAF3FF] shadow-sm"
            />
            <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full"></span>
          </div>

          {/* Details */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-[#073A68]">
                {currentUser.fullName}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#DCFCE7] text-[#15803D] border border-green-200">
                Sinh viên chính quy
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-xs text-gray-600">
              <span className="flex items-center gap-1 justify-center sm:justify-start">
                <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
                MSSV: <strong className="text-gray-900">{currentUser.studentId || '110124033'}</strong>
              </span>
              <span className="hidden sm:inline text-gray-300">•</span>
              <span>
                Lớp: <strong className="text-gray-900">{currentUser.class || 'DA24TTA'}</strong>
              </span>
              <span className="hidden sm:inline text-gray-300">•</span>
              <span className="flex items-center gap-1 justify-center sm:justify-start">
                <Mail className="w-3.5 h-3.5 text-blue-600" />
                {currentUser.email}
              </span>
            </div>
          </div>
        </div>

        {/* Action Button: Chỉnh sửa matching Screen 5 */}
        <button
          onClick={() => setIsEditModalOpen(true)}
          className="px-4 py-2 bg-white hover:bg-[#EAF3FF] text-[#0755D9] border border-[#B9D4FC] rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1.5 self-center md:self-start"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>Chỉnh sửa</span>
        </button>
      </div>

      {/* 2. 4 Stat Cards matching Screen 5 (3 CLB, 8 Hoạt động, 12 Điểm RL, 2 Giấy khen) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="CLB tham gia"
          value={studentMemberships.length > 0 ? studentMemberships.length : 3}
          icon={Users}
          colorScheme="emerald"
        />
        <StatCard
          label="Hoạt động đã tham gia"
          value={studentRegistrations.length > 0 ? studentRegistrations.length : 8}
          icon={Calendar}
          colorScheme="blue"
        />
        <StatCard
          label="Điểm rèn luyện"
          value={totalPoints > 0 ? totalPoints : 12}
          icon={Award}
          colorScheme="indigo"
          subText="Học kỳ 1 / 2026-2027"
        />
        <StatCard
          label="Giấy khen"
          value={2}
          icon={Scroll}
          colorScheme="amber"
          subText="Đoàn trường trao tặng"
        />
      </div>

      {/* 3. Section: Câu lạc bộ của tôi matching Screen 5 */}
      <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <h2 className="text-base font-bold text-[#073A68]">Câu lạc bộ của tôi</h2>
          <Link
            to="/cau-lac-bo"
            className="text-xs font-semibold text-[#0755D9] hover:underline"
          >
            Khám phá thêm CLB &rarr;
          </Link>
        </div>

        <div className="divide-y divide-gray-100">
          {studentMemberships.length > 0 ? (
            studentMemberships.map((membership) => {
              const club = clubs.find((c) => c.id === membership.clubId);
              return (
                <div
                  key={membership.id}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-gray-50/60 px-2 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-[#EAF3FF] text-[#0755D9] flex items-center justify-center font-bold text-sm shrink-0 border border-[#B9D4FC]">
                      {club?.name.includes('Công nghệ') ? '</>' : 'TVU'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-xs sm:text-sm text-gray-900">
                          {club?.name || membership.clubId}
                        </h3>
                        <StatusBadge status={membership.role || 'Thành viên'} size="sm" />
                      </div>
                      <p className="text-[11px] text-gray-500 mt-0.5">
                        Ngày gia nhập: <strong>{membership.joinedDate}</strong> • Ban: <strong>{membership.department}</strong>
                      </p>
                    </div>
                  </div>

                  <Link
                    to={`/cau-lac-bo/${membership.clubId}`}
                    className="px-3.5 py-1.5 bg-white hover:bg-blue-50 text-[#0755D9] border border-[#B9D4FC] rounded-md text-xs font-semibold transition-colors self-start sm:self-center"
                  >
                    Xem chi tiết
                  </Link>
                </div>
              );
            })
          ) : (
            <div className="py-8 text-center text-xs text-gray-500">
              Bạn chưa tham gia câu lạc bộ nào. Hãy vào mục{' '}
              <Link to="/cau-lac-bo" className="text-[#0755D9] font-bold underline">
                Danh sách câu lạc bộ
              </Link>{' '}
              để gửi yêu cầu tham gia!
            </div>
          )}
        </div>
      </div>

      {/* 4. Section: Yêu cầu gia nhập đang chờ duyệt */}
      {studentPendingRequests.length > 0 && (
        <div className="bg-amber-50/70 rounded-2xl border border-amber-200 p-5 shadow-xs space-y-3">
          <h3 className="font-bold text-xs text-amber-900 flex items-center gap-2 uppercase tracking-wider">
            <Clock className="w-4 h-4 text-amber-600" />
            Yêu cầu gia nhập đang chờ Ban chủ nhiệm duyệt ({studentPendingRequests.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {studentPendingRequests.map((req) => (
              <div key={req.id} className="p-3 bg-white rounded-lg border border-amber-200 shadow-2xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-gray-900">{req.clubName}</span>
                  <StatusBadge status="Chờ duyệt" size="sm" />
                </div>
                <p className="text-[11px] text-gray-500">
                  Ban đăng ký: <strong>{req.desiredDepartment}</strong> • Ngày gửi: {req.requestDate}
                </p>
                <p className="text-[11px] text-gray-600 italic line-clamp-1">&quot;{req.message}&quot;</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. Section: Hoạt động đã đăng ký gần đây */}
      <div className="bg-white rounded-2xl border border-[#DCE6F0] p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <h2 className="text-base font-bold text-[#073A68]">Hoạt động đã đăng ký</h2>
          <Link to="/hoat-dong" className="text-xs font-semibold text-[#0755D9] hover:underline">
            Đăng ký thêm hoạt động &rarr;
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#F1F6FC] text-[#073A68] uppercase text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Tên hoạt động</th>
                <th className="py-2.5 px-3">CLB tổ chức</th>
                <th className="py-2.5 px-3">Ngày đăng ký</th>
                <th className="py-2.5 px-3">Điểm danh</th>
                <th className="py-2.5 px-3 text-right">Chi tiết</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {studentRegistrations.map((reg) => (
                <tr key={reg.id} className="hover:bg-gray-50">
                  <td className="py-2.5 px-3 font-semibold text-gray-900">{reg.activityName}</td>
                  <td className="py-2.5 px-3 text-gray-600">{reg.clubName}</td>
                  <td className="py-2.5 px-3 text-gray-500">{reg.registeredAt}</td>
                  <td className="py-2.5 px-3">
                    {reg.attended ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Đã điểm danh ({reg.attendedAt})
                      </span>
                    ) : (
                      <span className="text-amber-600 font-medium">Chưa diễn ra / Chưa điểm danh</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <Link
                      to={`/hoat-dong/${reg.activityId}`}
                      className="text-[#0755D9] font-bold hover:underline"
                    >
                      Xem &rarr;
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Chỉnh sửa thông tin sinh viên"
        maxWidth="sm"
      >
        <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-gray-700 block mb-1">Họ và tên</label>
            <input
              type="text"
              required
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>
          <div>
            <label className="font-semibold text-gray-700 block mb-1">Email trường</label>
            <input
              type="email"
              required
              value={editEmail}
              onChange={(e) => setEditEmail(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>
          <div>
            <label className="font-semibold text-gray-700 block mb-1">Lớp</label>
            <input
              type="text"
              required
              value={editClass}
              onChange={(e) => setEditClass(e.target.value)}
              className="w-full bg-[#F8FAFC] border border-[#DCE6F0] rounded-md px-3 py-2 text-gray-800"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2 border-t border-gray-100">
            <button
              type="button"
              onClick={() => setIsEditModalOpen(false)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md font-semibold"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#0755D9] hover:bg-[#0646B5] text-white rounded-md font-semibold"
            >
              Lưu thay đổi
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
