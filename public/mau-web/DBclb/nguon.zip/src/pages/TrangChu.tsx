import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useClub } from '../context/ClubContext';
import { useAuth } from '../context/AuthContext';
import {
  Search,
  Users,
  Calendar,
  Award,
  ArrowRight,
  Code2,
  Music,
  HeartHandshake,
  Camera,
  Trophy,
  Lightbulb,
  CheckCircle,
  Sparkles
} from 'lucide-react';

export const TrangChu: React.FC = () => {
  const { clubs, activities } = useClub();
  const { role } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const featuredClubs = clubs.slice(0, 4);
  const upcomingActivities = activities.filter((a) => a.status === 'Đã phê duyệt' || a.status === 'Đang diễn ra').slice(0, 3);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/cau-lac-bo?q=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      navigate('/cau-lac-bo');
    }
  };

  const getClubIcon = (id: string) => {
    switch (id) {
      case 'CLB001':
        return Code2;
      case 'CLB002':
        return Music;
      case 'CLB003':
        return HeartHandshake;
      case 'CLB004':
        return Camera;
      case 'CLB005':
        return Trophy;
      default:
        return Lightbulb;
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* 1. Large Hero Banner matching Screen 1 exactly */}
      <div className="relative rounded-2xl overflow-hidden shadow-lg border border-[#DCE6F0] min-h-[360px] md:min-h-[420px] flex items-center">
        {/* Background photo */}
        <img
          src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80"
          alt="Sinh viên Trường Đại học Trà Vinh"
          className="absolute inset-0 w-full h-full object-cover"
        />

        {/* Overlay gradient - matching screenshot dark navy overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#033370]/95 via-[#0553A8]/80 to-transparent"></div>

        {/* Hero Content */}
        <div className="relative z-10 p-6 sm:p-10 md:p-14 max-w-2xl text-white space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-xs border border-white/20 text-xs font-semibold text-blue-100">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Cổng thông tin Câu lạc bộ TVU
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
            Cùng nhau <br />
            <span className="text-blue-200">Tạo nên những giá trị</span> <br />
            Sinh viên TVU
          </h1>

          <p className="text-sm sm:text-base text-blue-100/90 leading-relaxed max-w-xl font-normal">
            Khám phá các câu lạc bộ, tham gia hoạt động và phát triển bản thân cùng cộng đồng sinh viên Trường Đại học Trà Vinh.
          </p>

          {/* Search box directly inside hero */}
          <form onSubmit={handleSearch} className="pt-2 flex flex-col sm:flex-row gap-2 max-w-lg">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Tìm kiếm câu lạc bộ, hoạt động..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white text-gray-800 placeholder-gray-400 pl-10 pr-4 py-3 rounded-lg text-xs sm:text-sm shadow-md focus:outline-hidden focus:ring-2 focus:ring-[#0755D9]"
              />
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-[#0755D9] hover:bg-[#0646B5] text-white font-semibold rounded-lg text-xs sm:text-sm shadow-md transition-colors flex items-center justify-center gap-2 shrink-0"
            >
              <Search className="w-4 h-4" />
              <span>Tìm kiếm</span>
            </button>
          </form>
        </div>
      </div>

      {/* 2. Featured Clubs matching Screen 1 bottom section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-[#073A68]">Câu lạc bộ nổi bật</h2>
            <p className="text-xs text-gray-500">Các câu lạc bộ có quy mô thành viên và hoạt động sôi nổi nhất</p>
          </div>
          <Link
            to="/cau-lac-bo"
            className="text-xs font-semibold text-[#0755D9] hover:text-[#0646B5] flex items-center gap-1 group"
          >
            <span>Xem tất cả</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* 4 club cards in a row matching Screen 1 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {featuredClubs.map((club) => {
            const Icon = getClubIcon(club.id);
            return (
              <Link
                key={club.id}
                to={`/cau-lac-bo/${club.id}`}
                className="group bg-white rounded-xl border border-[#DCE6F0] overflow-hidden hover:shadow-md hover:border-blue-400 transition-all flex flex-col"
              >
                {/* Club photo */}
                <div className="relative h-32 overflow-hidden bg-slate-100">
                  <img
                    src={club.coverImage}
                    alt={club.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#073A68]/80 text-white backdrop-blur-xs">
                      {club.category}
                    </span>
                  </div>
                </div>

                {/* Club info */}
                <div className="p-3.5 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#EAF3FF] text-[#0755D9] flex items-center justify-center shrink-0 border border-[#B9D4FC] group-hover:bg-[#0755D9] group-hover:text-white transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-bold text-xs text-gray-900 truncate group-hover:text-[#0755D9] transition-colors">
                      {club.name}
                    </h3>
                    <p className="text-[11px] text-gray-500 flex items-center gap-1 mt-0.5">
                      <Users className="w-3 h-3 text-gray-400" />
                      <span>{club.id === 'CLB001' ? '120 thành viên' : club.id === 'CLB002' ? '85 thành viên' : club.id === 'CLB003' ? '98 thành viên' : '75 thành viên'}</span>
                    </p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* 3. Upcoming activities highlight */}
      <section className="space-y-4 pt-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-[#073A68]">Hoạt động sắp diễn ra</h2>
            <p className="text-xs text-gray-500">Đăng ký tham gia để tích lũy điểm rèn luyện và mở rộng kết nối</p>
          </div>
          <Link
            to="/hoat-dong"
            className="text-xs font-semibold text-[#0755D9] hover:text-[#0646B5] flex items-center gap-1 group"
          >
            <span>Tất cả hoạt động</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingActivities.map((act) => (
            <div
              key={act.id}
              className="bg-white rounded-xl border border-[#DCE6F0] overflow-hidden hover:shadow-md transition-all flex flex-col"
            >
              <div className="relative h-40 overflow-hidden bg-slate-100">
                <img
                  src={act.bannerImage}
                  alt={act.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2.5 left-2.5 flex gap-1.5">
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#0755D9] text-white">
                    {act.typeTag}
                  </span>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-500 text-white">
                    +{act.proposedTrainingPoints} Điểm RL
                  </span>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <span className="text-[11px] font-semibold text-[#0755D9] block">{act.clubName}</span>
                  <h3 className="font-bold text-sm text-gray-900 mt-1 line-clamp-1 hover:text-[#0755D9]">
                    <Link to={`/hoat-dong/${act.id}`}>{act.name}</Link>
                  </h3>
                  <p className="text-xs text-gray-500 mt-1.5 line-clamp-2">{act.description}</p>
                </div>

                <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-500">
                  <span className="flex items-center gap-1 text-[11px]">
                    <Calendar className="w-3.5 h-3.5 text-blue-600" />
                    {act.startDate.split(' ')[0]}
                  </span>
                  <Link
                    to={`/hoat-dong/${act.id}`}
                    className="px-3 py-1 bg-[#EAF3FF] hover:bg-blue-100 text-[#0755D9] font-semibold rounded text-xs transition-colors"
                  >
                    Chi tiết &rarr;
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. University Value Proposition / About section */}
      <section className="bg-gradient-to-br from-[#073A68] to-[#042342] text-white rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center mx-auto md:mx-0">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-white">Môi trường gắn kết sinh viên</h3>
            <p className="text-xs text-blue-200/80 leading-relaxed">
              Hơn 28 câu lạc bộ đa dạng từ công nghệ, học thuật, nghệ thuật đến thể thao và hoạt động tình nguyện cộng đồng.
            </p>
          </div>
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center mx-auto md:mx-0">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-white">Ghi nhận điểm rèn luyện</h3>
            <p className="text-xs text-blue-200/80 leading-relaxed">
              Tất cả hoạt động đều được quy chuẩn, điểm danh minh bạch qua mã QR và tự động đề xuất cộng điểm rèn luyện chính thức.
            </p>
          </div>
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center mx-auto md:mx-0">
              <CheckCircle className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-white">Quy trình trực tuyến tiện lợi</h3>
            <p className="text-xs text-blue-200/80 leading-relaxed">
              Gửi yêu cầu tham gia, phê duyệt hoạt động và cấp chứng nhận số hoàn toàn trên nền tảng TVU CLUB.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
