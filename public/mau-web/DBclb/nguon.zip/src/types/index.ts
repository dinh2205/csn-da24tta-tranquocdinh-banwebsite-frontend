export type UserRole = 'guest' | 'student' | 'club_manager' | 'school_manager' | 'admin';

export interface UserAccount {
  id: string;
  username: string;
  fullName: string;
  email: string;
  role: UserRole;
  roleTitle: string;
  status: 'active' | 'locked';
  avatar?: string;
  studentId?: string;
  clubId?: string; // Managed club for club_manager
  class?: string;
  createdAt: string;
}

export interface Club {
  id: string; // e.g. CLB001
  name: string;
  code: string;
  category: 'Công nghệ' | 'Văn hóa - Nghệ thuật' | 'Tình nguyện' | 'Truyền thông' | 'Thể thao' | 'Học thuật';
  type: string;
  establishedDate: string;
  status: 'Đang hoạt động' | 'Tạm ngưng';
  email: string;
  phone?: string;
  description: string;
  coverImage: string;
  avatarIcon?: string;
  yearsOperating: number;
  leaderName: string;
  leaderStudentId: string;
}

export interface ClubMember {
  id: string;
  clubId: string;
  studentId: string;
  fullName: string;
  className: string;
  department: string; // Ban/Nhóm: Ban Nội dung, Ban Kỹ thuật, Ban Truyền thông, Ban Sự kiện...
  role: 'Chủ nhiệm' | 'Phó chủ nhiệm' | 'Trưởng ban' | 'Phó ban' | 'Thành viên';
  joinedDate: string;
  status: 'Đang hoạt động' | 'Tạm dừng' | 'Đã rời';
  email: string;
  phone: string;
}

export interface JoinRequest {
  id: string;
  clubId: string;
  clubName: string;
  studentId: string;
  fullName: string;
  className: string;
  email: string;
  phone: string;
  requestDate: string;
  message: string;
  desiredDepartment: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  processedDate?: string;
}

export interface Activity {
  id: string; // HD001
  clubId: string;
  clubName: string;
  name: string;
  category: string;
  typeTag: string; // Workshop, Cuộc thi, Tọa đàm, Tình nguyện...
  description: string;
  startDate: string; // '10/11/2026 08:00'
  endDate: string;
  location: string;
  maxCapacity: number;
  registeredCount: number;
  registrationDeadline: string;
  proposedTrainingPoints: number;
  targetAudience: string;
  bannerImage: string;
  status: 'Chờ phê duyệt' | 'Đã phê duyệt' | 'Đang diễn ra' | 'Đã kết thúc' | 'Từ chối';
  submittedDate: string;
  approvalDate?: string;
  approvedBy?: string;
  rejectionReason?: string;
}

export interface ActivityRegistration {
  id: string;
  activityId: string;
  activityName: string;
  clubName: string;
  studentId: string;
  fullName: string;
  className: string;
  email: string;
  registeredAt: string;
  status: 'registered' | 'cancelled';
  attended: boolean;
  attendedAt?: string;
  attendedBy?: string;
  attendanceMethod?: 'manual' | 'qr';
}

export interface TrainingPointRecord {
  id: string;
  studentId: string;
  fullName: string;
  className: string;
  activityId: string;
  activityName: string;
  clubName: string;
  semester: string;
  academicYear: string;
  points: number;
  status: 'proposed' | 'approved' | 'rejected';
  proposedDate: string;
  approvedDate?: string;
  approvedBy?: string;
}

export interface ClubTerm {
  id: string;
  clubId: string;
  termName: string; // Nhiệm kỳ 2025 - 2026
  startDate: string;
  endDate: string;
  isActive: boolean;
  assignments: {
    studentId: string;
    fullName: string;
    position: string;
    appointedDate: string;
  }[];
}

export interface ClubProposal {
  id: string;
  clubName: string;
  category: string;
  proposedByStudentId: string;
  proposerName: string;
  proposerEmail: string;
  proposerPhone: string;
  goal: string;
  actionPlan: string;
  initialMemberCount: number;
  submittedDate: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewNote?: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  clubId?: string;
  clubName: string;
  category: string;
  publishDate: string;
  summary: string;
  content: string;
  image: string;
  views: number;
  isPinned?: boolean;
}
