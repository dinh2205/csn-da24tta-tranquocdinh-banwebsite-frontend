/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ThanhTimKiem } from './components/ThanhTimKiem';

import { TrangChu } from './pages/TrangChu';
import { DanhSachXe } from './pages/DanhSachXe';
import { ChiTietXe } from './pages/ChiTietXe';
import { DichVu } from './pages/DichVu';
import { TinTuc } from './pages/TinTuc';
import { LienHe } from './pages/LienHe';
import { DatLich } from './pages/DatLich';

// Scroll to top automatically when route changes
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant'
    });
  }, [pathname]);

  return null;
}

export default function App() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col bg-[#06131F] text-[#F7FAFF] antialiased selection:bg-[#00D4EE] selection:text-[#030C15]">
        
        {/* Header */}
        <Header 
          onOpenSearch={() => setIsSearchOpen(true)}
        />

        {/* Main Content Router */}
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<TrangChu />} />
            <Route path="/san-pham" element={<DanhSachXe />} />
            <Route path="/san-pham/:slug" element={<ChiTietXe />} />
            <Route path="/dich-vu" element={<DichVu />} />
            <Route path="/tin-tuc" element={<TinTuc />} />
            <Route path="/lien-he" element={<LienHe />} />
            <Route path="/dat-lich" element={<DatLich />} />
            <Route path="*" element={<TrangChu />} />
          </Routes>
        </div>

        {/* Footer */}
        <Footer />

        {/* Global Search Modal */}
        <ThanhTimKiem
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
        />

      </div>
    </BrowserRouter>
  );
}
