import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, ShieldCheck, ChevronRight } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#030C15] text-[#BAC9D6] border-t border-[#122A3C] pt-14 pb-8 transition-colors">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#122A3C]/70">
          
          {/* Col 1: Brand Info */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2 select-none group">
              <div className="flex items-center -space-x-1">
                <span className="w-2.5 h-6 bg-[#00D4EE] -skew-x-[24deg] transform rounded-[2px] shadow-[0_0_12px_rgba(0,212,238,0.6)]"></span>
                <span className="w-2.5 h-6 bg-[#00D4EE] -skew-x-[24deg] transform rounded-[2px] shadow-[0_0_12px_rgba(0,212,238,0.6)]"></span>
              </div>
              <span className="font-display font-black italic text-2xl tracking-tight text-white group-hover:text-[#00D4EE] transition-colors">
                Auto<span className="text-[#00D4EE]">Vela</span>
              </span>
            </Link>
            <p className="text-sm text-[#8198AA] leading-relaxed">
              Showroom ô tô chuẩn quốc tế. Khám phá các dòng xe hiện đại, công nghệ hỗ trợ lái an toàn đỉnh cao và dịch vụ chăm sóc ô tô chuyên nghiệp toàn quốc.
            </p>
            <div className="flex items-center gap-2 text-xs text-[#00D4EE] font-semibold pt-1">
              <ShieldCheck className="w-4 h-4" />
              <span>100% Xe chính hãng & Bảo hành 5 năm</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-4">
            <h4 className="text-white font-display font-bold text-base uppercase tracking-wider border-l-2 border-[#00D4EE] pl-3">
              Khám Phá
            </h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'Trang chủ', path: '/' },
                { label: 'Danh mục sản phẩm', path: '/san-pham' },
                { label: 'SUV & Crossover', path: '/san-pham?loai=suv' },
                { label: 'Xe bán tải đa dụng', path: '/san-pham?loai=xe-ban-tai' },
                { label: 'Xe điện tương lai', path: '/san-pham?loai=xe-dien' },
                { label: 'Dịch vụ & Bảo dưỡng', path: '/dich-vu' },
              ].map((link, idx) => (
                <li key={idx}>
                  <Link
                    to={link.path}
                    className="flex items-center gap-1.5 text-[#BAC9D6] hover:text-[#00D4EE] transition-colors group"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-[#00D4EE] group-hover:translate-x-1 transition-transform" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Support & Policy */}
          <div className="space-y-4">
            <h4 className="text-white font-display font-bold text-base uppercase tracking-wider border-l-2 border-[#00D4EE] pl-3">
              Hỗ Trợ & Dịch Vụ
            </h4>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'Đặt lịch lái thử xe', path: '/dat-lich' },
                { label: 'Chính sách trả góp 0%', path: '/dich-vu' },
                { label: 'Quy trình kiểm tra 24 điểm', path: '/dich-vu' },
                { label: 'Tin tức & Kinh nghiệm', path: '/tin-tuc' },
                { label: 'Câu hỏi thường gặp (FAQ)', path: '/lien-he' },
                { label: 'Chính sách bảo mật', path: '/lien-he' },
              ].map((link, idx) => (
                <li key={idx}>
                  <Link
                    to={link.path}
                    className="flex items-center gap-1.5 text-[#BAC9D6] hover:text-[#00D4EE] transition-colors group"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-[#00D4EE] group-hover:translate-x-1 transition-transform" />
                    <span>{link.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Contact & Showroom */}
          <div className="space-y-4">
            <h4 className="text-white font-display font-bold text-base uppercase tracking-wider border-l-2 border-[#00D4EE] pl-3">
              Liên Hệ Showroom
            </h4>
            <div className="space-y-3 text-sm text-[#8198AA]">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#00D4EE] shrink-0 mt-0.5" />
                <span>Showroom 1: 88 Đại lộ Thăng Long, Nam Từ Liêm, Hà Nội</span>
              </div>
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#00D4EE] shrink-0 mt-0.5" />
                <span>Showroom 2: 120 Võ Văn Kiệt, Quận 1, TP. Hồ Chí Minh</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#00D4EE] shrink-0" />
                <span className="text-white font-bold">1900 8888 / 0988 123 456</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#00D4EE] shrink-0" />
                <span>contact@autovela.vn</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#00D4EE] shrink-0" />
                <span>08:00 - 20:00 (Tất cả các ngày)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#8198AA] gap-4">
          <p>© 2026 AutoVela. All rights reserved. Thế giới ô tô hiện đại.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-white transition-colors cursor-pointer">Điều khoản sử dụng</span>
            <span className="hover:text-white transition-colors cursor-pointer">Chính sách bảo mật</span>
            <span className="hover:text-white transition-colors cursor-pointer">Sơ đồ website</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
