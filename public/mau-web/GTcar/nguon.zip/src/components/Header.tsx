import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, ArrowRight, Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenSearch?: () => void;
  onOpenBooking?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSearch, onOpenBooking }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'Trang chủ', path: '/' },
    { label: 'Sản phẩm', path: '/san-pham' },
    { label: 'Dịch vụ', path: '/dich-vu' },
    { label: 'Tin tức', path: '/tin-tuc' },
    { label: 'Liên hệ', path: '/lien-he' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-50 h-[76px] bg-[#06131F]/95 backdrop-blur-md border-b border-[#122A3C] transition-all">
      <div className="max-w-[1320px] mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        
        {/* Logo AutoVela */}
        <Link to="/" className="flex items-center gap-2 group cursor-pointer select-none">
          {/* Two slanted cyan parallelograms */}
          <div className="flex items-center -space-x-1">
            <span className="w-2.5 h-6 bg-[#00D4EE] -skew-x-[24deg] transform rounded-[2px] shadow-[0_0_12px_rgba(0,212,238,0.6)]"></span>
            <span className="w-2.5 h-6 bg-[#00D4EE] -skew-x-[24deg] transform rounded-[2px] shadow-[0_0_12px_rgba(0,212,238,0.6)]"></span>
          </div>
          <span className="font-display font-black italic text-2xl tracking-tight text-white group-hover:text-[#00D4EE] transition-colors">
            Auto<span className="text-[#00D4EE]">Vela</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
          {navItems.map((item) => {
            const active = isActive(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`relative px-4 py-2 text-sm font-semibold transition-all duration-200 rounded-lg ${
                  active
                    ? 'text-white'
                    : 'text-[#BAC9D6] hover:text-[#00D4EE]'
                }`}
              >
                {item.label}
                {active && (
                  <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-[#00D4EE] shadow-[0_0_8px_#00D4EE] rounded-full"></span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="w-10 h-10 rounded-full border border-[#234A64] bg-[#0A2234]/70 hover:bg-[#123652] hover:border-[#00D4EE] text-[#BAC9D6] hover:text-[#00D4EE] flex items-center justify-center transition-all duration-200"
            title="Tìm kiếm xe"
            aria-label="Tìm kiếm"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Book Appointment CTA Button */}
          <Link
            to="/dat-lich"
            onClick={onOpenBooking}
            className="hidden sm:inline-flex items-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-sm px-5 py-2.5 rounded-full shadow-[0_0_18px_rgba(0,212,238,0.45)] hover:shadow-[0_0_25px_rgba(0,212,238,0.7)] transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
          >
            <span>Đặt lịch ngay</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden w-10 h-10 rounded-lg border border-[#234A64] bg-[#0A2234] text-white flex items-center justify-center hover:border-[#00D4EE]"
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#06131F]/98 border-b border-[#1A384F] px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-1">
            {navItems.map((item) => {
              const active = isActive(item.path);
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`px-4 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    active
                      ? 'bg-[#00D4EE]/10 text-[#00D4EE] border-l-4 border-[#00D4EE]'
                      : 'text-[#BAC9D6] hover:bg-[#0E2436] hover:text-white'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </div>

          <div className="pt-2">
            <Link
              to="/dat-lich"
              onClick={() => {
                setMobileMenuOpen(false);
                if (onOpenBooking) onOpenBooking();
              }}
              className="w-full flex items-center justify-center gap-2 bg-[#00D4EE] text-[#03131F] font-bold py-2.5 rounded-full shadow-[0_0_15px_rgba(0,212,238,0.4)]"
            >
              <span>Đặt lịch ngay</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
