import React from 'react';
import { X, Play, Volume2, Shield, Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface HopVideoProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HopVideo: React.FC<HopVideoProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-[#081B2B] border border-[#00D4EE]/40 rounded-2xl shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(0,212,238,0.3)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#05131F] border-b border-[#1A3F5B]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00D4EE] animate-pulse"></span>
            <span className="font-display font-bold text-white text-sm sm:text-base tracking-wide">
              AutoVela Cinematic Showcase | Hyundai Tucson & Công Nghệ SmartSense
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#0C273C] hover:bg-[#163E5E] text-[#BAC9D6] hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Canvas / Player Area */}
        <div className="relative aspect-video w-full bg-[#030B12] flex items-center justify-center overflow-hidden">
          {/* Backdrop Graphic with ambient effects */}
          <img
            src="/assets/hero-blue-suv.png"
            alt="AutoVela Showcase"
            className="w-3/4 max-h-[85%] object-contain drop-shadow-[0_20px_35px_rgba(0,0,0,0.9)] animate-pulse"
            style={{ animationDuration: '4s' }}
          />

          {/* Cyan diagonal aesthetic lighting trails */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#06131F] via-transparent to-black/60"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#00D4EE]/15 rounded-full blur-[100px] pointer-events-none"></div>

          {/* Central Play Badge */}
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 z-10 text-center px-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#00D4EE] text-[#03131F] flex items-center justify-center shadow-[0_0_35px_rgba(0,212,238,0.8)] transform hover:scale-110 transition-all cursor-pointer">
              <Play className="w-8 h-8 fill-current ml-1" />
            </div>
            <div className="space-y-1">
              <h3 className="text-white font-display font-black text-lg sm:text-2xl uppercase tracking-tight">
                Trải Nghiệm Lái Thực Tế 4K
              </h3>
              <p className="text-xs sm:text-sm text-[#00D4EE] font-medium">
                Khám phá hệ dẫn động HTRAC và hệ thống phanh an toàn chủ động
              </p>
            </div>
          </div>

          {/* Video Controls Bar Overlay at bottom */}
          <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-between text-xs text-white z-20">
            <div className="flex items-center gap-3">
              <span className="font-mono text-[#00D4EE]">01:45 / 03:20</span>
              <div className="w-32 sm:w-64 h-1 bg-white/20 rounded-full overflow-hidden">
                <div className="w-1/2 h-full bg-[#00D4EE]"></div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Volume2 className="w-4 h-4 text-[#BAC9D6]" />
              <span className="bg-[#00D4EE]/20 text-[#00D4EE] px-2 py-0.5 rounded text-[10px] font-bold">4K UHD</span>
            </div>
          </div>
        </div>

        {/* Bottom Action Footer */}
        <div className="p-4 sm:p-5 bg-[#071927] border-t border-[#163B55] flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs text-[#BAC9D6]">
            <div className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-[#00D4EE]" />
              <span>Tiêu chuẩn an toàn 5 sao</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#00D4EE]" />
              <span>Hỗ trợ lái thông minh</span>
            </div>
          </div>

          <Link
            to="/dat-lich"
            onClick={onClose}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-xs sm:text-sm px-5 py-2.5 rounded-full shadow-[0_0_15px_rgba(0,212,238,0.4)] transition-all"
          >
            <span>Đăng ký lái thử thực tế</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </div>
  );
};
