import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

interface NutQuayLaiProps {
  label?: string;
  to?: string;
}

export const NutQuayLai: React.FC<NutQuayLaiProps> = ({ 
  label = 'Quay lại', 
  to 
}) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (to) {
      navigate(to);
    } else {
      navigate(-1);
    }
  };

  return (
    <button
      onClick={handleClick}
      className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#BAC9D6] hover:text-[#00D4EE] transition-colors py-2 group cursor-pointer"
    >
      <div className="w-8 h-8 rounded-full bg-[#0A2234] border border-[#204A67] group-hover:border-[#00D4EE] flex items-center justify-center transition-colors">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
      </div>
      <span>{label}</span>
    </button>
  );
};
