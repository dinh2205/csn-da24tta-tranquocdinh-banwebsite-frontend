import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, Car } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import xeData from '../data/xe.json';

interface ThanhTimKiemProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ThanhTimKiem: React.FC<ThanhTimKiemProps> = ({ isOpen, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const normalize = (str: string) =>
    str
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');

  const filteredCars = searchTerm.trim()
    ? xeData.filter((car) => {
        const query = normalize(searchTerm);
        return (
          normalize(car.ten).includes(query) ||
          normalize(car.hang).includes(query) ||
          normalize(car.loai).includes(query) ||
          normalize(car.kieuDang).includes(query)
        );
      })
    : [];

  const handleSelectCar = (slug: string) => {
    onClose();
    navigate(`/san-pham/${slug}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#081C2C] border border-[#204967] rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_25px_rgba(0,212,238,0.2)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-5 py-4 border-b border-[#1A3F5B] gap-3">
          <Search className="w-5 h-5 text-[#00D4EE]" />
          <input
            ref={inputRef}
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tên xe, hãng, dòng xe (VD: Tucson, Elantra, Ranger, SUV)..."
            className="w-full bg-transparent text-white placeholder-[#8198AA] text-base focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-[#8198AA] hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold px-2.5 py-1 rounded-md bg-[#0F2E45] text-[#BAC9D6] hover:text-white border border-[#234F6E]"
          >
            ESC
          </button>
        </div>

        {/* Results Container */}
        <div className="max-h-[380px] overflow-y-auto p-3 space-y-2">
          {searchTerm.trim() ? (
            filteredCars.length > 0 ? (
              filteredCars.map((car) => (
                <div
                  key={car.id}
                  onClick={() => handleSelectCar(car.slug)}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#061523]/70 hover:bg-[#103049] border border-transparent hover:border-[#00D4EE]/50 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-12 rounded-lg bg-[#0A2234] p-1 flex items-center justify-center shrink-0">
                      <img
                        src={car.anh}
                        alt={car.ten}
                        className="max-h-full max-w-full object-contain"
                      />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-white text-sm group-hover:text-[#00D4EE] transition-colors">
                        {car.ten}
                      </h4>
                      <div className="text-xs text-[#8198AA] flex items-center gap-2 mt-0.5">
                        <span>{car.hang}</span>
                        <span>•</span>
                        <span>{car.loai}</span>
                        <span>•</span>
                        <span className="text-[#00D4EE] font-semibold">{car.giaHienThi}</span>
                      </div>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-[#8198AA] group-hover:text-[#00D4EE] group-hover:translate-x-1 transition-all" />
                </div>
              ))
            ) : (
              <div className="py-10 text-center text-[#8198AA] space-y-2">
                <Car className="w-8 h-8 mx-auto text-[#234A64]" />
                <p className="text-sm">Không tìm thấy dòng xe nào phù hợp với "{searchTerm}"</p>
                <p className="text-xs text-[#5D7B93]">Thử tìm các từ khóa: Elantra, Tucson, Santa Fe, Ranger, Xe điện...</p>
              </div>
            )
          ) : (
            <div className="p-4 space-y-3">
              <div className="text-xs font-semibold text-[#8198AA] uppercase tracking-wider">
                Gợi ý tìm kiếm phổ biến
              </div>
              <div className="flex flex-wrap gap-2">
                {['Hyundai Tucson', 'Hyundai Elantra', 'Ford Ranger', 'Hyundai Santa Fe', 'Xe điện', 'SUV / Crossover'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSearchTerm(tag)}
                    className="text-xs px-3 py-1.5 rounded-full bg-[#0A2438] text-[#BAC9D6] hover:text-[#00D4EE] hover:bg-[#123652] border border-[#1A3F5B] transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
