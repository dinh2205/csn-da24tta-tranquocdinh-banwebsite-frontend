import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Wrench, CheckCircle2, Phone, Calendar, Zap, Fuel, Gauge, Award } from 'lucide-react';
import xeData from '../data/xe.json';
import { NutQuayLai } from '../components/NutQuayLai';

export const ChiTietXe: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const car = xeData.find((x) => x.slug === slug) || xeData[0];
  const [selectedColor, setSelectedColor] = useState(car.mauSac ? car.mauSac[0] : 'Tiêu chuẩn');
  const [activeTab, setActiveTab] = useState<'thongso' | 'antoan' | 'uudiem'>('thongso');

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <NutQuayLai to="/san-pham" label="Về Danh sách xe" />
          <div className="flex items-center gap-2 text-xs text-[#8198AA]">
            <span>Sản phẩm</span>
            <span>/</span>
            <span>{car.hang}</span>
            <span>/</span>
            <span className="text-[#00D4EE] font-semibold">{car.ten}</span>
          </div>
        </div>

        {/* Main Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left / Center: Vehicle Gallery & Visual Stage (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#0F2D42] via-[#081B2B] to-[#04101A] border border-[#1F4967] p-6 sm:p-10 shadow-[0_15px_40px_rgba(0,0,0,0.6)] group">
              
              {/* Cyan geometric ambient backlight */}
              <div 
                className="absolute right-0 top-0 w-80 h-full bg-gradient-to-l from-[#00D4EE]/20 to-transparent pointer-events-none transform -skew-x-12"
              ></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#00D4EE]/10 rounded-full blur-[100px] pointer-events-none"></div>

              {/* Tag / Badge */}
              <div className="flex items-center justify-between relative z-10 mb-4">
                <span className="px-3 py-1 rounded-full bg-[#00D4EE]/20 border border-[#00D4EE] text-[#00D4EE] text-xs font-bold tracking-wider uppercase">
                  {car.loai}
                </span>
                <span className="text-xs text-[#8198AA]">Mẫu mới {car.namSanXuat}</span>
              </div>

              {/* High-res Image Display */}
              <div className="relative h-64 sm:h-80 w-full flex items-center justify-center my-4">
                <img
                  src={car.anh}
                  alt={car.ten}
                  className="max-h-full max-w-full object-contain drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)] transform group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute -bottom-4 w-4/5 h-6 bg-[#00D4EE]/20 blur-md rounded-full pointer-events-none"></div>
              </div>

              {/* Color Selector */}
              {car.mauSac && car.mauSac.length > 0 && (
                <div className="pt-4 border-t border-[#183952] relative z-10 space-y-2">
                  <div className="text-xs text-[#8198AA]">
                    Màu ngoại thất đang chọn: <span className="text-white font-semibold">{selectedColor}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {car.mauSac.map((mau) => (
                      <button
                        key={mau}
                        onClick={() => setSelectedColor(mau)}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer ${
                          selectedColor === mau
                            ? 'bg-[#00D4EE] text-[#03131F] font-bold border-[#00D4EE] shadow-[0_0_10px_rgba(0,212,238,0.4)]'
                            : 'bg-[#081C2C] text-[#BAC9D6] border-[#1C425F] hover:border-[#00D4EE]'
                        }`}
                      >
                        {mau}
                      </button>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Quick Specs Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#091F30] border border-[#1A3F5B] rounded-xl p-3.5 text-center">
                <Gauge className="w-5 h-5 text-[#00D4EE] mx-auto mb-1" />
                <div className="text-xs text-[#8198AA]">Công suất</div>
                <div className="font-display font-bold text-sm text-white mt-0.5">{car.congSuat}</div>
              </div>
              <div className="bg-[#091F30] border border-[#1A3F5B] rounded-xl p-3.5 text-center">
                <Wrench className="w-5 h-5 text-[#00D4EE] mx-auto mb-1" />
                <div className="text-xs text-[#8198AA]">Hộp số</div>
                <div className="font-display font-bold text-sm text-white mt-0.5">{car.hopSo}</div>
              </div>
              <div className="bg-[#091F30] border border-[#1A3F5B] rounded-xl p-3.5 text-center">
                <Fuel className="w-5 h-5 text-[#00D4EE] mx-auto mb-1" />
                <div className="text-xs text-[#8198AA]">Tiêu hao</div>
                <div className="font-display font-bold text-sm text-white mt-0.5">{car.nhienLieu}</div>
              </div>
              <div className="bg-[#091F30] border border-[#1A3F5B] rounded-xl p-3.5 text-center">
                <Award className="w-5 h-5 text-[#00D4EE] mx-auto mb-1" />
                <div className="text-xs text-[#8198AA]">Chỗ ngồi</div>
                <div className="font-display font-bold text-sm text-white mt-0.5">{car.soCho}</div>
              </div>
            </div>

          </div>

          {/* Right: Pricing, Description & Consultation Booking CTA (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 sm:p-7 shadow-[0_15px_35px_rgba(0,0,0,0.5)] space-y-5">
              
              <div>
                <span className="text-[#00D4EE] font-display font-bold text-xs uppercase tracking-widest block mb-1">
                  {car.hang} OFFICIAL
                </span>
                <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
                  {car.ten}
                </h1>
                <p className="text-sm text-[#BAC9D6] mt-2 leading-relaxed">
                  {car.moTa}
                </p>
              </div>

              {/* Price card */}
              <div className="bg-gradient-to-r from-[#0F3149] to-[#071825] border border-[#00D4EE]/40 rounded-2xl p-4 shadow-[0_0_20px_rgba(0,212,238,0.15)]">
                <div className="text-xs text-[#BAC9D6] uppercase tracking-wider">Giá bán tham khảo</div>
                <div className="font-display font-black text-2xl sm:text-3xl text-[#00D4EE] mt-0.5">
                  {car.giaHienThi}
                </div>
                <div className="text-xs text-[#8198AA] mt-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00D4EE]" />
                  <span>Hỗ trợ trả góp 0% chỉ từ {(car.gia * 0.15 / 1000000).toFixed(0)} triệu đồng trả trước</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-2">
                <button
                  onClick={() => navigate(`/dat-lich?xe=${encodeURIComponent(car.ten)}`)}
                  className="w-full flex items-center justify-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-base py-3.5 px-6 rounded-full shadow-[0_0_20px_rgba(0,212,238,0.5)] hover:shadow-[0_0_30px_rgba(0,212,238,0.8)] transition-all cursor-pointer"
                >
                  <Calendar className="w-5 h-5" />
                  <span>Đặt lịch lái thử & nhận báo giá</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                <a
                  href="tel:19008888"
                  className="w-full flex items-center justify-center gap-2 bg-[#0E283E] hover:bg-[#143754] text-white border border-[#245273] font-semibold text-sm py-3 px-6 rounded-full transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#00D4EE]" />
                  <span>Gọi Hotline 1900 8888 (Tư vấn 24/7)</span>
                </a>
              </div>

              {/* Showroom Commitments */}
              <div className="pt-4 border-t border-[#183952] space-y-2 text-xs text-[#BAC9D6]">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#00D4EE]" />
                  <span>Bảo hành chính hãng 5 năm hoặc 100.000 km</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#00D4EE]" />
                  <span>Giao xe tận nơi toàn quốc, hỗ trợ thủ tục đăng ký trong ngày</span>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Detailed Tabs: Specifications, Safety, Advantages */}
        <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 sm:p-8 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
          
          <div className="flex items-center gap-3 border-b border-[#1A3F5B] pb-4 mb-6">
            <button
              onClick={() => setActiveTab('thongso')}
              className={`font-display font-bold text-sm sm:text-base px-4 py-2 rounded-xl transition-all ${
                activeTab === 'thongso'
                  ? 'bg-[#00D4EE] text-[#03131F]'
                  : 'text-[#BAC9D6] hover:text-white hover:bg-[#123652]'
              }`}
            >
              Thông Số Kỹ Thuật
            </button>
            <button
              onClick={() => setActiveTab('antoan')}
              className={`font-display font-bold text-sm sm:text-base px-4 py-2 rounded-xl transition-all ${
                activeTab === 'antoan'
                  ? 'bg-[#00D4EE] text-[#03131F]'
                  : 'text-[#BAC9D6] hover:text-white hover:bg-[#123652]'
              }`}
            >
              Công Nghệ An Toàn
            </button>
            <button
              onClick={() => setActiveTab('uudiem')}
              className={`font-display font-bold text-sm sm:text-base px-4 py-2 rounded-xl transition-all ${
                activeTab === 'uudiem'
                  ? 'bg-[#00D4EE] text-[#03131F]'
                  : 'text-[#BAC9D6] hover:text-white hover:bg-[#123652]'
              }`}
            >
              Quyền Lợi Khách Hàng
            </button>
          </div>

          {activeTab === 'thongso' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(car.thongSo).map(([key, value]) => (
                <div
                  key={key}
                  className="flex items-center justify-between p-3.5 rounded-xl bg-[#061523] border border-[#163852]"
                >
                  <span className="text-xs sm:text-sm text-[#8198AA] font-medium">{key}</span>
                  <span className="text-xs sm:text-sm text-white font-semibold text-right max-w-[55%]">{value}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'antoan' && (
            <div className="space-y-4">
              <p className="text-sm text-[#BAC9D6] leading-relaxed">
                Mẫu xe được trang bị đầy đủ các hệ thống an toàn chủ động thế hệ mới nhất, kiểm định theo tiêu chuẩn 5 sao ASEAN NCAP & EURO NCAP:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
                {[
                  { title: 'Phanh khẩn cấp tự động (FCA)', desc: 'Phát hiện xe, người đi bộ và xe đạp cắt ngang phía trước' },
                  { title: 'Hỗ trợ giữ làn đường (LKA/LFA)', desc: 'Tự động can thiệp vô-lăng giữ xe ở chính giữa tâm làn' },
                  { title: 'Cảnh báo điểm mù chủ động (BCA)', desc: 'Cảnh báo hình ảnh trên gương và camera trực tiếp' },
                  { title: 'Camera toàn cảnh 360 độ', desc: 'Góc nhìn giả lập 3D sắc nét hỗ trợ đỗ xe dễ dàng' },
                  { title: 'Kiểm soát hành trình thông minh (SCC)', desc: 'Tự động bám đuôi xe phía trước và duy trì khoảng cách an toàn' },
                  { title: 'Cân bằng điện tử ESC & 6-7 Túi khí', desc: 'Bảo vệ toàn diện mọi vị trí ngồi khi xảy ra va chạm' },
                ].map((item, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-[#061523] border border-[#183C57]">
                    <div className="text-xs font-bold text-[#00D4EE] mb-1">{item.title}</div>
                    <div className="text-xs text-[#8198AA]">{item.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'uudiem' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-5 rounded-2xl bg-[#061523] border border-[#183C57] space-y-2">
                <ShieldCheck className="w-8 h-8 text-[#00D4EE]" />
                <h4 className="font-display font-bold text-white text-base">Cam kết xe 100% chính hãng</h4>
                <p className="text-xs text-[#8198AA] leading-relaxed">
                  Đầy đủ giấy tờ hải quan, xuất hóa đơn VAT, chứng chỉ xuất xưởng và bảo hành tại các đại lý ủy quyền toàn quốc.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#061523] border border-[#183C57] space-y-2">
                <Wrench className="w-8 h-8 text-[#00D4EE]" />
                <h4 className="font-display font-bold text-white text-base">Gói bảo dưỡng cao cấp</h4>
                <p className="text-xs text-[#8198AA] leading-relaxed">
                  Tặng 3 lần bảo dưỡng định kỳ miễn phí công kiểm tra và thay nhớt động cơ tại trung tâm dịch vụ AutoVela.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#061523] border border-[#183C57] space-y-2">
                <Calendar className="w-8 h-8 text-[#00D4EE]" />
                <h4 className="font-display font-bold text-white text-base">Lái thử tận nơi</h4>
                <p className="text-xs text-[#8198AA] leading-relaxed">
                  Đội ngũ nhân viên mang xe lái thử đến tận nhà hoặc cơ quan của bạn hoàn toàn miễn phí.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
