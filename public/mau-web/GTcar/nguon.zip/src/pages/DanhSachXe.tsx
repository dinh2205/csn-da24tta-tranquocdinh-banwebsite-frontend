import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, Filter, ArrowRight, SlidersHorizontal, Car, Check } from 'lucide-react';
import xeData from '../data/xe.json';
import { NutQuayLai } from '../components/NutQuayLai';

export const DanhSachXe: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('loai') || '';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('all');
  const [selectedType, setSelectedType] = useState(categoryParam || 'all');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('featured');

  // Sync categoryParam from URL if it changes
  React.useEffect(() => {
    if (categoryParam) {
      // Map potential slug params to Vietnamese name
      const map: Record<string, string> = {
        'xe-du-lich': 'Xe du lịch',
        'xe-ban-tai': 'Xe bán tải',
        'suv': 'SUV / Crossover',
        'xe-dien': 'Xe điện',
        'phu-kien': 'Phụ kiện'
      };
      setSelectedType(map[categoryParam] || categoryParam);
    }
  }, [categoryParam]);

  const brands = useMemo(() => {
    const list = Array.from(new Set(xeData.map(c => c.hang)));
    return ['all', ...list];
  }, []);

  const types = [
    'all',
    'Xe du lịch',
    'Xe bán tải',
    'SUV / Crossover',
    'Xe điện',
    'Phụ kiện'
  ];

  const filteredCars = useMemo(() => {
    return xeData.filter((car) => {
      // Search
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        car.ten.toLowerCase().includes(q) ||
        car.hang.toLowerCase().includes(q) ||
        car.loai.toLowerCase().includes(q);

      // Brand
      const matchBrand = selectedBrand === 'all' || car.hang === selectedBrand;

      // Type
      const matchType = selectedType === 'all' || car.loai === selectedType;

      // Price range
      let matchPrice = true;
      if (priceRange === 'under700') matchPrice = car.gia < 700000000;
      else if (priceRange === '700to1000') matchPrice = car.gia >= 700000000 && car.gia <= 1000000000;
      else if (priceRange === 'above1000') matchPrice = car.gia > 1000000000;

      return matchSearch && matchBrand && matchType && matchPrice;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.gia - b.gia;
      if (sortBy === 'price-desc') return b.gia - a.gia;
      return (b.noiBat ? 1 : 0) - (a.noiBat ? 1 : 0);
    });
  }, [searchQuery, selectedBrand, selectedType, priceRange, sortBy]);

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Breadcrumb / Back */}
        <div className="flex items-center justify-between">
          <NutQuayLai to="/" label="Về Trang chủ" />
          <div className="text-xs text-[#8198AA]">
            Hiển thị <span className="text-[#00D4EE] font-bold">{filteredCars.length}</span> mẫu xe
          </div>
        </div>

        {/* Page Title */}
        <div className="relative pb-4 border-b border-[#143249]">
          <span className="text-[#00D4EE] font-display font-extrabold text-xs tracking-[0.25em] uppercase block mb-1">
            DANH MỤC SHOWROOM
          </span>
          <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
            Bộ Sưu Tập Xe <span className="text-[#00D4EE]">Hiện Đại</span>
          </h1>
          <p className="text-sm text-[#BAC9D6] mt-1 max-w-xl">
            Tất cả các dòng xe chính hãng được kiểm định 24 bước tiêu chuẩn, hỗ trợ vay trả góp 0% và bảo hành lên đến 5 năm.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-[#0A2032] border border-[#234F6E] rounded-2xl p-4 sm:p-5 shadow-[0_10px_25px_rgba(0,0,0,0.4)] space-y-4">
          
          {/* Top row: Search input + Sort */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#00D4EE]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm theo tên xe, phiên bản..."
                className="w-full bg-[#061625] border border-[#1C425F] rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE] transition-colors"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <SlidersHorizontal className="w-4 h-4 text-[#8198AA] shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full sm:w-auto bg-[#061625] border border-[#1C425F] rounded-xl px-3 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-[#00D4EE] cursor-pointer"
              >
                <option value="featured">Sắp xếp: Nổi bật nhất</option>
                <option value="price-asc">Giá: Thấp đến Cao</option>
                <option value="price-desc">Giá: Cao đến Thấp</option>
              </select>
            </div>
          </div>

          {/* Bottom row: Category Pills */}
          <div className="space-y-3 pt-2 border-t border-[#143249]">
            <div className="flex items-center gap-2 text-xs font-bold text-[#8198AA] uppercase tracking-wider">
              <Filter className="w-3.5 h-3.5 text-[#00D4EE]" />
              <span>Phân loại dòng xe:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {types.map((type) => {
                const isSelected = selectedType === type;
                return (
                  <button
                    key={type}
                    onClick={() => {
                      setSelectedType(type);
                      setSearchParams(type === 'all' ? {} : { loai: type });
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#00D4EE] text-[#03131F] font-bold shadow-[0_0_12px_rgba(0,212,238,0.5)]'
                        : 'bg-[#081827] text-[#BAC9D6] hover:bg-[#123652] hover:text-white border border-[#1C425F]'
                    }`}
                  >
                    {type === 'all' ? 'Tất cả dòng xe' : type}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Secondary filter: Brand & Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div>
              <label className="block text-xs font-medium text-[#8198AA] mb-1.5">Hãng xe</label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full bg-[#061625] border border-[#1C425F] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00D4EE]"
              >
                <option value="all">Tất cả thương hiệu</option>
                {brands.filter(b => b !== 'all').map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#8198AA] mb-1.5">Khoảng giá</label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="w-full bg-[#061625] border border-[#1C425F] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00D4EE]"
              >
                <option value="all">Tất cả mức giá</option>
                <option value="under700">Dưới 700 triệu</option>
                <option value="700to1000">Từ 700 triệu - 1 tỷ</option>
                <option value="above1000">Trên 1 tỷ đồng</option>
              </select>
            </div>
          </div>

        </div>

        {/* Cars Grid */}
        {filteredCars.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredCars.map((car) => (
              <div
                key={car.id}
                className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#133248] via-[#0A1F30] to-[#061522] border border-[#244E6B] p-4 group hover:border-[#00D4EE] transition-all duration-300 transform hover:-translate-y-1.5 shadow-[0_10px_25px_rgba(0,0,0,0.5)] flex flex-col justify-between"
              >
                {/* Diagonal Accent Ribbon */}
                <div 
                  className="absolute top-0 left-0 w-20 h-12 bg-gradient-to-br from-[#00D4EE] to-[#078CD7] opacity-80 pointer-events-none"
                  style={{
                    clipPath: 'polygon(0 0, 100% 0, 45% 100%, 0 100%)'
                  }}
                ></div>

                <div>
                  {/* Category & Brand tags */}
                  <div className="flex justify-between items-center mb-2 relative z-10 pl-6">
                    <span className="text-[11px] font-bold text-[#00D4EE] uppercase tracking-wider">
                      {car.hang}
                    </span>
                    <span className="text-[11px] font-semibold text-[#8198AA] bg-[#061523]/80 px-2 py-0.5 rounded border border-[#16354B]">
                      {car.loai}
                    </span>
                  </div>

                  {/* Car Image with reflection */}
                  <Link to={`/san-pham/${car.slug}`} className="block relative h-40 w-full flex items-center justify-center select-none overflow-hidden my-2">
                    <img
                      src={car.anh}
                      alt={car.ten}
                      className="max-h-full w-auto object-contain drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute -bottom-2 w-3/4 h-3 bg-[#00D4EE]/15 blur-sm rounded-full pointer-events-none"></div>
                  </Link>

                  {/* Car Info */}
                  <div className="space-y-1 mt-2">
                    <Link to={`/san-pham/${car.slug}`}>
                      <h3 className="font-display font-bold text-base text-white group-hover:text-[#00D4EE] transition-colors line-clamp-1">
                        {car.ten}
                      </h3>
                    </Link>
                    <p className="text-xs text-[#8198AA] line-clamp-2">
                      {car.moTa}
                    </p>
                  </div>

                  {/* Highlights spec chips */}
                  <div className="grid grid-cols-2 gap-1.5 pt-3 text-[11px] text-[#BAC9D6]">
                    <div className="bg-[#081B2B] px-2 py-1 rounded border border-[#16354B] truncate">
                      ⚙️ {car.dongCo.split('/')[0]}
                    </div>
                    <div className="bg-[#081B2B] px-2 py-1 rounded border border-[#16354B] truncate">
                      ⛽ {car.nhienLieu.split('(')[0]}
                    </div>
                  </div>
                </div>

                {/* Bottom CTA Row */}
                <div className="mt-4 pt-3 border-t border-[#1C3E56]/60 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-[#8198AA] block uppercase">Giá bán niêm yết</span>
                    <span className="font-display font-bold text-base text-white">
                      {car.giaHienThi}
                    </span>
                  </div>

                  <Link
                    to={`/san-pham/${car.slug}`}
                    className="w-9 h-9 rounded-full bg-[#00D4EE] text-[#03131F] flex items-center justify-center shadow-[0_0_12px_rgba(0,212,238,0.5)] group-hover:bg-[#38E8FF] group-hover:scale-110 transition-all shrink-0"
                    title="Xem chi tiết"
                  >
                    <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                  </Link>
                </div>

              </div>
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-[#081C2C] border border-[#193F5E] rounded-2xl p-8 space-y-3">
            <Car className="w-12 h-12 text-[#224E70] mx-auto" />
            <h3 className="font-display font-bold text-lg text-white">Không tìm thấy mẫu xe phù hợp</h3>
            <p className="text-sm text-[#8198AA] max-w-md mx-auto">
              Vui lòng thử điều chỉnh lại bộ lọc phân loại dòng xe, thương hiệu hoặc từ khóa tìm kiếm.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedBrand('all');
                setSelectedType('all');
                setPriceRange('all');
              }}
              className="mt-2 px-5 py-2 rounded-full bg-[#00D4EE] text-[#03131F] font-bold text-xs"
            >
              Đặt lại bộ lọc
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
