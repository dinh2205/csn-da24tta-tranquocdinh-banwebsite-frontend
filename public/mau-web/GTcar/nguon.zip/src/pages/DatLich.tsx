import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Car, CheckCircle2, User, Phone, Mail, ArrowRight, ShieldCheck, History } from 'lucide-react';
import xeData from '../data/xe.json';
import { luuLichHen, layDanhSachLichHen, LichHen } from '../utils/luuLichHen';
import { NutQuayLai } from '../components/NutQuayLai';

export const DatLich: React.FC = () => {
  const [searchParams] = useSearchParams();
  const carNameParam = searchParams.get('xe') || '';
  const navigate = useNavigate();

  const [selectedCar, setSelectedCar] = useState(carNameParam || xeData[0].ten);
  const [showroom, setShowroom] = useState('Showroom 1: 88 Đại lộ Thăng Long, Nam Từ Liêm, Hà Nội');
  const [date, setDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('09:30 - 10:30');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [note, setNote] = useState('');
  const [successBooking, setSuccessBooking] = useState<LichHen | null>(null);
  const [bookingHistory, setBookingHistory] = useState<LichHen[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    // Set default date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setDate(tomorrow.toISOString().split('T')[0]);
    setBookingHistory(layDanhSachLichHen());
  }, []);

  const timeSlots = [
    '08:30 - 09:30',
    '09:30 - 10:30',
    '10:30 - 11:30',
    '14:00 - 15:00',
    '15:30 - 16:30',
    '17:00 - 18:00',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !phone) return;

    const matchedCar = xeData.find((x) => x.ten === selectedCar);
    const newBooking = luuLichHen({
      maXe: matchedCar?.id || 'xe-default',
      tenXe: selectedCar,
      hoTen: fullName,
      soDienThoai: phone,
      email: email || 'Chưa cung cấp',
      ngayHen: date,
      gioHen: timeSlot,
      showroom: showroom,
      ghiChu: note,
    });

    setSuccessBooking(newBooking);
    setBookingHistory(layDanhSachLichHen());
  };

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#143249] pb-4">
          <div>
            <NutQuayLai to="/" label="Về Trang chủ" />
            <span className="text-[#00D4EE] font-display font-extrabold text-xs tracking-[0.25em] uppercase block mt-2 mb-1">
              DỊCH VỤ TRẢI NGHIỆM ĐẲNG CẤP
            </span>
            <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
              Đặt Lịch Lái Thử & <span className="text-[#00D4EE]">Tư Vấn Trực Tiếp</span>
            </h1>
          </div>

          <button
            onClick={() => setShowHistory(!showHistory)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#092236] border border-[#1A4261] text-xs font-semibold text-[#BAC9D6] hover:text-[#00D4EE] hover:border-[#00D4EE] transition-colors self-start sm:self-auto"
          >
            <History className="w-4 h-4 text-[#00D4EE]" />
            <span>{showHistory ? 'Ẩn lịch đã đặt' : `Lịch hẹn của tôi (${bookingHistory.length})`}</span>
          </button>
        </div>

        {/* Existing Booking History drawer if toggled */}
        {showHistory && (
          <div className="bg-[#091F30] border border-[#00D4EE]/40 rounded-2xl p-5 animate-in fade-in space-y-4">
            <h3 className="font-display font-bold text-white text-base flex items-center gap-2">
              <History className="w-4 h-4 text-[#00D4EE]" />
              <span>Danh Sách Lịch Hẹn Đã Lưu (LocalStorage)</span>
            </h3>

            {bookingHistory.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {bookingHistory.map((item) => (
                  <div key={item.id} className="p-3.5 rounded-xl bg-[#061523] border border-[#183952] space-y-1.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-[#00D4EE] font-bold">{item.id}</span>
                      <span className="text-[10px] bg-[#00D4EE]/10 text-[#00D4EE] px-2 py-0.5 rounded font-semibold">Đã xác nhận</span>
                    </div>
                    <div className="text-white font-bold text-sm">{item.tenXe}</div>
                    <div className="text-[#BAC9D6]">Khách hàng: {item.hoTen} - {item.soDienThoai}</div>
                    <div className="text-[#8198AA]">Thời gian: {item.gioHen}, ngày {item.ngayHen}</div>
                    <div className="text-[#8198AA] truncate">Địa điểm: {item.showroom}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-[#8198AA]">Bạn chưa có lịch hẹn nào được ghi nhận trên thiết bị này.</p>
            )}
          </div>
        )}

        {/* Success Modal / Ticket State */}
        {successBooking ? (
          <div className="max-w-2xl mx-auto bg-gradient-to-b from-[#0F3149] via-[#092236] to-[#04121F] border border-[#00D4EE] rounded-3xl p-8 sm:p-10 shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_35px_rgba(0,212,238,0.3)] text-center space-y-6">
            <div className="w-20 h-20 rounded-full bg-[#00D4EE]/20 border-2 border-[#00D4EE] text-[#00D4EE] flex items-center justify-center mx-auto shadow-[0_0_25px_rgba(0,212,238,0.6)]">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs text-[#00D4EE] font-bold tracking-widest uppercase">
                PHIẾU XÁC NHẬN ĐẶT LỊCH
              </span>
              <h2 className="font-display font-black text-2xl sm:text-3xl text-white mt-1">
                Đặt Lịch Thành Công!
              </h2>
              <p className="text-sm text-[#BAC9D6] mt-2">
                Hệ thống AutoVela đã tiếp nhận yêu cầu trải nghiệm xe của Quý khách.
              </p>
            </div>

            {/* Ticket Card Details */}
            <div className="bg-[#061625] border border-[#1B4362] rounded-2xl p-5 text-left space-y-3 text-xs sm:text-sm">
              <div className="flex justify-between pb-2 border-b border-[#14344E]">
                <span className="text-[#8198AA]">Mã số lịch hẹn:</span>
                <span className="text-[#00D4EE] font-mono font-bold">{successBooking.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8198AA]">Dòng xe đăng ký:</span>
                <span className="text-white font-bold">{successBooking.tenXe}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8198AA]">Thời gian:</span>
                <span className="text-white font-semibold">{successBooking.gioHen} - Ngày {successBooking.ngayHen}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8198AA]">Người liên hệ:</span>
                <span className="text-white font-semibold">{successBooking.hoTen} ({successBooking.soDienThoai})</span>
              </div>
              <div className="pt-2 border-t border-[#14344E] text-xs text-[#8198AA]">
                <strong>Showroom tiếp nhận:</strong> {successBooking.showroom}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => setSuccessBooking(null)}
                className="px-6 py-3 rounded-full bg-[#0A2234] border border-[#234A64] text-white hover:border-[#00D4EE] text-xs font-bold transition-colors cursor-pointer"
              >
                Đặt thêm lịch hẹn khác
              </button>
              <button
                onClick={() => navigate('/san-pham')}
                className="px-6 py-3 rounded-full bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-xs shadow-[0_0_15px_rgba(0,212,238,0.5)] transition-all cursor-pointer"
              >
                Khám phá thêm các dòng xe
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: Booking Form (7 cols) */}
            <div className="lg:col-span-7 bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 sm:p-8 shadow-[0_15px_35px_rgba(0,0,0,0.5)] space-y-6">
              
              <div>
                <h2 className="font-display font-black text-xl sm:text-2xl text-white">
                  Thông Tin Lịch Hẹn
                </h2>
                <p className="text-xs sm:text-sm text-[#8198AA] mt-1">
                  Vui lòng điền thông tin để showroom chuẩn bị sẵn xe lái thử và phòng đón tiếp.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                
                {/* 1. Select Car */}
                <div>
                  <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                    <Car className="w-3.5 h-3.5 text-[#00D4EE]" />
                    <span>Dòng xe bạn quan tâm <span className="text-[#00D4EE]">*</span></span>
                  </label>
                  <select
                    value={selectedCar}
                    onChange={(e) => setSelectedCar(e.target.value)}
                    className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00D4EE] cursor-pointer"
                  >
                    {xeData.map((car) => (
                      <option key={car.id} value={car.ten}>
                        {car.ten} ({car.giaHienThi})
                      </option>
                    ))}
                  </select>
                </div>

                {/* 2. Select Showroom */}
                <div>
                  <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#00D4EE]" />
                    <span>Địa điểm lái thử & tư vấn</span>
                  </label>
                  <select
                    value={showroom}
                    onChange={(e) => setShowroom(e.target.value)}
                    className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00D4EE] cursor-pointer"
                  >
                    <option value="Showroom 1: 88 Đại lộ Thăng Long, Nam Từ Liêm, Hà Nội">
                      Showroom Hà Nội - 88 Đại lộ Thăng Long, Nam Từ Liêm
                    </option>
                    <option value="Showroom 2: 120 Võ Văn Kiệt, Quận 1, TP. Hồ Chí Minh">
                      Showroom TP.HCM - 120 Võ Văn Kiệt, Quận 1
                    </option>
                    <option value="Lái thử tại nhà / cơ quan khách hàng (Hà Nội & TP.HCM)">
                      Lái thử tận nhà / cơ quan của Quý khách
                    </option>
                  </select>
                </div>

                {/* 3. Date & Time */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>Ngày lái thử <span className="text-[#00D4EE]">*</span></span>
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00D4EE]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>Khung giờ thuận tiện</span>
                    </label>
                    <select
                      value={timeSlot}
                      onChange={(e) => setTimeSlot(e.target.value)}
                      className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00D4EE]"
                    >
                      {timeSlots.map((ts) => (
                        <option key={ts} value={ts}>{ts}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* 4. Customer Info */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>Họ và tên <span className="text-[#00D4EE]">*</span></span>
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Nguyễn Văn A"
                      className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>Số điện thoại <span className="text-[#00D4EE]">*</span></span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0988 123 456"
                      className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#00D4EE]" />
                    <span>Email nhận xác nhận</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                    Ghi chú thêm (yêu cầu màu xe, tính năng cần lái thử...)
                  </label>
                  <textarea
                    rows={2}
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Ví dụ: Muốn lái thử trên đường cao tốc, xem phiên bản màu trắng..."
                    className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-base py-3.5 px-6 rounded-full shadow-[0_0_20px_rgba(0,212,238,0.5)] hover:shadow-[0_0_30px_rgba(0,212,238,0.8)] transition-all cursor-pointer"
                >
                  <span>Xác nhận đặt lịch ngay</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
              </form>

            </div>

            {/* Right: Selected Car Preview & Benefits (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Car Card Preview */}
              {(() => {
                const matched = xeData.find((x) => x.ten === selectedCar) || xeData[0];
                return (
                  <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 shadow-[0_10px_30px_rgba(0,0,0,0.5)] space-y-4">
                    <span className="text-[11px] font-bold text-[#00D4EE] uppercase tracking-wider block">
                      XE ĐÃ CHỌN
                    </span>
                    <h3 className="font-display font-black text-xl text-white">
                      {matched.ten}
                    </h3>

                    <div className="relative h-44 w-full flex items-center justify-center bg-[#061523] rounded-2xl p-2 overflow-hidden border border-[#163852]">
                      <img
                        src={matched.anh}
                        alt={matched.ten}
                        className="max-h-full max-w-full object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]"
                      />
                    </div>

                    <div className="flex justify-between items-center text-sm pt-2">
                      <span className="text-[#8198AA]">Giá niêm yết:</span>
                      <span className="font-display font-bold text-[#00D4EE] text-base">
                        {matched.giaHienThi}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* VIP Benefits for Test Drive */}
              <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 shadow-[0_10px_30px_rgba(0,0,0,0.5)] space-y-4 text-xs text-[#BAC9D6]">
                <h4 className="font-display font-bold text-white text-sm uppercase tracking-wider flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#00D4EE]" />
                  <span>Đặc quyền khách hàng AutoVela</span>
                </h4>

                <div className="space-y-3">
                  <div className="flex items-start gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#00D4EE] mt-1.5 shrink-0"></div>
                    <span>Miễn phí 100% chi phí lái thử, đồ uống và quà lưu niệm chính hãng.</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#00D4EE] mt-1.5 shrink-0"></div>
                    <span>Chuyên viên hướng dẫn các tính năng lái nâng cao (Adaptive Cruise Control, giữ làn, phanh tự động).</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#00D4EE] mt-1.5 shrink-0"></div>
                    <span>Nhận ngay voucher ưu đãi phụ kiện trị giá 10.000.000 đ khi đặt cọc trong ngày.</span>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
