import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wrench, ShieldCheck, Tag, Headset, Calculator, Check, ArrowRight, Clock, Award } from 'lucide-react';
import dichVuData from '../data/dich-vu.json';
import { NutQuayLai } from '../components/NutQuayLai';
import { dinhDangGia } from '../utils/dinhDangGia';

export const DichVu: React.FC = () => {
  // Loan calculator state
  const [carPrice, setCarPrice] = useState(800000000);
  const [downPaymentPercent, setDownPaymentPercent] = useState(20);
  const [loanYears, setLoanYears] = useState(5);
  const [interestRate, setInterestRate] = useState(7.5); // %/year

  const downPaymentAmount = (carPrice * downPaymentPercent) / 100;
  const loanAmount = carPrice - downPaymentAmount;
  const totalMonths = loanYears * 12;
  const monthlyInterestRate = interestRate / 100 / 12;
  
  // Standard monthly payment calculation
  const monthlyPayment = monthlyInterestRate > 0
    ? (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths)) / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1)
    : loanAmount / totalMonths;

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Navigation & Header */}
        <div className="space-y-4">
          <NutQuayLai to="/" label="Về Trang chủ" />
          <div className="border-b border-[#143249] pb-4">
            <span className="text-[#00D4EE] font-display font-extrabold text-xs tracking-[0.25em] uppercase block mb-1">
              DỊCH VỤ & HẬU MÃI
            </span>
            <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
              Trung Tâm Chăm Sóc & <span className="text-[#00D4EE]">Bảo Dưỡng Toàn Diện</span>
            </h1>
            <p className="text-sm text-[#BAC9D6] mt-2 max-w-2xl">
              Đạt tiêu chuẩn 5 sao quốc tế với kỹ thuật viên lành nghề, phụ tùng chính hãng và thiết bị chẩn đoán điện tử tối tân.
            </p>
          </div>
        </div>

        {/* Services List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {dichVuData.map((dichVu, index) => (
            <div
              key={dichVu.id}
              className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#0F2D42] via-[#091D2C] to-[#05131E] border border-[#1C4661] p-6 sm:p-8 flex flex-col justify-between group hover:border-[#00D4EE] transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.5)]"
            >
              {/* Subtle top background diagonal light */}
              <div 
                className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-[#00D4EE]/15 to-transparent pointer-events-none rounded-bl-full"
              ></div>

              <div>
                <div className="flex items-center justify-between gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-[#071927] border border-[#00D4EE]/50 flex items-center justify-center text-[#00D4EE] shadow-[0_0_15px_rgba(0,212,238,0.25)]">
                    {index === 0 && <Wrench className="w-6 h-6" />}
                    {index === 1 && <ShieldCheck className="w-6 h-6" />}
                    {index === 2 && <Tag className="w-6 h-6" />}
                    {index === 3 && <Headset className="w-6 h-6" />}
                  </div>
                  <span className="text-xs text-[#00D4EE] font-semibold bg-[#061826] px-3 py-1 rounded-full border border-[#143952]">
                    {dichVu.thoiGian}
                  </span>
                </div>

                <h3 className="font-display font-black text-xl sm:text-2xl text-white group-hover:text-[#00D4EE] transition-colors mb-2">
                  {dichVu.tieuDe}
                </h3>

                <p className="text-xs sm:text-sm text-[#8198AA] leading-relaxed mb-4">
                  {dichVu.moTa}
                </p>

                <div className="space-y-2 mb-6">
                  {dichVu.chiTiet.map((item, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-[#BAC9D6]">
                      <Check className="w-4 h-4 text-[#00D4EE] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-[#183952] flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-[#8198AA] block uppercase">Chi phí ước tính</span>
                  <span className="font-display font-bold text-sm sm:text-base text-white">
                    {dichVu.gia}
                  </span>
                </div>

                <Link
                  to="/dat-lich"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-xs transition-all shadow-[0_0_12px_rgba(0,212,238,0.3)]"
                >
                  <span>Đặt lịch dịch vụ</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>

            </div>
          ))}
        </div>

        {/* Interactive Loan & Installment Calculator */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0C273C] via-[#091E2E] to-[#061522] border border-[#234E6F] p-6 sm:p-10 shadow-[0_15px_40px_rgba(0,0,0,0.6)]">
          <div className="flex items-center gap-2 mb-2">
            <Calculator className="w-5 h-5 text-[#00D4EE]" />
            <span className="text-xs font-bold text-[#00D4EE] uppercase tracking-wider">
              CÔNG CỤ TÍNH DỰ TOÁN TRẢ GÓP
            </span>
          </div>
          <h2 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight mb-2">
            Ước Tính Chi Phí Trả Góp <span className="text-[#00D4EE]">Linh Hoạt</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#8198AA] max-w-xl mb-8">
            Dễ dàng dự trù tài chính trước khi mua xe với các phương án vay ưu đãi liên kết hơn 12 ngân hàng đối tác của AutoVela.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Input sliders */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Car Price */}
              <div>
                <div className="flex justify-between text-xs sm:text-sm font-semibold mb-2">
                  <span className="text-[#BAC9D6]">Giá xe dự kiến:</span>
                  <span className="text-[#00D4EE] font-display font-bold">{dinhDangGia(carPrice)}</span>
                </div>
                <input
                  type="range"
                  min="500000000"
                  max="2000000000"
                  step="20000000"
                  value={carPrice}
                  onChange={(e) => setCarPrice(Number(e.target.value))}
                  className="w-full h-2 bg-[#081827] rounded-lg appearance-none cursor-pointer accent-[#00D4EE]"
                />
                <div className="flex justify-between text-[10px] text-[#8198AA] mt-1">
                  <span>500 triệu</span>
                  <span>1.2 tỷ</span>
                  <span>2 tỷ</span>
                </div>
              </div>

              {/* Down Payment */}
              <div>
                <div className="flex justify-between text-xs sm:text-sm font-semibold mb-2">
                  <span className="text-[#BAC9D6]">Tỷ lệ trả trước ({downPaymentPercent}%):</span>
                  <span className="text-[#00D4EE] font-display font-bold">{dinhDangGia(downPaymentAmount)}</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="70"
                  step="5"
                  value={downPaymentPercent}
                  onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                  className="w-full h-2 bg-[#081827] rounded-lg appearance-none cursor-pointer accent-[#00D4EE]"
                />
                <div className="flex justify-between text-[10px] text-[#8198AA] mt-1">
                  <span>15%</span>
                  <span>40%</span>
                  <span>70%</span>
                </div>
              </div>

              {/* Loan Duration */}
              <div>
                <div className="flex justify-between text-xs sm:text-sm font-semibold mb-2">
                  <span className="text-[#BAC9D6]">Thời hạn vay:</span>
                  <span className="text-[#00D4EE] font-display font-bold">{loanYears} năm ({totalMonths} tháng)</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="8"
                  step="1"
                  value={loanYears}
                  onChange={(e) => setLoanYears(Number(e.target.value))}
                  className="w-full h-2 bg-[#081827] rounded-lg appearance-none cursor-pointer accent-[#00D4EE]"
                />
                <div className="flex justify-between text-[10px] text-[#8198AA] mt-1">
                  <span>1 năm</span>
                  <span>4 năm</span>
                  <span>8 năm</span>
                </div>
              </div>

              {/* Interest Rate */}
              <div>
                <div className="flex justify-between text-xs sm:text-sm font-semibold mb-2">
                  <span className="text-[#BAC9D6]">Lãi suất ưu đãi:</span>
                  <span className="text-[#00D4EE] font-display font-bold">{interestRate}% / năm</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="12"
                  step="0.5"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full h-2 bg-[#081827] rounded-lg appearance-none cursor-pointer accent-[#00D4EE]"
                />
              </div>

            </div>

            {/* Calculated Result Card */}
            <div className="lg:col-span-5 bg-[#061625] border border-[#00D4EE]/40 rounded-2xl p-6 sm:p-7 shadow-[0_0_25px_rgba(0,212,238,0.2)] space-y-4">
              <span className="text-xs text-[#8198AA] uppercase tracking-wider block">Ước tính số tiền trả hàng tháng</span>
              <div className="font-display font-black text-3xl sm:text-4xl text-[#00D4EE] leading-none">
                {dinhDangGia(Math.round(monthlyPayment))}
                <span className="text-xs text-[#8198AA] font-normal"> / tháng</span>
              </div>

              <div className="space-y-2.5 pt-3 border-t border-[#163852] text-xs">
                <div className="flex justify-between text-[#BAC9D6]">
                  <span>Số tiền cần trả trước:</span>
                  <span className="text-white font-bold">{dinhDangGia(downPaymentAmount)}</span>
                </div>
                <div className="flex justify-between text-[#BAC9D6]">
                  <span>Số tiền vay ngân hàng:</span>
                  <span className="text-white font-bold">{dinhDangGia(loanAmount)}</span>
                </div>
                <div className="flex justify-between text-[#BAC9D6]">
                  <span>Thời hạn vay:</span>
                  <span className="text-white font-bold">{loanYears} năm</span>
                </div>
              </div>

              <Link
                to="/dat-lich"
                className="w-full inline-flex items-center justify-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-sm py-3 px-4 rounded-full shadow-[0_0_15px_rgba(0,212,238,0.4)] transition-all pt-2.5 cursor-pointer"
              >
                <span>Nhận bảng kế hoạch trả góp chi tiết</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
