import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, MessageSquare } from 'lucide-react';
import { NutQuayLai } from '../components/NutQuayLai';

export const LienHe: React.FC = () => {
  const [formData, setFormData] = useState({
    hoTen: '',
    soDienThoai: '',
    email: '',
    chuDe: 'Tư vấn mua xe',
    noiDung: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.hoTen || !formData.soDienThoai) return;
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation & Header */}
        <div className="space-y-4">
          <NutQuayLai to="/" label="Về Trang chủ" />
          <div className="border-b border-[#143249] pb-4">
            <span className="text-[#00D4EE] font-display font-extrabold text-xs tracking-[0.25em] uppercase block mb-1">
              LIÊN HỆ SHOWROOM
            </span>
            <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
              Kết Nối Cùng <span className="text-[#00D4EE]">AutoVela</span>
            </h1>
            <p className="text-sm text-[#BAC9D6] mt-2 max-w-xl">
              Hệ thống showroom hiện đại hàng đầu Việt Nam. Đội ngũ chuyên viên sẵn sàng tiếp đón và phục vụ quý khách 7 ngày trong tuần.
            </p>
          </div>
        </div>

        {/* Contact Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Showroom Locations & Quick Contacts (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 sm:p-7 shadow-[0_10px_30px_rgba(0,0,0,0.5)] space-y-6">
              <h3 className="font-display font-black text-xl text-white border-l-2 border-[#00D4EE] pl-3 uppercase">
                Hệ Thống Showroom
              </h3>

              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-[#061625] border border-[#163852] space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <MapPin className="w-4 h-4 text-[#00D4EE]" />
                    <span>AutoVela Hà Nội (Headquarter)</span>
                  </div>
                  <p className="text-xs text-[#8198AA] pl-6 leading-relaxed">
                    Số 88 Đại lộ Thăng Long, Phường Mễ Trì, Quận Nam Từ Liêm, Hà Nội.
                  </p>
                  <p className="text-xs text-[#00D4EE] pl-6 font-semibold">
                    Hotline: 024.7300.8888
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#061625] border border-[#163852] space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <MapPin className="w-4 h-4 text-[#00D4EE]" />
                    <span>AutoVela TP. Hồ Chí Minh</span>
                  </div>
                  <p className="text-xs text-[#8198AA] pl-6 leading-relaxed">
                    Số 120 Đường Võ Văn Kiệt, Phường Nguyễn Thái Bình, Quận 1, TP. Hồ Chí Minh.
                  </p>
                  <p className="text-xs text-[#00D4EE] pl-6 font-semibold">
                    Hotline: 028.7300.9999
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-[#163852] space-y-3 text-xs text-[#BAC9D6]">
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#00D4EE]" />
                  <span>Tổng đài toàn quốc: <strong className="text-white">1900 8888</strong> (Miễn phí cước)</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-[#00D4EE]" />
                  <span>Hòm thư tiếp nhận: <strong className="text-white">contact@autovela.vn</strong></span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#00D4EE]" />
                  <span>Giờ mở cửa: <strong className="text-white">08:00 - 20:00</strong> (Thứ 2 - Chủ Nhật)</span>
                </div>
              </div>

            </div>

            {/* Map Visual Card */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#092236] to-[#04101A] border border-[#1A405D] p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#00D4EE]" />
                  Chỉ đường tới showroom gần nhất
                </span>
                <span className="text-[10px] bg-[#00D4EE]/20 text-[#00D4EE] px-2 py-0.5 rounded font-bold">
                  Bãi đỗ xe miễn phí
                </span>
              </div>
              <div className="h-36 rounded-xl bg-[#061523] border border-[#12314A] flex items-center justify-center text-center p-4">
                <div className="space-y-1">
                  <div className="text-xs text-white font-semibold">Tọa độ trung tâm AutoVela Hub</div>
                  <div className="text-[11px] text-[#8198AA]">Khu trưng bày xe 3.000m² & Xưởng dịch vụ tiêu chuẩn 5 sao</div>
                  <div className="text-[10px] text-[#00D4EE] font-mono mt-1">21.0089° N, 105.7816° E</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Contact & Feedback Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-[#0A2032] border border-[#234F6E] rounded-3xl p-6 sm:p-8 shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
              
              {submitted ? (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#00D4EE]/20 border border-[#00D4EE] text-[#00D4EE] flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(0,212,238,0.5)]">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="font-display font-black text-2xl text-white">Gửi Thông Tin Thành Công!</h3>
                  <p className="text-sm text-[#BAC9D6] max-w-md mx-auto">
                    Cảm ơn <span className="text-[#00D4EE] font-bold">{formData.hoTen}</span>. Chuyên viên tư vấn AutoVela sẽ liên hệ lại qua số điện thoại <span className="text-[#00D4EE] font-bold">{formData.soDienThoai}</span> trong vòng 15 phút.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        hoTen: '',
                        soDienThoai: '',
                        email: '',
                        chuDe: 'Tư vấn mua xe',
                        noiDung: ''
                      });
                    }}
                    className="px-6 py-2.5 rounded-full bg-[#00D4EE] text-[#03131F] font-bold text-xs"
                  >
                    Gửi yêu cầu khác
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <h3 className="font-display font-black text-xl sm:text-2xl text-white">
                      Gửi Lời Nhắn Đến Ban Quản Trị
                    </h3>
                    <p className="text-xs sm:text-sm text-[#8198AA] mt-1">
                      Để lại thông tin bên dưới để được tư vấn báo giá lăn bánh, quà tặng phụ kiện và chương trình lái thử.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                        Họ và tên <span className="text-[#00D4EE]">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.hoTen}
                        onChange={(e) => setFormData({ ...formData, hoTen: e.target.value })}
                        placeholder="Nguyễn Văn A"
                        className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                        Số điện thoại <span className="text-[#00D4EE]">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.soDienThoai}
                        onChange={(e) => setFormData({ ...formData, soDienThoai: e.target.value })}
                        placeholder="0988 123 456"
                        className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                        Địa chỉ Email
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="example@gmail.com"
                        className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                        Chủ đề cần hỗ trợ
                      </label>
                      <select
                        value={formData.chuDe}
                        onChange={(e) => setFormData({ ...formData, chuDe: e.target.value })}
                        className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00D4EE]"
                      >
                        <option value="Tư vấn mua xe">Tư vấn mua xe & báo giá</option>
                        <option value="Đăng ký lái thử">Đăng ký lái thử trải nghiệm</option>
                        <option value="Gói vay trả góp 0%">Gói vay ngân hàng trả góp 0%</option>
                        <option value="Bảo dưỡng & sửa chữa">Bảo dưỡng & sửa chữa</option>
                        <option value="Khiếu nại & góp ý">Khiếu nại & góp ý dịch vụ</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#BAC9D6] mb-1.5">
                      Nội dung chi tiết
                    </label>
                    <textarea
                      rows={4}
                      value={formData.noiDung}
                      onChange={(e) => setFormData({ ...formData, noiDung: e.target.value })}
                      placeholder="Nhập thông tin dòng xe bạn quan tâm hoặc câu hỏi cần giải đáp..."
                      className="w-full bg-[#061625] border border-[#1A3E59] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#8198AA] focus:outline-none focus:border-[#00D4EE]"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-sm px-8 py-3.5 rounded-full shadow-[0_0_20px_rgba(0,212,238,0.45)] hover:shadow-[0_0_25px_rgba(0,212,238,0.7)] transition-all cursor-pointer"
                  >
                    <span>Gửi yêu cầu ngay</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
