import React, { useState } from 'react';
import { Calendar, User, ArrowRight, BookOpen, X } from 'lucide-react';
import tinTucData from '../data/tin-tuc.json';
import { NutQuayLai } from '../components/NutQuayLai';

export const TinTuc: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<typeof tinTucData[0] | null>(null);

  return (
    <div className="min-h-screen bg-[#06131F] py-8">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Navigation & Header */}
        <div className="space-y-4">
          <NutQuayLai to="/" label="Về Trang chủ" />
          <div className="border-b border-[#143249] pb-4">
            <span className="text-[#00D4EE] font-display font-extrabold text-xs tracking-[0.25em] uppercase block mb-1">
              TIN TỨC & SỰ KIỆN
            </span>
            <h1 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight">
              Thế Giới Ô Tô & <span className="text-[#00D4EE]">Kinh Nghiệm Lái</span>
            </h1>
            <p className="text-sm text-[#BAC9D6] mt-2 max-w-xl">
              Cập nhật đánh giá thực tế các dòng xe mới nhất, xu hướng công nghệ hỗ trợ lái thông minh và kinh nghiệm chăm sóc xe.
            </p>
          </div>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tinTucData.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#103046] via-[#091D2C] to-[#061522] border border-[#1E4865] hover:border-[#00D4EE] transition-all duration-300 transform hover:-translate-y-1.5 shadow-[0_10px_25px_rgba(0,0,0,0.5)] flex flex-col justify-between group cursor-pointer"
            >
              <div>
                {/* Article Image */}
                <div className="relative h-48 w-full bg-[#04101A] overflow-hidden flex items-center justify-center p-4">
                  <img
                    src={article.anh}
                    alt={article.tieuDe}
                    className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 bg-[#00D4EE] text-[#03131F] font-bold text-[10px] uppercase px-2.5 py-0.5 rounded-full shadow-[0_0_10px_rgba(0,212,238,0.5)]">
                    {article.theLoai}
                  </div>
                </div>

                {/* Article Content */}
                <div className="p-5 space-y-3">
                  <div className="flex items-center gap-4 text-xs text-[#8198AA]">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>{article.ngayDang}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-[#00D4EE]" />
                      <span>{article.tacGia}</span>
                    </div>
                  </div>

                  <h3 className="font-display font-bold text-base sm:text-lg text-white group-hover:text-[#00D4EE] transition-colors leading-snug line-clamp-2">
                    {article.tieuDe}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#8198AA] line-clamp-3 leading-relaxed">
                    {article.tomTat}
                  </p>
                </div>
              </div>

              {/* Bottom read button */}
              <div className="px-5 pb-5 pt-2 flex items-center justify-between text-xs font-semibold text-[#00D4EE]">
                <span>Đọc toàn bộ bài viết</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Article Detail Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-[#091F30] border border-[#00D4EE]/50 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-5 shadow-[0_20px_50px_rgba(0,0,0,0.8)]">
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-[#0C273C] text-white flex items-center justify-center hover:bg-[#00D4EE] hover:text-[#03131F] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <span className="inline-block px-3 py-1 rounded-full bg-[#00D4EE]/20 border border-[#00D4EE] text-[#00D4EE] text-xs font-bold uppercase">
              {selectedArticle.theLoai}
            </span>

            <h2 className="font-display font-black text-xl sm:text-2xl text-white leading-snug">
              {selectedArticle.tieuDe}
            </h2>

            <div className="flex items-center gap-4 text-xs text-[#8198AA] pb-3 border-b border-[#1A3F5B]">
              <span>Ngày đăng: {selectedArticle.ngayDang}</span>
              <span>Tác giả: {selectedArticle.tacGia}</span>
            </div>

            <div className="relative h-56 w-full bg-[#051422] rounded-xl overflow-hidden flex items-center justify-center p-4">
              <img
                src={selectedArticle.anh}
                alt={selectedArticle.tieuDe}
                className="max-h-full max-w-full object-contain"
              />
            </div>

            <p className="text-sm font-semibold text-[#00D4EE] italic">
              "{selectedArticle.tomTat}"
            </p>

            <div className="text-sm text-[#BAC9D6] leading-relaxed space-y-3">
              <p>{selectedArticle.noiDung}</p>
              <p>
                Tại AutoVela, mỗi chiếc xe bàn giao tới tay khách hàng đều trải qua quy trình kiểm tra gắt gao 24 bước kỹ thuật. Đội ngũ chuyên gia kỹ thuật của chúng tôi luôn sẵn sàng hỗ trợ bảo dưỡng, chẩn đoán điện tử và tư vấn nâng cấp phụ kiện chính hãng 24/7.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
