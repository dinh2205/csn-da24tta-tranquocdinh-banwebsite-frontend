import React, { useState } from 'react';
import { HeroXe } from '../sections/HeroXe';
import { DanhMucXe } from '../sections/DanhMucXe';
import { CongNgheXe } from '../sections/CongNgheXe';
import { XeNoiBat } from '../sections/XeNoiBat';
import { LoiIchDichVu } from '../sections/LoiIchDichVu';
import { HopVideo } from '../components/HopVideo';

export const TrangChu: React.FC = () => {
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  return (
    <main className="w-full">
      {/* 1. Automotive Hero Banner */}
      <HeroXe onOpenVideo={() => setIsVideoOpen(true)} />

      {/* 2. Vehicle Categories Navigation Strip */}
      <DanhMucXe />

      {/* 3. Dual Technology Feature Banners */}
      <CongNgheXe />

      {/* 4. Featured Cars Section */}
      <XeNoiBat />

      {/* 5. Horizontal Service Benefits Strip */}
      <LoiIchDichVu />

      {/* Video Showcase Modal */}
      <HopVideo isOpen={isVideoOpen} onClose={() => setIsVideoOpen(false)} />
    </main>
  );
};
