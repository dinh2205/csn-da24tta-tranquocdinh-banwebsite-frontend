import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export const CongNgheXe: React.FC = () => {
  return (
    <section className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Banner 1: An toàn trên mọi hành trình (Brake system) */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0C2A40] via-[#091D2C] to-[#05131E] border border-[#1C4661] p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-6 group hover:border-[#00D4EE]/70 transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
          
          {/* Diagonal Cyan Geometric Stripe in background */}
          <div 
            className="absolute left-[-20px] top-0 bottom-0 w-32 bg-gradient-to-b from-[#00D4EE]/30 to-[#078CD7]/10 opacity-70 pointer-events-none transform -skew-x-[25deg]"
          ></div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#00D4EE]/5 rounded-full blur-3xl pointer-events-none"></div>

          {/* Left: Brake Disc Image */}
          <div className="relative w-44 sm:w-52 h-44 sm:h-52 shrink-0 flex items-center justify-center select-none">
            <img
              src="/assets/brake-disc-blue.png"
              alt="Hệ thống phanh thể thao cao cấp AutoVela"
              className="w-full h-full object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.7)] group-hover:scale-105 group-hover:rotate-1 transition-transform duration-500"
            />
          </div>

          {/* Right: Editorial Text */}
          <div className="flex-1 space-y-3.5 z-10 text-center sm:text-left">
            <h3 className="font-display font-black italic text-2xl sm:text-3xl leading-[1.1] uppercase tracking-tight">
              <span className="block text-white">AN TOÀN</span>
              <span className="block text-white">TRÊN MỌI</span>
              <span className="block text-[#00D4EE]">HÀNH TRÌNH!</span>
            </h3>
            
            <p className="text-xs sm:text-sm text-[#BAC9D6] leading-relaxed line-clamp-3">
              Hệ thống phanh, lốp và các công nghệ hỗ trợ lái tiên tiến, mang đến sự an tâm tuyệt đối cho bạn và gia đình.
            </p>

            <div className="pt-2">
              <Link
                to="/dich-vu"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#00D4EE] bg-[#00D4EE]/10 hover:bg-[#00D4EE] text-[#00D4EE] hover:text-[#03131F] font-bold text-xs sm:text-sm transition-all duration-200 shadow-[0_0_12px_rgba(0,212,238,0.2)] hover:shadow-[0_0_20px_rgba(0,212,238,0.6)] cursor-pointer"
              >
                <span>Tìm hiểu công nghệ</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>

        {/* Banner 2: Động cơ bền bỉ, tiết kiệm (Engine) */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#0C2A40] via-[#091D2C] to-[#05131E] border border-[#1C4661] p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-6 group hover:border-[#00D4EE]/70 transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.5)]">
          
          {/* Diagonal Cyan Geometric Stripe in background */}
          <div 
            className="absolute left-[-20px] top-0 bottom-0 w-32 bg-gradient-to-b from-[#00D4EE]/30 to-[#078CD7]/10 opacity-70 pointer-events-none transform -skew-x-[25deg]"
          ></div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#078CD7]/5 rounded-full blur-3xl pointer-events-none"></div>

          {/* Left: Engine Image */}
          <div className="relative w-44 sm:w-52 h-44 sm:h-52 shrink-0 flex items-center justify-center select-none">
            <img
              src="/assets/blue-performance-engine.png"
              alt="Động cơ ô tô hiện đại AutoVela"
              className="w-full h-full object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.7)] group-hover:scale-105 group-hover:-rotate-1 transition-transform duration-500"
            />
          </div>

          {/* Right: Editorial Text */}
          <div className="flex-1 space-y-3.5 z-10 text-center sm:text-left">
            <h3 className="font-display font-black italic text-2xl sm:text-3xl leading-[1.1] uppercase tracking-tight">
              <span className="block text-white">ĐỘNG CƠ</span>
              <span className="block text-white">BỀN BỈ,</span>
              <span className="block text-[#00D4EE]">TIẾT KIỆM</span>
            </h3>
            
            <p className="text-xs sm:text-sm text-[#BAC9D6] leading-relaxed line-clamp-3">
              Hiệu suất mạnh mẽ, vận hành êm ái và tối ưu nhiên liệu. Trải nghiệm cảm giác bứt tốc đỉnh cao.
            </p>

            <div className="pt-2">
              <Link
                to="/dich-vu"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#00D4EE] bg-[#00D4EE]/10 hover:bg-[#00D4EE] text-[#00D4EE] hover:text-[#03131F] font-bold text-xs sm:text-sm transition-all duration-200 shadow-[0_0_12px_rgba(0,212,238,0.2)] hover:shadow-[0_0_20px_rgba(0,212,238,0.6)] cursor-pointer"
              >
                <span>Xem chi tiết</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
