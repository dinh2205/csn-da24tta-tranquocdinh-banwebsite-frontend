import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, Truck, Zap, Settings, Shield } from 'lucide-react';

interface CategoryItem {
  id: string;
  name: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  queryValue: string;
}

const CATEGORIES: CategoryItem[] = [
  {
    id: 'passenger',
    name: 'Xe du lịch',
    desc: 'Đa dạng mẫu mã',
    icon: Car,
    queryValue: 'Xe du lịch'
  },
  {
    id: 'pickup',
    name: 'Xe bán tải',
    desc: 'Mạnh mẽ, linh hoạt',
    icon: Truck,
    queryValue: 'Xe bán tải'
  },
  {
    id: 'suv',
    name: 'SUV / Crossover',
    desc: 'Không gian rộng rãi',
    icon: Shield,
    queryValue: 'SUV / Crossover'
  },
  {
    id: 'electric',
    name: 'Xe điện',
    desc: 'Thân thiện môi trường',
    icon: Zap,
    queryValue: 'Xe điện'
  },
  {
    id: 'accessories',
    name: 'Phụ kiện',
    desc: 'Chính hãng',
    icon: Settings,
    queryValue: 'Phụ kiện'
  }
];

interface DanhMucXeProps {
  activeCategory?: string;
  onSelectCategory?: (category: string) => void;
}

export const DanhMucXe: React.FC<DanhMucXeProps> = ({ 
  activeCategory = 'passenger',
  onSelectCategory 
}) => {
  const [selected, setSelected] = useState<string>(activeCategory);
  const navigate = useNavigate();

  const handleSelect = (cat: CategoryItem) => {
    setSelected(cat.id);
    if (onSelectCategory) {
      onSelectCategory(cat.queryValue);
    } else {
      navigate(`/san-pham?loai=${encodeURIComponent(cat.queryValue)}`);
    }
  };

  return (
    <section className="relative z-20 max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 -mt-6 sm:-mt-8">
      <div className="bg-[#0A2032] border border-[#28536E] rounded-2xl p-2 sm:p-2.5 shadow-[0_15px_35px_rgba(0,0,0,0.5)]">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {CATEGORIES.map((cat) => {
            const isActive = selected === cat.id;
            const Icon = cat.icon;

            return (
              <button
                key={cat.id}
                onClick={() => handleSelect(cat)}
                className={`flex items-center gap-3.5 px-4 py-3.5 rounded-xl transition-all duration-200 text-left cursor-pointer group ${
                  isActive
                    ? 'bg-gradient-to-r from-[#00E0EF] to-[#09B8E5] text-[#03131F] shadow-[0_0_20px_rgba(0,224,239,0.45)]'
                    : 'bg-[#081827]/40 hover:bg-[#102D42] text-[#BAC9D6] hover:text-white border border-transparent hover:border-[#1E4A68]'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                    isActive
                      ? 'bg-[#03131F]/15 text-[#03131F]'
                      : 'bg-[#0E293F] text-[#00D4EE] group-hover:bg-[#163D5C]'
                  }`}
                >
                  <Icon className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div className="min-w-0">
                  <div
                    className={`font-display font-bold text-sm tracking-tight truncate ${
                      isActive ? 'text-[#03131F]' : 'text-white'
                    }`}
                  >
                    {cat.name}
                  </div>
                  <div
                    className={`text-xs truncate ${
                      isActive ? 'text-[#042A3D] font-medium' : 'text-[#8198AA]'
                    }`}
                  >
                    {cat.desc}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
