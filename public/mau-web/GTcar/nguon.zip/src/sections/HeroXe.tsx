import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play, Car, ShieldCheck, Wrench } from 'lucide-react';

interface HeroXeProps {
  onOpenVideo?: () => void;
}

export const HeroXe: React.FC<HeroXeProps> = ({ onOpenVideo }) => {
  return (
    <section className="relative w-full overflow-hidden bg-gradient-to-r from-[#06131F] via-[#0B2537] to-[#04101C] pt-6 pb-12 lg:py-14 border-b border-[#122A3C]/40">
      
      {/* Background Watermark Faded Text "VELA" */}
      <div className="absolute left-2 lg:left-6 top-0 bottom-0 flex flex-col justify-center select-none pointer-events-none opacity-[0.06] font-display font-black italic text-8xl sm:text-9xl lg:text-[190px] leading-none text-white tracking-tighter z-0">
        <div>VELA</div>
        <div>VELA</div>
        <div>VELA</div>
      </div>

      {/* Cyan Light Trails & Arcs in Background */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#00D4EE]/10 rounded-full blur-[140px] pointer-events-none z-0"></div>
      <div className="absolute bottom-0 right-10 w-[450px] h-[250px] bg-[#078CD7]/15 rounded-full blur-[100px] pointer-events-none z-0"></div>

      {/* Ambient Curved Neon Curves */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none z-0 opacity-40"
        viewBox="0 0 1440 600"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M-50 450 C 350 550, 750 300, 1400 480"
          stroke="#00D4EE"
          strokeWidth="1.5"
          strokeDasharray="4 6"
          opacity="0.3"
        />
        <path
          d="M-20 490 C 400 620, 850 360, 1500 520"
          stroke="#078CD7"
          strokeWidth="2"
          opacity="0.5"
        />
        <path
          d="M600 -50 C 800 150, 1100 250, 1500 200"
          stroke="#00D4EE"
          strokeWidth="1"
          opacity="0.25"
        />
      </svg>

      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-4 items-center min-h-[460px] lg:min-h-[510px]">
          
          {/* Left Column: Typography & CTAs (approx 45% width) */}
          <div className="lg:col-span-5 space-y-6 z-20">
            {/* Eyebrow */}
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00D4EE] shadow-[0_0_8px_#00D4EE]"></span>
              <span className="text-[#00D4EE] font-display font-extrabold text-xs sm:text-sm tracking-[0.25em] uppercase">
                AUTO VELA
              </span>
            </div>

            {/* Main Headline: Bold Italic 3-line */}
            <h1 className="font-display font-black italic tracking-tight text-4xl sm:text-5xl lg:text-[58px] xl:text-[64px] leading-[1.05] uppercase">
              <span className="block text-white">NÂNG TẦM</span>
              <span className="block text-white">TRẢI NGHIỆM</span>
              <span className="block text-[#00D4EE] drop-shadow-[0_0_20px_rgba(0,212,238,0.45)]">
                LÁI XE
              </span>
            </h1>

            {/* Description */}
            <p className="text-sm sm:text-base text-[#BAC9D6] leading-relaxed max-w-lg font-normal">
              Khám phá các dòng xe hiện đại, an toàn và tiết kiệm nhiên liệu. Cùng AutoVela tìm chiếc xe phù hợp nhất với phong cách sống của bạn.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <Link
                to="/san-pham"
                className="inline-flex items-center gap-2 bg-[#00D4EE] hover:bg-[#38E8FF] text-[#03131F] font-bold text-sm sm:text-base px-6 py-3 rounded-full shadow-[0_0_20px_rgba(0,212,238,0.5)] hover:shadow-[0_0_30px_rgba(0,212,238,0.8)] transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Khám phá ngay</span>
                <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
              </Link>

              <button
                onClick={onOpenVideo}
                className="inline-flex items-center gap-2.5 bg-[#0A2234]/60 hover:bg-[#11324B] text-white border border-[#2A5570] hover:border-[#00D4EE] font-semibold text-sm sm:text-base px-6 py-3 rounded-full backdrop-blur-sm transition-all duration-200 group"
              >
                <div className="w-6 h-6 rounded-full border border-white/60 group-hover:border-[#00D4EE] flex items-center justify-center transition-colors">
                  <Play className="w-3 h-3 fill-current text-white group-hover:text-[#00D4EE] ml-0.5" />
                </div>
                <span>Xem video</span>
              </button>
            </div>
          </div>

          {/* Right Column: Hero Vehicle + Diagonal Cyan Panel + Floating Stats Panel */}
          <div className="lg:col-span-7 relative flex items-center justify-center lg:justify-end">
            
            {/* Diagonal Blue Geometric Panel behind the car */}
            <div 
              className="absolute right-0 top-[-30px] bottom-[-20px] w-[85%] lg:w-[92%] h-[115%] bg-gradient-to-br from-[#00D4EE] via-[#078CD7] to-[#044778] opacity-85 z-0 transform"
              style={{
                clipPath: 'polygon(30% 0%, 100% 0%, 75% 100%, 0% 100%)',
                filter: 'drop-shadow(0 0 40px rgba(0, 212, 238, 0.3))'
              }}
            >
              {/* Inner ambient glow line */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-white/20"></div>
            </div>

            {/* Glowing headlight beam effect on the left of vehicle */}
            <div className="absolute left-[8%] top-[40%] w-48 h-24 bg-gradient-to-r from-transparent via-[#00D4EE]/35 to-transparent blur-xl pointer-events-none z-10"></div>

            {/* Vehicle Image */}
            <div className="relative z-10 w-full max-w-[620px] lg:max-w-[680px] select-none group">
              <img
                src="/assets/hero-blue-suv.png"
                alt="AutoVela Hero SUV"
                className="w-full h-auto object-contain drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)] filter contrast-[1.03] transform group-hover:scale-[1.01] transition-transform duration-500"
              />
              {/* Floor reflective gradient */}
              <div className="absolute -bottom-4 left-6 right-6 h-10 bg-gradient-to-b from-[#00D4EE]/25 to-transparent blur-md -z-10 rounded-full"></div>
            </div>

            {/* Floating Info Stats Panel (Right Side, exactly as in screenshot) */}
            <div className="relative lg:absolute lg:right-[-12px] xl:right-[-20px] lg:top-1/2 lg:-translate-y-1/2 z-20 mt-4 lg:mt-0 w-full max-w-[210px] sm:max-w-[230px] bg-[#041321]/90 backdrop-blur-md border border-[#0ED9ED]/70 rounded-2xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.7),0_0_20px_rgba(14,217,237,0.25)]">
              <div className="space-y-3.5">
                
                {/* Stat 1 */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#09283F] border border-[#00D4EE]/40 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,212,238,0.2)]">
                    <Car className="w-5 h-5 text-[#00D4EE]" />
                  </div>
                  <div>
                    <div className="font-display font-black text-xl text-white leading-tight">50+</div>
                    <div className="text-xs text-[#8198AA]">Dòng xe</div>
                  </div>
                </div>

                <div className="h-[1px] bg-[#163850]/70"></div>

                {/* Stat 2 */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#09283F] border border-[#00D4EE]/40 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,212,238,0.2)]">
                    <ShieldCheck className="w-5 h-5 text-[#00D4EE]" />
                  </div>
                  <div>
                    <div className="font-display font-black text-xl text-white leading-tight">100%</div>
                    <div className="text-xs text-[#8198AA]">Chính hãng</div>
                  </div>
                </div>

                <div className="h-[1px] bg-[#163850]/70"></div>

                {/* Stat 3 */}
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#09283F] border border-[#00D4EE]/40 flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,212,238,0.2)]">
                    <Wrench className="w-5 h-5 text-[#00D4EE]" />
                  </div>
                  <div>
                    <div className="font-display font-bold text-base text-white leading-tight">Bảo hành</div>
                    <div className="text-xs text-[#8198AA]">lên đến 5 năm</div>
                  </div>
                </div>

              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
