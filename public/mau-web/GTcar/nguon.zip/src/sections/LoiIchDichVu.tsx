import React from 'react';
import { Tag, ShieldCheck, Wrench, Headset } from 'lucide-react';
import { Link } from 'react-router-dom';

export const LoiIchDichVu: React.FC = () => {
  const benefits = [
    {
      icon: Tag,
      title: 'Giá cạnh tranh',
      desc: 'Ưu đãi hấp dẫn mỗi tháng',
      link: '/san-pham'
    },
    {
      icon: ShieldCheck,
      title: 'Hỗ trợ trả góp',
      desc: 'Lãi suất chỉ từ 0%',
      link: '/dich-vu'
    },
    {
      icon: Wrench,
      title: 'Bảo dưỡng định kỳ',
      desc: 'Dịch vụ chuyên nghiệp',
      link: '/dich-vu'
    },
    {
      icon: Headset,
      title: 'Tư vấn 24/7',
      desc: 'Luôn sẵn sàng hỗ trợ',
      link: '/lien-he'
    }
  ];

  return (
    <section className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 pb-14 pt-4">
      <div className="bg-[#0B2031] border border-[#2B5971] rounded-2xl p-4 sm:p-6 shadow-[0_10px_30px_rgba(0,0,0,0.4)]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 divide-y sm:divide-y-0 sm:divide-x divide-[#224A63]">
          {benefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <Link
                key={idx}
                to={item.link}
                className={`flex items-center gap-4 py-2 sm:py-0 ${
                  idx > 0 ? 'sm:pl-6' : ''
                } group hover:opacity-90 transition-opacity`}
              >
                <div className="w-12 h-12 rounded-xl bg-[#071927] border border-[#00D4EE]/40 flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(0,212,238,0.25)] group-hover:border-[#00D4EE] transition-colors">
                  <Icon className="w-6 h-6 text-[#00D4EE] group-hover:scale-110 transition-transform" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-white group-hover:text-[#00D4EE] transition-colors leading-snug">
                    {item.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-[#8198AA] mt-0.5">
                    {item.desc}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};
