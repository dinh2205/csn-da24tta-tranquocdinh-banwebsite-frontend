import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import xeData from '../data/xe.json';

export const XeNoiBat: React.FC = () => {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);

  // Take the 4 featured cars as shown in reference
  const featuredCars = xeData.filter(x => x.noiBat);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? featuredCars.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === featuredCars.length - 1 ? 0 : prev + 1));
  };

  return (
    <section className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-[#00D4EE] font-display font-extrabold text-xs sm:text-sm tracking-[0.2em] uppercase block mb-1.5">
            SẢN PHẨM NỔI BẬT
          </span>
          <h2 className="font-display font-black text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight">
            Các dòng xe được <span className="text-[#00D4EE]">ưa chuộng</span>
          </h2>
        </div>

        <Link
          to="/san-pham"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#285877] hover:border-[#00D4EE] bg-[#0A2234]/40 hover:bg-[#123652] text-[#BAC9D6] hover:text-[#00D4EE] text-xs sm:text-sm font-semibold transition-all duration-200 self-start sm:self-auto group"
        >
          <span>Xem tất cả sản phẩm</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>

      {/* Carousel Container */}
      <div className="relative">
        
        {/* Navigation Arrows (outer sides) */}
        <button
          onClick={handlePrev}
          className="hidden lg:flex absolute -left-5 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full border border-[#234A64] bg-[#081B2B]/90 hover:bg-[#00D4EE] hover:border-[#00D4EE] text-[#BAC9D6] hover:text-[#03131F] items-center justify-center transition-all duration-200 shadow-lg cursor-pointer"
          aria-label="Previous"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          onClick={handleNext}
          className="hidden lg:flex absolute -right-5 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full border border-[#234A64] bg-[#081B2B]/90 hover:bg-[#00D4EE] hover:border-[#00D4EE] text-[#BAC9D6] hover:text-[#03131F] items-center justify-center transition-all duration-200 shadow-lg cursor-pointer"
          aria-label="Next"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* 4 Cards Grid (matching screenshot) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
          {featuredCars.map((car, index) => (
            <div
              key={car.id}
              onClick={() => navigate(`/san-pham/${car.slug}`)}
              className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#133248] via-[#0A1F30] to-[#061522] border border-[#244E6B] p-4 group hover:border-[#00D4EE] transition-all duration-300 transform hover:-translate-y-1 cursor-pointer shadow-[0_10px_25px_rgba(0,0,0,0.4)]"
            >
              {/* Cyan Accent Ribbon in Top Left */}
              <div 
                className="absolute top-0 left-0 w-20 h-12 bg-gradient-to-br from-[#00D4EE] to-[#078CD7] opacity-80 pointer-events-none"
                style={{
                  clipPath: 'polygon(0 0, 100% 0, 45% 100%, 0 100%)'
                }}
              ></div>

              {/* Category Tag Top Right */}
              <div className="flex justify-end mb-2 relative z-10">
                <span className="text-[11px] font-semibold text-[#8198AA] bg-[#061523]/80 px-2 py-0.5 rounded border border-[#16354B]">
                  {car.kieuDang}
                </span>
              </div>

              {/* Car Image with reflection */}
              <div className="relative h-36 sm:h-40 w-full flex items-center justify-center select-none overflow-hidden my-1">
                <img
                  src={car.anh}
                  alt={car.ten}
                  className="max-h-full w-auto object-contain drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] group-hover:scale-105 transition-transform duration-300"
                />
                {/* Floor glow reflection */}
                <div className="absolute -bottom-2 w-3/4 h-3 bg-[#00D4EE]/15 blur-sm rounded-full pointer-events-none"></div>
              </div>

              {/* Bottom Info: Car Name, Price, and Circular Arrow Button */}
              <div className="mt-4 pt-3 border-t border-[#1C3E56]/60 flex items-end justify-between">
                <div>
                  <h4 className="font-display font-bold text-base text-white group-hover:text-[#00D4EE] transition-colors leading-tight truncate">
                    {car.ten}
                  </h4>
                  <div className="font-display font-bold text-sm text-[#F7FAFF] mt-1">
                    {car.giaHienThi}
                  </div>
                </div>

                {/* Circular Cyan Arrow Button */}
                <div className="w-8 h-8 rounded-full bg-[#00D4EE] text-[#03131F] flex items-center justify-center shadow-[0_0_12px_rgba(0,212,238,0.5)] group-hover:bg-[#38E8FF] group-hover:scale-110 transition-all shrink-0 ml-2">
                  <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Carousel Pagination Dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {featuredCars.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => setCurrentIndex(dotIdx)}
              className={`transition-all duration-300 rounded-full h-1.5 ${
                currentIndex === dotIdx
                  ? 'w-6 bg-[#00D4EE] shadow-[0_0_8px_#00D4EE]'
                  : 'w-1.5 bg-[#234A64] hover:bg-[#356687]'
              }`}
              aria-label={`Slide ${dotIdx + 1}`}
            />
          ))}
        </div>

      </div>
    </section>
  );
};
