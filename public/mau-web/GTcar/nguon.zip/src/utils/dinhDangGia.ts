export function dinhDangGia(gia: number): string {
  return new Intl.NumberFormat('vi-VN').format(gia) + ' đ';
}
