export interface LichHen {
  id: string;
  maXe: string;
  tenXe: string;
  hoTen: string;
  soDienThoai: string;
  email: string;
  ngayHen: string;
  gioHen: string;
  showroom: string;
  ghiChu?: string;
  thoiGianTao: string;
}

const STORAGE_KEY = 'autovela_bookings';

export function layDanhSachLichHen(): LichHen[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Lỗi khi đọc lịch hẹn từ localStorage', error);
    return [];
  }
}

export function luuLichHen(lich: Omit<LichHen, 'id' | 'thoiGianTao'>): LichHen {
  const danhSach = layDanhSachLichHen();
  const lichMoi: LichHen = {
    ...lich,
    id: 'AV-' + Date.now().toString(36).toUpperCase(),
    thoiGianTao: new Date().toISOString()
  };
  
  danhSach.unshift(lichMoi);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(danhSach));
  return lichMoi;
}
