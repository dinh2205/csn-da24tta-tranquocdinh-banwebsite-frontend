import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ActivityFilmstrip } from './components/ActivityFilmstrip';
import { CoursesSection } from './components/CoursesSection';
import { BenefitsSection } from './components/BenefitsSection';
import { LearningRoadmap } from './components/LearningRoadmap';
import { TeachersSection } from './components/TeachersSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { RegistrationSection } from './components/RegistrationSection';
import { Course } from './data/landingData';

export default function App() {
  const [prefillLevel, setPrefillLevel] = useState<string>('');
  const [prefillTarget, setPrefillTarget] = useState<string>('');

  const scrollToRegistration = () => {
    const el = document.getElementById('registration');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCourse = (course: Course) => {
    setPrefillLevel(course.levelSelectValue);
    setPrefillTarget(course.targetSelectValue);
    scrollToRegistration();
  };

  return (
    <div className="min-h-screen bg-[#F7FFF5] flex flex-col font-sans selection:bg-[#16A83C] selection:text-white">
      {/* 1. Sticky Navigation Header */}
      <Header onRegisterClick={scrollToRegistration} />

      {/* Main Landing Page Stream */}
      <main className="flex-1">
        {/* 2. Hero Banner */}
        <HeroSection onRegisterClick={scrollToRegistration} />

        {/* 3. Hoạt động học viên (Activity Filmstrip) */}
        <ActivityFilmstrip />

        {/* 4. Khóa học IELTS nổi bật */}
        <CoursesSection onSelectCourse={handleSelectCourse} />

        {/* 5. Vì sao chọn EduRise */}
        <BenefitsSection />

        {/* 6. Lộ trình học tập */}
        <LearningRoadmap />

        {/* 7. Đội ngũ giảng viên */}
        <TeachersSection />

        {/* 8. Đánh giá học viên (Testimonials) */}
        <TestimonialsSection />

        {/* 9. Đăng ký tư vấn */}
        <RegistrationSection
          prefillLevel={prefillLevel}
          prefillTarget={prefillTarget}
        />
      </main>
    </div>
  );
}
