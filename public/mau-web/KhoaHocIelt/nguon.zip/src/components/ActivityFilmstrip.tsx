import React, { useState } from 'react';
import { ACTIVITIES } from '../data/landingData';
import { CameraSticker, SparkleStar } from './DoodleDecorations';
import { X, ZoomIn } from 'lucide-react';

export const ActivityFilmstrip: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<{ src: string; alt: string; caption: string } | null>(null);

  return (
    <section id="activities" className="relative py-7 overflow-hidden bg-[#9EEA76]">
      {/* Decorative stars */}
      <div className="absolute top-2 right-12 pointer-events-none hidden md:block">
        <SparkleStar className="w-5 h-5 text-white" />
      </div>

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 relative">
        
        {/* Filmstrip Frame - Angled and with Sprocket Perforations */}
        <div className="relative transform rotate-1 transition-transform duration-300">
          
          {/* Camera Doodle on the Left Edge */}
          <div className="absolute -top-6 -left-2 sm:-left-4 z-20 animate-float pointer-events-none">
            <CameraSticker className="w-14 h-14 sm:w-16 sm:h-16 -rotate-12" />
          </div>

          {/* Filmstrip Container */}
          <div className="relative bg-[#D4F7C3] border-3 border-[#2E9C34] rounded-2xl p-3 sm:p-4 shadow-xl shadow-emerald-950/15 overflow-hidden">
            
            {/* Top Film Reel Perforation Holes */}
            <div className="flex items-center justify-between gap-3 mb-2 px-1 overflow-hidden select-none">
              {Array.from({ length: 32 }).map((_, i) => (
                <div
                  key={i}
                  className="w-3.5 h-3 sm:w-4 sm:h-3.5 rounded-xs bg-[#2E9C34] shrink-0 opacity-80"
                />
              ))}
            </div>

            {/* Photos Strip - Horizontal Scroll on small screens, Grid on large screens */}
            <div className="flex items-center gap-3 sm:gap-4 overflow-x-auto pb-1 scrollbar-none snap-x">
              {ACTIVITIES.map((activity, idx) => (
                <div
                  key={idx}
                  onClick={() => setSelectedPhoto(activity)}
                  className="relative group shrink-0 w-[240px] sm:w-[260px] md:w-[280px] lg:flex-1 h-[155px] sm:h-[175px] rounded-xl overflow-hidden bg-white border-2 border-[#36B53E] cursor-pointer shadow-sm hover:shadow-md transition-all duration-300 hover:scale-[1.02] snap-center"
                >
                  <img
                    src={activity.src}
                    alt={activity.alt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
                  />

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-emerald-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                    <span className="p-2 rounded-full bg-white/90 text-emerald-800 shadow-md transform scale-90 group-hover:scale-100 transition-transform">
                      <ZoomIn className="w-5 h-5" />
                    </span>
                  </div>

                  {/* Minimal Sub-tag */}
                  <div className="absolute bottom-1.5 left-1.5 right-1.5 bg-black/60 backdrop-blur-xs text-white text-[11px] font-medium px-2 py-0.5 rounded truncate">
                    {activity.alt}
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Film Reel Perforation Holes */}
            <div className="flex items-center justify-between gap-3 mt-2 px-1 overflow-hidden select-none">
              {Array.from({ length: 32 }).map((_, i) => (
                <div
                  key={i}
                  className="w-3.5 h-3 sm:w-4 sm:h-3.5 rounded-xs bg-[#2E9C34] shrink-0 opacity-80"
                />
              ))}
            </div>

          </div>

        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedPhoto(null)}
        >
          <div
            className="relative max-w-3xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl p-4 animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-black transition-colors z-10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="rounded-xl overflow-hidden max-h-[70vh] bg-slate-100">
              <img
                src={selectedPhoto.src}
                alt={selectedPhoto.alt}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain mx-auto"
              />
            </div>
            <div className="mt-4 px-2">
              <h4 className="font-display font-bold text-lg text-[#18362A]">{selectedPhoto.alt}</h4>
              <p className="text-sm text-slate-600 mt-1">{selectedPhoto.caption}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
