import React from 'react';
import { Target, Users, BookOpen, BarChart3, Gem } from 'lucide-react';
import { BENEFITS } from '../data/landingData';
import { PencilDoodle, SparkleStar } from './DoodleDecorations';

export const BenefitsSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'target':
        return <Target className="w-6 h-6" />;
      case 'users':
        return <Users className="w-6 h-6" />;
      case 'book-open':
        return <BookOpen className="w-6 h-6" />;
      case 'chart':
        return <BarChart3 className="w-6 h-6" />;
      case 'gem':
        return <Gem className="w-6 h-6" />;
      default:
        return <Target className="w-6 h-6" />;
    }
  };

  return (
    <section id="why-us" className="relative py-14 md:py-20 bg-[#EBFFE3] overflow-hidden">
      {/* Background doodles */}
      <div className="absolute top-8 left-12 animate-float pointer-events-none hidden md:block">
        <SparkleStar className="w-6 h-6 text-[#16A83C]" />
      </div>
      <div className="absolute bottom-6 right-10 animate-float-reverse pointer-events-none hidden md:block">
        <span className="text-2xl">🌱</span>
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center justify-center gap-2 mb-2">
            <PencilDoodle className="w-6 h-6 -rotate-12" />
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#075827] tracking-tight uppercase">
              VÌ SAO CHỌN EDURISE?
            </h2>
            <span className="text-xl">✍️</span>
          </div>
          <p className="text-sm sm:text-base text-[#18362A] font-medium mt-1">
            Không chỉ là một khóa học, mà là người bạn đồng hành trên hành trình chinh phục IELTS!
          </p>
        </div>

        {/* 5 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
          {BENEFITS.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-6 text-center shadow-md shadow-emerald-950/5 border border-emerald-100/80 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-emerald-950/10 transition-all duration-300 flex flex-col items-center group"
            >
              {/* Icon Circle */}
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center mb-4 transition-transform duration-300 group-hover:scale-110 shadow-xs"
                style={{
                  backgroundColor: item.background,
                  color: item.color,
                }}
              >
                {getIcon(item.icon)}
              </div>

              {/* Title */}
              <h3 className="font-display font-bold text-base sm:text-lg text-[#18362A] mb-2 leading-snug">
                {item.title}
              </h3>

              {/* Description */}
              <p className="text-xs sm:text-[13px] text-slate-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
