import React, { useState } from 'react';
import { ArrowRight, Target, Calendar, Clock, Sparkles } from 'lucide-react';
import { COURSES, Course } from '../data/landingData';
import {
  PencilDoodle,
  WashiTape,
  CrownSticker,
  TrophySticker,
  StarSticker,
} from './DoodleDecorations';

interface CoursesSectionProps {
  onSelectCourse: (course: Course) => void;
}

export const CoursesSection: React.FC<CoursesSectionProps> = ({ onSelectCourse }) => {
  const [showAllModal, setShowAllModal] = useState(false);

  return (
    <section
      id="courses"
      className="relative py-14 md:py-20 overflow-hidden"
      style={{
        background: 'linear-gradient(180deg, #B2F18B 0%, #D8FFC4 50%, #EEFFE8 100%)',
      }}
    >
      {/* Decorative stars */}
      <div className="absolute top-10 left-8 pointer-events-none animate-float hidden md:block">
        <StarSticker className="w-7 h-7" />
      </div>
      <div className="absolute top-24 right-10 pointer-events-none animate-float-reverse hidden md:block">
        <CrownSticker className="w-9 h-9" />
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 md:mb-12">
          <div>
            <div className="inline-flex items-center gap-2 mb-2">
              <PencilDoodle className="w-7 h-7" />
              <h2 className="font-display font-extrabold text-2xl sm:text-3xl md:text-4xl tracking-tight">
                <span className="text-[#075827]">CÁC KHÓA HỌC </span>
                <span className="text-[#F66A11]">IELTS NỔI BẬT</span>
              </h2>
            </div>
            <p className="text-sm sm:text-base text-[#18362A] font-medium max-w-2xl">
              Lộ trình phù hợp cho mọi trình độ – Đồng hành cùng bạn đến band điểm mong muốn!
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowAllModal(true)}
            className="self-start md:self-auto inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-[#19883B] font-bold text-xs sm:text-sm shadow-xs border border-emerald-200 hover:border-emerald-400 transition-all cursor-pointer group"
          >
            <span>Xem tất cả khóa học</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 3 Course Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7 items-stretch">
          {COURSES.map((course) => {
            return (
              <div
                key={course.id}
                className="relative bg-white rounded-3xl p-6 sm:p-7 shadow-xl shadow-emerald-950/10 border-2 border-emerald-100 flex flex-col justify-between hover:-translate-y-2 transition-all duration-300 group"
              >
                {/* Washi Tape Strip at top */}
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20">
                  <WashiTape
                    color={
                      course.id === 'ielts-foundation'
                        ? 'mint'
                        : course.id === 'ielts-builder'
                        ? 'pink'
                        : 'yellow'
                    }
                  />
                </div>

                {/* Top Badge: "Dành cho..." */}
                <div className="mt-2 text-center">
                  <span
                    className="inline-block px-4 py-1.5 rounded-full text-white text-xs sm:text-[13px] font-bold tracking-wide shadow-xs"
                    style={{ backgroundColor: course.badgeBg }}
                  >
                    {course.badgeText}
                  </span>
                </div>

                {/* Course Title & Description */}
                <div className="mt-4">
                  <h3
                    className="font-display font-extrabold text-2xl sm:text-[26px] tracking-tight mb-2"
                    style={{ color: course.themeColor }}
                  >
                    {course.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed">
                    {course.description}
                  </p>
                </div>

                {/* Info Points */}
                <div className="mt-5 space-y-3 bg-[#F8FFF6] p-4 rounded-2xl border border-emerald-50">
                  {/* Target Band */}
                  <div className="flex items-start gap-2.5">
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-white"
                      style={{ backgroundColor: course.themeColor }}
                    >
                      <Target className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] uppercase font-bold text-slate-500 block">
                        Mục tiêu band
                      </span>
                      <span className="font-display font-extrabold text-base sm:text-lg text-[#18362A]">
                        {course.targetBand}
                      </span>
                    </div>
                  </div>

                  {/* Schedule */}
                  <div className="flex items-start gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] uppercase font-bold text-slate-500 block">
                        Lịch học
                      </span>
                      <span className="text-xs sm:text-[13px] font-bold text-[#18362A]">
                        {course.schedule}
                      </span>
                    </div>
                  </div>

                  {/* Start Date */}
                  <div className="flex items-start gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] uppercase font-bold text-slate-500 block">
                        Ngày khai giảng
                      </span>
                      <span className="font-bold text-xs sm:text-[13px] text-[#FF531F]">
                        {course.startDateDisplay}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom area: Action button + Student photo */}
                <div className="mt-6 flex items-end justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => onSelectCourse(course)}
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-full text-white font-display font-bold text-sm tracking-wide uppercase transition-all duration-200 cursor-pointer shadow-md shadow-orange-600/25 hover:shadow-lg hover:shadow-orange-600/40 hover:scale-105 active:scale-95 border-2 border-white"
                    style={{
                      background: 'linear-gradient(180deg, #FF9534 0%, #FF4315 100%)',
                    }}
                  >
                    <span>ĐĂNG KÝ NGAY</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  {/* Student Portrait Cutout */}
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 shrink-0 rounded-full overflow-hidden border-2 border-white shadow-md bg-white">
                    <img
                      src={course.image}
                      alt={course.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-top hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                </div>

                {/* Floating mini sticker corner */}
                {course.id === 'ielts-foundation' && (
                  <span className="absolute -bottom-2 -left-2 text-xl select-none animate-float">💡</span>
                )}
                {course.id === 'ielts-builder' && (
                  <span className="absolute -top-3 -right-2 text-xl select-none animate-float">👑</span>
                )}
                {course.id === 'ielts-performer' && (
                  <span className="absolute -top-3 -right-2 text-2xl select-none animate-float">🏆</span>
                )}
              </div>
            );
          })}
        </div>

      </div>

      {/* View All Courses Modal */}
      {showAllModal && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowAllModal(false)}
        >
          <div
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[85vh] overflow-y-auto shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#FF631C]" />
                <h3 className="font-display font-extrabold text-2xl text-[#075827]">
                  Toàn bộ chương trình IELTS tại EduRise
                </h3>
              </div>
              <button
                onClick={() => setShowAllModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="mt-5 space-y-4">
              {COURSES.map((c) => (
                <div
                  key={c.id}
                  className="p-4 rounded-2xl border border-emerald-100 bg-[#F9FFF8] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  <div>
                    <span
                      className="inline-block px-2.5 py-0.5 rounded-full text-white text-[11px] font-bold mb-1"
                      style={{ backgroundColor: c.badgeBg }}
                    >
                      {c.badgeText}
                    </span>
                    <h4 className="font-display font-bold text-lg text-[#18362A]">{c.name}</h4>
                    <p className="text-xs text-slate-600">{c.description}</p>
                    <div className="flex items-center gap-4 text-xs font-semibold text-emerald-800 mt-2">
                      <span>🎯 {c.targetBand}</span>
                      <span>📅 {c.schedule}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setShowAllModal(false);
                      onSelectCourse(c);
                    }}
                    className="shrink-0 px-4 py-2 rounded-full text-white text-xs font-bold bg-[#FF631C] hover:bg-[#e4510d] transition-colors"
                  >
                    Chọn khóa này
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
