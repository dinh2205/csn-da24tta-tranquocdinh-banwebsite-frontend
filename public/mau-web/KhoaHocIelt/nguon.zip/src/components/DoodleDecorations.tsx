import React from 'react';

// EduRise Brand Logo
export const EduRiseLogo: React.FC<{ className?: string }> = ({ className = 'h-11' }) => (
  <div className={`flex items-center gap-2.5 select-none ${className}`}>
    <div className="relative w-11 h-11 rounded-full bg-gradient-to-tr from-[#16A83C] to-[#48CA3B] flex items-center justify-center shadow-md shadow-green-600/20 shrink-0 border-2 border-white">
      <svg viewBox="0 0 40 40" className="w-7 h-7 fill-white" aria-hidden="true">
        {/* Stylized leaf & upward sprout */}
        <path d="M20 6C20 6 21 16 29 18C29 18 24 23 18 20C17.5 19.8 17 19.3 16.8 18.7C16 16.5 18 10 20 6Z" fill="#FFFFFF" />
        <path d="M19 12C19 12 14 15 12 21C12 21 17 24 21 21.5C21 19 20 14 19 12Z" fill="#D7FFBC" />
        <path d="M18 21C18 25 19 32 20 34" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
      {/* Mini sparkling star */}
      <span className="absolute -top-1 -right-1 text-xs">✨</span>
    </div>
    <div className="flex flex-col leading-none">
      <span className="font-display font-extrabold text-2xl tracking-tight text-[#075827]">
        EduRise
      </span>
      <span className="text-[10px] font-semibold text-[#16813A] tracking-wider uppercase">
        Rise Your English
      </span>
    </div>
  </div>
);

// Green Graduation Cap Sticker
export const GraduationCapSticker: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 100 100" className={`filter drop-shadow-md ${className}`} fill="none">
    {/* Cap diamond */}
    <polygon points="50,15 90,34 50,53 10,34" fill="#14983B" stroke="#075827" strokeWidth="3" strokeLinejoin="round" />
    <polygon points="50,22 80,36 50,50 20,36" fill="#24B34C" opacity="0.6" />
    {/* Cap skull cap under */}
    <path d="M30 44V64C30 72 70 72 70 64V44" fill="#0E782E" stroke="#075827" strokeWidth="3" />
    {/* Tassel button */}
    <circle cx="50" cy="34" r="4" fill="#FFD93D" stroke="#E5A800" strokeWidth="1.5" />
    {/* Tassel string & fringe */}
    <path d="M50 34C60 38 72 45 74 60" stroke="#FFD93D" strokeWidth="2.5" strokeLinecap="round" />
    <polygon points="71,60 77,60 75,76 69,76" fill="#FFD93D" stroke="#E5A800" strokeWidth="1" />
  </svg>
);

// Hand-drawn Paper Airplane
export const PaperAirplane: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <svg viewBox="0 0 100 100" className={`filter drop-shadow-sm ${className}`} fill="none">
    <path d="M12 48L88 16L54 86L40 58L12 48Z" fill="#FFFFFF" stroke="#0E782E" strokeWidth="3" strokeLinejoin="round" />
    <path d="M88 16L40 58V78L52 66" fill="#E8F8EA" stroke="#0E782E" strokeWidth="3" strokeLinejoin="round" />
  </svg>
);

// Yellow 5-point Star Sticker
export const StarSticker: React.FC<{ className?: string; size?: number }> = ({ className = 'w-7 h-7' }) => (
  <svg viewBox="0 0 40 40" className={`filter drop-shadow-sm ${className}`} fill="none">
    <polygon
      points="20,2 25,14 38,15 28,24 31,37 20,30 9,37 12,24 2,15 15,14"
      fill="#FFD93D"
      stroke="#14532D"
      strokeWidth="2"
      strokeLinejoin="round"
    />
  </svg>
);

// 4-point Sparkle Star
export const SparkleStar: React.FC<{ className?: string; color?: string }> = ({
  className = 'w-6 h-6',
  color = '#22C55E',
}) => (
  <svg viewBox="0 0 32 32" className={className} fill="none">
    <path
      d="M16 2C16 10 22 16 30 16C22 16 16 22 16 30C16 22 10 16 2 16C10 16 16 10 16 2Z"
      fill={color}
    />
  </svg>
);

// Hand-drawn Pencil Doodle
export const PencilDoodle: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 50 50" className={className} fill="none">
    <rect x="18" y="8" width="12" height="30" rx="2" transform="rotate(-35 18 8)" fill="#FFD93D" stroke="#075827" strokeWidth="2.5" />
    <polygon points="12,42 16,34 23,38" fill="#FFB020" stroke="#075827" strokeWidth="2" strokeLinejoin="round" />
    <polygon points="12,42 14,39 16,41" fill="#075827" />
    <rect x="27" y="3" width="12" height="6" rx="2" transform="rotate(-35 27 3)" fill="#FF6B8B" stroke="#075827" strokeWidth="2" />
  </svg>
);

// Doodle Camera
export const CameraSticker: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <svg viewBox="0 0 80 70" className={`filter drop-shadow-md ${className}`} fill="none">
    <rect x="8" y="18" width="64" height="46" rx="10" fill="#FFFFFF" stroke="#0E782E" strokeWidth="3" />
    <rect x="26" y="8" width="28" height="12" rx="4" fill="#36B53E" stroke="#0E782E" strokeWidth="2.5" />
    <circle cx="40" cy="41" r="16" fill="#E8F8EA" stroke="#0E782E" strokeWidth="3" />
    <circle cx="40" cy="41" r="10" fill="#24B34C" />
    <circle cx="43" cy="38" r="3" fill="#FFFFFF" />
    <circle cx="58" cy="28" r="4" fill="#FF531F" />
  </svg>
);

// Doodle Trophy
export const TrophySticker: React.FC<{ className?: string }> = ({ className = 'w-14 h-14' }) => (
  <svg viewBox="0 0 80 80" className={`filter drop-shadow-md ${className}`} fill="none">
    <path d="M22 18H58V36C58 46 50 54 40 54C30 54 22 46 22 36V18Z" fill="#FFD93D" stroke="#075827" strokeWidth="3" />
    <path d="M22 24H12C12 36 22 38 22 38" stroke="#075827" strokeWidth="3" strokeLinecap="round" />
    <path d="M58 24H68C68 36 58 38 58 38" stroke="#075827" strokeWidth="3" strokeLinecap="round" />
    <path d="M40 54V64" stroke="#075827" strokeWidth="4" strokeLinecap="round" />
    <rect x="26" y="64" width="28" height="8" rx="3" fill="#FF6B25" stroke="#075827" strokeWidth="3" />
    <polygon points="40,26 43,33 50,34 45,39 46,46 40,42 34,46 35,39 30,34 37,33" fill="#FFFFFF" />
  </svg>
);

// Doodle Rocket
export const RocketSticker: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 100 100" className={`filter drop-shadow-md ${className}`} fill="none">
    {/* Body */}
    <path d="M50 10C35 25 32 55 35 70L65 70C68 55 65 25 50 10Z" fill="#FFFFFF" stroke="#075827" strokeWidth="3" />
    {/* Red tip */}
    <path d="M50 10C43 18 40 28 39 34H61C60 28 57 18 50 10Z" fill="#FF531F" />
    {/* Window */}
    <circle cx="50" cy="46" r="8" fill="#38BDF8" stroke="#075827" strokeWidth="2.5" />
    <circle cx="48" cy="44" r="3" fill="#FFFFFF" />
    {/* Left wing */}
    <path d="M35 55L18 68L34 70" fill="#FF6B25" stroke="#075827" strokeWidth="3" strokeLinejoin="round" />
    {/* Right wing */}
    <path d="M65 55L82 68L66 70" fill="#FF6B25" stroke="#075827" strokeWidth="3" strokeLinejoin="round" />
    {/* Flame */}
    <polygon points="42,70 50,92 58,70" fill="#FFD93D" stroke="#FF531F" strokeWidth="2" />
    <polygon points="45,70 50,84 55,70" fill="#FF531F" />
  </svg>
);

// Doodle Crown
export const CrownSticker: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => (
  <svg viewBox="0 0 60 50" className={className} fill="none">
    <polygon points="8,40 12,18 24,28 30,12 36,28 48,18 52,40" fill="#FFD93D" stroke="#075827" strokeWidth="2.5" strokeLinejoin="round" />
    <circle cx="12" cy="18" r="2.5" fill="#FF531F" />
    <circle cx="30" cy="12" r="2.5" fill="#38BDF8" />
    <circle cx="48" cy="18" r="2.5" fill="#FF531F" />
    <rect x="8" y="38" width="44" height="6" rx="2" fill="#FFB020" stroke="#075827" strokeWidth="2" />
  </svg>
);

// Washi Tape Overlay
export const WashiTape: React.FC<{ color?: 'yellow' | 'pink' | 'mint' | 'orange'; className?: string }> = ({
  color = 'yellow',
  className = '',
}) => {
  const bgStyles = {
    yellow: 'bg-yellow-200/85 border-yellow-300',
    pink: 'bg-pink-200/85 border-pink-300',
    mint: 'bg-emerald-200/85 border-emerald-300',
    orange: 'bg-amber-200/85 border-amber-300',
  }[color];

  return (
    <div
      className={`h-5 w-24 rounded-sm shadow-xs border-dashed border-t border-b pointer-events-none opacity-90 select-none ${bgStyles} ${className}`}
      style={{
        clipPath: 'polygon(3% 0%, 97% 0%, 100% 50%, 97% 100%, 3% 100%, 0% 50%)',
      }}
    />
  );
};
