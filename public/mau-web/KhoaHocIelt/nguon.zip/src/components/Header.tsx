import React, { useState, useEffect } from 'react';
import { CalendarCheck, Menu, X, ArrowRight } from 'lucide-react';
import { EduRiseLogo } from './DoodleDecorations';

interface HeaderProps {
  onRegisterClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onRegisterClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'courses', 'why-us', 'learning-roadmap', 'teachers', 'testimonials', 'registration'];
      const scrollPos = window.scrollY + 100;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Trang chủ', href: '#home', id: 'home' },
    { label: 'Giới thiệu', href: '#why-us', id: 'why-us' },
    { label: 'Khóa học', href: '#courses', id: 'courses' },
    { label: 'Lịch khai giảng', href: '#courses', id: 'courses' },
    { label: 'Học viên', href: '#testimonials', id: 'testimonials' },
    { label: 'Liên hệ', href: '#registration', id: 'registration' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCtaClick = () => {
    setMobileMenuOpen(false);
    if (onRegisterClick) {
      onRegisterClick();
    } else {
      const reg = document.getElementById('registration');
      reg?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-200 bg-white ${
        isScrolled ? 'shadow-md shadow-emerald-900/5 py-2.5' : 'py-3.5 border-b border-[#E7F6E4]'
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a href="#home" onClick={(e) => { e.preventDefault(); handleNavClick('#home'); }} className="shrink-0 group">
          <EduRiseLogo />
        </a>

        {/* Desktop Nav Items */}
        <nav className="hidden md:flex items-center gap-7 text-[15px] font-semibold text-[#18362A]">
          {navItems.map((item, idx) => {
            const isActive = activeSection === item.id;
            return (
              <a
                key={idx}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.href);
                }}
                className={`relative py-1 transition-colors hover:text-[#19883B] ${
                  isActive ? 'text-[#19883B] font-bold' : 'text-[#2D4536]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#19883B] rounded-full" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right CTA Button */}
        <div className="hidden sm:flex items-center gap-3">
          <button
            onClick={handleCtaClick}
            type="button"
            className="group inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-white text-[15px] font-bold bg-gradient-to-r from-[#16A83C] to-[#48CA3B] hover:from-[#138e33] hover:to-[#3fb733] shadow-md shadow-green-600/20 hover:shadow-lg hover:shadow-green-600/30 active:scale-95 transition-all cursor-pointer"
          >
            <CalendarCheck className="w-4 h-4 transition-transform group-hover:scale-110" />
            <span>Đăng ký học ngay</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="flex md:hidden items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#18362A] hover:bg-emerald-50 focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-emerald-100 bg-white px-5 pt-3 pb-6 shadow-xl space-y-3 animate-in slide-in-from-top duration-200">
          <div className="flex flex-col space-y-2">
            {navItems.map((item, idx) => (
              <a
                key={idx}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.href);
                }}
                className="py-2 px-3 rounded-lg text-base font-semibold text-[#18362A] hover:bg-[#EEFFE8] hover:text-[#19883B] transition-colors"
              >
                {item.label}
              </a>
            ))}
          </div>
          <div className="pt-2 border-t border-emerald-100">
            <button
              onClick={handleCtaClick}
              type="button"
              className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-full text-white font-bold bg-gradient-to-r from-[#16A83C] to-[#48CA3B] shadow-md"
            >
              <CalendarCheck className="w-5 h-5" />
              <span>Đăng ký học ngay</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
