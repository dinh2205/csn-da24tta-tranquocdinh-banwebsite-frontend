import React from 'react';
import { ArrowRight, MapPin, Award, ShieldCheck, Sparkles } from 'lucide-react';
import { IMAGES } from '../data/assets';
import {
  GraduationCapSticker,
  PaperAirplane,
  StarSticker,
  SparkleStar,
} from './DoodleDecorations';

interface HeroSectionProps {
  onRegisterClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onRegisterClick }) => {
  return (
    <section
      id="home"
      className="relative overflow-hidden pt-8 pb-14 md:pt-12 md:pb-20"
      style={{
        background: 'linear-gradient(115deg, #CBFFC1 0%, #9DF17E 48%, #76E472 100%)',
      }}
    >
      {/* Background Decorative Grid and Clouds */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `radial-gradient(#075827 1px, transparent 1px), radial-gradient(#075827 1px, transparent 1px)`,
          backgroundSize: '36px 36px',
          backgroundPosition: '0 0, 18px 18px',
        }}
      />

      {/* Floating White Clouds */}
      <div className="absolute top-6 left-10 w-28 h-12 bg-white/70 rounded-full blur-xs pointer-events-none" />
      <div className="absolute top-16 right-24 w-36 h-14 bg-white/60 rounded-full blur-xs pointer-events-none hidden md:block" />

      {/* Floating Sticker Stars */}
      <div className="absolute top-8 left-1/4 animate-float pointer-events-none">
        <StarSticker className="w-8 h-8 text-[#FFD93D]" />
      </div>
      <div className="absolute top-28 right-12 animate-float-reverse pointer-events-none hidden lg:block">
        <StarSticker className="w-6 h-6 text-[#FFD93D]" />
      </div>
      <div className="absolute bottom-12 left-8 animate-float pointer-events-none">
        <SparkleStar className="w-7 h-7 text-[#16813A]" />
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">
          
          {/* Left Column: Headline, handwritten sticker, badges, CTA */}
          <div className="lg:col-span-7 flex flex-col items-start z-10">
            
            {/* Handwritten Top Note */}
            <div className="relative inline-flex items-center gap-2 mb-2 ml-1">
              <span className="font-handwriting text-2xl md:text-[28px] font-bold text-[#143D24] -rotate-6 transform inline-block select-none tracking-wide">
                Hành trình IELTS bắt đầu từ hôm nay!
              </span>
              <Sparkles className="w-5 h-5 text-[#FF631C] animate-pulse" />
              {/* Little hand-drawn curved arrow indicator */}
              <svg className="w-6 h-6 text-[#075827] -rotate-12 transform hidden sm:inline-block" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <path d="M4 14C8 18 14 18 19 12M19 12L15 11M19 12L18 16" />
              </svg>
            </div>

            {/* Giant Stacked Sticker Headline with Graduation Cap */}
            <div className="relative my-2">
              {/* Graduation Cap Sticker resting playfully on top of the headline */}
              <div className="absolute -top-10 left-32 md:-top-14 md:left-48 z-20 animate-float pointer-events-none">
                <GraduationCapSticker className="w-16 h-16 md:w-20 md:h-20 -rotate-12 transform" />
              </div>

              {/* Stacked Sticker Container */}
              <div className="flex flex-col gap-2 -rotate-1 transform origin-left">
                {/* Row 1: BỨT PHÁ TIẾNG ANH */}
                <div className="flex flex-wrap items-center gap-2 md:gap-3">
                  <span className="inline-block px-3.5 py-1 md:px-5 md:py-1.5 bg-white rounded-2xl font-display font-extrabold text-3xl sm:text-5xl lg:text-[58px] leading-tight text-[#19883B] shadow-md shadow-emerald-900/10 tracking-tight border-2 border-white">
                    BỨT PHÁ
                  </span>
                  <span className="inline-block px-3.5 py-1 md:px-5 md:py-1.5 bg-white rounded-2xl font-display font-extrabold text-3xl sm:text-5xl lg:text-[58px] leading-tight text-[#FF6227] shadow-md shadow-orange-950/10 tracking-tight border-2 border-white">
                    TIẾNG ANH
                  </span>
                </div>

                {/* Row 2: CHINH PHỤC IELTS */}
                <div className="flex flex-wrap items-center gap-2 md:gap-3">
                  <span className="inline-block px-3.5 py-1 md:px-5 md:py-1.5 bg-white rounded-2xl font-display font-extrabold text-3xl sm:text-5xl lg:text-[58px] leading-tight text-[#16813A] shadow-md shadow-emerald-900/10 tracking-tight border-2 border-white">
                    CHINH PHỤC
                  </span>
                  <span className="inline-block px-3.5 py-1 md:px-5 md:py-1.5 bg-white rounded-2xl font-display font-extrabold text-3xl sm:text-5xl lg:text-[58px] leading-tight text-[#FA531F] shadow-md shadow-orange-950/10 tracking-tight border-2 border-white">
                    IELTS
                  </span>
                </div>
              </div>

              {/* Yellow Brush Banner: MÙA NÀY */}
              <div className="mt-3 inline-block">
                <div className="relative inline-block px-8 py-1.5 rounded-full bg-[#FFE556] shadow-sm transform -rotate-1 border border-yellow-300">
                  <span className="font-display font-extrabold text-xl sm:text-2xl text-[#174F27] tracking-wider uppercase">
                    MÙA NÀY
                  </span>
                  <span className="absolute -right-2 -top-2 text-base">✨</span>
                </div>
              </div>
            </div>

            {/* Benefit Pills */}
            <div className="mt-6 flex flex-wrap items-center gap-2 sm:gap-3.5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#18362A] text-sm font-bold shadow-sm shadow-emerald-900/5 border border-white">
                <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center text-[#19883B]">
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                <span>Lộ trình rõ ràng</span>
              </div>

              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#18362A] text-sm font-bold shadow-sm shadow-emerald-900/5 border border-white">
                <div className="w-5 h-5 rounded-full bg-orange-100 flex items-center justify-center text-[#FF631C]">
                  <Award className="w-3.5 h-3.5" />
                </div>
                <span>Giảng viên giàu kinh nghiệm</span>
              </div>

              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 text-[#18362A] text-sm font-bold shadow-sm shadow-emerald-900/5 border border-white">
                <div className="w-5 h-5 rounded-full bg-sky-100 flex items-center justify-center text-[#2188E8]">
                  <ShieldCheck className="w-3.5 h-3.5" />
                </div>
                <span>Cam kết đồng hành</span>
              </div>
            </div>

            {/* Main CTA Button */}
            <div className="mt-7 flex items-center gap-4">
              <button
                type="button"
                onClick={onRegisterClick}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full text-white font-display font-extrabold text-lg sm:text-xl tracking-wide uppercase transition-all duration-200 cursor-pointer shadow-xl shadow-orange-600/35 hover:shadow-2xl hover:shadow-orange-600/50 hover:scale-[1.03] active:scale-95 border-3 border-white"
                style={{
                  background: 'linear-gradient(180deg, #FF9534 0%, #FF4315 100%)',
                }}
              >
                <span>ĐĂNG KÝ HỌC NGAY</span>
                <ArrowRight className="w-6 h-6 transition-transform group-hover:translate-x-1" />
              </button>
            </div>

            {/* Paper Airplane doodle */}
            <div className="mt-4 -ml-2 hidden sm:block animate-float">
              <PaperAirplane className="w-12 h-12 -rotate-12" />
            </div>
          </div>

          {/* Right Column: Vietnamese IELTS Students with Speech Bubbles & Campus */}
          <div className="lg:col-span-5 relative flex justify-center lg:justify-end">
            
            {/* Campus / Building Motif Backdrop Card */}
            <div className="relative w-full max-w-[460px] lg:max-w-none">
              
              {/* Outer white polaroid / scrapbook border frame */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-emerald-950/20 border-4 border-white bg-white">
                <img
                  src={IMAGES.heroStudents}
                  alt="Học viên Việt Nam tự tin luyện thi IELTS tại EduRise"
                  referrerPolicy="no-referrer"
                  className="w-full h-[380px] sm:h-[460px] object-cover object-top hover:scale-105 transition-transform duration-500"
                />

                {/* Academy banner badge overlay inside photo */}
                <div className="absolute top-3 left-3 bg-[#075827]/90 backdrop-blur-xs text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5 shadow-md">
                  <span className="w-2 h-2 rounded-full bg-[#FFE556] inline-block" />
                  EduRise Campus · Hà Nội & TP.HCM
                </div>
              </div>

              {/* Floating Speech Bubble Top-Right: "Học thật - Làm thật - Đạt điểm thật!" */}
              <div className="absolute -top-5 -right-3 sm:-right-6 bg-white rounded-2xl px-4 py-2.5 shadow-xl shadow-emerald-950/15 border-2 border-emerald-100 z-20 animate-float transform rotate-2">
                <p className="font-display font-extrabold text-sm sm:text-base text-[#18362A] leading-tight">
                  Học thật · Làm thật
                </p>
                <p className="font-display font-bold text-xs sm:text-sm text-[#19883B] flex items-center gap-1">
                  Đạt điểm thật! 🎯
                </p>
                {/* Speech tail */}
                <div className="absolute -bottom-2 right-6 w-3 h-3 bg-white border-b-2 border-r-2 border-emerald-100 transform rotate-45" />
              </div>

              {/* Floating Round Badge Middle-Right: "YOU CAN DO IT!" */}
              <div className="absolute top-1/2 -right-4 sm:-right-8 bg-[#30A73E] text-white rounded-full w-20 h-20 sm:w-22 sm:h-22 flex flex-col items-center justify-center text-center p-2 shadow-xl shadow-green-900/25 border-3 border-white z-20 animate-float-reverse transform -rotate-12">
                <span className="font-display font-extrabold text-[12px] sm:text-[13px] leading-tight tracking-wider">
                  YOU CAN
                </span>
                <span className="font-display font-extrabold text-sm sm:text-base leading-tight text-[#FFD93D]">
                  DO IT!
                </span>
                <span className="text-[10px]">✨</span>
              </div>

              {/* Notebook Sticker Badge Bottom-Left */}
              <div className="absolute -bottom-4 -left-3 sm:-left-6 bg-[#FFFFFF] rounded-xl px-3.5 py-2 shadow-lg shadow-emerald-950/10 border-2 border-emerald-200 z-20 transform -rotate-3">
                <p className="font-handwriting font-bold text-sm text-[#075827]">
                  IELTS 7.0+ trong tầm tay! 🚀
                </p>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
