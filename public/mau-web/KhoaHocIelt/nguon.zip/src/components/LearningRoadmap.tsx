import React from 'react';
import { Search, ClipboardList, BookOpen, BarChart3, Trophy, ArrowRight, ArrowDown } from 'lucide-react';
import { ROADMAP_STEPS } from '../data/landingData';
import { PencilDoodle, RocketSticker } from './DoodleDecorations';

export const LearningRoadmap: React.FC = () => {
  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'search':
        return <Search className="w-5 h-5 text-[#19883B]" />;
      case 'clipboard':
        return <ClipboardList className="w-5 h-5 text-[#19883B]" />;
      case 'book':
        return <BookOpen className="w-5 h-5 text-[#19883B]" />;
      case 'chart':
        return <BarChart3 className="w-5 h-5 text-[#19883B]" />;
      case 'trophy':
        return <Trophy className="w-5 h-5 text-[#FF631C]" />;
      default:
        return <Search className="w-5 h-5 text-[#19883B]" />;
    }
  };

  return (
    <section id="learning-roadmap" className="relative py-14 md:py-20 bg-[#F2FFE9] overflow-hidden">
      {/* Floating Rocket Sticker on the right */}
      <div className="absolute top-6 right-6 md:right-16 z-10 animate-float pointer-events-none">
        <RocketSticker className="w-16 h-16 md:w-20 md:h-20 rotate-12" />
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center justify-center gap-2 mb-2">
            <PencilDoodle className="w-6 h-6 -rotate-12" />
            <h2 className="font-display font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#075827] tracking-tight uppercase">
              LỘ TRÌNH HỌC TẬP TẠI EDURISE
            </h2>
            <span className="text-xl">✍️</span>
          </div>
          <p className="text-sm sm:text-base text-[#18362A] font-medium mt-1">
            Từng bước vững chắc, chạm tới mục tiêu IELTS của bạn!
          </p>
        </div>

        {/* 5 Steps Connected Grid */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-3 lg:gap-4 relative items-start">
          {ROADMAP_STEPS.map((step, idx) => {
            const isLast = idx === ROADMAP_STEPS.length - 1;

            return (
              <div key={step.number} className="relative flex flex-col items-center">
                
                {/* Step Card */}
                <div className="relative w-full bg-white rounded-2xl p-5 pt-7 shadow-md shadow-emerald-950/5 border border-emerald-100 flex flex-col items-center text-center hover:shadow-xl transition-all duration-300 group">
                  
                  {/* Number Badge at Top Center / Top Left */}
                  <div className="absolute -top-4 w-9 h-9 rounded-full bg-[#19883B] text-white font-display font-bold text-base flex items-center justify-center shadow-md border-2 border-white">
                    {step.number}
                  </div>

                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    {getStepIcon(step.icon)}
                  </div>

                  {/* Title */}
                  <h3 className="font-display font-bold text-sm sm:text-[15px] text-[#18362A] mb-1.5 leading-snug">
                    {step.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Desktop Connector Arrow to next step */}
                {!isLast && (
                  <div className="hidden md:flex absolute top-1/2 -right-3.5 lg:-right-4 -translate-y-1/2 z-20 text-[#24A540]">
                    <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                  </div>
                )}

                {/* Mobile Connector Arrow to next step */}
                {!isLast && (
                  <div className="flex md:hidden my-2 text-[#24A540]">
                    <ArrowDown className="w-5 h-5 stroke-[2.5]" />
                  </div>
                )}

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
