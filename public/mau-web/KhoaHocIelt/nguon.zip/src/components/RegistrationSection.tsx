import React, { useState, useEffect } from 'react';
import { ArrowRight, CheckCircle2, AlertCircle, Trash2, Database, Sparkles } from 'lucide-react';
import { PaperAirplane, StarSticker } from './DoodleDecorations';

interface RegistrationRecord {
  id: string;
  fullName: string;
  phone: string;
  currentLevel: string;
  targetBand: string;
  createdAt: string;
}

interface RegistrationSectionProps {
  prefillLevel?: string;
  prefillTarget?: string;
}

export const RegistrationSection: React.FC<RegistrationSectionProps> = ({
  prefillLevel,
  prefillTarget,
}) => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [currentLevel, setCurrentLevel] = useState('');
  const [targetBand, setTargetBand] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showSavedList, setShowSavedList] = useState(false);
  const [savedRecords, setSavedRecords] = useState<RegistrationRecord[]>([]);

  // Sync prefill from course selections
  useEffect(() => {
    if (prefillLevel) setCurrentLevel(prefillLevel);
    if (prefillTarget) setTargetBand(prefillTarget);
  }, [prefillLevel, prefillTarget]);

  // Load from LocalStorage
  const loadSaved = () => {
    try {
      const data = localStorage.getItem('edurise_registrations');
      if (data) {
        setSavedRecords(JSON.parse(data));
      } else {
        setSavedRecords([]);
      }
    } catch {
      setSavedRecords([]);
    }
  };

  useEffect(() => {
    loadSaved();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('Vui lòng nhập họ và tên của bạn.');
      return;
    }

    if (!phone.trim()) {
      setError('Vui lòng nhập số điện thoại liên hệ.');
      return;
    }

    // Basic Vietnamese phone number check (9 to 11 digits)
    const phoneClean = phone.replace(/\s+/g, '');
    if (!/^[0-9+]{9,12}$/.test(phoneClean)) {
      setError('Số điện thoại không hợp lệ (cần từ 9 đến 11 chữ số).');
      return;
    }

    if (!currentLevel) {
      setError('Vui lòng chọn trình độ tiếng Anh hiện tại.');
      return;
    }

    if (!targetBand) {
      setError('Vui lòng chọn mục tiêu band điểm IELTS.');
      return;
    }

    const newRecord: RegistrationRecord = {
      id: Date.now().toString(),
      fullName: fullName.trim(),
      phone: phoneClean,
      currentLevel,
      targetBand,
      createdAt: new Date().toLocaleString('vi-VN'),
    };

    const existing = [...savedRecords, newRecord];
    setSavedRecords(existing);
    try {
      localStorage.setItem('edurise_registrations', JSON.stringify(existing));
    } catch (err) {
      console.warn('LocalStorage save failed', err);
    }

    setSuccess(true);
    setFullName('');
    setPhone('');
  };

  const handleClearHistory = () => {
    localStorage.removeItem('edurise_registrations');
    setSavedRecords([]);
  };

  const handleDeleteItem = (id: string) => {
    const updated = savedRecords.filter((r) => r.id !== id);
    setSavedRecords(updated);
    localStorage.setItem('edurise_registrations', JSON.stringify(updated));
  };

  return (
    <section
      id="registration"
      className="relative py-16 md:py-24 overflow-hidden text-white"
      style={{
        background: 'linear-gradient(115deg, #087F29 0%, #20AD3D 60%, #0A972D 100%)',
      }}
    >
      {/* Background decorations: paper plane, doodle stars, leaves */}
      <div className="absolute top-10 left-12 animate-float pointer-events-none hidden md:block">
        <PaperAirplane className="w-14 h-14 text-white/90" />
      </div>
      <div className="absolute bottom-8 left-1/3 animate-float-reverse pointer-events-none hidden md:block">
        <StarSticker className="w-8 h-8" />
      </div>
      <div className="absolute top-8 right-16 animate-float pointer-events-none hidden md:block">
        <StarSticker className="w-7 h-7" />
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Heading & Highlight */}
          <div className="lg:col-span-5 flex flex-col items-start">
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-[42px] leading-tight text-white tracking-tight">
              BẮT ĐẦU HÀNH TRÌNH <span className="text-[#FFE246]">IELTS</span> CÙNG EDURISE NGAY HÔM NAY!
            </h2>

            {/* Yellow brush subtitle ribbon */}
            <div className="mt-4 inline-block px-5 py-2 rounded-full bg-[#FFE15B] text-[#143D24] font-display font-bold text-sm sm:text-base shadow-sm transform -rotate-1 border border-yellow-300">
              Điền thông tin để được tư vấn khóa học phù hợp nhất! ✨
            </div>

            {/* Benefit Highlights */}
            <div className="mt-6 space-y-2 text-sm text-emerald-50">
              <p className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#FFE246]" />
                <span>Test trình độ và chấm chữa bài miễn phí cùng chuyên gia</span>
              </p>
              <p className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#FFE246]" />
                <span>Nhận ngay lộ trình nâng band 1:1 cá nhân hóa</span>
              </p>
              <p className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#FFE246]" />
                <span>Ưu đãi học phí đến 30% khi đăng ký sớm trong tháng</span>
              </p>
            </div>

            {/* Storage button for demo inspector */}
            <div className="mt-6">
              <button
                type="button"
                onClick={() => {
                  loadSaved();
                  setShowSavedList(true);
                }}
                className="inline-flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-lg bg-black/25 hover:bg-black/40 text-emerald-100 transition-colors border border-white/20 cursor-pointer"
              >
                <Database className="w-3.5 h-3.5 text-[#FFE246]" />
                <span>Xem danh sách đã lưu (LocalStorage: {savedRecords.length})</span>
              </button>
            </div>
          </div>

          {/* Right Column: Form Card + Cute Speech Heart Bubble */}
          <div className="lg:col-span-7 flex flex-col sm:flex-row items-center gap-4">
            
            {/* White Form Card */}
            <div className="w-full bg-white text-[#18362A] rounded-3xl p-6 sm:p-8 shadow-2xl shadow-emerald-950/20 border-3 border-white">
              
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Error Banner */}
                {error && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs sm:text-sm flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Success Banner */}
                {success && (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs sm:text-sm flex items-start gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-[#16A83C] shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-sm">Đăng ký tư vấn mô phỏng thành công!</p>
                      <p className="text-xs text-emerald-700 mt-0.5">
                        Dữ liệu đã được lưu an toàn vào LocalStorage. Chuyên viên EduRise sẽ liên hệ với bạn trong thời gian sớm nhất!
                      </p>
                    </div>
                  </div>
                )}

                {/* 2x2 Form Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs sm:text-[13px] font-bold text-[#18362A] mb-1.5">
                      Họ và tên <span className="text-[#FF4315]">*</span>
                    </label>
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Nhập họ và tên"
                      className="w-full px-4 py-3 rounded-xl bg-[#F8FFF6] border border-emerald-200 focus:border-[#16A83C] focus:bg-white focus:outline-none text-sm transition-all text-[#18362A]"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs sm:text-[13px] font-bold text-[#18362A] mb-1.5">
                      Số điện thoại <span className="text-[#FF4315]">*</span>
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="Nhập số điện thoại"
                      className="w-full px-4 py-3 rounded-xl bg-[#F8FFF6] border border-emerald-200 focus:border-[#16A83C] focus:bg-white focus:outline-none text-sm transition-all text-[#18362A]"
                    />
                  </div>

                  {/* Current Level */}
                  <div>
                    <label className="block text-xs sm:text-[13px] font-bold text-[#18362A] mb-1.5">
                      Trình độ hiện tại <span className="text-[#FF4315]">*</span>
                    </label>
                    <select
                      value={currentLevel}
                      onChange={(e) => setCurrentLevel(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#F8FFF6] border border-emerald-200 focus:border-[#16A83C] focus:bg-white focus:outline-none text-sm transition-all text-[#18362A] cursor-pointer"
                    >
                      <option value="">Chọn trình độ</option>
                      <option value="Mất gốc">Mất gốc tiếng Anh</option>
                      <option value="Dưới IELTS 3.0">Dưới IELTS 3.0</option>
                      <option value="IELTS 3.0 - 4.0">IELTS 3.0 – 4.0</option>
                      <option value="IELTS 4.0 - 5.5">IELTS 4.0 – 5.5</option>
                      <option value="IELTS 5.5 - 6.5">IELTS 5.5 – 6.5</option>
                      <option value="IELTS 6.5+">IELTS 6.5 trở lên</option>
                    </select>
                  </div>

                  {/* Target Band */}
                  <div>
                    <label className="block text-xs sm:text-[13px] font-bold text-[#18362A] mb-1.5">
                      Mục tiêu IELTS <span className="text-[#FF4315]">*</span>
                    </label>
                    <select
                      value={targetBand}
                      onChange={(e) => setTargetBand(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-[#F8FFF6] border border-emerald-200 focus:border-[#16A83C] focus:bg-white focus:outline-none text-sm transition-all text-[#18362A] cursor-pointer"
                    >
                      <option value="">Chọn mục tiêu</option>
                      <option value="IELTS 4.0">IELTS 4.0</option>
                      <option value="IELTS 5.0">IELTS 5.0</option>
                      <option value="IELTS 5.5">IELTS 5.5</option>
                      <option value="IELTS 6.5">IELTS 6.5</option>
                      <option value="IELTS 7.0">IELTS 7.0</option>
                      <option value="IELTS 7.5+">IELTS 7.5 trở lên</option>
                    </select>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="pt-2 flex justify-center">
                  <button
                    type="submit"
                    className="w-full sm:w-4/5 py-3.5 sm:py-4 px-6 rounded-full text-white font-display font-extrabold text-sm sm:text-base tracking-wide uppercase shadow-lg shadow-orange-600/35 hover:shadow-xl hover:shadow-orange-600/50 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer border-2 border-white"
                    style={{
                      background: 'linear-gradient(180deg, #FF9234 0%, #FF4315 100%)',
                    }}
                  >
                    <span>ĐĂNG KÝ TƯ VẤN MIỄN PHÍ</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </form>

            </div>

            {/* Cute Speech Heart Sticker Bubble on Far Right */}
            <div className="hidden xl:flex flex-col items-center justify-center p-4 rounded-3xl bg-white text-[#075827] shadow-xl border-2 border-emerald-100 rotate-6 transform shrink-0 w-36 text-center select-none animate-float">
              <span className="font-handwriting font-bold text-lg text-[#19883B] leading-tight">
                Học tốt hơn
              </span>
              <span className="font-handwriting font-bold text-lg text-[#FF631C] leading-tight">
                Mỗi ngày
              </span>
              <span className="font-handwriting font-bold text-sm text-[#075827] leading-tight">
                Cùng EduRise!
              </span>
              <span className="text-xl text-red-500 mt-1">♡</span>
            </div>

          </div>

        </div>
      </div>

      {/* LocalStorage Inspector Modal */}
      {showSavedList && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 text-[#18362A]"
          onClick={() => setShowSavedList(false)}
        >
          <div
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-xl w-full max-h-[80vh] overflow-y-auto shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-[#16A83C]" />
                <h3 className="font-display font-extrabold text-xl text-[#075827]">
                  Danh sách đăng ký tư vấn (LocalStorage)
                </h3>
              </div>
              <button
                onClick={() => setShowSavedList(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="mt-4">
              {savedRecords.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  <p>Chưa có thông tin đăng ký nào được lưu.</p>
                  <p className="text-xs mt-1">Hãy điền form để thử nghiệm tính năng LocalStorage!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs text-slate-500 mb-2">
                    <span>Tổng cộng: {savedRecords.length} lượt đăng ký</span>
                    <button
                      onClick={handleClearHistory}
                      className="text-red-600 hover:text-red-700 flex items-center gap-1 font-semibold"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Xóa tất cả
                    </button>
                  </div>

                  {savedRecords.map((item) => (
                    <div
                      key={item.id}
                      className="p-3.5 rounded-xl border border-emerald-100 bg-[#F8FFF6] flex items-center justify-between gap-3"
                    >
                      <div>
                        <h4 className="font-bold text-sm text-[#18362A]">{item.fullName}</h4>
                        <p className="text-xs text-slate-600 font-mono">SĐT: {item.phone}</p>
                        <div className="flex flex-wrap gap-2 text-[11px] font-semibold text-emerald-800 mt-1">
                          <span className="bg-emerald-100 px-2 py-0.5 rounded">Trình độ: {item.currentLevel}</span>
                          <span className="bg-orange-100 text-orange-800 px-2 py-0.5 rounded">Mục tiêu: {item.targetBand}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 block">{item.createdAt}</span>
                      </div>
                      <button
                        onClick={() => handleDeleteItem(item.id)}
                        className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                        title="Xóa bản ghi"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 text-right">
              <button
                onClick={() => setShowSavedList(false)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
