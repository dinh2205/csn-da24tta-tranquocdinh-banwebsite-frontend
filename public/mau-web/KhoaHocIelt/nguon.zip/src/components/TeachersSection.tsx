import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Award, Sparkles } from 'lucide-react';
import { TEACHERS, Teacher } from '../data/landingData';
import { SparkleStar } from './DoodleDecorations';

export const TeachersSection: React.FC = () => {
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  return (
    <section id="teachers" className="relative py-14 md:py-20 bg-white overflow-hidden">
      {/* Decorative stars */}
      <div className="absolute top-12 right-12 pointer-events-none animate-float hidden md:block">
        <SparkleStar className="w-6 h-6 text-[#19883B]" />
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 md:mb-12">
          <div>
            <div className="inline-flex items-center gap-2 mb-2">
              <span className="text-2xl">🎓</span>
              <h2 className="font-display font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#075827] tracking-tight uppercase">
                ĐỘI NGŨ GIẢNG VIÊN
              </h2>
              <span className="text-xl">✍️</span>
            </div>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Tận tâm – Chuyên môn cao – Truyền cảm hứng
            </p>
          </div>

          <button
            type="button"
            onClick={() => setSelectedTeacher(TEACHERS[0])}
            className="self-start md:self-auto inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-emerald-50 hover:bg-emerald-100 text-[#19883B] font-bold text-xs sm:text-sm border border-emerald-200 transition-all cursor-pointer group"
          >
            <span>Xem thêm giảng viên</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 3 Teacher Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TEACHERS.map((teacher) => (
            <div
              key={teacher.id}
              className="bg-white rounded-2xl border border-emerald-100 shadow-md shadow-emerald-950/5 hover:shadow-xl hover:border-emerald-300 transition-all duration-300 p-4 sm:p-5 flex gap-4 items-center group cursor-pointer"
              onClick={() => setSelectedTeacher(teacher)}
            >
              {/* Teacher Photo */}
              <div className="relative w-28 h-32 sm:w-32 sm:h-36 shrink-0 rounded-xl overflow-hidden bg-emerald-50 border-2 border-emerald-100 shadow-xs">
                <img
                  src={teacher.image}
                  alt={teacher.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-108"
                />
              </div>

              {/* Teacher Info */}
              <div className="flex-1 min-w-0">
                <h3 className="font-display font-bold text-lg sm:text-xl text-[#18362A] truncate">
                  {teacher.name}
                </h3>

                {/* Orange Badge */}
                <div className="mt-1 mb-2.5">
                  <span className="inline-block px-3 py-1 rounded-full text-white text-xs font-extrabold bg-[#FF631C] shadow-xs">
                    {teacher.ieltsOverall}
                  </span>
                </div>

                {/* Bullets */}
                <ul className="space-y-1 text-xs text-slate-600">
                  {teacher.highlights.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 leading-snug">
                      <span className="text-[#19883B] font-bold text-sm leading-none shrink-0">✦</span>
                      <span className="line-clamp-1">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Teacher Profile Detail Modal */}
      {selectedTeacher && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setSelectedTeacher(null)}
        >
          <div
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedTeacher(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold"
            >
              ✕
            </button>

            <div className="flex items-center gap-4">
              <img
                src={selectedTeacher.image}
                alt={selectedTeacher.name}
                referrerPolicy="no-referrer"
                className="w-24 h-28 rounded-2xl object-cover object-top shadow-md border-2 border-emerald-100"
              />
              <div>
                <span className="inline-block px-3 py-1 rounded-full text-white text-xs font-bold bg-[#FF631C]">
                  {selectedTeacher.ieltsOverall}
                </span>
                <h3 className="font-display font-extrabold text-2xl text-[#18362A] mt-1">
                  {selectedTeacher.name}
                </h3>
                <p className="text-xs text-emerald-800 font-semibold">Chuyên gia luyện thi IELTS tại EduRise</p>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <h4 className="text-xs uppercase font-bold text-slate-400 tracking-wider mb-2">
                Thành tích & Thế mạnh
              </h4>
              <ul className="space-y-2">
                {selectedTeacher.highlights.map((h, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-[#19883B] shrink-0" />
                    <span>{h}</span>
                  </li>
                ))}
                <li className="flex items-center gap-2 text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-[#19883B] shrink-0" />
                  <span>Cố vấn phương pháp tự học và nâng band tốc chiến</span>
                </li>
              </ul>
            </div>

            <div className="mt-6">
              <button
                onClick={() => {
                  setSelectedTeacher(null);
                  document.getElementById('registration')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-3 rounded-full bg-gradient-to-r from-[#16A83C] to-[#48CA3B] text-white font-bold text-sm shadow-md cursor-pointer hover:shadow-lg transition-all"
              >
                Đăng ký học với giảng viên
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
