import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../data/landingData';
import { SparkleStar } from './DoodleDecorations';

export const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="testimonials" className="relative py-14 md:py-20 bg-[#F5FFF2] overflow-hidden">
      {/* Decorative doodle */}
      <div className="absolute top-8 left-8 pointer-events-none animate-float hidden md:block">
        <span className="text-2xl">🍃</span>
      </div>

      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10 md:mb-12">
          <div>
            <div className="inline-flex items-center gap-2 mb-2">
              <span className="text-2xl">🍃</span>
              <h2 className="font-display font-extrabold text-2xl sm:text-3xl md:text-4xl text-[#075827] tracking-tight uppercase">
                HỌC VIÊN NÓI GÌ VỀ EDURISE?
              </h2>
              <span className="text-xl">💬</span>
            </div>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Những chia sẻ chân thực từ học viên đã và đang đồng hành cùng chúng tôi.
            </p>
          </div>

          <button
            type="button"
            onClick={handleNext}
            className="self-start md:self-auto inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white hover:bg-emerald-50 text-[#19883B] font-bold text-xs sm:text-sm border border-emerald-200 transition-all cursor-pointer group shadow-xs"
          >
            <span>Xem thêm đánh giá</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* Carousel Container with Left/Right Buttons */}
        <div className="relative flex items-center gap-2 sm:gap-4">
          
          {/* Left Arrow Button */}
          <button
            type="button"
            onClick={handlePrev}
            aria-label="Previous review"
            className="hidden sm:flex w-10 h-10 rounded-full bg-white border border-emerald-200 text-[#075827] items-center justify-center shadow-md hover:bg-emerald-50 hover:scale-105 active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Cards Grid / Carousel */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 flex-1">
            {TESTIMONIALS.map((review, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 sm:p-6 shadow-md shadow-emerald-950/5 border border-emerald-100 flex flex-col justify-between hover:shadow-xl transition-all duration-300 relative group"
              >
                {/* Quote Icon */}
                <div className="text-emerald-300 mb-2">
                  <Quote className="w-6 h-6 rotate-180" />
                </div>

                {/* Content */}
                <p className="text-xs sm:text-[13px] text-slate-700 italic leading-relaxed mb-6 font-normal">
                  &ldquo;{review.content}&rdquo;
                </p>

                {/* Student Info */}
                <div className="flex items-center gap-3.5 pt-4 border-t border-emerald-50">
                  <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border-2 border-emerald-200 shadow-xs bg-emerald-50">
                    <img
                      src={review.image}
                      alt={review.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-sm sm:text-base text-[#18362A] leading-tight">
                      {review.name}
                    </h4>
                    <p className="text-[11px] sm:text-xs font-semibold text-[#19883B] mt-0.5">
                      {review.course}
                    </p>
                  </div>
                </div>

              </div>
            ))}
          </div>

          {/* Right Arrow Button */}
          <button
            type="button"
            onClick={handleNext}
            aria-label="Next review"
            className="hidden sm:flex w-10 h-10 rounded-full bg-white border border-emerald-200 text-[#075827] items-center justify-center shadow-md hover:bg-emerald-50 hover:scale-105 active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

        </div>

      </div>
    </section>
  );
};
