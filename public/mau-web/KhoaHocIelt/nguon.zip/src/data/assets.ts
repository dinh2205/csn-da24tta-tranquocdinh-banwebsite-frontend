// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhActivityClassroom from '../assets/images/activity_classroom_1792081893322.jpg';
import anhActivityIeltsGroup from '../assets/images/activity_ielts_group_1792081915109.jpg';
import anhActivitySpeakingPractice from '../assets/images/activity_speaking_practice_1792081916167.jpg';
import anhHeroIeltsStudents from '../assets/images/hero_ielts_students_1792081893183.jpg';
import anhStudentBuilder from '../assets/images/student_builder_1792081914067.jpg';
import anhStudentFoundation from '../assets/images/student_foundation_1792081913212.jpg';
import anhStudentPerformer from '../assets/images/student_performer_1792081914927.jpg';
import anhTeacherKhanhVy from '../assets/images/teacher_khanh_vy_1792081893527.jpg';
import anhTeacherMinhAnh from '../assets/images/teacher_minh_anh_1792081893310.jpg';
import anhTeacherQuocHuy from '../assets/images/teacher_quoc_huy_1792081894933.jpg';

// Image paths for EduRise Landing Page

export const IMAGES = {
  heroStudents: anhHeroIeltsStudents,
  activityClassroom: anhActivityClassroom,
  activityGroup: anhActivityIeltsGroup,
  activitySpeaking: anhActivitySpeakingPractice,
  studentFoundation: anhStudentFoundation,
  studentBuilder: anhStudentBuilder,
  studentPerformer: anhStudentPerformer,
  teacherMinhAnh: anhTeacherMinhAnh,
  teacherKhanhVy: anhTeacherKhanhVy,
  teacherQuocHuy: anhTeacherQuocHuy,
  reviewHaLinh: anhStudentFoundation,
  reviewMinhQuan: anhStudentBuilder,
  reviewThuTrang: anhStudentPerformer,
};
