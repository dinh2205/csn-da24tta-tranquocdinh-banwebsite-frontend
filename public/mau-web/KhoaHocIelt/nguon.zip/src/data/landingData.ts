import { IMAGES } from './assets';

export interface Course {
  id: string;
  name: string;
  tagline: string;
  badgeText: string;
  badgeBg: string;
  themeColor: string;
  description: string;
  targetBand: string;
  schedule: string;
  startDate: string;
  startDateDisplay: string;
  image: string;
  targetSelectValue: string;
  levelSelectValue: string;
}

export interface Teacher {
  id: number;
  name: string;
  ieltsOverall: string;
  image: string;
  highlights: string[];
}

export interface Benefit {
  title: string;
  description: string;
  icon: string;
  color: string;
  background: string;
}

export interface RoadmapStep {
  number: number;
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  name: string;
  course: string;
  image: string;
  content: string;
}

export const COURSES: Course[] = [
  {
    id: 'ielts-foundation',
    name: 'IELTS FOUNDATION',
    tagline: 'Dành cho người mới bắt đầu',
    badgeText: 'Dành cho người mới bắt đầu',
    badgeBg: '#14983B',
    themeColor: '#14983B',
    description: 'Xây nền tảng tiếng Anh vững chắc, làm quen với format IELTS.',
    targetBand: '2.5 – 4.0',
    schedule: 'Thứ 3, 5, 7 (19h00 – 21h00)',
    startDate: '2026-07-15',
    startDateDisplay: '15/07/2026',
    image: IMAGES.studentFoundation,
    targetSelectValue: 'IELTS 4.0',
    levelSelectValue: 'Dưới IELTS 3.0',
  },
  {
    id: 'ielts-builder',
    name: 'IELTS BUILDER',
    tagline: 'Dành cho trình độ trung cấp',
    badgeText: 'Dành cho trình độ trung cấp',
    badgeBg: '#D431D1',
    themeColor: '#D431D1',
    description: 'Phát triển toàn diện 4 kỹ năng, chiến lược làm bài hiệu quả.',
    targetBand: '4.0 – 5.5',
    schedule: 'Thứ 2, 4, 6 (19h15 – 21h15)',
    startDate: '2026-07-20',
    startDateDisplay: '20/07/2026',
    image: IMAGES.studentBuilder,
    targetSelectValue: 'IELTS 5.5',
    levelSelectValue: 'IELTS 3.0 - 4.0',
  },
  {
    id: 'ielts-performer',
    name: 'IELTS PERFORMER',
    tagline: 'Dành cho mục tiêu band cao',
    badgeText: 'Dành cho mục tiêu band cao',
    badgeBg: '#FF531F',
    themeColor: '#FF531F',
    description: 'Tối ưu chiến lược, luyện đề chuyên sâu, sẵn sàng chinh phục band điểm cao.',
    targetBand: '5.5 – 7.5+',
    schedule: 'Thứ 7, CN (09h00 – 12h00)',
    startDate: '2026-07-22',
    startDateDisplay: '22/07/2026',
    image: IMAGES.studentPerformer,
    targetSelectValue: 'IELTS 7.0',
    levelSelectValue: 'IELTS 5.5 - 6.5',
  },
];

export const BENEFITS: Benefit[] = [
  {
    title: 'Lộ trình cá nhân hóa',
    description: 'Thiết kế phù hợp từng trình độ, mục tiêu',
    icon: 'target',
    color: '#0EAD45',
    background: '#E8FFEF',
  },
  {
    title: 'Giảng viên giàu kinh nghiệm',
    description: 'Chuyên môn cao, truyền cảm hứng',
    icon: 'users',
    color: '#FF6B25',
    background: '#FFF0E7',
  },
  {
    title: 'Phương pháp hiện đại',
    description: 'Học qua thực hành, case study, luyện đề thật',
    icon: 'book-open',
    color: '#F4B515',
    background: '#FFF8D8',
  },
  {
    title: 'Theo sát tiến độ',
    description: 'Kiểm tra định kỳ, báo cáo chi tiết',
    icon: 'chart',
    color: '#248CFA',
    background: '#E8F3FF',
  },
  {
    title: 'Môi trường truyền cảm hứng',
    description: 'Cộng đồng học viên năng động, hỗ trợ nhau',
    icon: 'gem',
    color: '#E93B97',
    background: '#FFEAF7',
  },
];

export const ROADMAP_STEPS: RoadmapStep[] = [
  {
    number: 1,
    title: 'Kiểm tra đầu vào',
    description: 'Đánh giá chính xác trình độ hiện tại',
    icon: 'search',
  },
  {
    number: 2,
    title: 'Tư vấn lộ trình cá nhân hóa',
    description: 'Đưa ra kế hoạch học tập phù hợp',
    icon: 'clipboard',
  },
  {
    number: 3,
    title: 'Học tập theo lộ trình',
    description: 'Rèn luyện 4 kỹ năng với giảng viên',
    icon: 'book',
  },
  {
    number: 4,
    title: 'Kiểm tra định kỳ',
    description: 'Đánh giá tiến độ, điều chỉnh kịp thời',
    icon: 'chart',
  },
  {
    number: 5,
    title: 'Chinh phục IELTS',
    description: 'Tự tin đạt band điểm mong muốn',
    icon: 'trophy',
  },
];

export const TEACHERS: Teacher[] = [
  {
    id: 1,
    name: 'Thầy Minh Anh',
    ieltsOverall: '8.5 IELTS Overall',
    image: IMAGES.teacherMinhAnh,
    highlights: [
      'Hơn 6 năm giảng dạy IELTS',
      'Chuyên sâu Writing & Speaking',
      'Truyền cảm hứng, gần gũi',
    ],
  },
  {
    id: 2,
    name: 'Cô Khánh Vy',
    ieltsOverall: '8.0 IELTS Overall',
    image: IMAGES.teacherKhanhVy,
    highlights: [
      'Thạc sĩ TESOL',
      'Chuyên sâu Listening & Reading',
      'Phương pháp giảng dạy hiện đại',
    ],
  },
  {
    id: 3,
    name: 'Thầy Quốc Huy',
    ieltsOverall: '8.0 IELTS Overall',
    image: IMAGES.teacherQuocHuy,
    highlights: [
      'Hơn 5 năm kinh nghiệm',
      'Chuyên sâu Speaking',
      'Giúp học viên tự tin, phản xạ tốt',
    ],
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Nguyễn Hà Linh',
    course: 'IELTS 7.0 – Học viên khóa Builder',
    image: IMAGES.reviewHaLinh,
    content:
      'Nhờ lộ trình rõ ràng và sự hướng dẫn tận tình của thầy cô, mình đã đạt 7.0 IELTS sau 6 tháng. Cảm ơn EduRise rất nhiều!',
  },
  {
    name: 'Trần Minh Quân',
    course: 'IELTS 6.5 – Học viên khóa Foundation',
    image: IMAGES.reviewMinhQuan,
    content:
      'Lớp học rất vui, giáo viên nhiệt tình, tài liệu sát đề thi thật. Mình tiến bộ rõ rệt từng ngày!',
  },
  {
    name: 'Lê Thu Trang',
    course: 'IELTS 7.5 – Học viên khóa Performer',
    image: IMAGES.reviewThuTrang,
    content:
      'Không chỉ học kiến thức, mình còn được truyền động lực và kỹ năng tự học lâu dài. EduRise là lựa chọn đúng đắn!',
  },
];

export const ACTIVITIES = [
  {
    src: IMAGES.activityClassroom,
    alt: 'Giảng viên hướng dẫn học viên IELTS',
    caption: 'Lớp học tương tác 1:1 cùng giảng viên giàu kinh nghiệm',
  },
  {
    src: IMAGES.activityGroup,
    alt: 'Học viên đạt điểm IELTS 7.0+ chụp ảnh tại EduRise',
    caption: 'Lễ vinh danh học viên đạt chứng chỉ IELTS 7.0+ xuất sắc',
  },
  {
    src: IMAGES.activitySpeaking,
    alt: 'Học viên trao đổi và luyện nói Speaking',
    caption: 'Câu lạc bộ luyện nói Speaking tương tác hàng tuần',
  },
  {
    src: IMAGES.heroStudents,
    alt: 'Học viên tự tin bước vào phòng thi',
    caption: 'Không gian học tập hiện đại, chuẩn quốc tế',
  },
  {
    src: IMAGES.activityClassroom,
    alt: 'Hoạt động thuyết trình IELTS trên lớp',
    caption: 'Học qua tình huống thực tế và bộ đề cập nhật liên tục',
  },
];
