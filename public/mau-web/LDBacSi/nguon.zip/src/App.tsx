/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { StatisticsSection } from './components/StatisticsSection';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { DoctorsSection } from './components/DoctorsSection';
import { AppointmentSection } from './components/AppointmentSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { ConsultationModal } from './components/ConsultationModal';
import { MyAppointmentsModal } from './components/MyAppointmentsModal';
import { AppointmentRecord } from './types/medcare';
import { PhoneCall, CalendarDays, ArrowUp } from 'lucide-react';

export default function App() {
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [consultationModalOpen, setConsultationModalOpen] = useState(false);
  const [myAppointmentsModalOpen, setMyAppointmentsModalOpen] = useState(false);
  
  const [preselectedSpecialty, setPreselectedSpecialty] = useState<string>('');
  const [preselectedDoctorName, setPreselectedDoctorName] = useState<string>('');
  
  const [appointments, setAppointments] = useState<AppointmentRecord[]>([]);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Load appointments from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem('medcare_appointments');
      if (stored) {
        setAppointments(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to load appointments from localStorage', e);
    }

    const checkScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', checkScroll);
    return () => window.removeEventListener('scroll', checkScroll);
  }, []);

  const handleAppointmentCreated = (newRecord: AppointmentRecord) => {
    setAppointments((prev) => [newRecord, ...prev]);
  };

  const handleCancelAppointment = (id: string) => {
    const updated = appointments.filter((item) => item.id !== id);
    setAppointments(updated);
    try {
      localStorage.setItem('medcare_appointments', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleClearAllAppointments = () => {
    setAppointments([]);
    try {
      localStorage.removeItem('medcare_appointments');
    } catch (e) {
      console.error(e);
    }
  };

  const handleSelectServiceToBook = (specialtyTitle: string) => {
    // Map service title if necessary to one of the 6 options
    let mapped = specialtyTitle;
    if (specialtyTitle.includes('Tim mạch')) mapped = 'Tim mạch';
    else if (specialtyTitle.includes('Nhi')) mapped = 'Nhi khoa';
    else if (specialtyTitle.includes('Xét nghiệm')) mapped = 'Xét nghiệm';
    else if (specialtyTitle.includes('Chẩn đoán hình ảnh')) mapped = 'Khám tổng quát';
    else if (specialtyTitle.includes('Tư vấn online')) mapped = 'Khám tổng quát';
    
    setPreselectedSpecialty(mapped);
    setPreselectedDoctorName('');
  };

  const handleSelectDoctorToBook = (specialtyName: string, doctorName: string) => {
    setPreselectedSpecialty(specialtyName);
    setPreselectedDoctorName(doctorName);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white text-[#102B55] flex flex-col font-sans selection:bg-[#0869C8] selection:text-white">
      {/* 1. Header (Sticky navigation, logo, hotline, appointment CTA) */}
      <Header
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenMyAppointments={() => setMyAppointmentsModalOpen(true)}
        appointmentCount={appointments.length}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <HeroSection
          onOpenConsultationModal={() => setConsultationModalOpen(true)}
        />

        {/* 3. Statistics Section (overlapping hero bottom by -35px) */}
        <StatisticsSection />

        {/* 4. Services Section */}
        <ServicesSection
          onSelectServiceToBook={handleSelectServiceToBook}
        />

        {/* 5. About Section */}
        <AboutSection />

        {/* 6. Doctors Section */}
        <DoctorsSection
          onSelectDoctorToBook={handleSelectDoctorToBook}
        />

        {/* 7. Appointment Booking Section */}
        <AppointmentSection
          preselectedSpecialty={preselectedSpecialty}
          preselectedDoctorName={preselectedDoctorName}
          onAppointmentCreated={handleAppointmentCreated}
        />

        {/* 8. Testimonials Section */}
        <TestimonialsSection />
      </main>

      {/* 9. Footer */}
      <Footer />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto">
        {/* Floating Quick Call Button */}
        <a
          href="tel:19003366"
          className="w-13 h-13 rounded-full bg-[#0869C8] hover:bg-[#0759ab] text-white shadow-xl flex items-center justify-center transition-transform hover:scale-110 active:scale-95 group relative"
          title="Gọi Hotline 1900 3366"
          aria-label="Hotline 1900 3366"
        >
          <PhoneCall className="w-6 h-6 animate-pulse" />
          <span className="absolute right-full mr-3 px-3 py-1.5 bg-[#092D63] text-white text-xs font-bold rounded-lg shadow-md whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            Hotline: 1900 3366
          </span>
        </a>

        {/* Scroll To Top Button */}
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md border border-[#DCEAF3] text-[#0869C8] shadow-md hover:bg-[#F3FAFE] flex items-center justify-center transition-all hover:scale-105 active:scale-95"
            aria-label="Lên đầu trang"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Quick Search Modal */}
      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectResult={(specialty) => {
          handleSelectServiceToBook(specialty);
        }}
      />

      {/* Free Consultation Request Modal */}
      <ConsultationModal
        isOpen={consultationModalOpen}
        onClose={() => setConsultationModalOpen(false)}
      />

      {/* User Bookings Modal */}
      <MyAppointmentsModal
        isOpen={myAppointmentsModalOpen}
        onClose={() => setMyAppointmentsModalOpen(false)}
        appointments={appointments}
        onCancelAppointment={handleCancelAppointment}
        onClearAll={handleClearAllAppointments}
      />
    </div>
  );
}
