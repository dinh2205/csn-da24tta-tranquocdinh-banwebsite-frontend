import React from 'react';
import { UserCheck, ClipboardCheck, CalendarCheck, HeartHandshake, Building2, Shield, Heart } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

export const AboutSection: React.FC = () => {
  const getFeatureIcon = (iconName: string) => {
    switch (iconName) {
      case 'user-round-check':
        return <UserCheck className="w-5 h-5 text-[#0869C8]" />;
      case 'clipboard-check':
        return <ClipboardCheck className="w-5 h-5 text-[#00A9B9]" />;
      case 'calendar-check':
        return <CalendarCheck className="w-5 h-5 text-[#13B995]" />;
      case 'heart-handshake':
        return <HeartHandshake className="w-5 h-5 text-[#FF526B]" />;
      default:
        return <UserCheck className="w-5 h-5 text-[#0869C8]" />;
    }
  };

  return (
    <section id="about" className="py-16 sm:py-24 bg-white relative overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Visual: Clinic Building & Floating Experience Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-[#E3EDF5] bg-gray-50 aspect-[4/3] group">
              <img
                src={MEDCARE_DATA.images.clinicBuilding}
                alt="Cơ sở phòng khám đa khoa MedCare"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#092D63]/70 via-transparent to-transparent" />
              
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center gap-2 mb-1">
                  <Building2 className="w-4 h-4 text-[#20CDB9]" />
                  <span className="text-xs uppercase font-bold tracking-wider text-[#20CDB9]">
                    Cơ sở vật chất hiện đại
                  </span>
                </div>
                <h4 className="text-base font-bold text-white drop-shadow-xs">
                  Phòng khám đa khoa quốc tế MedCare
                </h4>
                <p className="text-xs text-white/80 line-clamp-1">
                  56-123 Nguyễn Văn Cừ, Long Biên, Hà Nội
                </p>
              </div>
            </div>

            {/* Side Banner: Family Healthcare from JSON */}
            <div className="mt-4 sm:mt-5 p-4 rounded-xl bg-[#E8F7FF] border border-[#DCEAF3] flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0 border border-white shadow-xs">
                <img
                  src={MEDCARE_DATA.images.familyHealthcare}
                  alt="Chăm sóc sức khỏe gia đình"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#0869C8] mb-1">
                  <Heart className="w-3.5 h-3.5 fill-[#0869C8] text-[#0869C8]" />
                  <span>Sứ mệnh yêu thương</span>
                </div>
                <h5 className="text-sm font-bold text-[#092D63] leading-snug">
                  Sức khỏe tốt hơn - Cuộc sống hạnh phúc hơn
                </h5>
                <p className="text-xs text-[#62758E] mt-1">
                  Chăm sóc toàn diện từ trẻ sơ sinh, người trưởng thành đến người cao tuổi.
                </p>
              </div>
            </div>

            {/* Experience badge */}
            <div className="absolute -top-3 -right-3 hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white shadow-lg border border-[#DCEAF3] text-xs font-bold text-[#102B55]">
              <Shield className="w-4 h-4 text-[#13B995]" />
              <span>Tiêu chuẩn Quốc Tế ISO</span>
            </div>
          </div>

          {/* Right Content: About MedCare & 4 Features */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <span className="text-xs sm:text-sm font-bold text-[#0869C8] tracking-widest uppercase block mb-2">
                VỀ MEDCARE
              </span>
              <h2 className="text-2xl sm:text-3xl lg:text-[36px] font-extrabold text-[#092D63] tracking-tight leading-tight">
                Vì sao nên chọn chúng tôi?
              </h2>
              <p className="text-base text-[#62758E] mt-3 leading-relaxed">
                MedCare không chỉ là nơi khám chữa bệnh, mà còn là người bạn đồng hành đáng tin cậy trong hành trình chăm sóc sức khỏe của bạn và gia đình.
              </p>
            </div>

            {/* 4 Core Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {MEDCARE_DATA.aboutFeatures.map((feat, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-[#E3EDF5] bg-[#F3FAFE]/60 hover:bg-white hover:border-[#0869C8]/40 hover:shadow-md transition-all duration-200"
                >
                  <div className="w-10 h-10 rounded-lg bg-white border border-[#DCEAF3] flex items-center justify-center mb-3 shadow-2xs">
                    {getFeatureIcon(feat.icon)}
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-[#102B55] mb-1 leading-snug">
                    {feat.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#62758E] leading-relaxed">
                    {feat.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Bottom mini highlight */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <a
                href="#appointment"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-white font-semibold text-sm bg-[#0869C8] hover:bg-[#0759ab] shadow-sm transition-colors"
              >
                <span>Trải nghiệm dịch vụ</span>
                <span>→</span>
              </a>
              <span className="text-xs text-[#62758E]">
                * Tiếp nhận khám bảo hiểm y tế & bảo lãnh viện phí tư nhân
              </span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
