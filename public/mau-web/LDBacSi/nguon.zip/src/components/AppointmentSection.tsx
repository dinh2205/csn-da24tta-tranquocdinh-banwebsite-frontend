import React, { useState, useEffect } from 'react';
import { ArrowRight, Calendar, User, Phone, Stethoscope, CheckCircle2, ShieldCheck, Clock, AlertCircle } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';
import { AppointmentRecord } from '../types/medcare';

interface AppointmentSectionProps {
  preselectedSpecialty?: string;
  preselectedDoctorName?: string;
  onAppointmentCreated: (record: AppointmentRecord) => void;
}

export const AppointmentSection: React.FC<AppointmentSectionProps> = ({
  preselectedSpecialty,
  preselectedDoctorName,
  onAppointmentCreated,
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    specialty: '',
    appointmentDate: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successBooking, setSuccessBooking] = useState<AppointmentRecord | null>(null);

  // Today's date in YYYY-MM-DD for min date
  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (preselectedSpecialty) {
      setFormData((prev) => ({
        ...prev,
        specialty: preselectedSpecialty,
      }));
    }
  }, [preselectedSpecialty]);

  const validate = () => {
    const errs: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      errs.fullName = 'Vui lòng nhập họ và tên của bạn';
    } else if (formData.fullName.trim().length < 2) {
      errs.fullName = 'Họ và tên quá ngắn';
    }

    if (!formData.phone.trim()) {
      errs.phone = 'Vui lòng nhập số điện thoại';
    } else {
      // Vietnamese phone regex check (10 digits starting with 0)
      const cleanPhone = formData.phone.replace(/[\s.-]/g, '');
      const vnPhoneRegex = /(03|05|07|08|09|01[2|6|8|9])+([0-9]{8})\b/;
      if (!vnPhoneRegex.test(cleanPhone)) {
        errs.phone = 'Số điện thoại không hợp lệ (gồm 10 chữ số, ví dụ: 0912345678)';
      }
    }

    if (!formData.specialty) {
      errs.specialty = 'Vui lòng chọn chuyên khoa khám';
    }

    if (!formData.appointmentDate) {
      errs.appointmentDate = 'Vui lòng chọn ngày khám';
    } else if (formData.appointmentDate < todayStr) {
      errs.appointmentDate = 'Ngày khám không thể ở trong quá khứ';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const bookingCode = `MC-${Math.floor(10000 + Math.random() * 90000)}`;
      const newRecord: AppointmentRecord = {
        id: Date.now().toString(),
        bookingCode,
        fullName: formData.fullName.trim(),
        phone: formData.phone.trim(),
        specialty: formData.specialty,
        appointmentDate: formData.appointmentDate,
        createdAt: new Date().toISOString(),
        status: 'confirmed',
      };

      // Persist to localStorage with key 'medcare_appointments'
      const storageKey = 'medcare_appointments';
      try {
        const existingRaw = localStorage.getItem(storageKey);
        const list: AppointmentRecord[] = existingRaw ? JSON.parse(existingRaw) : [];
        list.unshift(newRecord);
        localStorage.setItem(storageKey, JSON.stringify(list));
      } catch (err) {
        console.error('Lỗi lưu lịch khám vào localStorage:', err);
      }

      setSuccessBooking(newRecord);
      onAppointmentCreated(newRecord);
      setIsSubmitting(false);

      // Reset form
      setFormData({
        fullName: '',
        phone: '',
        specialty: '',
        appointmentDate: '',
      });
      setErrors({});
    }, 400);
  };

  return (
    <section id="appointment" className="py-16 sm:py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        {/* Main Appointment Box with #F0F9FF background & 16px borderRadius */}
        <div className="bg-[#F0F9FF] rounded-[16px] border border-[#DCEAF3] shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
            
            {/* Left Content Column (48%) */}
            <div
              className="lg:col-span-6 p-8 sm:p-10 lg:p-12 flex flex-col justify-between relative"
              style={{
                background: 'linear-gradient(120deg, #E3F7FF 0%, #F9FDFF 100%)',
              }}
            >
              <div>
                <span className="text-xs sm:text-sm font-bold text-[#0869C8] tracking-widest uppercase block mb-2">
                  ĐẶT LỊCH KHÁM
                </span>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#092D63] tracking-tight leading-tight">
                  Chủ động chăm sóc sức khỏe ngay hôm nay
                </h2>
                <p className="text-sm sm:text-base text-[#62758E] mt-3 leading-relaxed">
                  Đặt lịch khám nhanh chóng, chọn bác sĩ phù hợp và nhận tư vấn miễn phí từ đội ngũ MedCare.
                </p>

                {/* Preselected indicator notice if user selected doctor from previous section */}
                {preselectedDoctorName && (
                  <div className="mt-4 p-3 rounded-lg bg-blue-100/70 border border-blue-200 text-xs text-[#0869C8] flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-[#0869C8]" />
                    <span>
                      Đang chọn đặt hẹn với <strong>{preselectedDoctorName}</strong> ({preselectedSpecialty})
                    </span>
                  </div>
                )}
              </div>

              {/* Doctor Visual & Trust Badges */}
              <div className="mt-8 pt-6 border-t border-[#DCEAF3]/80 space-y-4">
                <div className="relative rounded-xl overflow-hidden aspect-[16/9] shadow-sm border border-white bg-blue-50">
                  <img
                    src={MEDCARE_DATA.images.appointmentDoctor}
                    alt="Bác sĩ MedCare tư vấn chuyên sâu"
                    className="w-full h-full object-cover object-center"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#092D63]/60 via-transparent to-transparent" />
                  <div className="absolute bottom-3 left-3 text-white text-xs font-semibold">
                    ✦ Phòng khám tiếp nhận bệnh nhân tất cả các ngày trong tuần
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs text-[#102B55] font-medium pt-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#13B995] shrink-0" />
                    <span>Bảo mật thông tin bệnh nhân</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#0869C8] shrink-0" />
                    <span>Không mất phí đặt lịch hẹn</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Form Column (52%) */}
            <div className="lg:col-span-6 p-8 sm:p-10 lg:p-12 bg-white flex flex-col justify-center">
              <div className="mb-6">
                <h3 className="text-xl sm:text-2xl font-bold text-[#092D63]">
                  Thông tin đặt lịch khám
                </h3>
                <p className="text-xs sm:text-sm text-[#62758E] mt-1">
                  Vui lòng điền đầy đủ các thông tin bên dưới để được ưu tiên sắp xếp lịch
                </p>
              </div>

              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                {/* 2 columns on desktop for form fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div>
                    <label className="block text-xs font-bold text-[#102B55] uppercase tracking-wider mb-1.5">
                      Họ và tên <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                        <User className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder="Nhập họ và tên"
                        className={`w-full pl-10 pr-3.5 py-3 text-sm rounded-lg border bg-[#F8FBFE] text-[#102B55] placeholder-gray-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8] transition-colors ${
                          errors.fullName ? 'border-red-400' : 'border-[#DCEAF3]'
                        }`}
                      />
                    </div>
                    {errors.fullName && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.fullName}
                      </p>
                    )}
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-bold text-[#102B55] uppercase tracking-wider mb-1.5">
                      Số điện thoại <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                        <Phone className="w-4 h-4" />
                      </div>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="Ví dụ: 0912345678"
                        className={`w-full pl-10 pr-3.5 py-3 text-sm rounded-lg border bg-[#F8FBFE] text-[#102B55] placeholder-gray-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8] transition-colors ${
                          errors.phone ? 'border-red-400' : 'border-[#DCEAF3]'
                        }`}
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.phone}
                      </p>
                    )}
                  </div>
                </div>

                {/* 2 columns: Specialty & Appointment Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Specialty */}
                  <div>
                    <label className="block text-xs font-bold text-[#102B55] uppercase tracking-wider mb-1.5">
                      Chuyên khoa <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                        <Stethoscope className="w-4 h-4" />
                      </div>
                      <select
                        name="specialty"
                        value={formData.specialty}
                        onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
                        className={`w-full pl-10 pr-8 py-3 text-sm rounded-lg border bg-[#F8FBFE] text-[#102B55] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8] transition-colors appearance-none ${
                          errors.specialty ? 'border-red-400' : 'border-[#DCEAF3]'
                        }`}
                      >
                        <option value="">Chọn chuyên khoa</option>
                        {MEDCARE_DATA.specialtyOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-gray-400">
                        ▼
                      </div>
                    </div>
                    {errors.specialty && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.specialty}
                      </p>
                    )}
                  </div>

                  {/* Appointment Date */}
                  <div>
                    <label className="block text-xs font-bold text-[#102B55] uppercase tracking-wider mb-1.5">
                      Ngày khám <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                        <Calendar className="w-4 h-4" />
                      </div>
                      <input
                        type="date"
                        name="appointmentDate"
                        min={todayStr}
                        value={formData.appointmentDate}
                        onChange={(e) => setFormData({ ...formData, appointmentDate: e.target.value })}
                        className={`w-full pl-10 pr-3.5 py-3 text-sm rounded-lg border bg-[#F8FBFE] text-[#102B55] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8] transition-colors ${
                          errors.appointmentDate ? 'border-red-400' : 'border-[#DCEAF3]'
                        }`}
                      />
                    </div>
                    {errors.appointmentDate && (
                      <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {errors.appointmentDate}
                      </p>
                    )}
                  </div>
                </div>

                {/* Submit button (#0874D3 as specified in JSON) */}
                <div className="pt-3">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-6 rounded-lg text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.99] transition-all duration-200"
                    style={{ backgroundColor: '#0874D3' }}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Đang xử lý đặt lịch...</span>
                      </span>
                    ) : (
                      <>
                        <span>Đặt lịch khám ngay</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>

                {/* Simulated Notice */}
                <p className="text-[11px] text-center text-[#62758E] italic pt-1">
                  * Hệ thống mô phỏng đặt hẹn lưu trữ trên LocalStorage theo đặc tả. Nhân viên hỗ trợ sẽ liên hệ xác nhận trong giờ làm việc.
                </p>
              </form>
            </div>

          </div>
        </div>

      </div>

      {/* Appointment Confirmation Popup Modal */}
      {successBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-blue-100 relative text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <h3 className="text-xl font-extrabold text-[#092D63] mb-1">
              Đăng ký lịch khám thành công!
            </h3>
            <p className="text-xs text-amber-600 font-semibold mb-4 bg-amber-50 py-1.5 px-3 rounded-full inline-block">
              ⚠️ Đây là lịch hẹn mô phỏng (Demo LocalStorage)
            </p>

            <div className="bg-[#F8FBFE] border border-[#DCEAF3] rounded-xl p-4 text-left space-y-2 text-xs sm:text-sm mb-5">
              <div className="flex justify-between items-center pb-2 border-b border-[#DCEAF3]">
                <span className="text-[#62758E]">Mã đặt hẹn:</span>
                <span className="font-mono font-bold text-[#0869C8] text-base">
                  {successBooking.bookingCode}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#62758E]">Họ tên bệnh nhân:</span>
                <span className="font-semibold text-[#102B55]">{successBooking.fullName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#62758E]">Số điện thoại:</span>
                <span className="font-semibold text-[#102B55]">{successBooking.phone}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#62758E]">Chuyên khoa:</span>
                <span className="font-semibold text-[#00A9B9]">{successBooking.specialty}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#62758E]">Ngày khám:</span>
                <span className="font-semibold text-[#102B55]">{successBooking.appointmentDate}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setSuccessBooking(null)}
              className="w-full py-3 rounded-lg bg-[#0869C8] text-white font-bold text-sm hover:bg-[#0759ab] shadow-sm transition-colors"
            >
              Hoàn tất & Đóng
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
