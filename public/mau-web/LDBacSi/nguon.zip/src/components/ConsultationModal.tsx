import React, { useState } from 'react';
import { X, MessageCircle, Phone, CheckCircle2, ShieldCheck, Heart } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [symptom, setSymptom] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setName('');
      setPhone('');
      setSymptom('');
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-gray-100 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
          aria-label="Đóng"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-[#092D63] mb-2">
              Yêu cầu tư vấn đã được gửi!
            </h3>
            <p className="text-sm text-[#62758E] leading-relaxed">
              Bác sĩ trực tổng đài MedCare sẽ gọi lại cho bạn qua số điện thoại{' '}
              <strong className="text-[#0869C8]">{phone}</strong> trong vòng 10 phút tới.
            </p>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-[#E5F6FF] text-[#0869C8] flex items-center justify-center shrink-0">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-[#00A9B9] tracking-wider block">
                  Hỗ trợ 24/7 Miễn Phí
                </span>
                <h3 className="text-xl font-bold text-[#092D63]">
                  Tư vấn sức khỏe trực tuyến
                </h3>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#62758E] mb-5 leading-relaxed">
              Nhận lời khuyên sơ bộ từ bác sĩ chuyên khoa hoặc hướng dẫn đăng ký khám bệnh phù hợp nhất với tình trạng của bạn.
            </p>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-[#102B55] uppercase mb-1">
                  Họ và tên
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ví dụ: Nguyễn Văn An"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#DCEAF3] bg-[#F8FBFE] text-[#102B55] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#102B55] uppercase mb-1">
                  Số điện thoại
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Ví dụ: 0912345678"
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#DCEAF3] bg-[#F8FBFE] text-[#102B55] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#102B55] uppercase mb-1">
                  Tình trạng sức khỏe / Triệu chứng cần tư vấn
                </label>
                <textarea
                  rows={3}
                  value={symptom}
                  onChange={(e) => setSymptom(e.target.value)}
                  placeholder="Mô tả ngắn gọn dấu hiệu bạn đang gặp phải..."
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-[#DCEAF3] bg-[#F8FBFE] text-[#102B55] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#0869C8]"
                />
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-lg bg-[#0869C8] text-white font-bold text-sm hover:bg-[#0759ab] shadow-sm transition-colors"
                >
                  Gửi yêu cầu tư vấn
                </button>
                <a
                  href="tel:19003366"
                  className="p-3 rounded-lg bg-[#F3FAFE] border border-[#DCEAF3] text-[#0869C8] hover:bg-[#E5F6FF] flex items-center justify-center transition-colors"
                  title="Gọi trực tiếp 1900 3366"
                >
                  <Phone className="w-5 h-5" />
                </a>
              </div>

              <div className="pt-2 flex items-center justify-center gap-2 text-xs text-[#62758E]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#13B995]" />
                <span>Hoàn toàn miễn phí & thông tin được bảo mật</span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
