import React, { useState } from 'react';
import { Award, CalendarDays, ArrowRight, X, Stethoscope, CheckCircle2 } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';
import { DoctorItem } from '../types/medcare';

interface DoctorsSectionProps {
  onSelectDoctorToBook: (specialtyName: string, doctorName: string) => void;
}

export const DoctorsSection: React.FC<DoctorsSectionProps> = ({ onSelectDoctorToBook }) => {
  const [selectedDoctor, setSelectedDoctor] = useState<DoctorItem | null>(null);

  // Map doctor specialty to appointment form option
  const mapSpecialtyToForm = (specialty: string) => {
    if (specialty.includes('Tim mạch')) return 'Tim mạch';
    if (specialty.includes('Nhi')) return 'Nhi khoa';
    if (specialty.includes('Nội tổng quát')) return 'Nội tổng quát';
    if (specialty.includes('Sản phụ')) return 'Sản phụ khoa';
    return 'Khám tổng quát';
  };

  return (
    <section id="doctors" className="py-16 sm:py-20 bg-[#F8FBFE]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div className="max-w-2xl">
            <span className="text-xs sm:text-sm font-bold text-[#0869C8] tracking-widest uppercase block mb-2">
              ĐỘI NGŨ BÁC SĨ
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-extrabold text-[#092D63] tracking-tight">
              Các bác sĩ chuyên khoa
            </h2>
            <p className="text-sm sm:text-base text-[#62758E] mt-2.5 leading-relaxed">
              Quy tụ đội ngũ bác sĩ giỏi, tận tâm và giàu kinh nghiệm trong nhiều lĩnh vực y tế.
            </p>
          </div>

          <a
            href="#doctors"
            className="inline-flex items-center gap-2 text-sm font-bold text-[#0869C8] hover:text-[#00A9B9] transition-colors group shrink-0"
          >
            <span>Xem tất cả bác sĩ</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Doctors Grid: 4 cols desktop, 2 cols tablet, 1 col mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {MEDCARE_DATA.doctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white rounded-xl border border-[#E3EDF5] shadow-[0_4px_18px_rgba(15,55,100,0.06)] hover:shadow-[0_8px_25px_rgba(15,55,100,0.12)] hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col justify-between"
            >
              {/* Card Body with image on left (38%) and text on right */}
              <div className="flex p-3 sm:p-4 gap-3.5 items-stretch min-h-[140px]">
                {/* Image (left 38%) */}
                <div className="w-[38%] rounded-lg overflow-hidden bg-blue-50 relative shrink-0">
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full bg-[#13B995] ring-2 ring-white" title="Đang làm việc" />
                </div>

                {/* Text (right) */}
                <div className="w-[62%] flex flex-col justify-between">
                  <div>
                    <span className="inline-block text-[11px] font-bold text-[#00A9B9] uppercase tracking-wide">
                      {doctor.specialty}
                    </span>
                    <h3
                      onClick={() => setSelectedDoctor(doctor)}
                      className="text-sm font-bold text-[#102B55] hover:text-[#0869C8] cursor-pointer transition-colors leading-snug line-clamp-2 mt-0.5"
                    >
                      {doctor.name}
                    </h3>
                  </div>

                  <div className="mt-2 pt-2 border-t border-gray-100 flex items-center gap-1.5 text-xs text-[#62758E]">
                    <Award className="w-3.5 h-3.5 text-[#0869C8] shrink-0" />
                    <span className="truncate">{doctor.experience}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-3 pb-3 pt-1 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const formSpecialty = mapSpecialtyToForm(doctor.specialty);
                    onSelectDoctorToBook(formSpecialty, doctor.name);
                    const el = document.getElementById('appointment');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex-1 py-2 px-2.5 rounded-lg bg-[#E5F6FF] hover:bg-[#0869C8] text-[#0869C8] hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors duration-200"
                >
                  <CalendarDays className="w-3.5 h-3.5" />
                  <span>Đặt lịch khám</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedDoctor(doctor)}
                  className="py-2 px-2.5 rounded-lg border border-[#DCEAF3] hover:bg-gray-50 text-xs text-[#62758E] font-medium transition-colors"
                  title="Xem hồ sơ chi tiết"
                >
                  Hồ sơ
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Doctor Profile Modal */}
      {selectedDoctor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-gray-100 relative">
            <button
              onClick={() => setSelectedDoctor(null)}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Đóng"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-4">
              <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 border-2 border-blue-100">
                <img
                  src={selectedDoctor.image}
                  alt={selectedDoctor.name}
                  className="w-full h-full object-cover object-top"
                />
              </div>
              <div>
                <span className="text-xs font-bold text-[#00A9B9] uppercase tracking-wider block">
                  {selectedDoctor.specialty}
                </span>
                <h3 className="text-lg font-bold text-[#092D63]">
                  {selectedDoctor.name}
                </h3>
                <p className="text-xs text-[#62758E] font-medium mt-0.5">
                  {selectedDoctor.degree}
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#F3FAFE] border border-[#DCEAF3] space-y-2 mb-4 text-xs text-[#102B55]">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#0869C8] shrink-0" />
                <span className="font-semibold">{selectedDoctor.experience}</span>
              </div>
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-[#00A9B9] shrink-0" />
                <span>Thăm khám tại Phòng khám MedCare Hà Nội</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#13B995] shrink-0" />
                <span>Tiếp nhận đặt lịch trực tuyến có ưu tiên khám</span>
              </div>
            </div>

            <p className="text-xs text-[#62758E] leading-relaxed mb-5">
              {selectedDoctor.bio}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  const formSpecialty = mapSpecialtyToForm(selectedDoctor.specialty);
                  onSelectDoctorToBook(formSpecialty, selectedDoctor.name);
                  setSelectedDoctor(null);
                  const el = document.getElementById('appointment');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex-1 py-2.5 px-4 rounded-lg bg-[#0869C8] text-white font-semibold text-xs sm:text-sm hover:bg-[#0759ab] flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <CalendarDays className="w-4 h-4" />
                <span>Đặt lịch với bác sĩ này</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedDoctor(null)}
                className="py-2.5 px-4 rounded-lg bg-gray-100 text-gray-700 font-semibold text-xs sm:text-sm hover:bg-gray-200 transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
