import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2 } from 'lucide-react';
import { Logo } from './Logo';
import { MEDCARE_DATA } from '../data/medcareData';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
    }, 2000);
  };

  return (
    <footer
      id="contact"
      className="text-white relative overflow-hidden"
      style={{
        background: 'linear-gradient(110deg, #063467 0%, #052B56 100%)',
      }}
    >
      {/* Decorative top border highlight */}
      <div className="h-1 w-full bg-gradient-to-r from-[#0869C8] via-[#00A9B9] to-[#20CDB9]" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 pt-12 pb-6">
        
        {/* 5 columns on desktop, 2 on tablet, 1 on mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-10 border-b border-white/10">
          
          {/* Col 1: Brand & Socials */}
          <div className="space-y-4 lg:col-span-1">
            <Logo variant="light" showTagline={false} />
            <p className="text-xs sm:text-sm text-blue-100/80 leading-relaxed">
              Hệ thống y tế MedCare - đồng hành cùng bạn và gia đình trên hành trình chăm sóc sức khỏe toàn diện.
            </p>
            
            {/* Social Links */}
            <div className="flex items-center gap-2.5 pt-2">
              {/* Facebook */}
              <a
                href="#"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#0869C8] flex items-center justify-center transition-colors text-white"
                aria-label="Facebook MedCare"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>

              {/* YouTube */}
              <a
                href="#"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-red-600 flex items-center justify-center transition-colors text-white"
                aria-label="YouTube MedCare"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                </svg>
              </a>

              {/* Instagram */}
              <a
                href="#"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-gradient-to-tr hover:from-yellow-500 hover:via-pink-500 hover:to-purple-500 flex items-center justify-center transition-all text-white"
                aria-label="Instagram MedCare"
              >
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Liên kết nhanh
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-blue-100/80">
              <li>
                <a href="#home" className="hover:text-[#20CDB9] transition-colors">
                  Trang chủ
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Dịch vụ y tế
                </a>
              </li>
              <li>
                <a href="#doctors" className="hover:text-[#20CDB9] transition-colors">
                  Đội ngũ bác sĩ
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#20CDB9] transition-colors">
                  Giới thiệu MedCare
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#20CDB9] transition-colors">
                  Liên hệ & Địa chỉ
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Services */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Dịch vụ
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-blue-100/80">
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Khám tổng quát
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Xét nghiệm máu & hóa sinh
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Chuyên khoa Tim mạch
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Chuyên khoa Nhi
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Chẩn đoán hình ảnh MRI / X-quang
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-[#20CDB9] transition-colors">
                  Tư vấn online 24/7
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Info */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Thông tin liên hệ
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm text-blue-100/80">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#20CDB9] shrink-0 mt-0.5" />
                <a href="tel:19003366" className="hover:text-[#20CDB9] font-bold text-white">
                  {MEDCARE_DATA.brand.hotline}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#20CDB9] shrink-0 mt-0.5" />
                <a href="mailto:cskh@medcare.vn" className="hover:text-[#20CDB9]">
                  {MEDCARE_DATA.brand.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#20CDB9] shrink-0 mt-0.5" />
                <span>{MEDCARE_DATA.brand.address}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#20CDB9] shrink-0 mt-0.5" />
                <span>{MEDCARE_DATA.brand.workingHours}</span>
              </li>
            </ul>
          </div>

          {/* Col 5: Newsletter */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-2">
              Đăng ký nhận tin sức khỏe
            </h4>
            <p className="text-xs text-blue-100/80 mb-3.5 leading-relaxed">
              Cập nhật những thông tin y tế hữu ích nhất từ các chuyên gia hàng tuần.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Nhập email của bạn"
                  required
                  className="w-full px-3.5 py-2.5 text-xs rounded-lg bg-white/10 border border-white/20 text-white placeholder-blue-200/60 focus:outline-none focus:ring-2 focus:ring-[#20CDB9] focus:bg-white/15"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 px-3 rounded-lg text-xs font-bold text-white flex items-center justify-center gap-1.5 shadow-sm hover:brightness-110 active:scale-95 transition-all"
                style={{ backgroundColor: '#0789E1' }}
              >
                <Send className="w-3.5 h-3.5" />
                <span>Gửi đăng ký</span>
              </button>
            </form>

            {subscribed && (
              <div className="mt-2 text-[11px] text-[#20CDB9] flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>Đã ghi nhận đăng ký thành công!</span>
              </div>
            )}
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-blue-200/70 gap-3 text-center sm:text-left">
          <p>© 2026 MedCare. Tất cả quyền được bảo lưu.</p>
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap justify-center">
            <a href="#" className="hover:text-white transition-colors">
              Chính sách bảo mật
            </a>
            <span>•</span>
            <a href="#" className="hover:text-white transition-colors">
              Điều khoản sử dụng
            </a>
            <span>•</span>
            <a href="#" className="hover:text-white transition-colors">
              Sơ đồ website
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
