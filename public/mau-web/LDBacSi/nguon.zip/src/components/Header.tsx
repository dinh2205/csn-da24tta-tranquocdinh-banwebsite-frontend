import React, { useState, useEffect } from 'react';
import { Search, PhoneCall, CalendarDays, Menu, X, Clock } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenMyAppointments: () => void;
  appointmentCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenMyAppointments,
  appointmentCount,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'services', 'about', 'doctors', 'appointment', 'contact'];
      const scrollPosition = window.scrollY + 120;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Trang chủ', href: '#home', id: 'home' },
    { label: 'Dịch vụ', href: '#services', id: 'services' },
    { label: 'Bác sĩ', href: '#doctors', id: 'doctors' },
    { label: 'Giới thiệu', href: '#about', id: 'about' },
    { label: 'Liên hệ', href: '#contact', id: 'contact' },
  ];

  return (
    <header
      className={`sticky top-0 z-50 w-full bg-white transition-all duration-300 ${
        isScrolled ? 'shadow-md py-2.5 bg-white/95 backdrop-blur-md' : 'py-4'
      }`}
      style={{ minHeight: '80px' }}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 flex items-center justify-between h-full">
        {/* Logo */}
        <Logo variant="dark" />

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-7">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <a
                key={item.href}
                href={item.href}
                className={`relative py-1 text-[15px] font-semibold transition-colors duration-200 ${
                  isActive ? 'text-[#0869C8]' : 'text-[#102B55] hover:text-[#0869C8]'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[2.5px] bg-[#0869C8] rounded-full animate-fade-in" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="hidden md:flex items-center gap-4">
          {/* Quick Search */}
          <button
            onClick={onOpenSearch}
            className="p-2.5 text-[#62758E] hover:text-[#0869C8] hover:bg-[#F3FAFE] rounded-full transition-colors border border-transparent hover:border-[#DCEAF3]"
            title="Tìm kiếm dịch vụ & bác sĩ"
            aria-label="Tìm kiếm"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Hotline */}
          <a
            href="tel:19003366"
            className="flex items-center gap-2.5 px-3.5 py-2 rounded-lg bg-[#F3FAFE] border border-[#DCEAF3] hover:border-[#0869C8]/40 hover:bg-[#E5F6FF] transition-all group"
          >
            <div className="w-8 h-8 rounded-full bg-[#0869C8]/10 text-[#0869C8] flex items-center justify-center group-hover:scale-105 transition-transform">
              <PhoneCall className="w-4 h-4 text-[#0869C8]" />
            </div>
            <div className="text-left">
              <span className="text-[11px] block font-medium text-[#62758E] uppercase tracking-wider">
                Hotline 24/7
              </span>
              <span className="text-sm font-bold text-[#092D63] tracking-wide">
                1900 3366
              </span>
            </div>
          </a>

          {/* Saved Appointments Badge if any */}
          {appointmentCount > 0 && (
            <button
              onClick={onOpenMyAppointments}
              className="relative px-3 py-2 text-xs font-semibold text-[#0869C8] bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors flex items-center gap-1.5"
              title="Xem lịch khám đã đặt"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Lịch hẹn ({appointmentCount})</span>
            </button>
          )}

          {/* Appointment CTA */}
          <a
            href="#appointment"
            className="flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#0869C8] hover:bg-[#0759ab] rounded-lg shadow-sm hover:shadow-md hover:shadow-blue-500/25 active:scale-95 transition-all duration-200"
          >
            <CalendarDays className="w-4 h-4" />
            <span>Đặt lịch khám</span>
          </a>
        </div>

        {/* Mobile menu button */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={onOpenSearch}
            className="p-2 text-[#62758E] hover:text-[#0869C8] rounded-lg"
            aria-label="Tìm kiếm"
          >
            <Search className="w-5 h-5" />
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#102B55] hover:text-[#0869C8] rounded-lg focus:outline-none"
            aria-label="Mở menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#DCEAF3] bg-white px-5 py-4 space-y-3 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-3 py-2.5 rounded-lg text-base font-semibold ${
                  activeSection === item.id
                    ? 'bg-[#E5F6FF] text-[#0869C8]'
                    : 'text-[#102B55] hover:bg-[#F3FAFE]'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-[#DCEAF3] space-y-2.5">
            <a
              href="tel:19003366"
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-[#F3FAFE] border border-[#DCEAF3] text-sm font-bold text-[#0869C8]"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Hotline 24/7: 1900 3366</span>
            </a>

            {appointmentCount > 0 && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenMyAppointments();
                }}
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg bg-blue-50 border border-blue-200 text-sm font-bold text-[#0869C8]"
              >
                <Clock className="w-4 h-4" />
                <span>Xem các lịch hẹn đã đặt ({appointmentCount})</span>
              </button>
            )}

            <a
              href="#appointment"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg bg-[#0869C8] text-white text-sm font-bold shadow-md hover:bg-[#0759ab]"
            >
              <CalendarDays className="w-4 h-4" />
              <span>Đặt lịch khám ngay</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
