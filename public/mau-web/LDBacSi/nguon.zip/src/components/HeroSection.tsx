import React from 'react';
import { CalendarDays, MessageCircle, HeartPulse, ShieldCheck, Sparkles } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

interface HeroSectionProps {
  onOpenConsultationModal: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenConsultationModal }) => {
  return (
    <section
      id="home"
      className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24"
      style={{
        background: 'linear-gradient(110deg, #E7F7FF 0%, #F5FCFF 55%, #DDF9F5 100%)',
      }}
    >
      {/* Background soft decorations */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-blue-300/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-teal-300/25 rounded-full blur-3xl pointer-events-none" />

      {/* Subtle medical cross watermark */}
      <div className="absolute top-16 right-1/3 text-blue-200/40 select-none pointer-events-none">
        <svg width="120" height="120" viewBox="0 0 24 24" fill="currentColor">
          <path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z" />
        </svg>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Content (48% on desktop) */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/80 border border-blue-200 shadow-xs text-xs font-bold tracking-wider text-[#0869C8] uppercase">
              <Sparkles className="w-3.5 h-3.5 text-[#00A9B9]" />
              <span>HỆ THỐNG Y TẾ MEDCARE</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-[46px] font-extrabold leading-[1.2] tracking-tight">
              <span className="block text-[#092D63]">Chăm sóc sức khỏe</span>
              <span className="block text-[#075E9E]">toàn diện cho bạn</span>
              <span className="block text-[#00A9B9]">và gia đình</span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-[#62758E] max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
              Với đội ngũ bác sĩ giàu kinh nghiệm, trang thiết bị hiện đại và dịch vụ tận tâm, chúng tôi đồng hành cùng bạn trên hành trình sống khỏe mạnh, hạnh phúc hơn mỗi ngày.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <a
                href="#appointment"
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-lg text-white font-semibold text-base bg-[#0869C8] hover:bg-[#0759ab] shadow-md shadow-blue-600/20 hover:shadow-lg transition-all duration-200 group"
              >
                <CalendarDays className="w-5 h-5 text-white/90 group-hover:scale-110 transition-transform" />
                <span>Đặt lịch ngay</span>
              </a>

              <button
                type="button"
                onClick={onOpenConsultationModal}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-lg text-[#0869C8] font-semibold text-base bg-white border border-[#0869C8]/30 hover:border-[#0869C8] hover:bg-[#F3FAFE] shadow-sm transition-all duration-200"
              >
                <MessageCircle className="w-5 h-5 text-[#00A9B9]" />
                <span>Tư vấn miễn phí</span>
              </button>
            </div>

            {/* Key trust bullets */}
            <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-5 text-xs text-[#62758E] font-medium border-t border-blue-100/80">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#13B995]" />
                <span>Đạt chuẩn Bộ Y Tế</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00A9B9]" />
                <span>Không mất phí chờ đợi</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0869C8]" />
                <span>Bảo mật hồ sơ 100%</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual (52% on desktop) */}
          <div className="lg:col-span-6 relative flex flex-col items-center">
            {/* Handwritten decoration note */}
            <div className="mb-2 w-full flex justify-center lg:justify-end pr-2">
              <p
                className="text-lg sm:text-xl font-bold tracking-wide italic text-[#087BAE]"
                style={{ fontFamily: "'Caveat', cursive, sans-serif" }}
              >
                ✦ Sức khỏe hôm nay - Cuộc sống tươi sáng ngày mai ✦
              </p>
            </div>

            {/* Main Visual Image Card */}
            <div className="relative w-full max-w-[530px] rounded-2xl overflow-hidden bg-gradient-to-b from-white/60 to-white/90 p-2.5 shadow-2xl shadow-blue-900/10 border border-white">
              <div className="relative rounded-xl overflow-hidden aspect-[4/3] bg-blue-50">
                <img
                  src={MEDCARE_DATA.images.heroDoctors}
                  alt="Đội ngũ bác sĩ và chuyên gia y tế MedCare"
                  className="w-full h-full object-cover object-center"
                  loading="eager"
                />

                {/* Subtle gradient overlay at bottom */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#092D63]/50 via-transparent to-transparent pointer-events-none" />

                {/* Mini bottom doctor label */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs bg-black/40 backdrop-blur-md px-3.5 py-2 rounded-lg">
                  <span className="font-medium">Đội ngũ chuyên gia đầu ngành & Điều dưỡng tận tâm</span>
                  <span className="text-[#20CDB9] font-bold">MedCare Team</span>
                </div>
              </div>

              {/* Floating Badge (Vì sức khỏe của cộng đồng Việt Nam) */}
              <div className="absolute -bottom-4 -left-3 sm:-left-5 bg-white rounded-2xl p-3.5 sm:p-4 shadow-xl shadow-blue-950/15 border border-[#DCEAF3] flex items-center gap-3.5 max-w-[270px] animate-bounce-subtle">
                <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-[#0869C8] to-[#20CDB9] flex items-center justify-center shrink-0 shadow-md">
                  <HeartPulse className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#0869C8]">Sứ mệnh cao quý</div>
                  <div className="text-xs sm:text-sm font-bold text-[#102B55] leading-snug">
                    Vì sức khỏe của cộng đồng Việt Nam
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
