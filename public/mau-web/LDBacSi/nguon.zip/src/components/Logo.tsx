import React from 'react';

interface LogoProps {
  variant?: 'light' | 'dark';
  showTagline?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ variant = 'dark', showTagline = true, className = '' }) => {
  const isLight = variant === 'light';

  return (
    <a href="#home" className={`flex items-center gap-3 group text-left ${className}`}>
      {/* Brand Icon Badge */}
      <div className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-tr from-[#0869C8] to-[#00A9B9] shadow-md shadow-cyan-600/20 group-hover:scale-105 transition-transform duration-300">
        <svg
          viewBox="0 0 24 24"
          className="w-6 h-6 text-white stroke-current fill-none"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Medical Cross with Heartbeat */}
          <path d="M12 3v4m0 10v4M3 12h4m10 0h4" />
          <path d="M7 12h2l1.5-3 3 6 1.5-3h2" />
        </svg>
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#20CDB9] rounded-full ring-2 ring-white"></span>
      </div>

      {/* Brand Text & Tagline */}
      <div className="flex flex-col">
        <div className="flex items-center">
          <span className={`text-2xl font-bold tracking-tight ${isLight ? 'text-white' : 'text-[#092D63]'}`}>
            Med<span className="text-[#00A9B9]">Care</span>
          </span>
          <span className="ml-1 w-1.5 h-1.5 rounded-full bg-[#20CDB9]"></span>
        </div>
        {showTagline && (
          <span className={`text-[11px] leading-tight font-medium ${isLight ? 'text-blue-100/80' : 'text-[#62758E]'}`}>
            Vì một cuộc sống khỏe mạnh hơn
          </span>
        )}
      </div>
    </a>
  );
};
