import React from 'react';
import { X, Calendar, User, Phone, Stethoscope, Trash2, Clock, CheckCircle2 } from 'lucide-react';
import { AppointmentRecord } from '../types/medcare';

interface MyAppointmentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointments: AppointmentRecord[];
  onCancelAppointment: (id: string) => void;
  onClearAll: () => void;
}

export const MyAppointmentsModal: React.FC<MyAppointmentsModalProps> = ({
  isOpen,
  onClose,
  appointments,
  onCancelAppointment,
  onClearAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-100 relative max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#DCEAF3]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#E5F6FF] text-[#0869C8] flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#092D63]">
                Lịch khám của bạn
              </h3>
              <p className="text-xs text-[#62758E]">
                Dữ liệu mô phỏng được lưu trong LocalStorage ({appointments.length})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full"
            aria-label="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body list */}
        <div className="py-4 overflow-y-auto space-y-3.5 flex-1">
          {appointments.length === 0 ? (
            <div className="text-center py-10 text-[#62758E]">
              <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-sm font-semibold text-[#102B55]">
                Chưa có lịch hẹn nào được ghi nhận
              </p>
              <p className="text-xs text-gray-400 mt-1">
                Hãy điền form bên dưới phần "Đặt lịch khám" để tạo lịch hẹn mô phỏng.
              </p>
            </div>
          ) : (
            appointments.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl border border-[#DCEAF3] bg-[#F8FBFE] hover:bg-white transition-all space-y-2.5 shadow-2xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#0869C8] bg-blue-100/70 px-2 py-0.5 rounded">
                      {item.bookingCode}
                    </span>
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        item.status === 'confirmed'
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'bg-red-100 text-red-700'
                      }`}
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      {item.status === 'confirmed' ? 'Đã xác nhận' : 'Đã hủy'}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onCancelAppointment(item.id)}
                    className="text-xs text-red-500 hover:text-red-700 font-semibold p-1 hover:bg-red-50 rounded transition-colors flex items-center gap-1"
                    title="Xóa lịch này"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hủy</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="flex items-center gap-1.5 text-[#102B55]">
                    <User className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className="font-medium truncate">{item.fullName}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#102B55]">
                    <Phone className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span>{item.phone}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#00A9B9]">
                    <Stethoscope className="w-3.5 h-3.5 shrink-0" />
                    <span className="font-semibold">{item.specialty}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#0869C8]">
                    <Calendar className="w-3.5 h-3.5 shrink-0" />
                    <span className="font-semibold">{item.appointmentDate}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#DCEAF3] flex items-center justify-between">
          {appointments.length > 0 ? (
            <button
              type="button"
              onClick={onClearAll}
              className="text-xs text-gray-400 hover:text-red-500 font-medium transition-colors"
            >
              Xóa tất cả dữ liệu mẫu
            </button>
          ) : (
            <span />
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-[#0869C8] text-white text-xs font-bold hover:bg-[#0759ab] transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
