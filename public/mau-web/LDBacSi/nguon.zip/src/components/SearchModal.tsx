import React, { useState } from 'react';
import { Search, X, Stethoscope, User, ArrowRight } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (specialty: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredServices = MEDCARE_DATA.services.filter(
    (s) =>
      s.title.toLowerCase().includes(query.toLowerCase()) ||
      s.description.toLowerCase().includes(query.toLowerCase())
  );

  const filteredDoctors = MEDCARE_DATA.doctors.filter(
    (d) =>
      d.name.toLowerCase().includes(query.toLowerCase()) ||
      d.specialty.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-gray-100 overflow-hidden">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-[#DCEAF3] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#0869C8] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Tìm dịch vụ, chuyên khoa hoặc tên bác sĩ (ví dụ: Tim mạch, Nhi, BS. Minh...)"
            className="w-full text-sm sm:text-base text-[#102B55] placeholder-gray-400 focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full"
            aria-label="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-4">
          {/* Services Matches */}
          {filteredServices.length > 0 && (
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-[#0869C8] mb-2">
                Dịch vụ ({filteredServices.length})
              </div>
              <div className="space-y-1.5">
                {filteredServices.map((service) => (
                  <div
                    key={service.id}
                    onClick={() => {
                      onSelectResult(service.title);
                      onClose();
                      const el = document.getElementById('appointment');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="p-3 rounded-xl hover:bg-[#F3FAFE] border border-transparent hover:border-[#DCEAF3] flex items-center justify-between cursor-pointer group transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0869C8] flex items-center justify-center">
                        <Stethoscope className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#102B55] group-hover:text-[#0869C8]">
                          {service.title}
                        </div>
                        <div className="text-xs text-[#62758E] line-clamp-1">
                          {service.description}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-[#0869C8] group-hover:translate-x-1 transition-all" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Doctors Matches */}
          {filteredDoctors.length > 0 && (
            <div className="pt-2">
              <div className="text-xs font-bold uppercase tracking-wider text-[#00A9B9] mb-2">
                Bác sĩ ({filteredDoctors.length})
              </div>
              <div className="space-y-1.5">
                {filteredDoctors.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => {
                      onSelectResult(doc.specialty);
                      onClose();
                      const el = document.getElementById('appointment');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="p-3 rounded-xl hover:bg-[#F0FCFA] border border-transparent hover:border-teal-100 flex items-center justify-between cursor-pointer group transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full overflow-hidden bg-teal-50 shrink-0 border border-teal-200">
                        <img src={doc.image} alt={doc.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#102B55] group-hover:text-[#00A9B9]">
                          {doc.name}
                        </div>
                        <div className="text-xs text-[#62758E]">
                          {doc.specialty} • {doc.experience}
                        </div>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-[#00A9B9] group-hover:translate-x-1 transition-all" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {filteredServices.length === 0 && filteredDoctors.length === 0 && (
            <div className="py-8 text-center text-sm text-[#62758E]">
              Không tìm thấy kết quả phù hợp với từ khóa "{query}". Bạn có thể thử tìm "Tim mạch", "Nhi", "Xét nghiệm"...
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="bg-[#F8FBFE] p-3 px-4 border-t border-[#DCEAF3] flex items-center justify-between text-xs text-[#62758E]">
          <span>Gợi ý: Tìm chuyên khoa để đặt lịch nhanh</span>
          <button
            onClick={onClose}
            className="text-[#0869C8] font-semibold hover:underline"
          >
            Đóng cửa sổ
          </button>
        </div>
      </div>
    </div>
  );
};
