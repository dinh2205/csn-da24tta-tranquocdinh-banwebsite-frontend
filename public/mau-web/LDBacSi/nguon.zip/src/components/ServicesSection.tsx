import React, { useState } from 'react';
import {
  Stethoscope,
  TestTube,
  HeartPulse,
  Baby,
  Scan,
  MessagesSquare,
  ArrowRight,
  ChevronRight,
  CheckCircle2,
  CalendarDays,
  X,
} from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';
import { ServiceItem } from '../types/medcare';

interface ServicesSectionProps {
  onSelectServiceToBook: (specialtyName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectServiceToBook }) => {
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);

  const renderIcon = (iconName: string, color: string) => {
    const props = { className: 'w-7 h-7', style: { color } };
    switch (iconName) {
      case 'stethoscope':
        return <Stethoscope {...props} />;
      case 'test-tube':
        return <TestTube {...props} />;
      case 'heart-pulse':
        return <HeartPulse {...props} />;
      case 'baby':
        return <Baby {...props} />;
      case 'scan':
        return <Scan {...props} />;
      case 'messages-square':
        return <MessagesSquare {...props} />;
      default:
        return <Stethoscope {...props} />;
    }
  };

  return (
    <section id="services" className="py-16 sm:py-20 bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div className="max-w-2xl">
            <span className="text-xs sm:text-sm font-bold text-[#0869C8] tracking-widest uppercase block mb-2">
              DỊCH VỤ NỔI BẬT
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-extrabold text-[#092D63] tracking-tight">
              Danh mục dịch vụ y tế
            </h2>
            <p className="text-sm sm:text-base text-[#62758E] mt-2.5 leading-relaxed">
              Cung cấp các dịch vụ khám chữa bệnh chất lượng cao, đáp ứng nhu cầu chăm sóc sức khỏe toàn diện cho mọi lứa tuổi.
            </p>
          </div>

          <a
            href="#services"
            className="inline-flex items-center gap-2 text-sm font-bold text-[#0869C8] hover:text-[#00A9B9] transition-colors group shrink-0"
          >
            <span>Xem tất cả dịch vụ</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Services Grid: 6 cols on desktop, 3 on tablet, 2 on mobile */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {MEDCARE_DATA.services.map((service) => (
            <div
              key={service.id}
              onClick={() => setSelectedService(service)}
              className="group cursor-pointer rounded-xl p-5 border border-[#E3EDF5] shadow-xs hover:shadow-[0_8px_24px_rgba(8,105,200,0.12)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col items-center text-center justify-between"
              style={{ backgroundColor: service.background }}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter') setSelectedService(service);
              }}
            >
              <div className="w-full flex flex-col items-center">
                {/* Icon wrapper */}
                <div
                  className="w-14 h-14 rounded-2xl bg-white shadow-xs flex items-center justify-center mb-4 transition-transform group-hover:scale-110 group-hover:rotate-2 border border-black/5"
                >
                  {renderIcon(service.icon, service.iconColor)}
                </div>

                {/* Title */}
                <h3 className="text-sm sm:text-base font-bold text-[#102B55] mb-2 group-hover:text-[#0869C8] transition-colors leading-snug line-clamp-2">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-[#62758E] line-clamp-3 leading-relaxed">
                  {service.description}
                </p>
              </div>

              {/* View detail button icon */}
              <div className="mt-4 pt-3 border-t border-black/5 w-full flex items-center justify-center text-xs font-semibold text-[#0869C8] opacity-90 group-hover:opacity-100">
                <span className="text-[11px]">Chi tiết</span>
                <ChevronRight className="w-3.5 h-3.5 ml-0.5 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-gray-100 relative">
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Đóng"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3.5 mb-4">
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center shadow-xs"
                style={{ backgroundColor: selectedService.background }}
              >
                {renderIcon(selectedService.icon, selectedService.iconColor)}
              </div>
              <div>
                <span className="text-xs uppercase font-bold text-[#00A9B9] tracking-wider">
                  Chuyên khoa MedCare
                </span>
                <h3 className="text-xl font-bold text-[#092D63]">
                  {selectedService.title}
                </h3>
              </div>
            </div>

            <p className="text-sm text-[#102B55] font-semibold mb-3">
              {selectedService.description}
            </p>

            <p className="text-sm text-[#62758E] leading-relaxed mb-5 bg-[#F3FAFE] p-4 rounded-xl border border-[#DCEAF3]">
              {selectedService.details ||
                "Dịch vụ được thực hiện bởi đội ngũ bác sĩ chuyên khoa giàu kinh nghiệm kết hợp cùng trang thiết bị chẩn đoán tân tiến."}
            </p>

            <div className="space-y-2 mb-6 text-xs text-[#102B55]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#13B995]" />
                <span>Quy trình vô trùng, máy móc nhập khẩu từ Đức và Nhật Bản</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#13B995]" />
                <span>Trả kết quả nhanh qua cổng thông tin bệnh án điện tử</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#13B995]" />
                <span>Bác sĩ trực tiếp tư vấn cặn kẽ sau khi thăm khám</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  onSelectServiceToBook(selectedService.title);
                  setSelectedService(null);
                  const el = document.getElementById('appointment');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="flex-1 py-3 px-4 rounded-lg bg-[#0869C8] text-white font-semibold text-sm hover:bg-[#0759ab] flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <CalendarDays className="w-4 h-4" />
                <span>Đặt lịch khám chuyên khoa này</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedService(null)}
                className="py-3 px-4 rounded-lg bg-gray-100 text-gray-700 font-semibold text-sm hover:bg-gray-200 transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
