import React from 'react';
import { UserRound, Users, Clock, Heart } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

export const StatisticsSection: React.FC = () => {
  const getIcon = (iconName: string, color: string) => {
    const props = { className: 'w-7 h-7', style: { color } };
    switch (iconName) {
      case 'user-round':
        return <UserRound {...props} />;
      case 'users-round':
        return <Users {...props} />;
      case 'clock':
        return <Clock {...props} />;
      case 'heart':
        return <Heart {...props} />;
      default:
        return <UserRound {...props} />;
    }
  };

  return (
    <section className="relative z-20 max-w-[1200px] mx-auto px-4 sm:px-6 -mt-9 sm:-mt-10 mb-12 sm:mb-16">
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {MEDCARE_DATA.statistics.map((stat, idx) => (
          <div
            key={idx}
            className="group bg-white rounded-xl p-5 sm:p-6 border border-[#E3EDF5] shadow-[0_4px_18px_rgba(15,55,100,0.06)] hover:shadow-[0_8px_25px_rgba(15,55,100,0.12)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-3">
              <span
                className="text-2xl sm:text-3xl lg:text-[32px] font-extrabold tracking-tight"
                style={{ color: stat.color }}
              >
                {stat.value}
              </span>
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                style={{ backgroundColor: `${stat.color}15` }}
              >
                {getIcon(stat.icon, stat.color)}
              </div>
            </div>

            <div>
              <h4 className="text-sm sm:text-base font-bold text-[#102B55] leading-snug">
                {stat.label}
              </h4>
              <p className="text-xs sm:text-sm text-[#62758E] font-medium mt-0.5">
                {stat.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
