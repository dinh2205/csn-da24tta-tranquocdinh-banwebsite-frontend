import React, { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote, ShieldAlert } from 'lucide-react';
import { MEDCARE_DATA } from '../data/medcareData';

export const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const reviews = MEDCARE_DATA.testimonials;

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="testimonials" className="py-16 sm:py-24 bg-white">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row items-center justify-between mb-10 gap-4 text-center sm:text-left">
          <div>
            <span className="text-xs sm:text-sm font-bold text-[#0869C8] tracking-widest uppercase block mb-2">
              CẢM NHẬN BỆNH NHÂN
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-extrabold text-[#092D63] tracking-tight">
              Khách hàng nói về chúng tôi
            </h2>
          </div>

          {/* Carousel Arrows */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrev}
              className="p-2.5 rounded-full border border-[#DCEAF3] hover:border-[#0869C8] text-[#102B55] hover:text-[#0869C8] hover:bg-[#F3FAFE] transition-colors"
              aria-label="Đánh giá trước"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              className="p-2.5 rounded-full border border-[#DCEAF3] hover:border-[#0869C8] text-[#102B55] hover:text-[#0869C8] hover:bg-[#F3FAFE] transition-colors"
              aria-label="Đánh giá tiếp theo"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reviews Grid: 3 cols desktop, 2 tablet, 1 mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, idx) => (
            <div
              key={review.id}
              className={`bg-white rounded-xl p-6 sm:p-7 border border-[#E3EDF5] shadow-[0_4px_18px_rgba(15,55,100,0.06)] hover:shadow-[0_8px_25px_rgba(15,55,100,0.12)] transition-all duration-300 flex flex-col justify-between relative ${
                idx === currentIndex ? 'ring-2 ring-[#0869C8]/20' : ''
              }`}
            >
              {/* Decorative Quote mark */}
              <div className="absolute top-5 right-5 text-blue-100">
                <Quote className="w-8 h-8 rotate-180" />
              </div>

              {/* Rating stars */}
              <div>
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-[#FFB020] text-[#FFB020]"
                    />
                  ))}
                </div>

                {/* Content */}
                <p className="text-sm sm:text-base text-[#102B55] leading-relaxed italic mb-6">
                  "{review.content}"
                </p>
              </div>

              {/* Reviewer info */}
              <div className="flex items-center gap-3.5 pt-4 border-t border-gray-100">
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-blue-100 shrink-0 bg-blue-50">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#092D63]">
                    {review.name}
                  </h4>
                  <span className="text-xs text-[#62758E]">
                    {review.location}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Note required by JSON */}
        <div className="mt-8 pt-4 flex items-center justify-center gap-2 text-xs text-[#62758E] italic text-center">
          <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0" />
          <span>Dữ liệu đánh giá mô phỏng, không phải nhận xét bệnh nhân thực tế.</span>
        </div>

      </div>
    </section>
  );
};
