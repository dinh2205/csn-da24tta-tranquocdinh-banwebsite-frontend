export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  iconColor: string;
  background: string;
  details?: string;
}

export interface DoctorItem {
  id: number;
  name: string;
  specialty: string;
  experience: string;
  image: string;
  degree?: string;
  bio?: string;
}

export interface StatisticItem {
  value: string;
  label: string;
  description: string;
  icon: string;
  color: string;
}

export interface TestimonialItem {
  id: number;
  name: string;
  location: string;
  rating: number;
  image: string;
  content: string;
}

export interface AppointmentRecord {
  id: string;
  bookingCode: string;
  fullName: string;
  phone: string;
  specialty: string;
  appointmentDate: string;
  createdAt: string;
  status: 'confirmed' | 'cancelled';
}

export interface AppointmentFormData {
  fullName: string;
  phone: string;
  specialty: string;
  appointmentDate: string;
}
