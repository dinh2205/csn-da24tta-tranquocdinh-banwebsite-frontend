/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Header, NavSectionId } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { BookingModal, ModalTab } from './components/BookingModal';

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSectionId>('home');
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTab, setModalTab] = useState<ModalTab>('booking');

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      const aboutEl = document.getElementById('about');
      const servicesEl = document.getElementById('services');

      if (servicesEl && scrollPos >= servicesEl.offsetTop) {
        setActiveSection('services');
      } else if (aboutEl && scrollPos >= aboutEl.offsetTop) {
        setActiveSection('about');
      } else {
        setActiveSection('home');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (sectionId: NavSectionId) => {
    setActiveSection(sectionId);

    if (sectionId === 'home' || sectionId === 'about' || sectionId === 'services') {
      const target = document.getElementById(sectionId);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return;
    }

    if (sectionId === 'doctors') {
      const servicesTarget = document.getElementById('services');
      if (servicesTarget) {
        servicesTarget.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      setModalTab('doctors');
      setModalOpen(true);
      return;
    }

    if (sectionId === 'contact') {
      setModalTab('contact');
      setModalOpen(true);
    }
  };

  const handleOpenBooking = (defaultTab: ModalTab = 'booking') => {
    setModalTab(defaultTab);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen w-full bg-white text-[#475569] flex flex-col">
      <Header
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenBooking={handleOpenBooking}
      />

      <main className="flex-1">
        <HeroSection onOpenBooking={() => handleOpenBooking('booking')} />
        <AboutSection onOpenBooking={() => handleOpenBooking('booking')} />
        <ServicesSection />
      </main>

      <BookingModal
        isOpen={modalOpen}
        initialTab={modalTab}
        onClose={() => setModalOpen(false)}
      />
    </div>
  );
}
