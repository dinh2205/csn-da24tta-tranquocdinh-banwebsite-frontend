import React, { useState } from 'react';
import { ArrowRight, UserCheck } from 'lucide-react';

interface AboutSectionProps {
  onOpenBooking: () => void;
}

import DOCTOR_PORTRAIT_PATH from '../assets/images/vietnamese_doctor_portrait_1792081480491.jpg';

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenBooking }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="about"
      className="relative w-full bg-white lg:h-[620px] overflow-hidden"
    >
      <div className="mx-auto grid h-full max-w-[1200px] grid-cols-1 md:grid-cols-2 lg:grid-cols-[55%_45%] items-center px-5 md:px-6">
        {/* Left Column: Eyebrow, Heading, Two Paragraphs, CTA Button */}
        <div className="py-12 md:py-16 lg:py-20 pr-0 md:pr-6">
          <p className="text-[16px] md:text-[17px] font-semibold uppercase tracking-wide text-[#38B2F6]">
            VỀ VITACARE
          </p>

          <h2 className="mt-2.5 text-[30px] md:text-[32px] lg:text-[38px] font-bold leading-[1.25] text-[#102A5A]">
            Vì sao nên chọn chúng tôi?
          </h2>

          <p className="mt-6 text-[16px] font-normal leading-[1.8] text-[#475569] max-w-[560px] mb-6">
            Chúng tôi tin rằng sức khỏe là nền tảng của một cuộc sống hạnh phúc.
            VitaCare cam kết mang đến dịch vụ y tế chất lượng cao với sự tận
            tâm, minh bạch và luôn đặt người bệnh làm trung tâm.
          </p>

          <p className="text-[16px] font-normal leading-[1.8] text-[#475569] max-w-[560px] mb-8">
            Từ thăm khám tổng quát đến điều trị chuyên sâu, chúng tôi đồng hành
            cùng bạn và gia đình trong suốt hành trình chăm sóc sức khỏe, với
            phương châm “Sức khỏe của bạn là sứ mệnh của chúng tôi”.
          </p>

          <button
            type="button"
            onClick={onOpenBooking}
            className="inline-flex items-center justify-center gap-2.5 rounded-[4px] bg-[#60B9F4] px-[28px] py-[14px] text-[15px] font-semibold text-white transition-colors duration-200 hover:bg-[#38B2F6] active:bg-[#0876BD] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#102A5A]"
          >
            <span>Đặt lịch ngay</span>
            <ArrowRight className="h-4 w-4 shrink-0" />
          </button>
        </div>

        {/* Right Column: Doctor Portrait flush at bottom edge of section */}
        <div className="relative flex h-full w-full items-end justify-center lg:justify-end self-end pt-2 lg:pt-8 overflow-hidden">
          {!imgError ? (
            <img
              src={DOCTOR_PORTRAIT_PATH}
              alt="Bác sĩ VitaCare"
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="max-h-[420px] md:max-h-[500px] lg:max-h-[575px] w-auto object-contain object-bottom mix-blend-multiply select-none"
            />
          ) : (
            <div className="flex h-[420px] w-full max-w-[360px] flex-col items-center justify-center bg-slate-50 text-[#102A5A]">
              <UserCheck className="h-16 w-16 text-[#38B2F6] mb-3" />
              <span className="text-base font-semibold">Bác sĩ Chuyên khoa VitaCare</span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
