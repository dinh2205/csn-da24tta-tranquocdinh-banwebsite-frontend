import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  Phone,
  MapPin,
  CheckCircle2,
  UserCheck,
  Mail,
  ArrowRight,
} from 'lucide-react';

export type ModalTab = 'booking' | 'doctors' | 'contact';

interface BookingModalProps {
  isOpen: boolean;
  initialTab: ModalTab;
  onClose: () => void;
}

interface DoctorInfo {
  id: string;
  name: string;
  title: string;
  specialty: string;
  experience: string;
  education: string;
}

const SPECIALTIES = [
  'Khám sức khỏe tổng quát',
  'Ngoại khoa & Phẫu thuật nội soi',
  'Nội tổng quát & Tim mạch',
  'Nhi khoa toàn diện',
  'Chẩn đoán hình ảnh & Xét nghiệm',
];

const DOCTORS_LIST: DoctorInfo[] = [
  {
    id: 'bs-vinh',
    name: 'PGS.TS.BS Nguyễn Quang Vinh',
    title: 'Giám đốc Chuyên môn',
    specialty: 'Ngoại khoa & Phẫu thuật nội soi',
    experience: '22 năm kinh nghiệm',
    education: 'Tu nghiệp Chuyên khoa Ngoại tại Pháp & Singapore',
  },
  {
    id: 'bs-lan',
    name: 'TS.BS Trần Thị Minh Lan',
    title: 'Trưởng khoa Nội Tổng Quát',
    specialty: 'Nội tổng quát & Tim mạch',
    experience: '18 năm kinh nghiệm',
    education: 'Tiến sĩ Y học - Đại học Y Dược TP. Hồ Chí Minh',
  },
  {
    id: 'bs-hung',
    name: 'BS.CKII Lê Hoàng Hùng',
    title: 'Trưởng khoa Phẫu thuật Gây mê Hồi sức',
    specialty: 'Ngoại khoa & Phẫu thuật nội soi',
    experience: '16 năm kinh nghiệm',
    education: 'Bác sĩ Chuyên khoa II - Bệnh viện Chợ Rẫy',
  },
  {
    id: 'bs-thao',
    name: 'ThS.BS Phạm Phương Thảo',
    title: 'Chuyên gia Nhi khoa & Dinh dưỡng',
    specialty: 'Nhi khoa toàn diện',
    experience: '12 năm kinh nghiệm',
    education: 'Thạc sĩ Nhi khoa - Đại học Y Hà Nội',
  },
];

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  initialTab,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<ModalTab>(initialTab);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [specialty, setSpecialty] = useState(SPECIALTIES[0]);
  const [selectedDoctor, setSelectedDoctor] = useState('Tự động sắp xếp bác sĩ phù hợp');
  const [date, setDate] = useState('2026-10-16');
  const [timeSlot, setTimeSlot] = useState('09:00');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedBookingCode, setSubmittedBookingCode] = useState<string | null>(null);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab, isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmedName = fullName.trim();
    const cleanedPhone = phone.replace(/\s+/g, '');

    if (trimmedName.length < 2) {
      setErrorMsg('Vui lòng nhập họ và tên đầy đủ của người khám.');
      return;
    }

    const vnPhoneRegex = /^(0|\+84)[35789][0-9]{8}$/;
    if (!vnPhoneRegex.test(cleanedPhone)) {
      setErrorMsg('Vui lòng nhập số điện thoại hợp lệ tại Việt Nam (ví dụ: 0901234567).');
      return;
    }

    if (!date) {
      setErrorMsg('Vui lòng chọn ngày khám dự kiến.');
      return;
    }

    const randomCode = `VC-${Math.floor(100000 + Math.random() * 900000)}`;
    setSubmittedBookingCode(randomCode);
  };

  const handleSelectDoctorForBooking = (doc: DoctorInfo) => {
    setSpecialty(doc.specialty);
    setSelectedDoctor(doc.name);
    setSubmittedBookingCode(null);
    setActiveTab('booking');
  };

  const handleResetBooking = () => {
    setSubmittedBookingCode(null);
    setFullName('');
    setPhone('');
    setNotes('');
    setErrorMsg('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#102A5A]/55 p-4 backdrop-blur-[2px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="vitacare-modal-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-[640px] max-h-[90vh] overflow-y-auto rounded-[4px] bg-white shadow-2xl border border-[#E5E7EB]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Modal Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-white px-6 py-4">
          <div>
            <h2
              id="vitacare-modal-title"
              className="text-[20px] font-bold text-[#102A5A]"
            >
              Phòng khám Đa khoa Quốc tế VitaCare
            </h2>
            <p className="text-[13px] text-[#475569]">
              Hệ thống đặt lịch hẹn & thông tin dịch vụ trực tuyến
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-10 w-10 items-center justify-center rounded-[4px] text-[#475569] hover:bg-slate-100 hover:text-[#102A5A] transition-colors cursor-pointer"
            aria-label="Đóng cửa sổ"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Clean Segmented Control Tabs */}
        <div className="flex border-b border-[#E5E7EB] bg-slate-50 px-6">
          <button
            type="button"
            onClick={() => setActiveTab('booking')}
            className={`py-3 px-4 text-[14px] font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'booking'
                ? 'border-[#38B2F6] text-[#102A5A] bg-white'
                : 'border-transparent text-[#475569] hover:text-[#102A5A]'
            }`}
          >
            Đặt lịch khám
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('doctors')}
            className={`py-3 px-4 text-[14px] font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'doctors'
                ? 'border-[#38B2F6] text-[#102A5A] bg-white'
                : 'border-transparent text-[#475569] hover:text-[#102A5A]'
            }`}
          >
            Đội ngũ Bác sĩ
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('contact')}
            className={`py-3 px-4 text-[14px] font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'contact'
                ? 'border-[#38B2F6] text-[#102A5A] bg-white'
                : 'border-transparent text-[#475569] hover:text-[#102A5A]'
            }`}
          >
            Thông tin Liên hệ
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'booking' && (
            <>
              {submittedBookingCode ? (
                <div className="py-6 text-center">
                  <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[#38B2F6]/15 text-[#0876BD]">
                    <CheckCircle2 className="h-8 w-8" />
                  </div>
                  <h3 className="text-[22px] font-bold text-[#102A5A]">
                    Đăng ký lịch khám thành công
                  </h3>
                  <p className="mt-2 text-[15px] text-[#475569] max-w-md mx-auto">
                    Cảm ơn <strong>{fullName}</strong>. Bộ phận Chăm sóc Khách
                    hàng VitaCare sẽ liên hệ qua số <strong>{phone}</strong>{' '}
                    trong vòng 15 phút để xác nhận.
                  </p>

                  <div className="mt-6 rounded-[4px] border border-[#E5E7EB] bg-slate-50 p-4 text-left max-w-md mx-auto space-y-2 text-[14px]">
                    <div className="flex justify-between">
                      <span className="text-[#475569]">Mã phiếu hẹn:</span>
                      <span className="font-mono font-bold text-[#0876BD] tabular-nums">
                        {submittedBookingCode}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#475569]">Chuyên khoa:</span>
                      <span className="font-medium text-[#102A5A]">{specialty}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#475569]">Bác sĩ phụ trách:</span>
                      <span className="font-medium text-[#102A5A]">{selectedDoctor}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#475569]">Thời gian hẹn:</span>
                      <span className="font-medium text-[#102A5A] tabular-nums">
                        {timeSlot} · {date}
                      </span>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={handleResetBooking}
                      className="rounded-[4px] border border-[#E5E7EB] px-5 py-2.5 text-[14px] font-semibold text-[#475569] hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      Đặt lịch hẹn khác
                    </button>
                    <button
                      type="button"
                      onClick={onClose}
                      className="rounded-[4px] bg-[#60B9F4] px-6 py-2.5 text-[14px] font-semibold text-white hover:bg-[#38B2F6] transition-colors cursor-pointer"
                    >
                      Hoàn tất
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4" noValidate>
                  {errorMsg && (
                    <div
                      role="alert"
                      className="rounded-[4px] border border-red-200 bg-red-50 px-4 py-3 text-[14px] font-medium text-red-700"
                    >
                      {errorMsg}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-name"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Họ và tên người khám <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="booking-name"
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Nguyễn Văn An"
                        className="w-full rounded-[4px] border border-[#E5E7EB] px-3.5 py-2.5 text-[15px] text-[#102A5A] placeholder:text-slate-400 focus:border-[#38B2F6] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="booking-phone"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Số điện thoại liên hệ <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="booking-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="0901 234 567"
                        className="w-full rounded-[4px] border border-[#E5E7EB] px-3.5 py-2.5 text-[15px] text-[#102A5A] placeholder:text-slate-400 focus:border-[#38B2F6] focus:outline-none tabular-nums"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-specialty"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Chuyên khoa đăng ký
                      </label>
                      <select
                        id="booking-specialty"
                        value={specialty}
                        onChange={(e) => setSpecialty(e.target.value)}
                        className="w-full rounded-[4px] border border-[#E5E7EB] bg-white px-3.5 py-2.5 text-[15px] text-[#102A5A] focus:border-[#38B2F6] focus:outline-none"
                      >
                        {SPECIALTIES.map((spec) => (
                          <option key={spec} value={spec}>
                            {spec}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="booking-doctor"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Bác sĩ khám
                      </label>
                      <select
                        id="booking-doctor"
                        value={selectedDoctor}
                        onChange={(e) => setSelectedDoctor(e.target.value)}
                        className="w-full rounded-[4px] border border-[#E5E7EB] bg-white px-3.5 py-2.5 text-[15px] text-[#102A5A] focus:border-[#38B2F6] focus:outline-none"
                      >
                        <option value="Tự động sắp xếp bác sĩ phù hợp">
                          Tự động sắp xếp bác sĩ phù hợp
                        </option>
                        {DOCTORS_LIST.map((doc) => (
                          <option key={doc.id} value={doc.name}>
                            {doc.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="booking-date"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Ngày khám dự kiến
                      </label>
                      <div className="relative">
                        <input
                          id="booking-date"
                          type="date"
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className="w-full rounded-[4px] border border-[#E5E7EB] px-3.5 py-2.5 text-[15px] text-[#102A5A] focus:border-[#38B2F6] focus:outline-none tabular-nums"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="booking-time"
                        className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                      >
                        Khung giờ ưu tiên
                      </label>
                      <select
                        id="booking-time"
                        value={timeSlot}
                        onChange={(e) => setTimeSlot(e.target.value)}
                        className="w-full rounded-[4px] border border-[#E5E7EB] bg-white px-3.5 py-2.5 text-[15px] text-[#102A5A] focus:border-[#38B2F6] focus:outline-none tabular-nums"
                      >
                        <option value="08:00">08:00 - 09:00 (Buổi sáng)</option>
                        <option value="09:00">09:00 - 10:00 (Buổi sáng)</option>
                        <option value="10:30">10:30 - 11:30 (Buổi sáng)</option>
                        <option value="14:00">14:00 - 15:00 (Buổi chiều)</option>
                        <option value="15:30">15:30 - 16:30 (Buổi chiều)</option>
                        <option value="17:30">17:30 - 18:30 (Ngoài giờ)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="booking-notes"
                      className="block text-[14px] font-semibold text-[#102A5A] mb-1.5"
                    >
                      Triệu chứng hoặc yêu cầu thêm (không bắt buộc)
                    </label>
                    <textarea
                      id="booking-notes"
                      rows={3}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Mô tả ngắn gọn tình trạng sức khỏe hoặc nhu cầu tầm soát..."
                      className="w-full rounded-[4px] border border-[#E5E7EB] px-3.5 py-2 text-[15px] text-[#102A5A] placeholder:text-slate-400 focus:border-[#38B2F6] focus:outline-none"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-4">
                    <p className="text-[13px] text-[#475569]">
                      Tổng đài hỗ trợ khẩn cấp:{' '}
                      <strong className="text-[#102A5A] tabular-nums">1900 6889</strong>
                    </p>
                    <button
                      type="submit"
                      className="inline-flex items-center justify-center gap-2 rounded-[4px] bg-[#60B9F4] px-7 py-3 text-[15px] font-semibold text-white hover:bg-[#38B2F6] active:bg-[#0876BD] transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <span>Xác nhận đặt lịch</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </form>
              )}
            </>
          )}

          {activeTab === 'doctors' && (
            <div className="space-y-4">
              <p className="text-[15px] text-[#475569] leading-relaxed">
                Đội ngũ y bác sĩ tại VitaCare có trình độ chuyên môn cao, tận
                tâm lắng nghe và trực tiếp thăm khám, hội chẩn chuyên sâu.
              </p>
              <div className="divide-y divide-[#E5E7EB] border border-[#E5E7EB] rounded-[4px]">
                {DOCTORS_LIST.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 hover:bg-slate-50/80 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <UserCheck className="h-4 w-4 text-[#38B2F6] shrink-0" />
                        <h3 className="text-[16px] font-bold text-[#102A5A]">
                          {doc.name}
                        </h3>
                      </div>
                      <p className="mt-1 text-[13px] text-[#475569]">
                        <span>{doc.title}</span>
                        <span className="mx-1.5" aria-hidden="true">·</span>
                        <span>{doc.specialty}</span>
                        <span className="mx-1.5" aria-hidden="true">·</span>
                        <span className="tabular-nums">{doc.experience}</span>
                      </p>
                      <p className="mt-1 text-[13px] text-slate-500">
                        {doc.education}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleSelectDoctorForBooking(doc)}
                      className="self-start sm:self-center rounded-[4px] border border-[#38B2F6] px-4 py-2 text-[13px] font-semibold text-[#0876BD] hover:bg-[#38B2F6] hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Đặt lịch với Bác sĩ
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'contact' && (
            <div className="space-y-5">
              <p className="text-[15px] text-[#475569] leading-relaxed">
                Quý khách có thể liên hệ trực tiếp với Phòng khám VitaCare qua
                hệ thống tổng đài hoặc đến thăm khám tại các cơ sở dưới đây:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="rounded-[4px] border border-[#E5E7EB] p-4">
                  <div className="flex items-center gap-2 text-[#102A5A] font-bold text-[15px]">
                    <MapPin className="h-4 w-4 text-[#38B2F6] shrink-0" />
                    <span>Cơ sở TP. Hồ Chí Minh</span>
                  </div>
                  <p className="mt-2 text-[14px] text-[#475569] leading-relaxed">
                    168 Nguyễn Thị Minh Khai, Phường Võ Thị Sáu, Quận 3, TP. Hồ
                    Chí Minh
                  </p>
                </div>

                <div className="rounded-[4px] border border-[#E5E7EB] p-4">
                  <div className="flex items-center gap-2 text-[#102A5A] font-bold text-[15px]">
                    <MapPin className="h-4 w-4 text-[#38B2F6] shrink-0" />
                    <span>Cơ sở Hà Nội</span>
                  </div>
                  <p className="mt-2 text-[14px] text-[#475569] leading-relaxed">
                    82 Trần Hưng Đạo, Phường Cửa Nam, Quận Hoàn Kiếm, TP. Hà Nội
                  </p>
                </div>
              </div>

              <div className="rounded-[4px] border border-[#E5E7EB] bg-slate-50 p-4 space-y-2.5 text-[14px]">
                <div className="flex items-center gap-2.5 text-[#102A5A]">
                  <Phone className="h-4 w-4 text-[#38B2F6] shrink-0" />
                  <span>
                    Hotline Đặt lịch & Cấp cứu:{' '}
                    <strong className="tabular-nums">1900 6889</strong> ·{' '}
                    <strong className="tabular-nums">(028) 3822 6889</strong>
                  </span>
                </div>
                <div className="flex items-center gap-2.5 text-[#102A5A]">
                  <Clock className="h-4 w-4 text-[#38B2F6] shrink-0" />
                  <span className="tabular-nums">
                    Giờ làm việc: 07:00 – 20:00 (Từ Thứ 2 đến Chủ Nhật, kể cả
                    Ngày Lễ)
                  </span>
                </div>
                <div className="flex items-center gap-2.5 text-[#102A5A]">
                  <Mail className="h-4 w-4 text-[#38B2F6] shrink-0" />
                  <span>Email: cskh@vitacare.vn</span>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setActiveTab('booking')}
                  className="inline-flex items-center gap-2 rounded-[4px] bg-[#60B9F4] px-6 py-2.5 text-[14px] font-semibold text-white hover:bg-[#38B2F6] transition-colors cursor-pointer"
                >
                  <Calendar className="h-4 w-4" />
                  <span>Đặt lịch khám ngay</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
