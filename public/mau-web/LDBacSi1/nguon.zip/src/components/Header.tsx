import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export type NavSectionId = 'home' | 'about' | 'services' | 'doctors' | 'contact';

interface HeaderProps {
  activeSection: NavSectionId;
  onNavigate: (sectionId: NavSectionId) => void;
  onOpenBooking: (defaultTab?: 'booking' | 'doctors' | 'contact') => void;
}

interface NavItem {
  id: NavSectionId;
  label: string;
  href: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Trang chủ', href: '#home' },
  { id: 'about', label: 'Giới thiệu', href: '#about' },
  { id: 'services', label: 'Dịch vụ', href: '#services' },
  { id: 'doctors', label: 'Bác sĩ', href: '#doctors' },
  { id: 'contact', label: 'Liên hệ', href: '#contact' },
];

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onNavigate,
  onOpenBooking,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 8);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    item: NavItem
  ) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    onNavigate(item.id);
  };

  const handleCtaClick = (e: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    onOpenBooking('booking');
  };

  return (
    <header
      className={`sticky top-0 z-40 h-[76px] w-full bg-white transition-shadow duration-200 ${
        isScrolled ? 'shadow-[0_2px_12px_rgba(16,42,90,0.06)]' : ' border-b border-[#E5E7EB]/60'
      }`}
    >
      <div className="mx-auto flex h-full max-w-[1200px] items-center justify-between gap-8 px-5 md:px-6">
        {/* Zone 1: Brand Logo */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            setMobileMenuOpen(false);
            onNavigate('home');
          }}
          className="group flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#38B2F6]"
          aria-label="VitaCare - Trang chủ"
        >
          {/* Two-tone Medical Cross SVG matching reference image */}
          <svg
            width="36"
            height="36"
            viewBox="0 0 36 36"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-9 w-9 shrink-0 transition-transform duration-200 group-hover:scale-[1.03]"
            aria-hidden="true"
          >
            {/* Vertical bar (Deep Medical Blue) */}
            <rect
              x="12.5"
              y="3"
              width="11"
              height="30"
              rx="4.5"
              fill="#1E78C8"
            />
            {/* Horizontal bar (Light Sky Blue) */}
            <rect
              x="3"
              y="12.5"
              width="30"
              height="11"
              rx="4.5"
              fill="#60B9F4"
            />
            {/* Diagonal subtle overlap accent matching VitaCare logo */}
            <path
              d="M12.5 16.5L23.5 12.5V23.5H12.5V16.5Z"
              fill="#2B8CE0"
            />
            <path
              d="M11 22.5L25 13.5"
              stroke="#FFFFFF"
              strokeWidth="1.6"
              strokeLinecap="round"
            />
          </svg>
          <span className="text-[28px] lg:text-[30px] font-bold tracking-tight leading-none">
            <span className="text-[#102A5A]">Vita</span>
            <span className="text-[#38B2F6]">Care</span>
          </span>
        </a>

        {/* Zone 2: Desktop Navigation Links */}
        <nav
          className="hidden md:flex items-center gap-7 lg:gap-9"
          aria-label="Điều hướng chính"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <a
                key={item.id}
                href={item.href}
                onClick={(e) => handleNavClick(e, item)}
                className={`relative py-1.5 text-[15px] font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#38B2F6] ${
                  isActive
                    ? 'text-[#102A5A] font-semibold border-b-2 border-[#38B2F6]'
                    : 'text-[#1E293B] hover:text-[#38B2F6] border-b-2 border-transparent'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & Mobile Hamburger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleCtaClick}
            className="hidden md:inline-flex items-center justify-center rounded-[4px] bg-[#60B9F4] px-[26px] py-[11px] text-[15px] font-semibold text-white transition-all duration-200 hover:bg-[#38B2F6] active:bg-[#0876BD] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#102A5A]"
          >
            Đặt lịch ngay
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="inline-flex md:hidden h-11 w-11 items-center justify-center rounded-[4px] text-[#102A5A] hover:bg-slate-100 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#38B2F6]"
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Đóng menu' : 'Mở menu điều hướng'}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#E5E7EB] bg-white px-5 pt-2 pb-5 shadow-lg">
          <nav className="flex flex-col space-y-1" aria-label="Menu di động">
            {NAV_ITEMS.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item)}
                  className={`flex items-center justify-between rounded-[4px] px-3 py-2.5 text-[15px] font-medium transition-colors duration-150 ${
                    isActive
                      ? 'bg-[#38B2F6]/10 text-[#102A5A] font-semibold'
                      : 'text-[#334155] hover:bg-slate-50 hover:text-[#102A5A]'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && (
                    <span className="h-1.5 w-6 rounded-full bg-[#38B2F6]" aria-hidden="true" />
                  )}
                </a>
              );
            })}
            <div className="pt-3">
              <button
                type="button"
                onClick={handleCtaClick}
                className="w-full rounded-[4px] bg-[#60B9F4] py-3 px-6 text-center text-[15px] font-semibold text-white transition-colors duration-200 hover:bg-[#38B2F6] active:bg-[#0876BD]"
              >
                Đặt lịch ngay
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
