import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';

interface HeroSectionProps {
  onOpenBooking: () => void;
}

import HERO_IMAGE_PATH from '../assets/images/medical_surgery_hero_1792081481611.jpg';

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenBooking }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="home"
      className="relative w-full min-h-[560px] lg:h-[620px] flex items-center overflow-hidden bg-[#138BD3]"
    >
      {/* Background Medical Surgery Photography */}
      {!imgError && (
        <img
          src={HERO_IMAGE_PATH}
          alt="Đội ngũ bác sĩ phẫu thuật VitaCare trong phòng mổ hiện đại"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="absolute inset-0 h-full w-full object-cover object-[65%_center] md:object-right select-none"
        />
      )}

      {/* Clinical Blue Translucent Gradient Overlay matching reference image */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(90deg, rgba(19, 139, 211, 0.82) 0%, rgba(37, 157, 229, 0.58) 55%, rgba(33, 146, 216, 0.28) 100%)',
        }}
        aria-hidden="true"
      />

      {/* Mobile additional legibility overlay */}
      <div
        className="absolute inset-0 bg-[#128BD7]/25 md:hidden"
        aria-hidden="true"
      />

      {/* Main Content Container */}
      <div className="relative z-10 mx-auto w-full max-w-[1200px] px-5 py-14 md:px-6 md:py-16">
        <div className="max-w-[640px] text-left">
          <h1 className="text-[32px] md:text-[40px] lg:text-[48px] font-bold leading-[1.18] text-white tracking-tight max-w-[650px]">
            Đội ngũ bác sĩ tận tâm
            <br className="hidden sm:inline" /> cho sức khỏe gia đình bạn
          </h1>

          <p className="mt-4 text-[19px] md:text-[22px] font-semibold text-white leading-[1.35]">
            Dịch vụ y tế hiện đại, chất lượng cao tại Việt Nam
          </p>

          <p className="mt-4 text-[16px] font-normal leading-[1.7] text-white/95 max-w-[540px]">
            VitaCare mang đến giải pháp chăm sóc sức khỏe toàn diện với đội ngũ
            bác sĩ giàu kinh nghiệm, trang thiết bị hiện đại và quy trình khám
            chữa bệnh an toàn, chuyên nghiệp.
          </p>

          <div className="mt-8">
            <button
              type="button"
              onClick={onOpenBooking}
              className="inline-flex w-[190px] items-center justify-center gap-2.5 rounded-[4px] bg-white px-[30px] py-[14px] text-[15px] font-semibold text-[#0876BD] shadow-sm transition-all duration-200 hover:bg-[#F0F9FF] active:scale-[0.99] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <span>Đặt lịch ngay</span>
              <ArrowRight className="h-4 w-4 shrink-0" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
