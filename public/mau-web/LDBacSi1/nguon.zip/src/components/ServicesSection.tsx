import React, { useState } from 'react';
import { Stethoscope } from 'lucide-react';

import SURGERY_TEAM_PATH from '../assets/images/surgery_team_operating_1792081480714.jpg';

export const ServicesSection: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="services"
      className="grid w-full grid-cols-1 lg:grid-cols-2 min-h-[480px] gap-0"
    >
      {/* Left 50%: Operating Room Photography */}
      <div className="relative h-[300px] sm:h-[380px] lg:h-full w-full overflow-hidden bg-[#102A5A]">
        {!imgError ? (
          <img
            src={SURGERY_TEAM_PATH}
            alt="Đội ngũ bác sĩ đang thực hiện phẫu thuật"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="block h-full w-full object-cover object-center select-none"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-[#102A5A] p-8 text-white">
            <Stethoscope className="h-14 w-14 text-[#60B9F4] mb-3" />
            <span className="text-lg font-semibold">Phòng Phẫu Thuật Hiện Đại VitaCare</span>
          </div>
        )}
      </div>

      {/* Right 50%: Flat Blue Content Block (#61B9ED) */}
      <div className="flex flex-col items-center justify-center bg-[#61B9ED] px-6 py-12 md:p-16 text-center">
        <p className="text-[15px] md:text-[16px] font-medium uppercase tracking-wider text-white">
          DỊCH VỤ NỔI BẬT
        </p>

        <h3 className="mt-[18px] text-[28px] md:text-[32px] lg:text-[34px] font-bold leading-[1.25] text-white">
          Đội ngũ chuyên môn cao
        </h3>

        <p className="mt-5 max-w-[500px] text-[16px] font-normal leading-[1.8] text-white/95">
          VitaCare quy tụ đội ngũ bác sĩ chuyên khoa giàu kinh nghiệm, được đào
          tạo bài bản trong và ngoài nước, cùng hệ thống trang thiết bị hiện
          đại, mang đến hiệu quả chẩn đoán và điều trị tối ưu cho người bệnh.
        </p>
      </div>
    </section>
  );
};
