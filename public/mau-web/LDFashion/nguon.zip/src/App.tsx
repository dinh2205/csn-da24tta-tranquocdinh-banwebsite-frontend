/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CollectionSection } from './components/CollectionSection';
import { FeaturedProducts } from './components/FeaturedProducts';
import { WinterCampaign } from './components/WinterCampaign';
import { WhyChooseUs } from './components/WhyChooseUs';
import { NewsletterSection } from './components/NewsletterSection';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { AccountModal } from './components/AccountModal';
import { Toast, ToastMessage } from './components/Toast';
import { PRODUCTS_DATA } from './data/fashionData';
import { Product, CartItem } from './types';

export default function App() {
  const [products, setProducts] = useState<Product[]>(PRODUCTS_DATA);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('asha_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlistIds, setWishlistIds] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('asha_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals and Drawers states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [isAccountOpen, setIsAccountOpen] = useState<boolean>(false);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'cart' | 'favorite' | 'info', title: string, message: string) => {
    const id = Date.now().toString() + Math.random().toString();
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('asha_cart', JSON.stringify(cart));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cart]);

  // Sync wishlist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('asha_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error('Failed to save wishlist to localStorage', e);
    }
  }, [wishlistIds]);

  // Color change on a product card
  const handleColorChange = (productId: number, color: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, selectedColor: color } : p))
    );
  };

  // Toggle favorite
  const handleToggleFavorite = (product: Product) => {
    setWishlistIds((prev) => {
      const exists = prev.includes(product.id);
      if (exists) {
        addToast('favorite', 'Đã bỏ yêu thích', `Đã xóa "${product.name}" khỏi danh sách yêu thích.`);
        return prev.filter((id) => id !== product.id);
      } else {
        addToast('favorite', 'Đã thêm yêu thích', `Đã lưu "${product.name}" vào danh sách yêu thích.`);
        return [...prev, product.id];
      }
    });
  };

  // Add to cart from Product Modal
  const handleAddToCart = (product: Product, quantity: number, color: string, size: string) => {
    setCart((prev) => {
      const existingIndex = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.selectedColor === color &&
          item.selectedSize === size
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        return [...prev, { product, quantity, selectedColor: color, selectedSize: size }];
      }
    });

    addToast(
      'cart',
      'Đã thêm vào giỏ hàng',
      `${quantity}x ${product.name} (Size: ${size})`
    );
  };

  // Quick Add from Card or Hero
  const handleQuickAdd = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const color = product.selectedColor || product.colors[0] || '#C8AE94';
    const size = product.sizes && product.sizes.length > 0 ? product.sizes[0] : 'M';
    handleAddToCart(product, 1, color, size);
  };

  // Cart quantity update
  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(index);
      return;
    }
    setCart((prev) => {
      const updated = [...prev];
      updated[index].quantity = newQty;
      return updated;
    });
  };

  // Remove cart item
  const handleRemoveCartItem = (index: number) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
    addToast('info', 'Đã cập nhật giỏ hàng', 'Đã xóa sản phẩm khỏi giỏ hàng.');
  };

  // Clear cart
  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist products
  const favoriteProducts = products.filter((p) => wishlistIds.includes(p.id));

  // Category select with smooth scroll to products
  const handleSelectCategory = (category: string) => {
    setSelectedCategory(category);
    const el = document.getElementById('products');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCollection = (collectionId: string) => {
    if (collectionId === 'streetwear') {
      setSelectedCategory('men');
    } else if (collectionId === 'elegance' || collectionId === 'party') {
      setSelectedCategory('women');
    } else {
      setSelectedCategory('all');
    }
    const el = document.getElementById('products');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white text-[#171717] flex flex-col font-sans">
      {/* 1. Header Navigation */}
      <Header
        cartCount={totalCartCount}
        wishlistCount={wishlistIds.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onSelectCategory={handleSelectCategory}
      />

      {/* Main Content Sections */}
      <main className="flex-grow">
        {/* 2. Hero Section */}
        <HeroSection
          onExploreClick={() => handleSelectCategory('all')}
          onQuickAddProduct={handleQuickAdd}
        />

        {/* 3. Collection Grid (Bộ sưu tập) */}
        <CollectionSection onSelectCollection={handleSelectCollection} />

        {/* 4. Featured Products (Sản phẩm nổi bật) */}
        <FeaturedProducts
          products={products}
          wishlistIds={wishlistIds}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onToggleFavorite={handleToggleFavorite}
          onSelectProduct={(product) => {
            setSelectedProduct(product);
            setIsProductModalOpen(true);
          }}
          onQuickAdd={handleQuickAdd}
          onColorChange={handleColorChange}
          searchQuery={searchQuery}
        />

        {/* 5. Winter Campaign Banner (Banner Thu Đông) */}
        <WinterCampaign onExplore={() => handleSelectCategory('all')} />

        {/* 6. Why Choose Us (Vì sao chọn ASHA?) */}
        <WhyChooseUs />

        {/* 7. Newsletter Section (Đăng ký nhận tin) */}
        <NewsletterSection />
      </main>

      {/* 8. Footer */}
      <Footer onSelectCategory={handleSelectCategory} />

      {/* Modals & Slide-out Drawers */}
      <ProductModal
        product={selectedProduct}
        isOpen={isProductModalOpen}
        onClose={() => {
          setIsProductModalOpen(false);
          setSelectedProduct(null);
        }}
        onAddToCart={handleAddToCart}
        isFavorite={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onToggleFavorite={handleToggleFavorite}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        favoriteProducts={favoriteProducts}
        onRemoveFavorite={handleToggleFavorite}
        onAddToCart={(p) => {
          handleQuickAdd(p);
          setIsWishlistOpen(false);
        }}
      />

      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        wishlistCount={wishlistIds.length}
        cartCount={totalCartCount}
      />

      {/* Floating Notifications */}
      <Toast toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
