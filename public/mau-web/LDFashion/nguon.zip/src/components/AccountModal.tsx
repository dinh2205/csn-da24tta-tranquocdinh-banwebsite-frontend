import React from 'react';
import { X, User, Award, Package, Heart, LogOut } from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistCount: number;
  cartCount: number;
}

export const AccountModal: React.FC<AccountModalProps> = ({
  isOpen,
  onClose,
  wishlistCount,
  cartCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="relative bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-neutral-200 p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-black rounded-full"
          aria-label="Đóng"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Header */}
        <div className="flex items-center gap-4 pb-6 border-b border-neutral-100">
          <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#FF5B23] to-[#FF8A41] text-white flex items-center justify-center font-bold text-xl shadow-md">
            AS
          </div>
          <div>
            <h3 className="font-bold text-lg text-neutral-900">Asha Member</h3>
            <p className="text-xs text-neutral-500">thanhvien@asha.vn</p>
            <div className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 bg-[#FFF1E8] text-[#FF5B23] rounded-full text-[11px] font-semibold">
              <Award className="w-3 h-3" />
              <span>Hạng Vàng (Gold Member)</span>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-2 my-5 text-center">
          <div className="p-3 bg-neutral-50 rounded-lg">
            <span className="block text-lg font-bold text-[#FF5B23]">350</span>
            <span className="text-[11px] text-neutral-500">Điểm tích lũy</span>
          </div>
          <div className="p-3 bg-neutral-50 rounded-lg">
            <span className="block text-lg font-bold text-neutral-800">{wishlistCount}</span>
            <span className="text-[11px] text-neutral-500">Yêu thích</span>
          </div>
          <div className="p-3 bg-neutral-50 rounded-lg">
            <span className="block text-lg font-bold text-neutral-800">{cartCount}</span>
            <span className="text-[11px] text-neutral-500">Trong giỏ</span>
          </div>
        </div>

        {/* Quick Menu Options */}
        <div className="space-y-1 text-sm text-neutral-700">
          <button
            onClick={onClose}
            className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-neutral-50 transition-colors text-left"
          >
            <span className="flex items-center gap-3">
              <Package className="w-4 h-4 text-[#FF5B23]" />
              <span>Lịch sử đơn hàng</span>
            </span>
            <span className="text-xs text-neutral-400">Xem</span>
          </button>

          <button
            onClick={onClose}
            className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-neutral-50 transition-colors text-left"
          >
            <span className="flex items-center gap-3">
              <Heart className="w-4 h-4 text-[#FF5B23]" />
              <span>Danh sách đã lưu</span>
            </span>
            <span className="text-xs text-neutral-400">{wishlistCount} mục</span>
          </button>

          <button
            onClick={onClose}
            className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-neutral-50 transition-colors text-left"
          >
            <span className="flex items-center gap-3">
              <User className="w-4 h-4 text-[#FF5B23]" />
              <span>Cài đặt thông tin cá nhân</span>
            </span>
            <span className="text-xs text-neutral-400">Chỉnh sửa</span>
          </button>
        </div>

        <div className="mt-6 pt-4 border-t border-neutral-100">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Đóng thông tin</span>
          </button>
        </div>
      </div>
    </div>
  );
};
