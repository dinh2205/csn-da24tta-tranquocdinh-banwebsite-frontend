import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { CartItem } from '../types';
import { formatCurrencyVND } from '../data/fashionData';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bank'>('cod');

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const FREE_SHIPPING_THRESHOLD = 499000;
  const isFreeShipping = subtotal >= FREE_SHIPPING_THRESHOLD;
  const missingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const shippingPercent = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !customerAddress) {
      alert('Vui lòng điền đầy đủ Họ tên, Số điện thoại và Địa chỉ nhận hàng.');
      return;
    }

    // Save order simulation
    const newOrder = {
      orderId: 'ASHA-' + Math.floor(100000 + Math.random() * 900000),
      createdAt: new Date().toISOString(),
      customer: { name: customerName, phone: customerPhone, address: customerAddress },
      paymentMethod,
      items,
      subtotal,
    };

    try {
      const existingOrders = JSON.parse(localStorage.getItem('asha_orders') || '[]');
      existingOrders.unshift(newOrder);
      localStorage.setItem('asha_orders', JSON.stringify(existingOrders));
    } catch (e) {
      console.error(e);
    }

    setOrderSuccess(true);
    onClearCart();
  };

  const handleResetCheckout = () => {
    setIsCheckingOut(false);
    setOrderSuccess(false);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#FF5B23]" />
              <h3 className="text-lg font-bold text-neutral-900">
                Giỏ hàng của bạn ({items.reduce((acc, i) => acc + i.quantity, 0)})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-full transition-colors"
              aria-label="Đóng giỏ hàng"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Bar */}
          {items.length > 0 && (
            <div className="bg-[#FFF9F5] px-5 py-3 border-b border-[#FFE7DB]">
              <div className="flex items-center justify-between text-xs mb-1.5 font-medium">
                {isFreeShipping ? (
                  <span className="text-emerald-700 font-bold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" /> Chúc mừng! Đơn hàng được Miễn phí giao hàng
                  </span>
                ) : (
                  <span className="text-neutral-700">
                    Mua thêm <strong className="text-[#FF5B23]">{formatCurrencyVND(missingForFreeShipping)}</strong> để được <strong className="text-emerald-700">Freeship</strong>
                  </span>
                )}
                <span className="text-neutral-500">{shippingPercent}%</span>
              </div>
              <div className="w-full bg-neutral-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#FF5B23] h-full transition-all duration-300 rounded-full"
                  style={{ width: `${shippingPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-5">
            {orderSuccess ? (
              <div className="text-center py-10 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-bold text-neutral-900">Đặt hàng thành công!</h4>
                <p className="text-sm text-neutral-600 leading-relaxed">
                  Cảm ơn bạn đã tin tưởng lựa chọn thương hiệu thời trang ASHA. Chuyên viên sẽ gọi điện xác nhận đơn và giao tới bạn sớm nhất!
                </p>
                <div className="p-3 bg-neutral-50 rounded-lg text-xs text-neutral-600 text-left border border-neutral-200">
                  <p><strong>Người nhận:</strong> {customerName}</p>
                  <p><strong>Số điện thoại:</strong> {customerPhone}</p>
                  <p><strong>Địa chỉ:</strong> {customerAddress}</p>
                  <p><strong>Thanh toán:</strong> {paymentMethod === 'cod' ? 'Thanh toán khi nhận hàng (COD)' : 'Chuyển khoản ngân hàng'}</p>
                </div>
                <button
                  onClick={handleResetCheckout}
                  className="w-full py-3 bg-[#FF5B23] text-white font-semibold rounded-lg hover:bg-[#EB4815] transition-colors"
                >
                  Tiếp tục mua sắm
                </button>
              </div>
            ) : isCheckingOut ? (
              <form onSubmit={handleOrderSubmit} className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-neutral-200">
                  <h4 className="font-bold text-base text-neutral-900">Thông tin giao hàng</h4>
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="text-xs text-[#FF5B23] font-semibold hover:underline"
                  >
                    Quay lại giỏ hàng
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Họ và tên người nhận *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Nguyễn Văn A"
                    className="w-full p-2.5 text-sm border border-neutral-300 rounded-md focus:border-[#FF5B23] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Số điện thoại *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="0912 345 678"
                    className="w-full p-2.5 text-sm border border-neutral-300 rounded-md focus:border-[#FF5B23] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Địa chỉ giao hàng chi tiết *
                  </label>
                  <textarea
                    required
                    rows={2}
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố"
                    className="w-full p-2.5 text-sm border border-neutral-300 rounded-md focus:border-[#FF5B23] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">
                    Hình thức thanh toán
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-2.5 rounded border text-left font-medium transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-[#FF5B23] bg-[#FFF1E8] text-[#BB401D]'
                          : 'border-neutral-300 text-neutral-700'
                      }`}
                    >
                      <div className="font-bold">Thanh toán khi nhận (COD)</div>
                      <span className="text-[10px] text-neutral-500">Kiểm tra trước khi trả tiền</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bank')}
                      className={`p-2.5 rounded border text-left font-medium transition-all ${
                        paymentMethod === 'bank'
                          ? 'border-[#FF5B23] bg-[#FFF1E8] text-[#BB401D]'
                          : 'border-neutral-300 text-neutral-700'
                      }`}
                    >
                      <div className="font-bold">Chuyển khoản ngân hàng</div>
                      <span className="text-[10px] text-neutral-500">VietQR / MoMo / ZaloPay</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-neutral-50 rounded-lg text-xs space-y-1.5 border border-neutral-200 mt-4">
                  <div className="flex justify-between text-neutral-600">
                    <span>Tổng tiền hàng:</span>
                    <span className="tabular-nums">{formatCurrencyVND(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-neutral-600">
                    <span>Phí giao hàng:</span>
                    <span className="tabular-nums">{isFreeShipping ? 'Miễn phí' : '30.000đ'}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-neutral-900 pt-1 border-t border-neutral-200">
                    <span>Tổng thanh toán:</span>
                    <span className="text-[#FF5B23] tabular-nums">
                      {formatCurrencyVND(subtotal + (isFreeShipping ? 0 : 30000))}
                    </span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#FF5B23] hover:bg-[#EB4815] text-white font-bold text-sm rounded-lg shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <span>Hoàn tất đặt hàng</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            ) : items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-neutral-800">Giỏ hàng của bạn đang trống</h4>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                  Hãy khám phá ngay các bộ sưu tập thời trang ASHA mới nhất và lựa chọn trang phục yêu thích.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-[#FF5B23] text-white text-xs font-semibold rounded-md hover:bg-[#EB4815] transition-colors"
                >
                  Khám phá ngay
                </button>
              </div>
            ) : (
              <div className="divide-y divide-neutral-100">
                {items.map((item, index) => (
                  <div key={`${item.product.id}-${item.selectedColor}-${item.selectedSize}-${index}`} className="py-4 flex gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-20 h-24 object-cover rounded bg-neutral-100 shrink-0"
                    />
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="text-sm font-bold text-neutral-900 line-clamp-1">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(index)}
                            className="text-neutral-400 hover:text-red-500 p-1"
                            title="Xóa khỏi giỏ"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Variants */}
                        <div className="flex items-center gap-2 mt-1 text-xs text-neutral-500">
                          <span className="flex items-center gap-1">
                            Màu:
                            <span
                              className="w-3 h-3 rounded-full border border-neutral-300 inline-block"
                              style={{ backgroundColor: item.selectedColor }}
                            />
                          </span>
                          <span>•</span>
                          <span>Size: <strong>{item.selectedSize}</strong></span>
                        </div>

                        {/* Price */}
                        <div className="mt-1 text-sm font-bold text-[#FF5B23] tabular-nums">
                          {formatCurrencyVND(item.product.price)}
                        </div>
                      </div>

                      {/* Quantity Stepper */}
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border border-neutral-300 rounded">
                          <button
                            onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                            className="px-2.5 py-0.5 text-xs font-bold text-neutral-600 hover:bg-neutral-100"
                          >
                            -
                          </button>
                          <span className="px-3 py-0.5 text-xs font-semibold tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                            className="px-2.5 py-0.5 text-xs font-bold text-neutral-600 hover:bg-neutral-100"
                          >
                            +
                          </button>
                        </div>

                        <span className="text-xs font-semibold text-neutral-700 tabular-nums">
                          {formatCurrencyVND(item.product.price * item.quantity)}
                        </span>
                      </div>

                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer Subtotal & Checkout */}
          {items.length > 0 && !isCheckingOut && !orderSuccess && (
            <div className="p-5 border-t border-neutral-200 bg-white space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-neutral-600 font-medium">Tạm tính:</span>
                <span className="text-lg font-extrabold text-[#171717] tabular-nums">
                  {formatCurrencyVND(subtotal)}
                </span>
              </div>
              <p className="text-[11px] text-neutral-500">
                Phí vận chuyển và thuế sẽ được áp dụng tại bước thanh toán.
              </p>
              <button
                onClick={() => setIsCheckingOut(true)}
                className="w-full py-3.5 bg-[#FF5B23] hover:bg-[#EB4815] text-white font-bold text-sm rounded-lg shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <span>Tiến hành đặt hàng</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
