import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Collection } from '../types';

interface CollectionCardProps {
  collection: Collection;
  onClick: (collectionId: string) => void;
}

export const CollectionCard: React.FC<CollectionCardProps> = ({ collection, onClick }) => {
  return (
    <div
      onClick={() => onClick(collection.id)}
      className="group relative overflow-hidden rounded-md cursor-pointer aspect-[3/4] shadow-md hover:shadow-xl transition-all duration-300"
    >
      {/* Background Image */}
      <img
        src={collection.image}
        alt={collection.title}
        className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 ease-out"
        referrerPolicy="no-referrer"
      />

      {/* Gradient Scrim for Legibility */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent transition-opacity group-hover:from-black/85" />

      {/* Content at Bottom-Left */}
      <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6 flex flex-col justify-end text-white z-10">
        <span className="text-[11px] sm:text-xs uppercase tracking-widest text-orange-300 font-semibold mb-1 opacity-90">
          Bộ sưu tập
        </span>
        <h3 className="text-lg sm:text-xl lg:text-2xl font-bold leading-snug drop-shadow-sm text-white group-hover:text-orange-200 transition-colors">
          {collection.title}
        </h3>
        <div className="flex items-center gap-2 mt-2 text-xs sm:text-sm font-medium text-white/90 group-hover:text-white transition-colors">
          <span>{collection.action}</span>
          <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform" />
        </div>
      </div>
    </div>
  );
};
