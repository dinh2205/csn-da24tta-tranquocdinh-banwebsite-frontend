import React from 'react';
import { COLLECTIONS_DATA } from '../data/fashionData';
import { CollectionCard } from './CollectionCard';

interface CollectionSectionProps {
  onSelectCollection: (id: string) => void;
}

export const CollectionSection: React.FC<CollectionSectionProps> = ({ onSelectCollection }) => {
  return (
    <section id="collections" className="py-12 sm:py-16 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        {/* Section Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-10 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold tracking-[3px] uppercase text-[#FF5B23] mb-1">
              <span className="w-4 h-[2px] bg-[#FF5B23]" />
              XU HƯỚNG MÙA NÀY
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#171717] tracking-tight">
              BỘ SƯU TẬP ĐẶC BIỆT
            </h2>
          </div>
          <p className="text-sm sm:text-base text-[#737373] max-w-md">
            Những định hình phong cách được chăm chút tỉ mỉ từ chất liệu đến kiểu dáng cho tủ đồ của bạn.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 lg:gap-6">
          {COLLECTIONS_DATA.map((col) => (
            <CollectionCard
              key={col.id}
              collection={col}
              onClick={onSelectCollection}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
