import React, { useMemo } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface FeaturedProductsProps {
  products: Product[];
  wishlistIds: number[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onToggleFavorite: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product, e: React.MouseEvent) => void;
  onColorChange: (productId: number, color: string) => void;
  searchQuery: string;
}

export const FeaturedProducts: React.FC<FeaturedProductsProps> = ({
  products,
  wishlistIds,
  selectedCategory,
  onSelectCategory,
  onToggleFavorite,
  onSelectProduct,
  onQuickAdd,
  onColorChange,
  searchQuery,
}) => {
  const categoryTabs = [
    { id: 'all', label: 'Tất cả' },
    { id: 'new', label: 'Hàng mới' },
    { id: 'women', label: 'Thời trang nữ' },
    { id: 'men', label: 'Thời trang nam' },
    { id: 'accessories', label: 'Phụ kiện & Giày' },
  ];

  // Filter products by category and search query
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category filter
      if (selectedCategory === 'new') {
        if (!p.badge || !p.badge.toLowerCase().includes('mới')) return false;
      } else if (selectedCategory === 'women') {
        if (p.categorySlug !== 'women') return false;
      } else if (selectedCategory === 'men') {
        if (p.categorySlug !== 'men') return false;
      } else if (selectedCategory === 'accessories') {
        if (p.categorySlug !== 'accessories') return false;
      }

      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchName = p.name.toLowerCase().includes(query);
        const matchCategory = p.category.toLowerCase().includes(query);
        return matchName || matchCategory;
      }

      return true;
    });
  }, [products, selectedCategory, searchQuery]);

  return (
    <section id="products" className="py-12 sm:py-16 bg-[#FAFAFA] border-t border-b border-[#F0F0F0]">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold tracking-[3px] uppercase text-[#FF5B23] mb-1">
              <span className="w-4 h-[2px] bg-[#FF5B23]" />
              THIẾT KẾ ĐƯỢC YÊU THÍCH
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#171717] tracking-tight">
              SẢN PHẨM NỔI BẬT
            </h2>
            <p className="text-sm sm:text-base text-[#737373] mt-1">
              Những thiết kế được yêu thích nhất tại Asha.
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {categoryTabs.map((tab) => {
              const isActive = selectedCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onSelectCategory(tab.id)}
                  className={`px-3.5 py-1.5 text-xs sm:text-sm font-medium rounded-full transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-[#FF5B23] text-white shadow-sm'
                      : 'bg-white text-[#555555] hover:bg-neutral-100 hover:text-[#171717] border border-[#E9E5E2]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search Results Notice if filtered */}
        {searchQuery && (
          <div className="mb-6 flex items-center justify-between p-3 bg-[#FFF1E8] border border-[#FFD9C6] rounded-md text-sm text-[#BB401D]">
            <span>
              Kết quả tìm kiếm cho: <strong>"{searchQuery}"</strong> ({filteredProducts.length} sản phẩm)
            </span>
            <button
              onClick={() => onSelectCategory('all')}
              className="text-xs font-bold underline hover:text-[#FF5B23]"
            >
              Xóa bộ lọc
            </button>
          </div>
        )}

        {/* Products Grid: 6 columns on desktop, 3 on tablet, 2 on mobile */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5 sm:gap-4 lg:gap-4.5">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                isFavorite={wishlistIds.includes(product.id)}
                onToggleFavorite={onToggleFavorite}
                onSelectProduct={onSelectProduct}
                onQuickAdd={onQuickAdd}
                onColorChange={onColorChange}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-lg border border-neutral-200 p-8 max-w-md mx-auto">
            <Sparkles className="w-10 h-10 text-[#FF5B23] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-neutral-800">Không tìm thấy sản phẩm phù hợp</h3>
            <p className="text-sm text-neutral-500 mt-1">
              Vui lòng thử tìm kiếm với từ khóa khác hoặc xóa bộ lọc danh mục hiện tại.
            </p>
            <button
              onClick={() => {
                onSelectCategory('all');
              }}
              className="mt-4 px-5 py-2 bg-[#FF5B23] text-white text-sm font-semibold rounded-md hover:bg-[#EB4815] transition-colors"
            >
              Xem tất cả sản phẩm
            </button>
          </div>
        )}

        {/* View All Bottom Link */}
        <div className="mt-10 text-center">
          <button
            onClick={() => onSelectCategory('all')}
            className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-[#171717] hover:text-[#FF5B23] transition-colors group"
          >
            <span>Xem tất cả bộ sưu tập thời trang</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </div>
    </section>
  );
};
