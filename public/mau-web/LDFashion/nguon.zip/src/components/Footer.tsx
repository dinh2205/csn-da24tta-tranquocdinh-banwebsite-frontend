import React from 'react';
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Youtube } from 'lucide-react';

interface FooterProps {
  onSelectCategory: (category: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory }) => {
  return (
    <footer className="bg-[#1C1C1C] text-white pt-16 pb-8 border-t border-neutral-800">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        
        {/* Main 5-Column Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12">
          
          {/* Column 1: Brand & Social */}
          <div className="lg:col-span-1 space-y-4">
            <a
              href="#home"
              className="font-editorial text-3xl font-semibold text-white tracking-tight hover:text-[#FF5B23] transition-colors inline-block"
            >
              Asha
            </a>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Asha là thương hiệu thời trang hiện đại mang đến những thiết kế thanh lịch, chất lượng và truyền cảm hứng cho phong cách sống tích cực.
            </p>
            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-[#FF5B23] flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-[#FF5B23] flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-[#FF5B23] flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-full bg-neutral-800 hover:bg-[#FF5B23] flex items-center justify-center text-neutral-300 hover:text-white transition-colors text-xs font-bold"
                aria-label="TikTok"
              >
                TT
              </a>
            </div>
          </div>

          {/* Column 2: Danh mục */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white border-b border-neutral-800 pb-2">
              Danh mục
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-neutral-400">
              <li>
                <button
                  onClick={() => onSelectCategory('new')}
                  className="hover:text-[#FF5B23] transition-colors"
                >
                  Hàng mới về
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('women')}
                  className="hover:text-[#FF5B23] transition-colors"
                >
                  Thời trang nữ
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('men')}
                  className="hover:text-[#FF5B23] transition-colors"
                >
                  Thời trang nam
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('accessories')}
                  className="hover:text-[#FF5B23] transition-colors"
                >
                  Phụ kiện & Giày
                </button>
              </li>
              <li>
                <a href="#collections" className="hover:text-[#FF5B23] transition-colors">
                  Bộ sưu tập theo mùa
                </a>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategory('all')}
                  className="hover:text-[#FF5B23] transition-colors text-orange-400 font-medium"
                >
                  Ưu đãi đặc biệt
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Hỗ trợ khách hàng */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white border-b border-neutral-800 pb-2">
              Hỗ trợ khách hàng
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm text-neutral-400">
              <li>
                <a href="#faq" className="hover:text-[#FF5B23] transition-colors">
                  Hướng dẫn mua hàng
                </a>
              </li>
              <li>
                <a href="#shipping" className="hover:text-[#FF5B23] transition-colors">
                  Chính sách giao hàng
                </a>
              </li>
              <li>
                <a href="#returns" className="hover:text-[#FF5B23] transition-colors">
                  Chính sách đổi trả 30 ngày
                </a>
              </li>
              <li>
                <a href="#sizes" className="hover:text-[#FF5B23] transition-colors">
                  Bảng quy đổi kích cỡ
                </a>
              </li>
              <li>
                <a href="#membership" className="hover:text-[#FF5B23] transition-colors">
                  Chương trình thành viên
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Liên hệ */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white border-b border-neutral-800 pb-2">
              Thông tin liên hệ
            </h4>
            <ul className="space-y-3 text-xs sm:text-sm text-neutral-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#FF5B23] shrink-0 mt-0.5" />
                <span>123 Đường Nguyễn Huệ, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#FF5B23] shrink-0" />
                <span className="font-semibold text-white">1900 1234</span>
                <span className="text-[11px] text-neutral-500">(1.000đ/phút)</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#FF5B23] shrink-0" />
                <a href="mailto:hello@asha.vn" className="hover:text-white transition-colors">
                  hello@asha.vn
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#FF5B23] shrink-0" />
                <span>Thứ 2 - Chủ nhật: 8:00 - 22:00</span>
              </li>
            </ul>
          </div>

          {/* Column 5: Phương thức thanh toán */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white border-b border-neutral-800 pb-2">
              Thanh toán & Chứng nhận
            </h4>
            <p className="text-xs text-neutral-400">
              Hỗ trợ đa dạng phương thức thanh toán bảo mật và tiện lợi.
            </p>
            {/* Payment Method Badges */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="bg-white text-neutral-900 rounded px-3 py-2 text-center text-xs font-bold flex items-center justify-center border border-neutral-700 shadow-sm">
                <span className="text-blue-800 font-extrabold italic text-sm">VISA</span>
              </div>
              <div className="bg-white text-neutral-900 rounded px-3 py-2 text-center text-xs font-bold flex items-center justify-center border border-neutral-700 shadow-sm">
                <span className="text-red-600 font-bold text-xs">Mastercard</span>
              </div>
              <div className="bg-[#A50064] text-white rounded px-3 py-2 text-center text-xs font-bold flex items-center justify-center shadow-sm">
                <span>MoMo</span>
              </div>
              <div className="bg-[#0068FF] text-white rounded px-3 py-2 text-center text-xs font-bold flex items-center justify-center shadow-sm">
                <span>ZaloPay</span>
              </div>
            </div>
            <div className="pt-2 text-[11px] text-neutral-500">
              🔒 Đảm bảo an toàn thanh toán chuẩn PCI DSS quốc tế.
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Links */}
        <div className="pt-8 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© 2026 ASHA Fashion. Tất cả quyền được bảo lưu.</p>
          <div className="flex items-center gap-6">
            <a href="#terms" className="hover:text-neutral-300 transition-colors">
              Điều khoản sử dụng
            </a>
            <a href="#privacy" className="hover:text-neutral-300 transition-colors">
              Chính sách bảo mật
            </a>
            <a href="#contact" className="hover:text-neutral-300 transition-colors">
              Liên hệ
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
