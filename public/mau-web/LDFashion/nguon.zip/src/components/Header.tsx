import React, { useState } from 'react';
import { Search, Heart, ShoppingBag, User, Menu, X } from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAccount: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSelectCategory: (category: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenAccount,
  searchQuery,
  setSearchQuery,
  onSelectCategory,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const navLinks = [
    { label: 'Trang chủ', href: '#home', filter: 'all' },
    { label: 'Hàng mới', href: '#products', filter: 'new' },
    { label: 'Nữ', href: '#products', filter: 'women' },
    { label: 'Nam', href: '#products', filter: 'men' },
    { label: 'Phụ kiện', href: '#products', filter: 'accessories' },
    { label: 'Bộ sưu tập', href: '#collections', filter: '' },
  ];

  const handleNavClick = (link: typeof navLinks[0]) => {
    if (link.filter) {
      onSelectCategory(link.filter);
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#E9E5E2] transition-all">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14 h-[72px] flex items-center justify-between gap-4">
        {/* Mobile menu trigger */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#171717] hover:text-[#FF5B23] transition-colors"
            aria-label="Mở menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <button
            onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
            className="p-2 text-[#171717] hover:text-[#FF5B23] transition-colors"
            aria-label="Tìm kiếm"
          >
            <Search className="w-5 h-5" />
          </button>
        </div>

        {/* Brand Logo */}
        <a
          href="#home"
          className="font-editorial text-[32px] sm:text-[36px] font-semibold text-[#111111] tracking-tight hover:opacity-90 transition-opacity whitespace-nowrap"
        >
          Asha
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8 text-[15px] font-medium text-[#262626]">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => handleNavClick(link)}
              className="relative py-1 hover:text-[#FF5B23] transition-colors after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#FF5B23] hover:after:w-full after:transition-all whitespace-nowrap"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Desktop Search Bar */}
          <div className="relative hidden md:block w-48 lg:w-60">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm sản phẩm..."
              className="w-full pl-9 pr-4 py-2 text-sm bg-[#F6F6F6] text-[#171717] placeholder-[#888888] rounded-full border border-transparent focus:border-[#FF5B23] focus:bg-white focus:outline-none transition-all"
            />
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#888888]" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-xs text-[#888888] hover:text-[#171717]"
              >
                ✕
              </button>
            )}
          </div>

          {/* Account Button */}
          <button
            onClick={onOpenAccount}
            className="p-2 text-[#171717] hover:text-[#FF5B23] hover:bg-[#FFF1E8] rounded-full transition-colors relative"
            aria-label="Tài khoản cá nhân"
            title="Tài khoản"
          >
            <User className="w-5 h-5" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={onOpenWishlist}
            className="p-2 text-[#171717] hover:text-[#FF5B23] hover:bg-[#FFF1E8] rounded-full transition-colors relative"
            aria-label="Sản phẩm yêu thích"
            title="Danh sách yêu thích"
          >
            <Heart className="w-5 h-5" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-[#FF5B23] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="p-2 text-[#171717] hover:text-[#FF5B23] hover:bg-[#FFF1E8] rounded-full transition-colors relative"
            aria-label="Giỏ hàng"
            title="Giỏ hàng của bạn"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-1 right-1 min-w-4 h-4 px-1 bg-[#FF5B23] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Search input dropdown */}
      {mobileSearchOpen && (
        <div className="md:hidden px-4 pb-3 pt-1 border-t border-[#F0F0F0] bg-white animate-fadeIn">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm sản phẩm ASHA..."
              className="w-full pl-9 pr-8 py-2 text-sm bg-[#F6F6F6] text-[#171717] rounded-full border border-[#E9E5E2] focus:border-[#FF5B23] focus:outline-none"
              autoFocus
            />
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#888888]" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-xs text-[#888888]"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      )}

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#E9E5E2] bg-white px-6 py-5 shadow-xl animate-fadeIn">
          <div className="flex flex-col gap-4 text-base font-medium text-[#222222]">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => handleNavClick(link)}
                className="py-1 hover:text-[#FF5B23] transition-colors border-b border-neutral-100 last:border-b-0"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 flex items-center justify-between text-sm text-[#737373]">
              <span>Hotline hỗ trợ: <strong className="text-[#FF5B23]">1900 1234</strong></span>
              <span>8:00 - 22:00</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
