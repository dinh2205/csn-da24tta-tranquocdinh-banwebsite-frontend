import React from 'react';
import { ArrowRight, Truck, ShieldCheck, Headphones, Star, Plus } from 'lucide-react';
import { HERO_ASSETS, formatCurrencyVND } from '../data/fashionData';
import { Product } from '../types';

// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhProductBomberMan from '../assets/images/product_bomber_man_1792082787298.jpg';

interface HeroSectionProps {
  onExploreClick: () => void;
  onQuickAddProduct: (product: Product) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onQuickAddProduct,
}) => {
  const sampleBomberProduct: Product = {
    id: 2,
    name: 'Áo khoác bomber nam',
    category: 'Thời trang nam',
    categorySlug: 'men',
    price: 699000,
    oldPrice: 899000,
    currency: 'VND',
    badge: 'Mới',
    image: anhProductBomberMan,
    colors: ['#55633E', '#77716B', '#111111'],
    selectedColor: '#55633E',
    isFavorite: false,
    sizes: ['M', 'L', 'XL'],
  };

  return (
    <section
      id="home"
      className="relative overflow-hidden bg-gradient-to-br from-[#FF5722] via-[#FF762D] to-[#FF8A41] text-white pt-8 sm:pt-12 pb-16 lg:pb-20"
    >
      {/* Abstract Background Decorative Circles */}
      <div
        className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white/10 blur-2xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/2 right-10 w-[500px] h-[500px] rounded-full bg-orange-400/20 blur-3xl pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute -bottom-20 left-1/3 w-80 h-80 rounded-full border border-white/10 pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">
          
          {/* Left Column: Branding, Big Title, Description, CTA, Benefits */}
          <div className="lg:col-span-6 xl:col-span-6 flex flex-col justify-center space-y-6">
            
            {/* Eyebrow */}
            <div className="flex items-center gap-3">
              <span className="w-8 h-[2px] bg-white/80" />
              <p className="text-sm sm:text-base font-semibold tracking-[4px] uppercase text-white/95">
                THỜI TRANG ASHA
              </p>
            </div>

            {/* Giant Headline */}
            <h1 className="font-display text-[48px] sm:text-[68px] md:text-[84px] xl:text-[98px] leading-[0.98] tracking-[-1.5px] uppercase font-black text-white drop-shadow-sm select-none">
              PHONG CÁCH <br />
              VƯỢT THỜI GIAN
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-white/90 max-w-[500px] leading-relaxed font-normal">
              Khám phá bộ sưu tập mới với những thiết kế hiện đại, thanh lịch và đầy cảm hứng cho cuộc sống mỗi ngày.
            </p>

            {/* CTA Button */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <a
                href="#products"
                onClick={onExploreClick}
                className="inline-flex items-center justify-center gap-3 px-8 py-3.5 bg-white text-[#171717] font-semibold text-base rounded-md shadow-lg shadow-black/10 hover:bg-[#171717] hover:text-white transform hover:-translate-y-0.5 transition-all duration-200 group"
              >
                <span>Mua ngay</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="#collections"
                className="inline-flex items-center justify-center px-6 py-3.5 text-white/95 border border-white/40 hover:border-white font-medium text-base rounded-md hover:bg-white/10 transition-all duration-200"
              >
                Xem bộ sưu tập
              </a>
            </div>

            {/* 3 Benefits Row */}
            <div className="pt-6 sm:pt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-white/20 mt-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-white/15 rounded-lg shrink-0 mt-0.5">
                  <Truck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Miễn phí giao hàng</h4>
                  <p className="text-xs text-white/80">Cho đơn từ 499.000đ</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-white/15 rounded-lg shrink-0 mt-0.5">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Đổi trả dễ dàng</h4>
                  <p className="text-xs text-white/80">Trong 30 ngày</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 bg-white/15 rounded-lg shrink-0 mt-0.5">
                  <Headphones className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Hỗ trợ 24/7</h4>
                  <p className="text-xs text-white/80">Tận tâm chu đáo</p>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Vietnamese Models & Floating Badges */}
          <div className="lg:col-span-6 xl:col-span-6 relative flex justify-center items-end mt-4 lg:mt-0">
            
            {/* Handwritten Quote */}
            <div className="absolute top-0 right-4 sm:right-8 z-20 pointer-events-none transform -rotate-6 hidden sm:block">
              <span className="font-handwriting text-2xl sm:text-3xl lg:text-4xl text-white drop-shadow-md whitespace-nowrap">
                Thời trang cho phiên bản tốt hơn của bạn ✨
              </span>
            </div>

            {/* Main Image Container */}
            <div className="relative w-full max-w-[480px] lg:max-w-[540px] rounded-2xl overflow-hidden shadow-2xl border-4 border-white/20 bg-white/10 aspect-[3/4] group">
              <img
                src={HERO_ASSETS.heroModels}
                alt="Người mẫu thời trang ASHA - Phong cách Việt Nam hiện đại"
                className="w-full h-full object-cover object-top transform group-hover:scale-102 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
            </div>

            {/* Floating Product Card (Right-Middle) */}
            <div className="absolute -left-2 sm:left-2 bottom-28 sm:bottom-32 z-30 bg-white text-[#171717] p-3 rounded-xl shadow-2xl border border-neutral-100 max-w-[210px] transform hover:scale-105 transition-all">
              <div className="flex gap-2.5 items-center">
                <img
                  src={sampleBomberProduct.image}
                  alt={sampleBomberProduct.name}
                  className="w-14 h-16 object-cover rounded-md bg-neutral-100 shrink-0"
                />
                <div className="flex flex-col justify-center">
                  <span className="text-[10px] font-bold text-[#FF5B23] uppercase tracking-wider">Bán chạy nhất</span>
                  <h4 className="text-xs font-bold leading-tight line-clamp-1 mt-0.5 text-neutral-900">
                    {sampleBomberProduct.name}
                  </h4>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-xs font-bold text-[#FF5B23]">
                      {formatCurrencyVND(sampleBomberProduct.price)}
                    </span>
                    <span className="text-[10px] text-neutral-400 line-through">
                      {formatCurrencyVND(sampleBomberProduct.oldPrice || 0)}
                    </span>
                  </div>
                  <button
                    onClick={() => onQuickAddProduct(sampleBomberProduct)}
                    className="mt-1.5 flex items-center justify-center gap-1 w-full py-1 px-2 bg-[#FF5B23] text-white rounded text-[10px] font-semibold hover:bg-[#EB4815] transition-colors"
                  >
                    <Plus className="w-3 h-3" /> Thêm nhanh
                  </button>
                </div>
              </div>
            </div>

            {/* Floating Rating Card (Right-Bottom) */}
            <div className="absolute -right-2 sm:right-4 bottom-4 z-30 bg-white/95 backdrop-blur-md text-[#171717] px-4 py-3 rounded-xl shadow-2xl border border-neutral-100 flex items-center gap-3">
              {/* Overlapping Avatars */}
              <div className="flex -space-x-2">
                <img
                  className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                  alt="Khách hàng ASHA"
                />
                <img
                  className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
                  alt="Khách hàng ASHA"
                />
                <img
                  className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80"
                  alt="Khách hàng ASHA"
                />
              </div>

              <div>
                <div className="flex items-center gap-1">
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-neutral-900 ml-1">4.9/5</span>
                </div>
                <p className="text-[11px] text-neutral-600 font-medium">
                  Hơn <strong className="text-neutral-900">10.000+</strong> khách hàng tin tưởng
                </p>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
