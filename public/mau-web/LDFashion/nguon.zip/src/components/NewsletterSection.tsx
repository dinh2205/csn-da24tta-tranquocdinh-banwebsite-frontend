import React, { useState } from 'react';
import { Mail, CheckCircle2, ArrowRight } from 'lucide-react';
import { HERO_ASSETS } from '../data/fashionData';

export const NewsletterSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim() || !emailRegex.test(email.trim())) {
      setErrorMessage('Vui lòng nhập địa chỉ email hợp lệ.');
      return;
    }

    try {
      const existing = JSON.parse(
        localStorage.getItem('asha_newsletter_subscriptions') || '[]'
      );
      if (!existing.includes(email.trim())) {
        existing.push(email.trim());
        localStorage.setItem(
          'asha_newsletter_subscriptions',
          JSON.stringify(existing)
        );
      }
      setIsSubmitted(true);
      setEmail('');
    } catch (err) {
      console.error(err);
      setIsSubmitted(true);
    }
  };

  return (
    <section className="py-10 sm:py-14 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#E9D7C9] via-[#EFE3DB] to-[#F2E8E1] shadow-lg border border-[#DEC7B6]/40 p-6 sm:p-10 lg:p-12">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Visual: Model in Cream Sweater */}
            <div className="lg:col-span-3 flex justify-center lg:justify-start">
              <div className="relative w-44 sm:w-52 aspect-[3/4] rounded-xl overflow-hidden shadow-md border-2 border-white/60 bg-white">
                <img
                  src={HERO_ASSETS.newsletterModel}
                  alt="Người mẫu ASHA trong áo len ấm áp"
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
              </div>
            </div>

            {/* Center Content: Title, description, and newsletter form */}
            <div className="lg:col-span-6 text-center lg:text-left space-y-3">
              <span className="text-xs font-bold uppercase tracking-[2.5px] text-[#FF5B23]">
                BẢN TIN ASHA CLUB
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#222222] tracking-tight">
                ĐĂNG KÝ NHẬN TIN TỪ ASHA
              </h2>
              <p className="text-sm sm:text-base text-[#666666] max-w-lg leading-relaxed">
                Cập nhật nhanh nhất về bộ sưu tập mới, ưu đãi đặc biệt và quà tặng sinh nhật dành riêng cho bạn.
              </p>

              {isSubmitted ? (
                <div className="pt-2 flex items-center justify-center lg:justify-start gap-2 text-emerald-700 bg-emerald-50 border border-emerald-200 py-3 px-4 rounded-lg animate-fadeIn max-w-md">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span className="text-sm font-medium">
                    Cảm ơn bạn đã đăng ký! Asha sẽ gửi ưu đãi sớm nhất tới email của bạn.
                  </span>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="pt-2 max-w-md mx-auto lg:mx-0">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <div className="relative flex-grow">
                      <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-neutral-400" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (errorMessage) setErrorMessage('');
                        }}
                        placeholder="Nhập email của bạn..."
                        className="w-full pl-10 pr-4 py-3 bg-white text-[#171717] placeholder-neutral-400 text-sm rounded-lg border border-neutral-300 focus:border-[#FF5B23] focus:ring-2 focus:ring-[#FF5B23]/20 focus:outline-none transition-all shadow-sm"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#FF5B23] hover:bg-[#EB4815] text-white font-semibold text-sm rounded-lg shadow-md transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
                    >
                      <span>Đăng ký</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                  {errorMessage && (
                    <p className="text-xs text-red-600 mt-1.5 text-left pl-1 font-medium">
                      {errorMessage}
                    </p>
                  )}
                  <p className="text-[11px] text-neutral-500 mt-2 text-left pl-1">
                    *Chúng tôi cam kết bảo mật thông tin cá nhân và không spam thư rác.
                  </p>
                </form>
              )}
            </div>

            {/* Right Decoration: Handwritten Typography */}
            <div className="lg:col-span-3 flex justify-center lg:justify-end text-center lg:text-right">
              <div className="transform -rotate-6 bg-white/60 backdrop-blur-sm p-4 rounded-xl border border-white/80 shadow-sm max-w-[220px]">
                <p className="font-handwriting text-2xl sm:text-3xl text-[#6A4B3B] leading-tight font-semibold">
                  Tham gia cộng đồng Asha ngay hôm nay! ✨
                </p>
                <div className="mt-2 text-[11px] font-bold text-[#FF5B23] uppercase tracking-wider">
                  #AshaFashion #PhongCachViet
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
