import React from 'react';
import { Heart, Plus } from 'lucide-react';
import { Product } from '../types';
import { formatCurrencyVND } from '../data/fashionData';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product, e: React.MouseEvent) => void;
  onColorChange: (productId: number, color: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isFavorite,
  onToggleFavorite,
  onSelectProduct,
  onQuickAdd,
  onColorChange,
}) => {
  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group flex flex-col bg-white rounded-md overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-1 hover:shadow-lg border border-neutral-100/80"
    >
      {/* Product Image Container */}
      <div className="relative aspect-[3/4] bg-[#F3F3F3] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center transform group-hover:scale-104 transition-transform duration-500 ease-out"
          referrerPolicy="no-referrer"
        />

        {/* Badge (Mới, -20%) */}
        {product.badge && (
          <div className="absolute top-2.5 left-2.5 z-10">
            <span
              className={`text-[11px] font-bold px-2 py-0.5 rounded tracking-wide uppercase ${
                product.badge.includes('%')
                  ? 'bg-[#FF4B1F] text-white'
                  : 'bg-[#171717] text-white'
              }`}
            >
              {product.badge}
            </span>
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite(product);
          }}
          className={`absolute top-2.5 right-2.5 z-10 p-1.5 rounded-full transition-all shadow-sm ${
            isFavorite
              ? 'bg-[#FF5B23] text-white'
              : 'bg-white/80 hover:bg-white text-[#171717] hover:text-[#FF5B23]'
          }`}
          aria-label={isFavorite ? 'Bỏ yêu thích' : 'Yêu thích'}
          title={isFavorite ? 'Bỏ yêu thích' : 'Thêm vào yêu thích'}
        >
          <Heart
            className={`w-4 h-4 transition-transform ${isFavorite ? 'fill-current scale-110' : ''}`}
          />
        </button>

        {/* Quick Add overlay button on hover */}
        <div className="absolute inset-x-2 bottom-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={(e) => onQuickAdd(product, e)}
            className="w-full py-2 bg-white/95 hover:bg-[#FF5B23] text-[#171717] hover:text-white text-xs font-semibold rounded shadow-md flex items-center justify-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Thêm nhanh</span>
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-3 flex flex-col flex-grow justify-between">
        <div>
          {/* Category */}
          <span className="text-[11px] font-medium text-[#737373] uppercase tracking-wider block">
            {product.category}
          </span>

          {/* Product Name */}
          <h3 className="text-[13px] sm:text-[14px] font-semibold text-[#171717] group-hover:text-[#FF5B23] transition-colors line-clamp-1 mt-0.5" title={product.name}>
            {product.name}
          </h3>
        </div>

        <div className="mt-2.5">
          {/* Price */}
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-[15px] font-bold text-[#F04C20] tabular-nums">
              {formatCurrencyVND(product.price)}
            </span>
            {product.oldPrice && (
              <span className="text-xs text-[#999999] line-through tabular-nums">
                {formatCurrencyVND(product.oldPrice)}
              </span>
            )}
          </div>

          {/* Color Selection Swatches */}
          {product.colors && product.colors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2" onClick={(e) => e.stopPropagation()}>
              {product.colors.map((color, idx) => {
                const isSelected = product.selectedColor === color || (!product.selectedColor && idx === 0);
                return (
                  <button
                    key={color}
                    onClick={() => onColorChange(product.id, color)}
                    className={`w-3.5 h-3.5 rounded-full border transition-all ${
                      isSelected
                        ? 'ring-2 ring-[#FF5B23] ring-offset-1 scale-110 border-white'
                        : 'border-neutral-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: color }}
                    aria-label={`Màu ${color}`}
                    title={`Màu ${color}`}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
