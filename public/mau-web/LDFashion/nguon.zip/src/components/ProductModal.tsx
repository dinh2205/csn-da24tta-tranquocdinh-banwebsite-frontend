import React, { useState, useEffect } from 'react';
import { X, Heart, ShoppingBag, Star, Check, Truck, ShieldCheck } from 'lucide-react';
import { Product } from '../types';
import { formatCurrencyVND } from '../data/fashionData';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, color: string, size: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
  isFavorite,
  onToggleFavorite,
}) => {
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  useEffect(() => {
    if (product) {
      setSelectedColor(product.selectedColor || product.colors[0] || '#C8AE94');
      setSelectedSize(product.sizes && product.sizes.length > 0 ? product.sizes[0] : 'M');
      setQuantity(1);
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    onAddToCart(product, quantity, selectedColor, selectedSize);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="relative bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-neutral-500 hover:text-black bg-white/80 hover:bg-neutral-100 rounded-full transition-colors"
          aria-label="Đóng"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Left: Product Image */}
          <div className="relative aspect-[3/4] bg-neutral-100 overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover object-center"
              referrerPolicy="no-referrer"
            />
            {product.badge && (
              <span className="absolute top-4 left-4 bg-[#FF5B23] text-white text-xs font-bold px-2.5 py-1 rounded uppercase tracking-wider">
                {product.badge}
              </span>
            )}
          </div>

          {/* Right: Product Details & Controls */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-5">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-[#737373] mb-1">
                <span className="uppercase tracking-wider font-semibold">{product.category}</span>
                <div className="flex items-center gap-1 text-amber-500 font-semibold">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{product.rating || 4.9}</span>
                  <span className="text-neutral-400">({product.reviewsCount || 100}+)</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-2xl font-bold text-[#171717]">
                {product.name}
              </h2>

              {/* Price */}
              <div className="flex items-baseline gap-3 mt-3">
                <span className="text-2xl font-extrabold text-[#F04C20] tabular-nums">
                  {formatCurrencyVND(product.price)}
                </span>
                {product.oldPrice && (
                  <span className="text-sm text-neutral-400 line-through tabular-nums">
                    {formatCurrencyVND(product.oldPrice)}
                  </span>
                )}
                {product.oldPrice && (
                  <span className="text-xs font-bold text-[#FF5B23] bg-[#FFF1E8] px-2 py-0.5 rounded">
                    Tiết kiệm {formatCurrencyVND(product.oldPrice - product.price)}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-neutral-600 mt-4 leading-relaxed">
                {product.description || 'Sản phẩm cao cấp thiết kế bởi thương hiệu thời trang ASHA, mang đến sự tinh tế, thoải mái và tự tin cho người mặc.'}
              </p>

              {/* Color Selector */}
              {product.colors && product.colors.length > 0 && (
                <div className="mt-5">
                  <div className="flex items-center justify-between text-xs font-semibold text-neutral-700 mb-2">
                    <span>Màu sắc:</span>
                    <span className="text-[#FF5B23]">{selectedColor}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {product.colors.map((c) => (
                      <button
                        key={c}
                        onClick={() => setSelectedColor(c)}
                        className={`w-7 h-7 rounded-full border-2 transition-all flex items-center justify-center ${
                          selectedColor === c
                            ? 'ring-2 ring-[#FF5B23] ring-offset-2 scale-110 border-white'
                            : 'border-neutral-300 hover:scale-105'
                        }`}
                        style={{ backgroundColor: c }}
                        title={`Màu ${c}`}
                      >
                        {selectedColor === c && (
                          <Check className={`w-3.5 h-3.5 ${c === '#FFFFFF' || c === '#E9E2D9' ? 'text-black' : 'text-white'}`} />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Size Selector */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="mt-5">
                  <div className="flex items-center justify-between text-xs font-semibold text-neutral-700 mb-2">
                    <span>Kích thước:</span>
                    <span className="text-[#FF5B23] font-bold">{selectedSize}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((s) => (
                      <button
                        key={s}
                        onClick={() => setSelectedSize(s)}
                        className={`px-3.5 py-1.5 text-xs font-semibold rounded border transition-all ${
                          selectedSize === s
                            ? 'bg-[#171717] text-white border-[#171717]'
                            : 'bg-white text-neutral-700 border-neutral-300 hover:border-neutral-400'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity Selector */}
              <div className="mt-5 flex items-center gap-4">
                <span className="text-xs font-semibold text-neutral-700">Số lượng:</span>
                <div className="flex items-center border border-neutral-300 rounded-md">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-sm font-bold text-neutral-600 hover:bg-neutral-100 transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 text-xs font-bold tabular-nums">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-sm font-bold text-neutral-600 hover:bg-neutral-100 transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            {/* Actions: Add to cart & Wishlist */}
            <div className="pt-4 border-t border-neutral-100 space-y-3">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleAddToCart}
                  className="flex-grow py-3 px-6 bg-[#FF5B23] hover:bg-[#EB4815] text-white font-bold text-sm rounded-lg shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Thêm vào giỏ hàng • {formatCurrencyVND(product.price * quantity)}</span>
                </button>

                <button
                  onClick={() => onToggleFavorite(product)}
                  className={`p-3 rounded-lg border transition-colors ${
                    isFavorite
                      ? 'bg-[#FFF1E8] border-[#FF5B23] text-[#FF5B23]'
                      : 'border-neutral-300 text-neutral-700 hover:bg-neutral-50'
                  }`}
                  aria-label="Yêu thích"
                  title="Lưu vào yêu thích"
                >
                  <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Trust markers */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-500 pt-1">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#FF5B23]" />
                  <span>Freeship đơn từ 499k</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#FF5B23]" />
                  <span>Đổi trả 30 ngày dễ dàng</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
