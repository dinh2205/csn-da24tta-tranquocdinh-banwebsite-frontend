import React from 'react';
import { CheckCircle2, ShoppingBag, Heart } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'cart' | 'favorite' | 'info';
  title: string;
  message: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const Toast: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          onClick={() => onDismiss(toast.id)}
          className="pointer-events-auto bg-neutral-900/95 backdrop-blur-md text-white p-3.5 rounded-xl shadow-2xl border border-neutral-700/60 flex items-start gap-3 cursor-pointer transform hover:scale-102 transition-all animate-bounceIn"
        >
          <div className="p-1.5 rounded-lg bg-[#FF5B23] text-white shrink-0 mt-0.5">
            {toast.type === 'cart' ? (
              <ShoppingBag className="w-4 h-4" />
            ) : toast.type === 'favorite' ? (
              <Heart className="w-4 h-4 fill-current" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
          </div>
          <div className="flex-1">
            <h5 className="text-xs font-bold text-white leading-tight">{toast.title}</h5>
            <p className="text-[11px] text-neutral-300 mt-0.5">{toast.message}</p>
          </div>
        </div>
      ))}
    </div>
  );
};
