import React from 'react';
import { Gem, Truck, PackageCheck, Headphones } from 'lucide-react';
import { WHY_CHOOSE_US_DATA } from '../data/fashionData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'gem':
        return <Gem className="w-8 h-8 text-[#FF5B23]" />;
      case 'truck':
        return <Truck className="w-8 h-8 text-[#FF5B23]" />;
      case 'package-check':
        return <PackageCheck className="w-8 h-8 text-[#FF5B23]" />;
      case 'headphones':
        return <Headphones className="w-8 h-8 text-[#FF5B23]" />;
      default:
        return <Gem className="w-8 h-8 text-[#FF5B23]" />;
    }
  };

  return (
    <section className="py-14 sm:py-20 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center justify-center gap-2 text-xs font-bold tracking-[3px] uppercase text-[#FF5B23] mb-2">
            <span className="w-4 h-[2px] bg-[#FF5B23]" />
            CAM KẾT THƯƠNG HIỆU
            <span className="w-4 h-[2px] bg-[#FF5B23]" />
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#171717] tracking-tight">
            VÌ SAO CHỌN ASHA?
          </h2>
          <p className="text-sm sm:text-base text-[#737373] mt-2">
            Chúng tôi không chỉ bán quần áo, mà còn mang đến phong cách sống hiện đại cho bạn.
          </p>
        </div>

        {/* 4 Benefits with Vertical Separators */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#FFD9C6]/60 rounded-xl bg-[#FFF9F5] p-6 sm:p-10 border border-[#FFE7DB]">
          {WHY_CHOOSE_US_DATA.map((benefit, index) => (
            <div
              key={benefit.title}
              className={`flex flex-col items-center text-center p-4 sm:p-6 transition-all hover:-translate-y-1 ${
                index > 0 ? 'sm:border-l-0' : ''
              }`}
            >
              <div className="w-16 h-16 rounded-2xl bg-white shadow-sm flex items-center justify-center mb-4 border border-[#FFE3D4]">
                {getIcon(benefit.icon)}
              </div>
              <h3 className="text-base sm:text-lg font-bold text-[#171717] mb-2">
                {benefit.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#737373] leading-relaxed max-w-[240px]">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
