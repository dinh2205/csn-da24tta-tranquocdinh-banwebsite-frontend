import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { HERO_ASSETS } from '../data/fashionData';

interface WinterCampaignProps {
  onExplore: () => void;
}

export const WinterCampaign: React.FC<WinterCampaignProps> = ({ onExplore }) => {
  return (
    <section className="py-8 sm:py-12 bg-white">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 lg:px-14">
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-[#B94320] via-[#E66D36] to-[#D99A6E] text-white shadow-xl min-h-[340px] sm:min-h-[400px] flex items-center">
          
          {/* Background Image on Right with Smooth Fade */}
          <div className="absolute top-0 right-0 bottom-0 w-full md:w-3/5 lg:w-1/2 overflow-hidden pointer-events-none">
            <img
              src={HERO_ASSETS.winterCampaign}
              alt="Bộ sưu tập Thu Đông ASHA"
              className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-1000"
              referrerPolicy="no-referrer"
            />
            {/* Gradient Scrim for Content Readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#B94320] via-[#B94320]/80 md:via-[#B94320]/60 to-transparent" />
          </div>

          {/* Text Content on Left */}
          <div className="relative z-10 w-full md:w-3/5 lg:w-1/2 p-6 sm:p-10 lg:p-12 flex flex-col justify-center space-y-4">
            
            {/* Eyebrow & Badge */}
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-sm text-xs font-semibold tracking-wider uppercase text-white">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                BỘ SƯU TẬP THU ĐÔNG
              </span>
            </div>

            {/* Title */}
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl tracking-tight leading-[1.05] uppercase font-black drop-shadow-sm">
              ẤM ÁP <br />
              ĐẦY CẢM HỨNG
            </h2>

            {/* Description */}
            <p className="text-sm sm:text-base text-white/90 max-w-md leading-relaxed font-normal">
              Những thiết kế mới cho mùa thu đông - kết hợp hoàn hảo giữa sự thoải mái, giữ nhiệt ấm êm và phong cách đương đại sắc sảo.
            </p>

            {/* Handwritten Note */}
            <div className="pt-1">
              <span className="font-handwriting text-xl sm:text-2xl text-amber-200">
                "Mùa mới, phong cách mới, câu chuyện mới"
              </span>
            </div>

            {/* Action Button */}
            <div className="pt-2">
              <a
                href="#products"
                onClick={onExplore}
                className="inline-flex items-center gap-2.5 px-7 py-3 bg-white text-[#171717] font-semibold text-sm sm:text-base rounded-md hover:bg-[#171717] hover:text-white transition-all shadow-md group"
              >
                <span>Khám phá ngay</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
