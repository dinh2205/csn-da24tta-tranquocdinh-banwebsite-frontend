import React from 'react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { Product } from '../types';
import { formatCurrencyVND } from '../data/fashionData';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  favoriteProducts: Product[];
  onRemoveFavorite: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  favoriteProducts,
  onRemoveFavorite,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-5 border-b border-neutral-200 flex items-center justify-between bg-white">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-[#FF5B23] fill-current" />
              <h3 className="text-lg font-bold text-neutral-900">
                Sản phẩm yêu thích ({favoriteProducts.length})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-500 hover:text-black hover:bg-neutral-100 rounded-full transition-colors"
              aria-label="Đóng"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List of Wishlist items */}
          <div className="flex-1 overflow-y-auto p-5">
            {favoriteProducts.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <div className="w-16 h-16 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center mx-auto">
                  <Heart className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-neutral-800">
                  Danh sách yêu thích trống
                </h4>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                  Bấm vào biểu tượng trái tim trên các sản phẩm bạn yêu thích để lưu lại và xem sau.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-[#FF5B23] text-white text-xs font-semibold rounded-md hover:bg-[#EB4815] transition-colors"
                >
                  Khám phá ngay
                </button>
              </div>
            ) : (
              <div className="divide-y divide-neutral-100">
                {favoriteProducts.map((product) => (
                  <div key={product.id} className="py-4 flex gap-3">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-20 h-24 object-cover rounded bg-neutral-100 shrink-0"
                    />
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="text-sm font-bold text-neutral-900 line-clamp-1">
                            {product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveFavorite(product)}
                            className="text-neutral-400 hover:text-red-500 p-1"
                            title="Xóa khỏi yêu thích"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        <span className="text-xs text-neutral-500 block mt-0.5">
                          {product.category}
                        </span>

                        <div className="mt-1 text-sm font-bold text-[#FF5B23] tabular-nums">
                          {formatCurrencyVND(product.price)}
                        </div>
                      </div>

                      <div className="mt-3">
                        <button
                          onClick={() => {
                            onAddToCart(product);
                          }}
                          className="w-full py-2 bg-neutral-900 hover:bg-[#FF5B23] text-white text-xs font-semibold rounded flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Thêm vào giỏ</span>
                        </button>
                      </div>

                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {favoriteProducts.length > 0 && (
            <div className="p-5 border-t border-neutral-200 bg-white">
              <button
                onClick={onClose}
                className="w-full py-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-semibold text-sm rounded-lg transition-colors"
              >
                Tiếp tục xem sản phẩm
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
