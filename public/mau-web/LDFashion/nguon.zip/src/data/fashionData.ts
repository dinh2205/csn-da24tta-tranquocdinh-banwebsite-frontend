import { Product, Collection, BenefitItem } from '../types';

// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhCollectionCouple from '../assets/images/collection_couple_1792082766755.jpg';
import anhCollectionElegantWoman from '../assets/images/collection_elegant_woman_1792082742757.jpg';
import anhCollectionPartyWoman from '../assets/images/collection_party_woman_1792082765737.jpg';
import anhCollectionStreetwearMan from '../assets/images/collection_streetwear_man_1792082743786.jpg';
import anhHeroFashionModels from '../assets/images/hero_fashion_models_1792082741797.jpg';
import anhNewsletterModel from '../assets/images/newsletter_model_1792082743193.jpg';
import anhProductBlazerWoman from '../assets/images/product_blazer_woman_1792082786306.jpg';
import anhProductBomberMan from '../assets/images/product_bomber_man_1792082787298.jpg';
import anhProductPoloMan from '../assets/images/product_polo_man_1792082810773.jpg';
import anhProductStripedKnit from '../assets/images/product_striped_knit_1792082787925.jpg';
import anhProductWhiteSneakers from '../assets/images/product_white_sneakers_1792082787861.jpg';
import anhProductWideLegPants from '../assets/images/product_wide_leg_pants_1792082810752.jpg';
import anhWinterFashionBanner from '../assets/images/winter_fashion_banner_1792082742333.jpg';

export const HERO_ASSETS = {
  heroModels: anhHeroFashionModels,
  winterCampaign: anhWinterFashionBanner,
  newsletterModel: anhNewsletterModel,
};

export const COLLECTIONS_DATA: Collection[] = [
  {
    id: 'elegance',
    title: 'Thanh lịch hằng ngày',
    image: anhCollectionElegantWoman,
    theme: 'Cô nàng thanh lịch trong áo khoác beige',
    textColor: '#FFFFFF',
    action: 'Khám phá',
    href: '#products',
  },
  {
    id: 'streetwear',
    title: 'Dạo phố cuối tuần',
    image: anhCollectionStreetwearMan,
    theme: 'Chàng trai phong cách streetwear đen cá tính',
    textColor: '#FFFFFF',
    action: 'Khám phá',
    href: '#products',
  },
  {
    id: 'party',
    title: 'Phong cách dự tiệc',
    image: anhCollectionPartyWoman,
    theme: 'Đầm lụa satin màu cam đất sang trọng',
    textColor: '#FFFFFF',
    action: 'Khám phá',
    href: '#products',
  },
  {
    id: 'couple',
    title: 'Cặp đôi hiện đại',
    image: anhCollectionCouple,
    theme: 'Cặp đôi trẻ với trang phục tone màu trung tính hài hòa',
    textColor: '#FFFFFF',
    action: 'Khám phá',
    href: '#products',
  },
];

export const PRODUCTS_DATA: Product[] = [
  {
    id: 1,
    name: 'Áo blazer nữ thanh lịch',
    category: 'Thời trang nữ',
    categorySlug: 'women',
    price: 599000,
    oldPrice: 799000,
    currency: 'VND',
    badge: 'Mới',
    image: anhProductBlazerWoman,
    colors: ['#C8AE94', '#FFFFFF', '#222222'],
    selectedColor: '#C8AE94',
    isFavorite: false,
    description: 'Chất liệu vải tuýt si cao cấp, phom dáng suông vừa vặn tôn dáng, đường may chuẩn chỉ phù hợp công sở và dạo phố.',
    sizes: ['S', 'M', 'L'],
    rating: 4.9,
    reviewsCount: 128,
  },
  {
    id: 2,
    name: 'Áo khoác bomber nam',
    category: 'Thời trang nam',
    categorySlug: 'men',
    price: 699000,
    oldPrice: 899000,
    currency: 'VND',
    badge: 'Mới',
    image: anhProductBomberMan,
    colors: ['#55633E', '#77716B', '#111111'],
    selectedColor: '#55633E',
    isFavorite: false,
    description: 'Áo khoác bomber nam phong cách quân đội hiện đại, lớp lót gió êm ái, khóa kéo kim loại bền chắc và túi tay cá tính.',
    sizes: ['M', 'L', 'XL', '2XL'],
    rating: 5.0,
    reviewsCount: 94,
  },
  {
    id: 3,
    name: 'Áo len sọc nữ cổ tròn',
    category: 'Thời trang nữ',
    categorySlug: 'women',
    price: 399000,
    oldPrice: 499000,
    currency: 'VND',
    badge: null,
    image: anhProductStripedKnit,
    colors: ['#C3A58B', '#111111'],
    selectedColor: '#C3A58B',
    isFavorite: false,
    description: 'Sợi len dệt kim mềm mịn thoáng khí, họa tiết sọc ngang kinh điển phong cách Pháp trẻ trung dễ phối đồ.',
    sizes: ['Freesize', 'L'],
    rating: 4.8,
    reviewsCount: 86,
  },
  {
    id: 4,
    name: 'Áo polo nam basic',
    category: 'Thời trang nam',
    categorySlug: 'men',
    price: 319000,
    oldPrice: 399000,
    currency: 'VND',
    badge: '-20%',
    image: anhProductPoloMan,
    colors: ['#C09B7A', '#111111', '#818181'],
    selectedColor: '#C09B7A',
    isFavorite: false,
    description: 'Vải cotton cá sấu dệt 100% tự nhiên mềm mại, thấm hút mồ hôi tốt, cổ bo dệt co giãn giữ form sau nhiều lần giặt.',
    sizes: ['S', 'M', 'L', 'XL'],
    rating: 4.9,
    reviewsCount: 215,
  },
  {
    id: 5,
    name: 'Quần tây nữ ống rộng',
    category: 'Thời trang nữ',
    categorySlug: 'women',
    price: 459000,
    oldPrice: 599000,
    currency: 'VND',
    badge: null,
    image: anhProductWideLegPants,
    colors: ['#B89B7F', '#1A1A1A', '#E9E2D9'],
    selectedColor: '#B89B7F',
    isFavorite: false,
    description: 'Thiết kế cạp cao tôn chiều dài đôi chân, xếp ly tinh tế phía trước, chất vải rũ đứng dáng sang trọng.',
    sizes: ['S', 'M', 'L'],
    rating: 4.7,
    reviewsCount: 79,
  },
  {
    id: 6,
    name: 'Giày sneaker unisex',
    category: 'Giày dép & Phụ kiện',
    categorySlug: 'accessories',
    price: 690000,
    oldPrice: 860000,
    currency: 'VND',
    badge: null,
    image: anhProductWhiteSneakers,
    colors: ['#C77D48', '#161616'],
    selectedColor: '#C77D48',
    isFavorite: false,
    description: 'Da nhân tạo cao cấp bề mặt mịn, đệm lót êm chân hỗ trợ vận động cả ngày, điểm nhấn viền gót cam đất đặc trưng ASHA.',
    sizes: ['38', '39', '40', '41', '42'],
    rating: 5.0,
    reviewsCount: 162,
  },
];

export const WHY_CHOOSE_US_DATA: BenefitItem[] = [
  {
    icon: 'gem',
    title: 'Thiết kế độc đáo',
    description: 'Cập nhật xu hướng mới nhất từ các kinh đô thời trang thế giới.',
  },
  {
    icon: 'truck',
    title: 'Giao hàng nhanh chóng',
    description: 'Miễn phí giao hàng cho đơn từ 499.000đ.',
  },
  {
    icon: 'package-check',
    title: 'Đổi trả dễ dàng',
    description: 'Hỗ trợ đổi trả trong 30 ngày với mọi sản phẩm đủ điều kiện.',
  },
  {
    icon: 'headphones',
    title: 'Hỗ trợ tận tâm',
    description: 'Đội ngũ CSKH luôn sẵn sàng hỗ trợ bạn 24/7.',
  },
];

export const formatCurrencyVND = (amount: number): string => {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount).replace('₫', 'đ');
};
