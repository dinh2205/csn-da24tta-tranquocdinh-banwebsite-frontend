export interface Product {
  id: number;
  name: string;
  category: string;
  categorySlug: 'women' | 'men' | 'accessories';
  price: number;
  oldPrice?: number;
  currency: string;
  badge?: string | null;
  image: string;
  colors: string[];
  selectedColor?: string;
  isFavorite?: boolean;
  description?: string;
  sizes?: string[];
  rating?: number;
  reviewsCount?: number;
}

export interface Collection {
  id: string;
  title: string;
  image: string;
  theme: string;
  textColor: string;
  action: string;
  href: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
  selectedSize: string;
}

export interface BenefitItem {
  icon: string;
  title: string;
  description: string;
}
