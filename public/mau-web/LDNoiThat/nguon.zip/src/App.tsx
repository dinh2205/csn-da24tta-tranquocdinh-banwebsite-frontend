/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { SearchStatistics } from './components/SearchStatistics';
import { CollectionSection } from './components/CollectionSection';
import { AboutSection } from './components/AboutSection';
import { Footer } from './components/Footer';
import { CartDrawer, CartItem } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CollectionModal } from './components/CollectionModal';
import { AuthModal } from './components/AuthModal';
import { 
  ServicesModal, 
  ContactModal, 
  PolicyModal, 
  StoryModal 
} from './components/InfoModals';
import { Product, SAMPLE_PRODUCTS } from './data/products';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  
  // Cart state persisted to LocalStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('camhome_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // User auth state persisted to LocalStorage
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string } | null>(() => {
    try {
      const saved = localStorage.getItem('camhome_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Modals state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [authModal, setAuthModal] = useState<{ open: boolean; mode: 'login' | 'register' }>({
    open: false,
    mode: 'login',
  });
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCollectionId, setActiveCollectionId] = useState<string | null>(null);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [activePolicy, setActivePolicy] = useState<string | null>(null);
  const [storyOpen, setStoryOpen] = useState(false);

  // Save cart to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('camhome_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  // Handle smooth scroll navigation
  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleLogout = () => {
    localStorage.removeItem('camhome_user');
    setCurrentUser(null);
  };

  const handleOpenProductById = (productId: string) => {
    const found = SAMPLE_PRODUCTS.find((p) => p.id === productId);
    if (found) {
      setSelectedProduct(found);
    }
  };

  const cartTotalItems = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#FFF5ED] text-[#251D1A] flex flex-col font-sans-main">
      {/* 1. Header Navigation */}
      <Header
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenAuth={(mode) => setAuthModal({ open: true, mode })}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenServices={() => setServicesOpen(true)}
        onOpenContact={() => setContactOpen(true)}
        cartCount={cartTotalItems}
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Main Content Sections strictly in order */}
      <main className="flex-1 w-full">
        {/* 2. Hero Section */}
        <HeroSection
          onExplore={() => handleNavigate('collections')}
          onOpenProduct={handleOpenProductById}
        />

        {/* 3. Search and Statistics Bar */}
        <SearchStatistics
          onSelectProduct={(product) => setSelectedProduct(product)}
        />

        {/* 4. Asymmetric Collection Grid ("Bộ sưu tập của chúng tôi") */}
        <CollectionSection
          onExploreCollection={(collectionId) => setActiveCollectionId(collectionId)}
        />

        {/* 5. Brand Introduction / About Cam Home */}
        <AboutSection
          onExplore={() => handleNavigate('collections')}
          onOpenStoryModal={() => setStoryOpen(true)}
        />
      </main>

      {/* 6. Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenPolicy={(policy) => setActivePolicy(policy)}
        onOpenServices={() => setServicesOpen(true)}
        onOpenContact={() => setContactOpen(true)}
      />

      {/* Interactive Drawers & Modals */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      <CollectionModal
        collectionId={activeCollectionId}
        onClose={() => setActiveCollectionId(null)}
        onSelectProduct={(product) => {
          setSelectedProduct(product);
          setActiveCollectionId(null);
        }}
        onQuickAddToCart={(product) => handleAddToCart(product, 1)}
      />

      <AuthModal
        isOpen={authModal.open}
        initialMode={authModal.mode}
        onClose={() => setAuthModal({ ...authModal, open: false })}
        onLoginSuccess={(user) => setCurrentUser(user)}
      />

      <ServicesModal
        isOpen={servicesOpen}
        onClose={() => setServicesOpen(false)}
      />

      <ContactModal
        isOpen={contactOpen}
        onClose={() => setContactOpen(false)}
      />

      <PolicyModal
        policyTitle={activePolicy}
        onClose={() => setActivePolicy(null)}
      />

      <StoryModal
        isOpen={storyOpen}
        onClose={() => setStoryOpen(false)}
      />
    </div>
  );
}
