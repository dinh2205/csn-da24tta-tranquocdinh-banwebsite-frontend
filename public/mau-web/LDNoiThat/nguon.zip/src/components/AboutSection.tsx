import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhAboutOrangeRoom from '../assets/images/about_orange_room_1792083006613.jpg';

interface AboutSectionProps {
  onExplore: () => void;
  onOpenStoryModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  onExplore,
  onOpenStoryModal,
}) => {
  return (
    <section 
      id="about" 
      className="w-full bg-[#FFF8F3] py-14 sm:py-20 lg:py-24 overflow-hidden"
    >
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* LEFT CONTENT */}
          <div className="lg:col-span-6 flex flex-col justify-center text-left">
            {/* Eyebrow Kicker */}
            <div className="flex items-center gap-2 mb-3">
              <span className="w-4 h-[2px] bg-[#B45134]" />
              <span className="text-[12px] font-bold tracking-[0.28em] text-[#B45134] uppercase">
                VỀ CHÚNG TÔI
              </span>
            </div>

            {/* Headline */}
            <h2 className="font-display text-3xl sm:text-4xl lg:text-[46px] font-semibold text-[#301E18] tracking-tight leading-tight mb-2">
              Nội Thất Cam Home
            </h2>

            {/* Subtitle */}
            <h3 className="text-lg sm:text-xl font-bold text-[#301E18] mb-5">
              Kiến tạo không gian sống tốt đẹp hơn
            </h3>

            {/* Description */}
            <p className="text-[#66605C] text-[15px] sm:text-[15.5px] leading-[1.8] mb-8 font-normal max-w-xl">
              Chúng tôi tin rằng một không gian sống đẹp không chỉ đến từ những món đồ nội thất, mà còn từ cảm xúc và câu chuyện của mỗi gia đình. Nội Thất Cam Home luôn nỗ lực mang đến những sản phẩm chất lượng, thiết kế tinh tế và dịch vụ tận tâm, giúp bạn biến ngôi nhà thành tổ ấm thực sự.
            </p>

            {/* Button */}
            <div>
              <button
                onClick={onOpenStoryModal}
                className="inline-flex items-center gap-3 bg-[#FF5315] hover:bg-[#E8440A] text-white text-[14.5px] font-semibold px-7 py-3.5 rounded-md shadow-md hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer group"
              >
                <span>Khám phá thêm</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* RIGHT VISUAL: Room with strongly curved top-left corner */}
          <div className="lg:col-span-6 relative">
            <div className="relative group">
              {/* Soft glow/shadow */}
              <div className="absolute -inset-2 bg-gradient-to-tr from-[#FF5315]/20 to-transparent rounded-3xl blur-lg -z-10 opacity-70" />

              <div 
                className="overflow-hidden shadow-2xl border border-[#F4C7B2]/40 bg-white transition-transform duration-500 group-hover:scale-[1.01]"
                style={{
                  borderTopLeftRadius: '180px',
                  borderTopRightRadius: '0px',
                  borderBottomRightRadius: '0px',
                  borderBottomLeftRadius: '0px',
                }}
              >
                <img
                  src={anhAboutOrangeRoom}
                  alt="Không gian phòng khách ấm áp cùng ghế màu cam Nội Thất Cam Home"
                  className="w-full h-[360px] sm:h-[430px] lg:h-[480px] object-cover object-center"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Decorative Floating Pill Tag */}
              <div className="absolute bottom-5 left-5 bg-white/95 backdrop-blur-md px-4 py-2.5 rounded-xl shadow-lg border border-[#F4C7B2]/50 flex items-center gap-2 text-xs font-semibold text-[#301E18]">
                <Sparkles className="w-4 h-4 text-[#FF5315]" />
                <span>Không gian sống ấm áp & đầy cảm hứng</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
