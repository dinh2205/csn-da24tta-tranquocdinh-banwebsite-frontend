import React, { useState } from 'react';
import { X, User, Mail, Lock, Check, Sparkles } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'register';
  onClose: () => void;
  onLoginSuccess: (user: { name: string; email: string }) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onLoginSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'login') {
      if (!email || !password) {
        setError('Vui lòng nhập đầy đủ email và mật khẩu.');
        return;
      }
      // Check stored users or fallback
      const stored = localStorage.getItem('camhome_user');
      let userData = stored ? JSON.parse(stored) : null;
      if (!userData || userData.email !== email) {
        // Allow login as named user for demo
        userData = { name: email.split('@')[0], email };
        localStorage.setItem('camhome_user', JSON.stringify(userData));
      }
      setSuccessMsg('Đăng nhập thành công!');
      setTimeout(() => {
        onLoginSuccess(userData);
        onClose();
      }, 700);
    } else {
      if (!name || !email || !password) {
        setError('Vui lòng điền các trường bắt buộc.');
        return;
      }
      const newUser = { name, email, phone };
      localStorage.setItem('camhome_user', JSON.stringify(newUser));
      setSuccessMsg('Đăng ký tài khoản thành công!');
      setTimeout(() => {
        onLoginSuccess(newUser);
        onClose();
      }, 700);
    }
  };

  const handleQuickDemo = () => {
    const demoUser = { name: 'Khách Hàng VIP', email: 'khachhang@camhome.vn' };
    localStorage.setItem('camhome_user', JSON.stringify(demoUser));
    onLoginSuccess(demoUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#FFEADC] flex items-center justify-center text-[#FF5315]">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#301E18]">
                {mode === 'login' ? 'Đăng nhập tài khoản' : 'Đăng ký thành viên'}
              </h3>
              <p className="text-xs text-[#8C827D]">Nội Thất Cam Home</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-neutral-800 rounded-full hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="grid grid-cols-2 p-1.5 bg-[#FFEFE5] border-b border-[#F4C7B2]/40 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`py-2 rounded-lg transition-colors cursor-pointer ${
              mode === 'login'
                ? 'bg-white text-[#FF5315] shadow-xs'
                : 'text-[#66605C] hover:text-[#301E18]'
            }`}
          >
            Đăng nhập
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setError('');
            }}
            className={`py-2 rounded-lg transition-colors cursor-pointer ${
              mode === 'register'
                ? 'bg-white text-[#FF5315] shadow-xs'
                : 'text-[#66605C] hover:text-[#301E18]'
            }`}
          >
            Đăng ký mới
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-600">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-700 flex items-center gap-1.5">
              <Check className="w-4 h-4" />
              <span>{successMsg}</span>
            </div>
          )}

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-[#301E18] mb-1">
                Họ và tên
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ví dụ: Nguyễn Văn A"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#301E18] mb-1">
              Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tenban@email.com"
                className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#301E18] mb-1">
              Mật khẩu
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-[#301E18] mb-1">
                Số điện thoại (tùy chọn)
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0912 345 678"
                className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
              />
            </div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 bg-[#FF5315] hover:bg-[#E8440A] text-white rounded-md font-semibold text-xs shadow-md transition-colors cursor-pointer"
          >
            {mode === 'login' ? 'Đăng nhập ngay' : 'Tạo tài khoản'}
          </button>

          {/* Quick Demo Login Helper */}
          <div className="pt-2 text-center">
            <button
              type="button"
              onClick={handleQuickDemo}
              className="inline-flex items-center gap-1.5 text-xs text-[#FF5315] font-semibold hover:underline cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Đăng nhập nhanh tài khoản mẫu VIP</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
