import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ShoppingBag, CheckCircle2, ArrowRight } from 'lucide-react';
import { Product, formatVND } from '../data/products';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [orderCompleted, setOrderCompleted] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalAmount = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeShippingThreshold = 5000000;
  const isFreeShipping = totalAmount >= freeShippingThreshold;

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !customerAddress) return;

    const fakeOrderId = 'CH-' + Math.floor(100000 + Math.random() * 900000);
    setOrderCompleted(fakeOrderId);
    onClearCart();
  };

  const handleReset = () => {
    setOrderCompleted(null);
    setIsCheckingOut(false);
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-xs transition-opacity duration-300"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FFF9F5] shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-5 border-b border-[#F4C7B2] bg-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#FF5315]" />
              <h3 className="text-base font-bold text-[#301E18]">
                Giỏ hàng của bạn ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 text-neutral-400 hover:text-neutral-700 rounded-full hover:bg-neutral-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Main Body */}
          <div className="flex-1 overflow-y-auto p-5">
            {orderCompleted ? (
              <div className="py-12 text-center flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-xl font-bold text-[#301E18] mb-1">Đặt Hàng Thành Công!</h4>
                <p className="text-xs text-[#8C827D] mb-4">
                  Mã đơn hàng: <span className="font-mono font-bold text-[#FF5315]">{orderCompleted}</span>
                </p>
                <p className="text-sm text-[#66605C] max-w-xs leading-relaxed mb-6">
                  Cảm ơn quý khách đã tin tưởng Nội Thất Cam Home. Chuyên viên tư vấn sẽ liên hệ xác nhận đơn hàng và lịch giao lắp trong vòng 15 phút.
                </p>
                <button
                  onClick={handleReset}
                  className="bg-[#FF5315] text-white px-6 py-2.5 rounded-md text-sm font-semibold hover:bg-[#E8440A] transition-colors cursor-pointer"
                >
                  Tiếp tục mua sắm
                </button>
              </div>
            ) : isCheckingOut ? (
              <form onSubmit={handleSubmitOrder} className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-[#F4C7B2]">
                  <span className="text-sm font-bold text-[#301E18]">Thông tin giao hàng COD</span>
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="text-xs text-[#FF5315] font-semibold hover:underline cursor-pointer"
                  >
                    Quay lại giỏ hàng
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#301E18] mb-1">
                    Họ và tên người nhận *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Ví dụ: Nguyễn Văn A"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#301E18] mb-1">
                    Số điện thoại liên hệ *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="Ví dụ: 0912 345 678"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#301E18] mb-1">
                    Địa chỉ nhận hàng chi tiết *
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố"
                    className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-sm focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                  />
                </div>

                <div className="p-3 bg-[#FFEADC]/60 rounded-lg text-xs text-[#66605C] leading-relaxed">
                  ✓ Thanh toán tiền mặt khi nhận hàng & kiểm tra (COD)<br />
                  ✓ Miễn phí vận chuyển & hỗ trợ lắp đặt nội thất tại nhà.
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#FF5315] hover:bg-[#E8440A] text-white rounded-md font-semibold text-sm shadow-md transition-colors cursor-pointer"
                >
                  Xác nhận đặt hàng ({formatVND(totalAmount)})
                </button>
              </form>
            ) : cart.length === 0 ? (
              <div className="py-16 text-center">
                <ShoppingBag className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
                <p className="text-sm font-semibold text-[#301E18]">Giỏ hàng của bạn đang trống</p>
                <p className="text-xs text-[#8C827D] mt-1 mb-5">
                  Hãy khám phá những mẫu sofa và nội thất cao cấp của Cam Home!
                </p>
                <button
                  onClick={onClose}
                  className="bg-[#FF5315] text-white px-5 py-2 rounded-md text-xs font-semibold hover:bg-[#E8440A] transition-colors cursor-pointer"
                >
                  Khám phá ngay
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Free shipping notification */}
                <div className="p-2.5 bg-[#FFEFE5] border border-[#F4C7B2] rounded-lg text-xs text-[#66605C]">
                  {isFreeShipping ? (
                    <span className="text-emerald-700 font-medium">
                      🎉 Đơn hàng của bạn đủ điều kiện miễn phí vận chuyển toàn quốc!
                    </span>
                  ) : (
                    <span>
                      Mua thêm <b>{formatVND(freeShippingThreshold - totalAmount)}</b> để được miễn phí vận chuyển.
                    </span>
                  )}
                </div>

                {/* Items list */}
                <div className="divide-y divide-[#F4C7B2]/40">
                  {cart.map((item) => (
                    <div key={item.product.id} className="py-3.5 flex gap-3.5 items-center">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 rounded-md object-cover border border-[#F4C7B2]/50 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-semibold text-[#301E18] truncate">
                          {item.product.name}
                        </h4>
                        <p className="text-[11px] text-[#8C827D]">
                          {item.product.categoryName}
                        </p>
                        <p className="text-xs font-bold text-[#FF5315] mt-0.5">
                          {formatVND(item.product.price)}
                        </p>

                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, -1)}
                            className="w-5 h-5 rounded border border-neutral-300 flex items-center justify-center text-xs text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-semibold w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, 1)}
                            className="w-5 h-5 rounded border border-neutral-300 flex items-center justify-center text-xs text-neutral-600 hover:bg-neutral-100 cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => onRemoveItem(item.product.id)}
                        className="p-1.5 text-neutral-400 hover:text-red-500 transition-colors cursor-pointer"
                        title="Xóa"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer Subtotal & Action */}
          {!orderCompleted && cart.length > 0 && !isCheckingOut && (
            <div className="p-5 border-t border-[#F4C7B2] bg-white">
              <div className="flex justify-between items-center mb-1 text-xs text-[#66605C]">
                <span>Tạm tính</span>
                <span>{formatVND(totalAmount)}</span>
              </div>
              <div className="flex justify-between items-center mb-3 text-xs text-[#66605C]">
                <span>Phí giao hàng</span>
                <span>{isFreeShipping ? 'Miễn phí' : '150.000 đ'}</span>
              </div>
              <div className="flex justify-between items-center mb-4 text-sm font-bold text-[#301E18]">
                <span>Tổng cộng</span>
                <span className="text-base text-[#FF5315] font-extrabold">
                  {formatVND(isFreeShipping ? totalAmount : totalAmount + 150000)}
                </span>
              </div>

              <button
                onClick={() => setIsCheckingOut(true)}
                className="w-full py-3 bg-[#FF5315] hover:bg-[#E8440A] text-white rounded-md font-semibold text-sm shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Tiến hành đặt hàng (COD)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
