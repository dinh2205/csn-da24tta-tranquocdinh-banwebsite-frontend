import React from 'react';
import { ArrowRight } from 'lucide-react';
import { CollectionItem } from '../data/products';

interface CollectionCardProps {
  item: CollectionItem;
  onExplore: (collectionId: string) => void;
}

export const CollectionCard: React.FC<CollectionCardProps> = ({
  item,
  onExplore,
}) => {
  const isLarge = item.colSpan === 'large';

  return (
    <div
      onClick={() => onExplore(item.id)}
      className={`group relative rounded-2xl overflow-hidden bg-gradient-to-br ${item.bgGradient} shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 flex flex-col justify-between cursor-pointer ${
        isLarge
          ? 'h-[400px] sm:h-[430px] lg:h-[440px]'
          : 'h-[310px] sm:h-[340px] lg:h-[350px]'
      }`}
    >
      {/* Background Photography with Warm Contrast Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-full object-cover object-center transition-transform duration-700 ease-out group-hover:scale-105"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        {/* Soft directional gradient to keep text readable on top of furniture photo */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/20 to-black/35 pointer-events-none" />
      </div>

      {/* Card Content Top: Title & Description */}
      <div className="relative z-10 p-6 sm:p-7 max-w-[380px]">
        <h3 className={`font-display text-white font-medium leading-tight mb-2.5 drop-shadow-xs ${
          isLarge ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
        }`}>
          {item.title}
        </h3>

        {item.description && (
          <p className="text-white/90 text-xs sm:text-[13.5px] leading-relaxed drop-shadow-xs">
            {item.description}
          </p>
        )}
      </div>

      {/* Card Content Bottom: "Khám phá thêm" Button */}
      <div className="relative z-10 p-6 sm:p-7 pt-0">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onExplore(item.id);
          }}
          className="inline-flex items-center gap-2 bg-white text-[#D8440F] hover:bg-[#FFF5ED] px-4 py-2 sm:px-5 sm:py-2.5 rounded-md text-xs sm:text-[13px] font-semibold shadow-sm transition-all duration-200 group-hover:shadow-md group-hover:scale-[1.02] cursor-pointer"
        >
          <span>Khám phá thêm</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#D8440F] transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </div>
  );
};
