import React, { useState } from 'react';
import { X, ArrowRight, ShoppingBag, Eye } from 'lucide-react';
import { SAMPLE_PRODUCTS, COLLECTIONS_DATA, Product, formatVND } from '../data/products';

interface CollectionModalProps {
  collectionId: string | null;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
}

export const CollectionModal: React.FC<CollectionModalProps> = ({
  collectionId,
  onClose,
  onSelectProduct,
  onQuickAddToCart,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(collectionId || 'all');

  if (!collectionId) return null;

  const currentCollection = COLLECTIONS_DATA.find((c) => c.id === collectionId);
  const activeFilter = selectedCategory === 'all' ? collectionId : selectedCategory;

  const displayProducts = SAMPLE_PRODUCTS.filter((p) => {
    if (activeFilter === 'all') return true;
    return p.category === activeFilter;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#FF5315] uppercase tracking-wider">
              Bộ sưu tập Cam Home
            </span>
            <h3 className="font-display text-2xl font-semibold text-[#301E18]">
              {currentCollection?.title || 'Sản phẩm nội thất'}
            </h3>
            {currentCollection?.description && (
              <p className="text-xs sm:text-sm text-[#66605C] mt-1 max-w-lg">
                {currentCollection.description}
              </p>
            )}
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-800 rounded-full hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Category Pill Filters */}
        <div className="px-6 py-3 bg-[#FFEFE5]/60 border-b border-[#F4C7B2]/40 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#FF5315] text-white shadow-xs'
                : 'bg-white text-[#66605C] hover:bg-[#FFE3D2]'
            }`}
          >
            Tất cả sản phẩm
          </button>
          {COLLECTIONS_DATA.map((col) => (
            <button
              key={col.id}
              onClick={() => setSelectedCategory(col.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                activeFilter === col.id
                  ? 'bg-[#FF5315] text-white shadow-xs'
                  : 'bg-white text-[#66605C] hover:bg-[#FFE3D2]'
              }`}
            >
              {col.title}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {displayProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-white rounded-xl overflow-hidden border border-[#F4C7B2]/60 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
              >
                {/* Image */}
                <div 
                  className="relative h-48 bg-[#FFEFE5] overflow-hidden cursor-pointer"
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <span className="bg-white/90 backdrop-blur-xs text-[#301E18] text-xs font-semibold px-3 py-1.5 rounded-md flex items-center gap-1 shadow-md">
                      <Eye className="w-3.5 h-3.5" />
                      Xem chi tiết
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[11px] font-semibold text-[#FF5315] uppercase tracking-wide">
                      {product.categoryName}
                    </span>
                    <h4 
                      onClick={() => onSelectProduct(product)}
                      className="text-sm font-bold text-[#301E18] mt-1 group-hover:text-[#FF5315] transition-colors cursor-pointer line-clamp-1"
                    >
                      {product.name}
                    </h4>
                    <p className="text-xs text-[#66605C] line-clamp-2 mt-1">
                      {product.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#F4C7B2]/30 flex items-center justify-between">
                    <div>
                      <span className="text-sm font-bold text-[#FF5315]">
                        {formatVND(product.price)}
                      </span>
                      {product.originalPrice && (
                        <span className="block text-[11px] text-neutral-400 line-through">
                          {formatVND(product.originalPrice)}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => onQuickAddToCart(product)}
                      className="p-2 rounded-md bg-[#FFEFE5] hover:bg-[#FF5315] text-[#FF5315] hover:text-white transition-colors cursor-pointer"
                      title="Thêm vào giỏ"
                    >
                      <ShoppingBag className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
