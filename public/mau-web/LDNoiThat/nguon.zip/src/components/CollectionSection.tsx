import React from 'react';
import { COLLECTIONS_DATA, CollectionItem } from '../data/products';
import { CollectionCard } from './CollectionCard';

interface CollectionSectionProps {
  onExploreCollection: (collectionId: string) => void;
}

export const CollectionSection: React.FC<CollectionSectionProps> = ({
  onExploreCollection,
}) => {
  const topRowItems = COLLECTIONS_DATA.slice(0, 2);
  const bottomRowItems = COLLECTIONS_DATA.slice(2, 5);

  return (
    <section 
      id="collections" 
      className="w-full bg-[#FFF0E6] py-14 lg:py-20 relative"
    >
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12">
        {/* Section Heading */}
        <div className="text-center mb-10 sm:mb-14">
          <h2 className="font-display text-3xl sm:text-4xl lg:text-[42px] font-medium text-[#301E18] tracking-tight">
            Bộ sưu tập của{' '}
            <span className="relative inline-block text-[#FF5315]">
              chúng tôi
              <span className="absolute bottom-1 left-0 right-0 h-[2.5px] bg-[#FF5315] rounded-full" />
            </span>
          </h2>
        </div>

        {/* Asymmetric Collection Grid */}
        <div className="space-y-4 sm:space-y-4.5">
          {/* Top Row: Two Large Cards (Outdoor & Sofa) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-4.5">
            {topRowItems.map((item: CollectionItem) => (
              <CollectionCard
                key={item.id}
                item={item}
                onExplore={onExploreCollection}
              />
            ))}
          </div>

          {/* Bottom Row: Three Cards (Modern Chair, Egg Swing, Pendant Lights) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-4.5">
            {bottomRowItems.map((item: CollectionItem) => (
              <CollectionCard
                key={item.id}
                item={item}
                onExplore={onExploreCollection}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
