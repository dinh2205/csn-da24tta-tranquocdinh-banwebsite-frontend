import React from 'react';
import { Logo } from './Logo';
import { 
  Facebook, 
  Instagram, 
  Youtube, 
  Music2, 
  MapPin, 
  Mail, 
  Phone, 
  Clock, 
  Heart 
} from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenPolicy: (title: string) => void;
  onOpenServices: () => void;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onOpenPolicy,
  onOpenServices,
  onOpenContact,
}) => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: 'Trang chủ', action: () => onNavigate('home') },
    { label: 'Sản phẩm', action: () => onNavigate('collections') },
    { label: 'Dịch vụ', action: onOpenServices },
    { label: 'Về chúng tôi', action: () => onNavigate('about') },
    { label: 'Liên hệ', action: onOpenContact },
  ];

  const policyLinks = [
    'Chính sách bảo mật',
    'Điều khoản sử dụng',
    'Chính sách giao hàng',
    'Chính sách đổi trả',
    'Câu hỏi thường gặp',
  ];

  return (
    <footer className="w-full bg-gradient-to-b from-[#FFE5D4] to-[#FFF0E5] text-[#4F433D] pt-14 pb-8 border-t border-[#F3C9B1]">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12">
        {/* Main 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-10 pb-12">
          
          {/* Column 1: Brand & Social */}
          <div className="lg:col-span-4 flex flex-col justify-between">
            <div>
              <Logo color="#FF5315" textColor="text-[#FF5315]" />
              <p className="mt-4 text-xs sm:text-[13.5px] leading-relaxed text-[#66605C] max-w-sm">
                Mang đến những giải pháp nội thất hiện đại, tinh tế và tiện nghi cho mọi gia đình Việt. Kiến tạo không gian sống tốt đẹp hơn mỗi ngày.
              </p>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-2.5 mt-6">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook Nội Thất Cam Home"
                className="w-8 h-8 rounded-full bg-[#251D1A] hover:bg-[#FF5315] text-white flex items-center justify-center transition-colors shadow-2xs"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram Nội Thất Cam Home"
                className="w-8 h-8 rounded-full bg-[#251D1A] hover:bg-[#FF5315] text-white flex items-center justify-center transition-colors shadow-2xs"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                aria-label="YouTube Nội Thất Cam Home"
                className="w-8 h-8 rounded-full bg-[#251D1A] hover:bg-[#FF5315] text-white flex items-center justify-center transition-colors shadow-2xs"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noreferrer"
                aria-label="TikTok Nội Thất Cam Home"
                className="w-8 h-8 rounded-full bg-[#251D1A] hover:bg-[#FF5315] text-white flex items-center justify-center transition-colors shadow-2xs"
              >
                <Music2 className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-2">
            <h4 className="text-[15px] font-bold text-[#251D1A] mb-4">
              Liên kết nhanh
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-[13.5px]">
              {quickLinks.map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={link.action}
                    className="hover:text-[#FF5315] transition-colors cursor-pointer text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Policies */}
          <div className="lg:col-span-3">
            <h4 className="text-[15px] font-bold text-[#251D1A] mb-4">
              Chính sách
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-[13.5px]">
              {policyLinks.map((policy, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => onOpenPolicy(policy)}
                    className="hover:text-[#FF5315] transition-colors cursor-pointer text-left"
                  >
                    {policy}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact Information */}
          <div className="lg:col-span-3">
            <h4 className="text-[15px] font-bold text-[#251D1A] mb-4">
              Thông tin liên hệ
            </h4>
            <ul className="space-y-3 text-xs sm:text-[13px] text-[#554C46]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#FF5315] shrink-0 mt-0.5" />
                <span>Số 123 Đường Bình An, Phường An Phú, TP. Thủ Đức, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#FF5315] shrink-0" />
                <a href="mailto:info@camhome.vn" className="hover:text-[#FF5315] transition-colors">
                  info@camhome.vn
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#FF5315] shrink-0" />
                <a href="tel:02812345678" className="hover:text-[#FF5315] transition-colors font-medium">
                  (028) 1234 5678
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-[#FF5315] shrink-0" />
                <span>Thứ 2 - Chủ nhật: 8:00 - 22:00</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar with Hairline Divider */}
        <div className="pt-6 border-t border-[#F3C9B1] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#7A6E67]">
          <div>
            © {currentYear} Nội Thất Cam Home. Tất cả quyền được bảo lưu.
          </div>
          <div className="flex items-center gap-1.5 font-medium">
            <span>Thiết kế không gian – Kiến tạo hạnh phúc</span>
            <Heart className="w-3.5 h-3.5 fill-[#FF5315] text-[#FF5315]" />
          </div>
        </div>
      </div>
    </footer>
  );
};
