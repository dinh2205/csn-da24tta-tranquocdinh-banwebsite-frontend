import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Menu, X, ShoppingBag, User, LogOut } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenCart: () => void;
  onOpenServices: () => void;
  onOpenContact: () => void;
  cartCount: number;
  currentUser: { name: string; email: string } | null;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onNavigate,
  onOpenAuth,
  onOpenCart,
  onOpenServices,
  onOpenContact,
  cartCount,
  currentUser,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Trang chủ', action: () => onNavigate('home') },
    { id: 'collections', label: 'Sản phẩm', action: () => onNavigate('collections') },
    { id: 'services', label: 'Dịch vụ', action: onOpenServices },
    { id: 'contact', label: 'Liên hệ', action: onOpenContact },
    { id: 'about', label: 'Về chúng tôi', action: () => onNavigate('about') },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#FFF5ED]/95 backdrop-blur-md shadow-xs py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12 flex items-center justify-between gap-4">
        {/* Logo */}
        <Logo />

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 lg:gap-9 text-[14.5px] font-medium text-[#301E18]">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={item.action}
                className="relative py-1 transition-colors hover:text-[#FF5315] whitespace-nowrap cursor-pointer"
              >
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#FF5315] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Action Controls & Auth */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            aria-label="Giỏ hàng"
            className="relative p-2 text-[#301E18] hover:text-[#FF5315] hover:bg-[#FFE5D4]/60 rounded-full transition-colors cursor-pointer"
            title="Xem giỏ hàng"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#FF5315] text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* User Logged In State or Auth Buttons */}
          {currentUser ? (
            <div className="hidden sm:flex items-center gap-2 bg-white/80 border border-[#F4C7B2] rounded-md px-3 py-1.5 text-xs font-semibold text-[#301E18]">
              <div className="w-5 h-5 rounded-full bg-[#FF5315] text-white flex items-center justify-center text-[10px]">
                {currentUser.name.charAt(0).toUpperCase()}
              </div>
              <span className="max-w-[90px] truncate">{currentUser.name}</span>
              <button
                onClick={onLogout}
                className="ml-1 text-[#66605C] hover:text-[#FF5315] transition-colors p-0.5 cursor-pointer"
                title="Đăng xuất"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2.5">
              <button
                onClick={() => onOpenAuth('login')}
                className="px-4 py-2 text-[13.5px] font-semibold text-[#301E18] bg-white border border-[#E8D4C8] hover:border-[#FF5315] hover:text-[#FF5315] rounded-md transition-all shadow-2xs whitespace-nowrap cursor-pointer"
              >
                Đăng nhập
              </button>
              <button
                onClick={() => onOpenAuth('register')}
                className="px-4 py-2 text-[13.5px] font-semibold text-white bg-[#FF5315] hover:bg-[#E8440A] rounded-md transition-all shadow-xs whitespace-nowrap cursor-pointer"
              >
                Đăng ký
              </button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#301E18] hover:text-[#FF5315] rounded-lg transition-colors cursor-pointer"
            aria-label="Mở menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FFF5ED] border-b border-[#F4C7B2] px-6 py-5 shadow-lg animate-in slide-in-from-top-3 duration-200">
          <nav className="flex flex-col gap-3 text-[15px] font-medium text-[#301E18]">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  item.action();
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded-lg transition-colors cursor-pointer ${
                  activeSection === item.id
                    ? 'bg-[#FFE2D1] text-[#FF5315] font-semibold'
                    : 'hover:bg-[#FFEADB]'
                }`}
              >
                {item.label}
              </button>
            ))}

            <div className="pt-3 mt-2 border-t border-[#F4C7B2] flex flex-col gap-2">
              {currentUser ? (
                <div className="flex items-center justify-between p-2 bg-white rounded-lg border border-[#F4C7B2]">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-[#FF5315]" />
                    <span className="text-sm font-semibold">{currentUser.name}</span>
                  </div>
                  <button
                    onClick={() => {
                      onLogout();
                      setMobileMenuOpen(false);
                    }}
                    className="text-xs text-red-600 font-medium cursor-pointer"
                  >
                    Đăng xuất
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      onOpenAuth('login');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 text-center text-sm font-semibold text-[#301E18] bg-white border border-[#E8D4C8] rounded-md cursor-pointer"
                  >
                    Đăng nhập
                  </button>
                  <button
                    onClick={() => {
                      onOpenAuth('register');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 text-center text-sm font-semibold text-white bg-[#FF5315] rounded-md cursor-pointer"
                  >
                    Đăng ký
                  </button>
                </div>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
