import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';

// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhHeroLivingRoom from '../assets/images/hero_living_room_1792082900887.jpg';

interface HeroSectionProps {
  onExplore: () => void;
  onOpenProduct: (productId: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplore,
  onOpenProduct,
}) => {
  return (
    <section 
      id="home"
      className="relative w-full min-h-[640px] lg:min-h-[720px] bg-[#FFF5ED] overflow-hidden pt-24 pb-12 lg:pt-28 lg:pb-16 flex items-center"
    >
      {/* 
        Background Decorative Organic Orange Arc 
        Matches the distinctive reference curved orange area on the left
      */}
      <div 
        className="absolute top-0 left-0 w-[80%] sm:w-[65%] lg:w-[54%] h-[85%] lg:h-[92%] bg-gradient-to-br from-[#FF6820] via-[#FF5416] to-[#F1460A] -z-0 pointer-events-none"
        style={{
          borderBottomRightRadius: '68% 78%',
        }}
      />

      {/* Subtle angled soft peach geometric backdrop on the top-right */}
      <div 
        className="absolute top-0 right-0 w-[45%] h-[60%] bg-[#FFE3D2]/40 -z-0 pointer-events-none transform -skew-y-6 origin-top-right"
      />

      {/* Decorative Hanging Pendant Light matching reference scene */}
      <div className="absolute top-0 left-[26%] sm:left-[28%] lg:left-[24%] z-10 pointer-events-none hidden sm:block">
        <div className="w-[2px] h-24 lg:h-32 bg-[#5A3825]/70 mx-auto" />
        <div className="relative -mt-1">
          {/* Bell/Dome Wooden Lamp Shade */}
          <div className="w-16 h-12 lg:w-20 lg:h-14 bg-gradient-to-b from-[#8C532B] to-[#5A351D] rounded-t-full shadow-lg relative flex items-center justify-center">
            {/* Inner warm bulb glow */}
            <div className="absolute -bottom-1 w-6 h-3 bg-[#FFE799] rounded-b-full blur-[1px] shadow-[0_0_15px_#FFA726]" />
          </div>
        </div>
      </div>

      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 items-center">
          
          {/* LEFT: Dominant Living Room Furniture Scene */}
          <div className="lg:col-span-7 relative group">
            {/* Ambient shadow underneath */}
            <div className="absolute -inset-4 bg-gradient-to-tr from-black/20 via-transparent to-transparent rounded-3xl blur-xl -z-10 opacity-70" />
            
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/40 bg-white/10 backdrop-blur-xs transition-transform duration-500 group-hover:scale-[1.01]">
              <img
                src={anhHeroLivingRoom}
                alt="Phòng khách hiện đại Cam Home với sofa kem cao cấp và bàn trà gỗ"
                className="w-full h-[320px] sm:h-[420px] lg:h-[500px] object-cover object-center"
                loading="eager"
                referrerPolicy="no-referrer"
              />

              {/* Interactive Quick-view overlay badge */}
              <button
                onClick={() => onOpenProduct('prod-hero-1')}
                className="absolute bottom-4 right-4 bg-white/95 hover:bg-white text-[#251D1A] px-3.5 py-1.5 rounded-md text-xs font-semibold shadow-md flex items-center gap-1.5 backdrop-blur-md transition-all hover:scale-105 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#FF5315]" />
                <span>Xem chi tiết bộ Signature</span>
              </button>
            </div>
          </div>

          {/* RIGHT: Typography & Call to Action */}
          <div className="lg:col-span-5 flex flex-col justify-center text-left lg:pl-4">
            {/* Eyebrow kicker with line */}
            <div className="flex items-center gap-2 mb-3">
              <span className="w-4 h-[2px] bg-[#D64C18]" />
              <span className="text-[12px] font-bold tracking-[0.25em] text-[#D64C18] uppercase">
                NỘI THẤT CAM HOME
              </span>
            </div>

            {/* Display Headline */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[56px] font-semibold leading-[1.12] tracking-tight text-[#301E18] mb-5">
              <span>Không gian sống</span>
              <br />
              <span className="text-[#FF5315]">đầy tinh tế</span>
            </h1>

            {/* Body Description */}
            <p className="text-[#66605C] text-[15.5px] leading-[1.75] max-w-[460px] mb-8 font-normal">
              Nội Thất Cam Home mang đến những thiết kế nội thất hiện đại, tinh tế và tiện nghi, giúp bạn kiến tạo không gian sống ấm cúng, sang trọng và đậm chất riêng.
            </p>

            {/* CTA Button */}
            <div>
              <button
                onClick={onExplore}
                className="inline-flex items-center justify-center gap-3 bg-[#FF5315] hover:bg-[#E24209] text-white text-[15px] font-semibold px-8 py-3.5 rounded-md shadow-md hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer group"
              >
                <span>Mua ngay</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
