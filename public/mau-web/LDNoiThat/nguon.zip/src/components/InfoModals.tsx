import React, { useState } from 'react';
import { X, CheckCircle2, Phone, Mail, MapPin, Clock, Send, Shield, Compass, Sparkles, Wrench, Truck } from 'lucide-react';

/* 1. SERVICES MODAL */
interface ServicesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ServicesModal: React.FC<ServicesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const services = [
    {
      icon: Compass,
      title: 'Tư Vấn & Thiết Kế Phối Cảnh 3D',
      desc: 'Đội ngũ kiến trúc sư Cam Home lên layout công năng và dựng hình phối cảnh 3D không gian phòng khách, ban công thực tế miễn phí cho đơn hàng từ 15 triệu.',
    },
    {
      icon: Wrench,
      title: 'Thi Công & Hoàn Thiện Trọn Gói',
      desc: 'Dịch vụ may đo sofa nỉ, da microfiber, đặt xích đu và ghế mây theo kích thước chuẩn xác, đồng bộ với phong cách ngôi nhà bạn.',
    },
    {
      icon: Truck,
      title: 'Vận Chuyển & Lắp Đặt Tận Nhà',
      desc: 'Đội ngũ kỹ thuật viên chuyên nghiệp vận chuyển an toàn, bốc xếp và hỗ trợ bố trí nội thất theo đúng vị trí phong thủy và sở thích gia chủ.',
    },
    {
      icon: Shield,
      title: 'Bảo Hành 5 Năm & Bảo Trì Trọn Đời',
      desc: 'Cam kết bảo hành khung sofa và xích đu lên đến 5 năm, miễn phí vệ sinh và hỗ trợ bọc mới đệm nỉ với giá xưởng ưu đãi.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#FF5315] uppercase tracking-wider">Giải pháp toàn diện</span>
            <h3 className="font-display text-2xl font-semibold text-[#301E18]">Dịch vụ Nội Thất Cam Home</h3>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-800 rounded-full cursor-pointer">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {services.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="bg-white p-4.5 rounded-xl border border-[#F4C7B2]/60 shadow-2xs">
                <div className="w-10 h-10 rounded-lg bg-[#FFEADC] text-[#FF5315] flex items-center justify-center mb-3">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-[#301E18] mb-1.5">{item.title}</h4>
                <p className="text-xs text-[#66605C] leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>

        <div className="p-5 bg-[#FFEFE5] border-t border-[#F4C7B2]/60 text-center">
          <p className="text-xs text-[#66605C] mb-3">Bạn đang cần tư vấn cho căn hộ hoặc biệt thự mới?</p>
          <a
            href="tel:02812345678"
            className="inline-flex items-center gap-2 bg-[#FF5315] text-white px-5 py-2.5 rounded-md text-xs font-semibold hover:bg-[#E8440A] transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Gọi hotline tư vấn miễn phí: (028) 1234 5678</span>
          </a>
        </div>
      </div>
    </div>
  );
};

/* 2. CONTACT MODAL */
interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose }) => {
  const [sent, setSent] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', note: '' });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#FF5315] uppercase tracking-wider">Liên hệ với chúng tôi</span>
            <h3 className="font-display text-2xl font-semibold text-[#301E18]">Hỗ Trợ & Tư Vấn Showroom</h3>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-800 rounded-full cursor-pointer">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {sent ? (
            <div className="py-8 text-center flex flex-col items-center">
              <CheckCircle2 className="w-12 h-12 text-emerald-600 mb-2" />
              <h4 className="text-base font-bold text-[#301E18]">Gửi Yêu Cầu Thành Công!</h4>
              <p className="text-xs text-[#66605C] mt-1 max-w-xs">
                Chuyên viên tư vấn Cam Home sẽ liên hệ với quý khách trong thời gian sớm nhất.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#301E18] mb-1">Họ tên của bạn *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Nguyễn Văn A"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#301E18] mb-1">Số điện thoại *</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="0912 345 678"
                  className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#301E18] mb-1">Nội dung tư vấn / Sản phẩm quan tâm</label>
                <textarea
                  rows={3}
                  value={formData.note}
                  onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                  placeholder="Ví dụ: Tôi muốn tư vấn bộ sofa nỉ phòng khách và ghế thư giãn ban công chung cư..."
                  className="w-full px-3.5 py-2.5 bg-white border border-[#F4C7B2] rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-[#FF5315]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#FF5315] hover:bg-[#E8440A] text-white rounded-md font-semibold text-xs shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Gửi thông tin tư vấn</span>
              </button>
            </form>
          )}

          {/* Quick contact direct channels */}
          <div className="pt-4 border-t border-[#F4C7B2]/60 grid grid-cols-2 gap-3 text-xs text-[#554C46]">
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#FF5315]" />
              <div>
                <span className="font-semibold block text-[#301E18]">Hotline</span>
                <span>(028) 1234 5678</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#FF5315]" />
              <div>
                <span className="font-semibold block text-[#301E18]">Email</span>
                <span>info@camhome.vn</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* 3. POLICY MODAL */
interface PolicyModalProps {
  policyTitle: string | null;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ policyTitle, onClose }) => {
  if (!policyTitle) return null;

  const policyContent: Record<string, { summary: string; bullets: string[] }> = {
    'Chính sách bảo mật': {
      summary: 'Cam Home cam kết bảo vệ thông tin cá nhân và dữ liệu riêng tư của quý khách hàng tuyệt đối.',
      bullets: [
        'Chỉ thu thập tên, số điện thoại và địa chỉ giao hàng nhằm phục vụ xác nhận đơn hàng và bảo hành sản phẩm.',
        'Không bao giờ chia sẻ, kinh doanh dữ liệu khách hàng cho bên thứ ba dưới bất kỳ hình thức nào.',
        'Hệ thống lưu trữ tuân thủ các tiêu chuẩn bảo mật dữ liệu hiện hành.',
      ],
    },
    'Điều khoản sử dụng': {
      summary: 'Quy định và quyền lợi khi tham quan, đặt hàng trực tiếp tại website Nội Thất Cam Home.',
      bullets: [
        'Mọi hình ảnh sản phẩm và nội dung thiết kế thuộc quyền sở hữu độc quyền của Nội Thất Cam Home.',
        'Giá bán niêm yết đã bao gồm VAT và áp dụng đồng nhất trên toàn hệ thống showroom và online.',
        'Khách hàng có quyền kiểm tra hình thức và kết cấu nội thất trước khi thanh toán tiền mặt.',
      ],
    },
    'Chính sách giao hàng': {
      summary: 'Dịch vụ vận chuyển chuyên nghiệp trên toàn quốc với thời gian cam kết.',
      bullets: [
        'Nội thành TP. Hồ Chí Minh và Hà Nội: Giao & lắp đặt hoàn thiện trong vòng 24 - 48 giờ.',
        'Các tỉnh thành khác trên toàn quốc: Giao hàng qua xe chuyên dụng trong 3 ngày làm việc.',
        'Miễn phí vận chuyển cho đơn hàng từ 5.000.000 đ.',
      ],
    },
    'Chính sách đổi trả': {
      summary: 'Chính sách đổi trả linh hoạt, bảo đảm sự an tâm tuyệt đối của khách hàng.',
      bullets: [
        'Đổi mới 1:1 trong 30 ngày nếu phát sinh lỗi từ nhà sản xuất hoặc cong vênh, rách nỉ do vận chuyển.',
        'Hỗ trợ đổi mẫu khác nếu kích thước không vừa vặn không gian phòng trong vòng 7 ngày đầu.',
        'Quy trình đổi trả tận nhà, quý khách không cần phải vận chuyển.',
      ],
    },
    'Câu hỏi thường gặp': {
      summary: 'Giải đáp những thắc mắc phổ biến về chất liệu, bảo quản và đặt hàng.',
      bullets: [
        'Sofa nỉ có dễ vệ sinh không? Vải nỉ Cam Home xử lý công nghệ kháng nước bề mặt Nano, dễ dàng lau sạch vết bẩn bằng khăn ẩm.',
        'Xích đu mây có chịu được mưa nắng không? Mẫu xích đu ban công sử dụng sợi mây PE kháng tia UV và khung sắt sơn tĩnh điện ngoài trời chuyên dụng.',
        'Có nhận đóng sofa theo kích thước riêng không? Cam Home nhận may đo thiết kế theo yêu cầu riêng từ 5 - 7 ngày.',
      ],
    },
  };

  const current = policyContent[policyTitle] || {
    summary: 'Chính sách dịch vụ khách hàng của Nội Thất Cam Home.',
    bullets: ['Cam kết sản phẩm chất lượng cao.', 'Dịch vụ khách hàng tận tâm và chu đáo.'],
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <h3 className="font-display text-xl font-bold text-[#301E18]">{policyTitle}</h3>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-800 rounded-full cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-xs sm:text-sm text-[#554C46] leading-relaxed font-medium">
            {current.summary}
          </p>
          <ul className="space-y-2.5 text-xs text-[#66605C]">
            {current.bullets.map((b, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF5315] mt-1.5 shrink-0" />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-4 bg-white border-t border-[#F4C7B2]/40 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#FF5315] text-white rounded-md text-xs font-semibold hover:bg-[#E8440A] transition-colors cursor-pointer"
          >
            Đã hiểu
          </button>
        </div>
      </div>
    </div>
  );
};

/* 4. STORY MODAL (VỀ CHÚNG TÔI) */
interface StoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StoryModal: React.FC<StoryModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative bg-[#FFF9F5] rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="p-6 bg-white border-b border-[#F4C7B2] flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-[#FF5315] uppercase tracking-wider">Hành trình Cam Home</span>
            <h3 className="font-display text-2xl font-semibold text-[#301E18]">Câu Chuyện Thương Hiệu</h3>
          </div>
          <button onClick={onClose} className="p-1 text-neutral-400 hover:text-neutral-800 rounded-full cursor-pointer">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs sm:text-[13.5px] text-[#66605C] leading-relaxed">
          <p>
            Ra đời từ tình yêu với những đường nét tối giản của nội thất Bắc Âu và sự ấm cúng trong nếp nhà người Việt, <b>Nội Thất Cam Home</b> chọn sắc cam terracotta và màu kem tự nhiên làm nguồn cảm hứng chủ đạo.
          </p>
          <div className="grid grid-cols-2 gap-3 my-4">
            <div className="bg-white p-3.5 rounded-xl border border-[#F4C7B2]">
              <Sparkles className="w-5 h-5 text-[#FF5315] mb-1.5" />
              <b className="text-xs block text-[#301E18]">Chất Liệu Tuyển Chọn</b>
              <span className="text-[11px] text-[#8C827D]">Gỗ sồi tự nhiên, mây tre đan thủ công, đệm nỉ cao cấp.</span>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-[#F4C7B2]">
              <Shield className="w-5 h-5 text-[#FF5315] mb-1.5" />
              <b className="text-xs block text-[#301E18]">Cam Kết Chất Lượng</b>
              <span className="text-[11px] text-[#8C827D]">Bảo hành 5 năm, hoàn thiện tinh xảo từng đường may.</span>
            </div>
          </div>
          <p>
            Mỗi chiếc sofa, chiếc ghế mây hay chiếc đèn thả không chỉ là một sản phẩm nội thất, mà là người bạn đồng hành cùng gia đình bạn trong từng phút giây sum vầy, thư thái sau những giờ làm việc mệt mỏi.
          </p>
        </div>

        <div className="p-4 bg-white border-t border-[#F4C7B2]/40 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-[#FF5315] text-white rounded-md text-xs font-semibold hover:bg-[#E8440A] transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
