import React from 'react';

interface LogoProps {
  color?: string;
  textColor?: string;
  size?: 'default' | 'small' | 'large';
}

export const Logo: React.FC<LogoProps> = ({
  color = '#FF5315',
  textColor = 'text-[#251D1A]',
  size = 'default',
}) => {
  return (
    <a href="#home" className="flex items-center gap-2.5 group select-none">
      {/* Modern Sofa Line Icon matching the reference logo */}
      <div 
        className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-transform duration-200 group-hover:scale-105"
        style={{ color }}
      >
        <svg 
          viewBox="0 0 40 40" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
          className="w-9 h-9 stroke-current"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Sofa Backrest */}
          <path d="M7 16C7 13.7909 8.79086 12 11 12H29C31.2091 12 33 13.7909 33 16V22H7V16Z" fill="currentColor" fillOpacity="0.12" />
          {/* Main Seat */}
          <rect x="5" y="21" width="30" height="7" rx="3.5" fill="currentColor" fillOpacity="0.2" />
          {/* Left Armrest */}
          <rect x="4" y="16" width="5.5" height="12" rx="2.5" />
          {/* Right Armrest */}
          <rect x="30.5" y="16" width="5.5" height="12" rx="2.5" />
          {/* Legs */}
          <path d="M9 28V32" />
          <path d="M31 28V32" />
          <path d="M12 28V30.5" />
          <path d="M28 28V30.5" />
        </svg>
      </div>

      <div className="flex flex-col leading-tight">
        <span className={`text-[12px] font-semibold tracking-wider uppercase text-neutral-500`}>
          Nội Thất
        </span>
        <span className={`text-[19px] font-extrabold tracking-tight ${textColor}`}>
          Cam Home
        </span>
      </div>
    </a>
  );
};
