import React, { useState } from 'react';
import { X, Star, ShoppingBag, ShieldCheck, Truck, Check, Sparkles } from 'lucide-react';
import { Product, formatVND } from '../data/products';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative bg-[#FFFBF8] rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-[#F4C7B2] z-10 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-white/90 hover:bg-white text-neutral-600 hover:text-black flex items-center justify-center shadow-md transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image */}
          <div className="relative bg-[#FFEFE5] h-[280px] md:h-full min-h-[300px]">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {product.isPopular && (
              <span className="absolute top-4 left-4 bg-[#FF5315] text-white text-[11px] font-bold px-2.5 py-1 rounded-sm shadow-xs flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Bộ sưu tập Cam Home
              </span>
            )}
          </div>

          {/* Product Info */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-[#8C827D] mb-2">
                <span className="font-semibold uppercase tracking-wider text-[#FF5315]">
                  {product.categoryName}
                </span>
                <div className="flex items-center gap-1 text-amber-500 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{product.rating}</span>
                  <span className="text-neutral-400 font-normal">({product.reviewCount} đánh giá)</span>
                </div>
              </div>

              {/* Product Title */}
              <h3 className="font-display text-2xl font-semibold text-[#301E18] mb-3 leading-snug">
                {product.name}
              </h3>

              {/* Price */}
              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-2xl font-bold text-[#FF5315]">
                  {formatVND(product.price)}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-neutral-400 line-through">
                    {formatVND(product.originalPrice)}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-[13.5px] text-[#66605C] leading-relaxed mb-5">
                {product.description}
              </p>

              {/* Specifications */}
              <div className="bg-[#FFEFE5]/70 rounded-xl p-3.5 space-y-2 text-xs text-[#554C46] mb-6">
                <div>
                  <b className="text-[#301E18]">Kích thước:</b> {product.dimensions}
                </div>
                <div>
                  <b className="text-[#301E18]">Chất liệu:</b> {product.material}
                </div>
              </div>
            </div>

            {/* Actions & Assurance */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                {/* Quantity */}
                <div className="flex items-center border border-[#F4C7B2] rounded-md bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 text-sm font-bold text-[#66605C] hover:text-[#FF5315] cursor-pointer"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-sm font-semibold min-w-[36px] text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-sm font-bold text-[#66605C] hover:text-[#FF5315] cursor-pointer"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart Button */}
                <button
                  onClick={handleAdd}
                  className="flex-1 bg-[#FF5315] hover:bg-[#E8440A] text-white py-2.5 px-4 rounded-md font-semibold text-sm shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  {addedNotice ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Đã thêm vào giỏ!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Thêm vào giỏ hàng</span>
                    </>
                  )}
                </button>
              </div>

              {/* Badges */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#F4C7B2]/40 text-[11px] text-[#66605C]">
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#FF5315]" />
                  <span>Giao & lắp đặt tận nơi</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#FF5315]" />
                  <span>Bảo hành chính hãng 5 năm</span>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
