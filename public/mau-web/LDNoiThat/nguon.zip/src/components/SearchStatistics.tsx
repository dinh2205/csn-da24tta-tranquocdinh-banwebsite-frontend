import React, { useState, useRef, useEffect } from 'react';
import { Search, UsersRound, Truck, X, ArrowUpRight } from 'lucide-react';
import { SAMPLE_PRODUCTS, Product, formatVND } from '../data/products';

interface SearchStatisticsProps {
  onSelectProduct: (product: Product) => void;
  onFilterCategory?: (category: string) => void;
}

export const SearchStatistics: React.FC<SearchStatisticsProps> = ({
  onSelectProduct,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Filter products by search term
  const filteredProducts = searchTerm.trim()
    ? SAMPLE_PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.categoryName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Demo avatar photos with natural diverse faces
  const avatarList = [
    { name: 'Lan Anh', bg: 'bg-[#FF7A45]', initials: 'LA' },
    { name: 'Minh Hoàng', bg: 'bg-[#FFA940]', initials: 'MH' },
    { name: 'Thu Thảo', bg: 'bg-[#FF5315]', initials: 'TT' },
    { name: 'Đức Trí', bg: 'bg-[#E03E05]', initials: 'ĐT' },
  ];

  return (
    <section className="w-full bg-[#FFF8F3] border-y border-[#F6DAC8]/60 py-7 lg:py-9">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-12">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
          
          {/* SEARCH INPUT BAR */}
          <div ref={containerRef} className="w-full lg:w-[410px] relative shrink-0">
            <div className="relative flex items-center">
              <div className="absolute left-4.5 text-[#FF5315] pointer-events-none">
                <Search className="w-5 h-5" />
              </div>

              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setIsOpen(true);
                }}
                onFocus={() => setIsOpen(true)}
                placeholder="Bạn đang tìm kiếm sản phẩm gì?"
                className="w-full pl-12 pr-10 py-3.5 bg-white border border-[#FF5315] rounded-full text-[14.5px] text-[#251D1A] placeholder:text-[#8C827D] focus:outline-none focus:ring-2 focus:ring-[#FF5315]/30 shadow-2xs transition-all"
              />

              {searchTerm && (
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setIsOpen(false);
                  }}
                  className="absolute right-4 text-neutral-400 hover:text-neutral-700 cursor-pointer"
                  aria-label="Xóa tìm kiếm"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Live Search Results Dropdown */}
            {isOpen && searchTerm.trim().length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-[#F4C7B2] overflow-hidden z-40 max-h-80 overflow-y-auto">
                <div className="p-2.5 text-xs font-semibold text-[#8C827D] uppercase tracking-wider border-b border-[#F5E1D6]">
                  Kết quả tìm kiếm ({filteredProducts.length})
                </div>

                {filteredProducts.length > 0 ? (
                  <div className="divide-y divide-[#F8EAE1]">
                    {filteredProducts.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => {
                          onSelectProduct(product);
                          setIsOpen(false);
                          setSearchTerm('');
                        }}
                        className="w-full p-3 text-left hover:bg-[#FFF5ED] flex items-center gap-3 transition-colors cursor-pointer group"
                      >
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 rounded-lg object-cover border border-[#F4C7B2]/60"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-[#301E18] truncate group-hover:text-[#FF5315]">
                            {product.name}
                          </p>
                          <p className="text-xs text-[#8C827D]">{product.categoryName}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-xs font-bold text-[#FF5315]">
                            {formatVND(product.price)}
                          </p>
                          <ArrowUpRight className="w-3.5 h-3.5 text-neutral-400 group-hover:text-[#FF5315] ml-auto mt-0.5" />
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-sm text-[#8C827D]">
                    Không tìm thấy sản phẩm phù hợp với từ khóa "{searchTerm}".
                  </div>
                )}
              </div>
            )}
          </div>

          {/* THREE METRICS / STATISTICS */}
          <div className="w-full lg:flex-1 grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-2 items-center divide-y sm:divide-y-0 sm:divide-x divide-[#F1D4C2]">
            
            {/* Stat 1: Satisfied Customers with Avatar Group */}
            <div className="flex items-center gap-3.5 sm:px-4 pt-3 sm:pt-0">
              {/* Overlapping Avatars */}
              <div className="flex -space-x-2.5 overflow-hidden shrink-0">
                {avatarList.map((av, idx) => (
                  <div
                    key={idx}
                    className={`inline-block w-8 h-8 rounded-full ring-2 ring-white text-white ${av.bg} flex items-center justify-center text-[10px] font-bold shadow-xs`}
                    title={av.name}
                  >
                    {av.initials}
                  </div>
                ))}
              </div>
              <div>
                <div className="text-2xl sm:text-[28px] font-bold text-[#FF5315] tracking-tight leading-none">
                  1.3M+
                </div>
                <div className="text-xs sm:text-[13px] text-[#66605C] font-medium mt-1">
                  Khách hàng hài lòng
                </div>
              </div>
            </div>

            {/* Stat 2: Members */}
            <div className="flex items-center gap-3.5 sm:px-6 pt-3 sm:pt-0">
              <div className="w-10 h-10 rounded-full bg-[#FFEADC] flex items-center justify-center text-[#FF5315] shrink-0">
                <UsersRound className="w-5 h-5" />
              </div>
              <div>
                <div className="text-2xl sm:text-[28px] font-bold text-[#FF5315] tracking-tight leading-none">
                  4.7M+
                </div>
                <div className="text-xs sm:text-[13px] text-[#66605C] font-medium mt-1">
                  Thành viên
                </div>
              </div>
            </div>

            {/* Stat 3: Fast Nationwide Shipping */}
            <div className="flex items-center gap-3.5 sm:px-6 pt-3 sm:pt-0">
              <div className="w-10 h-10 rounded-full bg-[#FFEADC] flex items-center justify-center text-[#FF5315] shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <div className="text-2xl sm:text-[28px] font-bold text-[#FF5315] tracking-tight leading-none">
                  3 ngày
                </div>
                <div className="text-xs sm:text-[13px] text-[#66605C] font-medium mt-1">
                  Giao hàng toàn quốc
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
