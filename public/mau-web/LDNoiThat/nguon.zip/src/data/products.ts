
// Import ảnh để Vite đóng gói vào bản build (chuỗi '/src/...' chỉ chạy được ở chế độ dev)
import anhAboutOrangeRoom from '../assets/images/about_orange_room_1792083006613.jpg';
import anhCollectionChair from '../assets/images/collection_chair_1792082955425.jpg';
import anhCollectionLights from '../assets/images/collection_lights_1792082988724.jpg';
import anhCollectionOutdoor from '../assets/images/collection_outdoor_1792082919818.jpg';
import anhCollectionSofa from '../assets/images/collection_sofa_1792082939071.jpg';
import anhCollectionSwing from '../assets/images/collection_swing_1792082973075.jpg';
import anhHeroLivingRoom from '../assets/images/hero_living_room_1792082900887.jpg';

export interface Product {
  id: string;
  name: string;
  category: 'outdoor' | 'sofa' | 'chair' | 'swing' | 'lighting';
  categoryName: string;
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  dimensions: string;
  material: string;
  rating: number;
  reviewCount: number;
  isPopular?: boolean;
}

export interface CollectionItem {
  id: 'outdoor' | 'sofa' | 'chair' | 'swing' | 'lighting';
  title: string;
  description?: string;
  image: string;
  bgGradient: string;
  colSpan: 'large' | 'small';
}

export const COLLECTIONS_DATA: CollectionItem[] = [
  {
    id: 'outdoor',
    title: 'Ghế thư giãn ngoài trời',
    description: 'Tận hưởng phút giây thư thái với những mẫu ghế ngoài trời thoải mái và tinh tế.',
    image: anhCollectionOutdoor,
    bgGradient: 'from-[#FF5E1E] to-[#F14408]',
    colSpan: 'large',
  },
  {
    id: 'sofa',
    title: 'Sofa hiện đại',
    description: 'Những mẫu sofa sang trọng, êm ái, phù hợp với mọi không gian sống.',
    image: anhCollectionSofa,
    bgGradient: 'from-[#FF5E1E] to-[#F14408]',
    colSpan: 'large',
  },
  {
    id: 'chair',
    title: 'Ghế đơn thời thượng',
    image: anhCollectionChair,
    bgGradient: 'from-[#FF6322] to-[#ED4709]',
    colSpan: 'small',
  },
  {
    id: 'swing',
    title: 'Xích đu mây tinh tế',
    image: anhCollectionSwing,
    bgGradient: 'from-[#FF6120] to-[#EB4609]',
    colSpan: 'small',
  },
  {
    id: 'lighting',
    title: 'Đèn treo trang trí',
    image: anhCollectionLights,
    bgGradient: 'from-[#FF6221] to-[#EC480A]',
    colSpan: 'small',
  },
];

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'prod-outdoor-1',
    name: 'Bộ Ghế Mây Ban Công Patio Oasis',
    category: 'outdoor',
    categoryName: 'Ghế ngoài trời',
    price: 8900000,
    originalPrice: 10500000,
    image: anhCollectionOutdoor,
    description: 'Bộ gồm 2 ghế mây đan thủ công cao cấp cùng bàn gỗ sồi bo tròn, đệm vải chống thấm kháng tia UV hoàn hảo cho sân vườn và ban công.',
    dimensions: 'Ghế: 78 x 82 x 84 cm | Bàn: Ø 65 x 46 cm',
    material: 'Khung mây tự nhiên đã qua xử lý, gỗ sồi nhập khẩu, đệm mút D40',
    rating: 4.9,
    reviewCount: 38,
    isPopular: true,
  },
  {
    id: 'prod-sofa-1',
    name: 'Sofa Nỉ Băng Dài Cam Home Luxe',
    category: 'sofa',
    categoryName: 'Sofa hiện đại',
    price: 18500000,
    originalPrice: 21900000,
    image: anhCollectionSofa,
    description: 'Thiết kế tối giản phong cách Bắc Âu với tone màu kem thanh lịch điểm gối cam đất ấm áp, lò xo túi êm ái chống xẹp lún.',
    dimensions: '240 x 95 x 82 cm',
    material: 'Vải nỉ nhung dệt chống bám bẩn, khung gỗ thông Bắc Mỹ, chân thép sơn tĩnh điện',
    rating: 5.0,
    reviewCount: 64,
    isPopular: true,
  },
  {
    id: 'prod-chair-1',
    name: 'Ghế Đơn Thư Giãn Solace Armchair',
    category: 'chair',
    categoryName: 'Ghế đơn thời thượng',
    price: 5200000,
    originalPrice: 6000000,
    image: anhCollectionChair,
    description: 'Ghế armchair bọc nỉ lông cừu Bouclé cao cấp, ôm trọn dáng ngồi thư giãn đọc sách và thưởng thức trà chiều.',
    dimensions: '82 x 78 x 88 cm',
    material: 'Vải lông cừu Bouclé kem, đệm mút nguyên khối, chân hợp kim titan đen mờ',
    rating: 4.8,
    reviewCount: 42,
    isPopular: true,
  },
  {
    id: 'prod-swing-1',
    name: 'Xích Đu Trứng Mây Đan Serenity Egg Chair',
    category: 'swing',
    categoryName: 'Xích đu mây tinh tế',
    price: 6800000,
    originalPrice: 7900000,
    image: anhCollectionSwing,
    description: 'Kiểu dáng tổ chim hình oval tinh tế với họa tiết nan mây thủ công, trang bị gối tựa nhung cam đất và nệm ngồi dày 12cm.',
    dimensions: 'Lồng: 95 x 75 x 120 cm | Cột treo: Ø 105 x 195 cm',
    material: 'Khung sắt chịu lực 200kg sơn tĩnh điện, sợi mây PE cao cấp, đệm bông gòn sợi tự nhiên',
    rating: 4.9,
    reviewCount: 51,
  },
  {
    id: 'prod-light-1',
    name: 'Bộ 3 Đèn Treo Bắc Âu Scandinavian Glow',
    category: 'lighting',
    categoryName: 'Đèn treo trang trí',
    price: 3400000,
    originalPrice: 4200000,
    image: anhCollectionLights,
    description: 'Bộ ba chao đèn phối kết hợp kim nhôm trắng mờ, gỗ sồi tiện nguyên khối và thủy tinh vân sọc ấm áp, tạo điểm nhấn nghệ thuật phòng ăn.',
    dimensions: 'Dây thả điều chỉnh 120 cm | Đường kính chao 18 - 25 cm',
    material: 'Gỗ sồi, thủy tinh borosilicate chịu nhiệt, chóa kim loại phủ nano',
    rating: 4.9,
    reviewCount: 29,
  },
  {
    id: 'prod-hero-1',
    name: 'Bộ Sofa Phòng Khách Cam Home Signature',
    category: 'sofa',
    categoryName: 'Sofa hiện đại',
    price: 24500000,
    originalPrice: 28000000,
    image: anhHeroLivingRoom,
    description: 'Tổ hợp không gian phòng khách hoàn mỹ gồm sofa góc chữ L kem trang nhã, bàn trà gỗ sồi nguyên khối và đôn tròn bọc nỉ cam ấm áp.',
    dimensions: 'Sofa: 280 x 180 x 85 cm | Bàn trà: Ø 90 x 42 cm',
    material: 'Vải Linen nhập khẩu Bỉ, khung gỗ sồi Nga tự nhiên',
    rating: 5.0,
    reviewCount: 88,
    isPopular: true,
  },
  {
    id: 'prod-about-1',
    name: 'Ghế Armchair Da Bò Terra Warmth',
    category: 'chair',
    categoryName: 'Ghế đơn thời thượng',
    price: 7600000,
    originalPrice: 9200000,
    image: anhAboutOrangeRoom,
    description: 'Ghế bành đơn tone cam đất Terracotta lấy cảm hứng từ phong cách Ý sang trọng, điểm nhấn cho không gian đọc sách hay góc chill bên cửa sổ.',
    dimensions: '86 x 84 x 82 cm',
    material: 'Nỉ nhung nhung mềm hoặc da microfiber cao cấp, chân gỗ óc chó',
    rating: 4.9,
    reviewCount: 33,
  }
];

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount).replace('₫', 'đ');
}
