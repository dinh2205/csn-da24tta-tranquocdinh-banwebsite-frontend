import React from 'react';
import { ArrowRight, Leaf, Heart, Droplets, Sprout } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const benefitCards = [
    {
      title: '100%',
      subtitle: 'Tự nhiên',
      desc: 'Không chất bảo quản',
      icon: Leaf,
      iconColor: 'text-[#218D28]',
      iconBg: 'bg-[#D3F2D0]',
      cardBg: 'bg-[#EAF8E8]',
    },
    {
      title: 'Tốt cho',
      subtitle: 'sức khỏe',
      desc: 'Giàu vitamin',
      icon: Heart,
      iconColor: 'text-[#FF8909]',
      iconBg: 'bg-[#FFE8B3]',
      cardBg: 'bg-[#FFF7DE]',
    },
    {
      title: 'Hương vị',
      subtitle: 'thơm ngon',
      desc: 'Từ trái cây thật',
      icon: Droplets,
      iconColor: 'text-[#0EA5E9]',
      iconBg: 'bg-[#CBEFFF]',
      cardBg: 'bg-[#E5F9FF]',
    },
    {
      title: 'Thân thiện',
      subtitle: 'môi trường',
      desc: 'Bao bì có thể tái chế',
      icon: Sprout,
      iconColor: 'text-[#218D28]',
      iconBg: 'bg-[#D3F2D0]',
      cardBg: 'bg-[#E9F8E4]',
    },
  ];

  return (
    <section id="about" className="py-12 sm:py-16 lg:py-20 max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-7 items-center">
        {/* Left Column: Orchard Photo with Organic Natural Seal Badge */}
        <div className="lg:col-span-4 relative group">
          <div className="relative rounded-[28px] overflow-hidden shadow-md">
            <img
              src="./assets/orange-orchard.jpg"
              alt="Nông trại trái cây thiên nhiên Eco Fruits Việt Nam"
              className="w-full aspect-square object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
          </div>

          {/* Natural Circular Leaf Seal Badge */}
          <div className="absolute -top-3.5 -right-3.5 sm:-top-5 sm:-right-5 z-20 w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-white shadow-lg border-2 border-[#E2EBDC] flex items-center justify-center p-2 text-center animate-spin-slow">
            <div className="relative w-full h-full flex items-center justify-center">
              <svg className="w-full h-full animate-[spin_20s_linear_infinite]" viewBox="0 0 100 100">
                <path
                  id="circlePath"
                  d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
                  fill="none"
                />
                <text className="text-[10.5px] font-extrabold uppercase fill-[#1A6E24] tracking-[0.14em]">
                  <textPath href="#circlePath" startOffset="0%">
                    TRÁI CÂY THIÊN NHIÊN • 100% TỰ NHIÊN •
                  </textPath>
                </text>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <Leaf className="w-6 h-6 text-[#218D28] fill-[#218D28]" />
              </div>
            </div>
          </div>
        </div>

        {/* Middle Column: Brand Story and Mission */}
        <div className="lg:col-span-4 flex flex-col justify-center">
          {/* Eyebrow Tag */}
          <div className="inline-flex items-center gap-1.5 text-[#218D28] font-bold text-sm tracking-wide mb-3">
            <Leaf className="w-4 h-4 fill-[#218D28]" />
            <span>Về chúng tôi</span>
          </div>

          {/* Heading */}
          <h2 className="text-[#136A2A] text-2xl sm:text-3xl lg:text-[32px] font-black leading-[1.25] tracking-tight">
            Eco Fruits – Hành trình vì sức khỏe cộng đồng
          </h2>

          {/* Description */}
          <p className="mt-4 text-[#556155] text-[15px] leading-[1.7] font-normal">
            Zest Citrus là thương hiệu nước trái cây thiên nhiên được ra đời với sứ mệnh mang đến những thức uống tươi mát, ngon lành và tốt cho sức khỏe. Chúng tôi sử dụng nguồn trái cây tự nhiên từ các vùng nông trại Việt Nam, kết hợp công nghệ hiện đại để giữ trọn hương vị và dinh dưỡng.
          </p>

          {/* Action Button */}
          <div className="mt-6">
            <a
              href="#benefits"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#218D28] hover:bg-[#1A7720] text-white text-[14px] font-bold rounded-full shadow-sm hover:shadow transition-all duration-200 transform hover:-translate-y-0.5"
            >
              <span>Tìm hiểu thêm</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Right Column: 2x2 Feature Cards */}
        <div className="lg:col-span-4 grid grid-cols-2 gap-3.5 sm:gap-4">
          {benefitCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className={`${card.cardBg} rounded-[22px] p-4 sm:p-5 flex flex-col items-center text-center transition-all duration-300 hover:shadow-md hover:-translate-y-1`}
              >
                <div className={`w-11 h-11 rounded-full ${card.iconBg} flex items-center justify-center mb-3 shadow-sm`}>
                  <Icon className={`w-5 h-5 ${card.iconColor}`} />
                </div>
                <div className="text-[15px] font-bold text-[#1A211A] leading-snug">
                  <div>{card.title}</div>
                  <div>{card.subtitle}</div>
                </div>
                <div className="text-[12px] text-[#606E61] mt-1 font-medium">
                  {card.desc}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
