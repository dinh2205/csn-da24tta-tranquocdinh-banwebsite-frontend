import React from 'react';
import { Leaf, ShieldCheck, Droplets, Globe } from 'lucide-react';

export const BenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: Leaf,
      title: 'Trái cây tuyển chọn',
      desc: 'Từ nông trại Việt Nam',
    },
    {
      icon: ShieldCheck,
      title: 'Quy trình hiện đại',
      desc: 'Giữ trọn dinh dưỡng',
    },
    {
      icon: Droplets,
      title: 'Không chất bảo quản',
      desc: 'An toàn cho sức khỏe',
    },
    {
      icon: Globe,
      title: 'Vì môi trường xanh',
      desc: 'Bao bì thân thiện',
    },
  ];

  return (
    <section id="benefits" className="py-8 sm:py-12 max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Horizontal Strip Container with Pale Green Background */}
      <div className="bg-[#EFFAEF] rounded-[24px] sm:rounded-[28px] p-6 sm:p-8 border border-[#E1F2E0]">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 divide-y sm:divide-y-0 lg:divide-x divide-[#D6EBD5]">
          {benefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="flex flex-col items-center text-center px-4 pt-4 sm:pt-0 group"
              >
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-full bg-[#D8F2D6] flex items-center justify-center text-[#218D28] mb-3 transition-transform duration-300 group-hover:scale-110 shadow-xs">
                  <Icon className="w-6 h-6 stroke-[2.2]" />
                </div>

                {/* Title */}
                <h3 className="text-[16px] sm:text-[17px] font-black text-[#1A211A] tracking-tight">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-[13px] sm:text-[14px] text-[#556355] mt-1 font-medium">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
