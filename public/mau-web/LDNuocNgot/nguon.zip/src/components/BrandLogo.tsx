import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  theme?: 'dark' | 'light';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  theme = 'dark',
}) => {
  const iconSize = size === 'sm' ? 32 : size === 'lg' ? 44 : 38;

  return (
    <a href="#home" className={`inline-flex items-center gap-2.5 group select-none ${className}`}>
      {/* Citrus Slice Icon with Green Leaf */}
      <div
        className="relative shrink-0 transition-transform duration-300 group-hover:rotate-12 group-hover:scale-105"
        style={{ width: iconSize, height: iconSize }}
      >
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          {/* Orange Slice Outer Rind */}
          <circle cx="50" cy="50" r="46" fill="#FFA500" stroke="#FF7A00" strokeWidth="3" />
          <circle cx="50" cy="50" r="41" fill="#FFF8E7" />
          <circle cx="50" cy="50" r="38" fill="#FF8C00" />
          
          {/* Citrus Segments */}
          <path d="M50 50 L50 14 A36 36 0 0 1 75.4 24.6 Z" fill="#FFAE19" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L75.4 24.6 A36 36 0 0 1 85.5 50 Z" fill="#FF9A00" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L85.5 50 A36 36 0 0 1 75.4 75.4 Z" fill="#FFAE19" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L75.4 75.4 A36 36 0 0 1 50 85.5 Z" fill="#FF8900" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L50 85.5 A36 36 0 0 1 24.6 75.4 Z" fill="#FFAE19" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L24.6 75.4 A36 36 0 0 1 14.5 50 Z" fill="#FF9A00" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L14.5 50 A36 36 0 0 1 24.6 24.6 Z" fill="#FFAE19" stroke="#FFF8E7" strokeWidth="2.5" />
          <path d="M50 50 L24.6 24.6 A36 36 0 0 1 50 14 Z" fill="#FF8900" stroke="#FFF8E7" strokeWidth="2.5" />

          {/* Central Core */}
          <circle cx="50" cy="50" r="5" fill="#FFF8E7" />

          {/* Top Green Leaf */}
          <path
            d="M50 12 C44 -4, 20 -2, 18 16 C30 18, 44 20, 50 12 Z"
            fill="#28A745"
            stroke="#1C7430"
            strokeWidth="1.5"
          />
          <path
            d="M26 12 Q38 10 48 13"
            stroke="#A7E979"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Brand Text */}
      <div className="flex flex-col leading-none">
        <span
          className={`font-black tracking-tight ${
            size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl'
          } ${theme === 'light' ? 'text-white' : 'text-[#1D6F22]'}`}
        >
          Zest
        </span>
        <span
          className={`font-black tracking-tight -mt-0.5 ${
            size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl'
          } ${theme === 'light' ? 'text-white/90' : 'text-[#1D6F22]'}`}
        >
          Citrus
        </span>
      </div>
    </a>
  );
};
