import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingBag, Sparkles, CheckCircle2 } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  if (!isOpen) return null;

  const subtotal = cart.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const discountRate = appliedCoupon === 'ZESTBERRY20' ? 0.2 : 0;
  const discountAmount = subtotal * discountRate;
  const shippingFee = subtotal > 150000 || subtotal === 0 ? 0 : 20000;
  const total = subtotal - discountAmount + shippingFee;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(price);
  };

  const applyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim().toUpperCase() === 'ZESTBERRY20') {
      setAppliedCoupon('ZESTBERRY20');
      setCouponCode('');
    } else {
      alert('Mã giảm giá không hợp lệ. Hãy thử mã "ZESTBERRY20"!');
    }
  };

  const handleCheckout = () => {
    setCheckoutSuccess(true);
    setTimeout(() => {
      onClearCart();
      setCheckoutSuccess(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#218D28]" />
            <h2 className="font-bold text-lg text-[#1A211A]">Giỏ hàng của bạn</h2>
            <span className="text-xs bg-[#EAF8E8] text-[#218D28] px-2 py-0.5 rounded-full font-bold">
              {cart.reduce((total, item) => total + item.quantity, 0)} sản phẩm
            </span>
          </div>
          <button
            onClick={onClose}
            aria-label="Đóng"
            className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-black transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {checkoutSuccess ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 bg-emerald-100 text-[#218D28] rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-[#1A211A]">Đặt hàng thành công!</h3>
              <p className="text-sm text-gray-600 mt-2">
                Cảm ơn bạn đã lựa chọn Zest Citrus. Đơn hàng đang được chuẩn bị và sẽ sớm được giao tới bạn.
              </p>
            </div>
          ) : cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-gray-500">
              <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4 text-gray-400">
                <ShoppingBag className="w-8 h-8 stroke-1" />
              </div>
              <p className="font-semibold text-gray-700">Giỏ hàng của bạn đang trống</p>
              <p className="text-xs text-gray-400 mt-1 max-w-xs">
                Hãy khám phá các hương vị nước ép tươi ngon bên dưới và thêm vào giỏ!
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-3.5 p-3 rounded-2xl bg-[#F8FAF7] border border-[#E8EDE5]"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-xl object-contain bg-white p-1 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-sm text-[#1A211A] truncate">
                      {item.product.name}
                    </h4>
                    <p className="text-xs text-gray-500 truncate">
                      {item.product.flavor}
                    </p>
                    <div className="text-sm font-bold text-[#FF8909] mt-1">
                      {formatPrice(item.product.price)}
                    </div>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex flex-col items-end gap-2">
                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-gray-400 hover:text-rose-500 transition-colors p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-full px-1.5 py-0.5">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, -1)}
                        className="w-5 h-5 flex items-center justify-center text-gray-500 hover:text-black"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold w-4 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, 1)}
                        className="w-5 h-5 flex items-center justify-center text-gray-500 hover:text-black"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {/* Coupon Form */}
              <div className="pt-2">
                {appliedCoupon ? (
                  <div className="p-3 bg-pink-50 border border-pink-200 rounded-xl flex items-center justify-between text-xs font-semibold text-pink-700">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      Đã áp dụng mã {appliedCoupon} (-20%)
                    </span>
                    <button
                      onClick={() => setAppliedCoupon(null)}
                      className="text-gray-400 hover:text-gray-700"
                    >
                      Xóa
                    </button>
                  </div>
                ) : (
                  <form onSubmit={applyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Mã giảm giá (ZESTBERRY20)"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-xl text-xs outline-none focus:border-[#218D28] uppercase"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-gray-800 text-white text-xs font-bold rounded-xl hover:bg-black transition-colors"
                    >
                      Áp dụng
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer / Total & Checkout */}
        {cart.length > 0 && !checkoutSuccess && (
          <div className="p-6 border-t border-gray-100 bg-[#FBFDFB]">
            <div className="space-y-2 mb-4 text-sm">
              <div className="flex justify-between text-gray-500">
                <span>Tạm tính</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-pink-600 font-semibold">
                  <span>Giảm giá (20%)</span>
                  <span>-{formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-500">
                <span>Phí vận chuyển</span>
                <span>{shippingFee === 0 ? 'Miễn phí' : formatPrice(shippingFee)}</span>
              </div>
              <div className="flex justify-between text-base font-black text-[#1A211A] pt-2 border-t border-gray-200">
                <span>Tổng cộng</span>
                <span className="text-[#FF8909] text-lg">{formatPrice(total)}</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              className="w-full py-3.5 bg-[#218D28] hover:bg-[#1A7720] text-white font-bold rounded-full shadow-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Thanh toán ngay</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
