import React from 'react';

export const FloatingDecorations: React.FC = () => {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-10 hidden xl:block">
      {/* Top Left Floating Orange Half Slice */}
      <div className="absolute top-[28%] -left-10 w-28 h-28 transform -rotate-12 opacity-85 transition-transform duration-700 hover:rotate-6">
        <svg viewBox="0 0 100 100" fill="none" className="w-full h-full drop-shadow-lg">
          <circle cx="50" cy="50" r="46" fill="#FFA500" stroke="#FF7A00" strokeWidth="2.5" />
          <circle cx="50" cy="50" r="42" fill="#FFFDF5" />
          <circle cx="50" cy="50" r="38" fill="#FF8C00" />
          <path d="M50 50 L50 14 A36 36 0 0 1 75.4 24.6 Z" fill="#FFAE19" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L75.4 24.6 A36 36 0 0 1 85.5 50 Z" fill="#FF9A00" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L85.5 50 A36 36 0 0 1 75.4 75.4 Z" fill="#FFAE19" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L75.4 75.4 A36 36 0 0 1 50 85.5 Z" fill="#FF8900" stroke="#FFFDF5" strokeWidth="2" />
          <circle cx="50" cy="50" r="4.5" fill="#FFFDF5" />
        </svg>
      </div>

      {/* Mid Right Floating Orange Slice near Products */}
      <div className="absolute top-[52%] -right-8 w-32 h-32 transform rotate-45 opacity-80 transition-transform duration-700">
        <svg viewBox="0 0 100 100" fill="none" className="w-full h-full drop-shadow-lg">
          <circle cx="50" cy="50" r="46" fill="#FFA500" stroke="#FF7A00" strokeWidth="2.5" />
          <circle cx="50" cy="50" r="42" fill="#FFFDF5" />
          <circle cx="50" cy="50" r="38" fill="#FF8C00" />
          <path d="M50 50 L50 85.5 A36 36 0 0 1 24.6 75.4 Z" fill="#FFAE19" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L24.6 75.4 A36 36 0 0 1 14.5 50 Z" fill="#FF9A00" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L14.5 50 A36 36 0 0 1 24.6 24.6 Z" fill="#FFAE19" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L24.6 24.6 A36 36 0 0 1 50 14 Z" fill="#FF8900" stroke="#FFFDF5" strokeWidth="2" />
          <circle cx="50" cy="50" r="4.5" fill="#FFFDF5" />
        </svg>
      </div>

      {/* Bottom Left Floating Orange Slice near Newsletter */}
      <div className="absolute top-[82%] -left-8 w-24 h-24 transform rotate-18 opacity-85 transition-transform duration-700">
        <svg viewBox="0 0 100 100" fill="none" className="w-full h-full drop-shadow-md">
          <circle cx="50" cy="50" r="46" fill="#FFA500" stroke="#FF7A00" strokeWidth="2.5" />
          <circle cx="50" cy="50" r="42" fill="#FFFDF5" />
          <circle cx="50" cy="50" r="38" fill="#FF8C00" />
          <path d="M50 50 L50 14 A36 36 0 0 1 75.4 24.6 Z" fill="#FFAE19" stroke="#FFFDF5" strokeWidth="2" />
          <path d="M50 50 L75.4 24.6 A36 36 0 0 1 85.5 50 Z" fill="#FF9A00" stroke="#FFFDF5" strokeWidth="2" />
          <circle cx="50" cy="50" r="4.5" fill="#FFFDF5" />
        </svg>
      </div>
    </div>
  );
};
