import React from 'react';
import { MapPin, Mail, Phone, Heart } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

export const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-[#FFFDF7] border-t border-[#EAEFE8] pt-14 pb-8 text-[#2A362A]">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main 4 Columns */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-10 pb-12">
          {/* Column 1: Brand & Mission */}
          <div className="lg:col-span-4 flex flex-col items-start">
            <BrandLogo />
            <p className="mt-4 text-[#5D6B5D] text-[14px] leading-relaxed max-w-sm">
              Nước trái cây thiên nhiên, tốt cho sức khỏe và thân thiện với môi trường.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="lg:col-span-2 sm:col-span-1">
            <h4 className="font-bold text-[16px] text-[#1A211A] mb-4">
              Liên kết nhanh
            </h4>
            <ul className="space-y-2.5 text-[14px] text-[#5D6B5D]">
              <li>
                <a href="#home" className="hover:text-[#218D28] transition-colors">
                  Trang chủ
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#218D28] transition-colors">
                  Về chúng tôi
                </a>
              </li>
              <li>
                <a href="#products" className="hover:text-[#218D28] transition-colors">
                  Sản phẩm
                </a>
              </li>
              <li>
                <a href="#benefits" className="hover:text-[#218D28] transition-colors">
                  Lợi ích
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#218D28] transition-colors">
                  Liên hệ
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Support & Policies */}
          <div className="lg:col-span-3 sm:col-span-1">
            <h4 className="font-bold text-[16px] text-[#1A211A] mb-4">
              Hỗ trợ
            </h4>
            <ul className="space-y-2.5 text-[14px] text-[#5D6B5D]">
              <li>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#218D28] transition-colors">
                  Chính sách bảo mật
                </a>
              </li>
              <li>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#218D28] transition-colors">
                  Điều khoản sử dụng
                </a>
              </li>
              <li>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#218D28] transition-colors">
                  Hướng dẫn mua hàng
                </a>
              </li>
              <li>
                <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-[#218D28] transition-colors">
                  Câu hỏi thường gặp
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact info */}
          <div className="lg:col-span-3 sm:col-span-1">
            <h4 className="font-bold text-[16px] text-[#1A211A] mb-4">
              Liên hệ
            </h4>
            <ul className="space-y-3 text-[14px] text-[#5D6B5D]">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#218D28] shrink-0 mt-1" />
                <span>123 Đường Trái Cây, Quận 1, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#218D28] shrink-0" />
                <a href="mailto:contact@zestcitrus.vn" className="hover:text-[#218D28] transition-colors">
                  contact@zestcitrus.vn
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#218D28] shrink-0" />
                <a href="tel:0123456789" className="hover:text-[#218D28] transition-colors">
                  0123 456 789
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="pt-8 border-t border-[#EAEFE8] flex flex-col sm:flex-row items-center justify-between gap-4 text-[13px] text-[#718071]">
          <div>
            © 2026 Zest Citrus. Tất cả quyền được bảo lưu.
          </div>
          <div className="flex items-center gap-1.5">
            <span>Thiết kế với</span>
            <Heart className="w-4 h-4 fill-red-500 text-red-500 inline" />
            <span>tại Việt Nam</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
