import React, { useState, useEffect } from 'react';
import { ShoppingCart, ArrowRight, Menu, X } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const Header: React.FC<HeaderProps> = ({ cartCount, onOpenCart }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'about', 'products', 'benefits', 'contact'];
      const scrollPosition = window.scrollY + 140;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Trang chủ', href: '#home', id: 'home' },
    { label: 'Về chúng tôi', href: '#about', id: 'about' },
    { label: 'Sản phẩm', href: '#products', id: 'products' },
    { label: 'Lợi ích', href: '#benefits', id: 'benefits' },
    { label: 'Liên hệ', href: '#contact', id: 'contact' },
  ];

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-[0_4px_20px_rgba(0,0,0,0.04)] py-3'
          : 'bg-white py-4'
      }`}
    >
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <BrandLogo />

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 lg:gap-10">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.id}
                href={link.href}
                className={`relative text-[15px] font-medium transition-colors duration-200 py-1 ${
                  isActive
                    ? 'text-[#218D28] font-semibold'
                    : 'text-[#4A554A] hover:text-[#218D28]'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#218D28] rounded-full" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-3.5">
          {/* Shopping Cart Button */}
          <button
            onClick={onOpenCart}
            aria-label="Mở giỏ hàng"
            className="relative p-2.5 rounded-full text-[#218D28] hover:bg-[#EAF8E8] transition-colors focus:outline-none"
          >
            <ShoppingCart className="w-5 h-5 stroke-[2.2]" />
            <span
              className={`absolute -top-1 -right-1 flex items-center justify-center min-w-[20px] h-5 px-1 text-[11px] font-bold text-white rounded-full transition-transform ${
                cartCount > 0 ? 'bg-[#FF8909] scale-100' : 'bg-[#218D28] scale-100'
              }`}
            >
              {cartCount}
            </span>
          </button>

          {/* "Mua ngay" Pill Button */}
          <a
            href="#products"
            className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 bg-[#218D28] hover:bg-[#1A7720] text-white text-[14px] font-semibold rounded-full shadow-sm hover:shadow transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <span>Mua ngay</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </a>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#218D28] rounded-lg hover:bg-[#EAF8E8] transition-colors"
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-[#E8EDE3] px-4 pt-4 pb-6 shadow-xl animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`py-2 px-3 rounded-lg text-base font-medium transition-colors ${
                  activeSection === link.id
                    ? 'bg-[#EAF8E8] text-[#218D28] font-bold'
                    : 'text-[#3D473D] hover:bg-gray-50'
                }`}
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 border-t border-gray-100 mt-2">
              <a
                href="#products"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-center gap-2 w-full py-3 bg-[#218D28] text-white text-base font-semibold rounded-full shadow"
              >
                <span>Mua ngay</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
