import React, { useState } from 'react';
import { ArrowRight, Play } from 'lucide-react';

interface HeroSectionProps {
  onOpenVideo: () => void;
  onExploreFlavors: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenVideo,
  onExploreFlavors,
}) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      title1: 'Zest',
      title2: 'Citrus',
      subtitle: 'Năng lượng tươi mới cho cuộc sống mỗi ngày',
      tag: '100% TỰ NHIÊN',
      handwriting: ['Tươi mát', 'Tự nhiên', 'Tràn năng lượng!'],
      image: './assets/hero-citrus-composite.jpg',
    },
    {
      title1: 'Green',
      title2: 'Boost',
      subtitle: 'Bừng tỉnh sảng khoái với chanh tươi & bạc hà',
      tag: '100% TỰ NHIÊN',
      handwriting: ['Thanh mát', 'Thư thái', 'Đầy sảng khoái!'],
      image: './assets/green-boost-composite.jpg',
    },
    {
      title1: 'Berry',
      title2: 'Bliss',
      subtitle: 'Ngọt ngào quyến rũ từ dâu tây & phúc bồn tử',
      tag: '100% TỰ NHIÊN',
      handwriting: ['Ngọt dịu', 'Trẻ trung', 'Rực sắc hồng!'],
      image: './assets/berry-bliss-composite.jpg',
    },
    {
      title1: 'Zest',
      title2: 'Citrus',
      subtitle: 'Vị cam bưởi tự nhiên đánh thức mọi giác quan',
      tag: '100% TỰ NHIÊN',
      handwriting: ['Nguyên bản', 'Đậm đà', 'Tươi mỗi ngày!'],
      image: './assets/zest-citrus-composite.jpg',
    },
  ];

  const current = slides[activeSlide];

  return (
    <section id="home" className="relative pt-2 pb-8 sm:pb-12 max-w-[1360px] mx-auto px-3 sm:px-6 lg:px-8">
      {/* Main Hero Container with Large Rounded Corners */}
      <div className="relative rounded-[32px] sm:rounded-[40px] overflow-hidden bg-gradient-to-r from-[#2B8B23] via-[#4DAD25] to-[#9EE12D] text-white shadow-xl shadow-green-900/10 min-h-[520px] lg:min-h-[580px] flex flex-col justify-between p-6 sm:p-10 lg:p-14">
        {/* Decorative Background Elements */}
        <div className="absolute top-0 right-0 w-[550px] h-[550px] bg-white/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-yellow-400/20 rounded-full blur-3xl pointer-events-none" />

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-4 items-center relative z-10 my-auto">
          {/* Left Column: Typography & CTAs */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            {/* Tag / Eyebrow */}
            <div className="flex items-center gap-3 mb-3 sm:mb-4">
              <span className="text-[12px] sm:text-[13px] font-bold tracking-[0.25em] text-white/95 uppercase">
                {current.tag}
              </span>
              <div className="flex items-center text-white/80">
                <span className="w-10 sm:w-14 h-[1.5px] bg-white/70 inline-block" />
                <span className="text-sm font-bold -ml-1">→</span>
              </div>
            </div>

            {/* Giant Display Headline */}
            <h1 className="font-display font-black text-[54px] sm:text-[80px] lg:text-[98px] xl:text-[104px] leading-[0.92] tracking-tight text-white drop-shadow-sm select-none">
              <div>{current.title1}</div>
              <div>{current.title2}</div>
            </h1>

            {/* Subtitle */}
            <p className="mt-4 sm:mt-5 text-white/95 text-lg sm:text-[22px] font-semibold max-w-md leading-snug">
              {current.subtitle}
            </p>

            {/* CTA Buttons */}
            <div className="mt-7 sm:mt-9 flex flex-wrap items-center gap-4 sm:gap-6">
              {/* Primary Orange Button */}
              <button
                onClick={onExploreFlavors}
                className="group inline-flex items-center gap-2.5 px-6 sm:px-7 py-3.5 bg-[#FF8909] hover:bg-[#F37B03] text-white text-[15px] font-bold rounded-full shadow-lg shadow-orange-950/20 hover:shadow-orange-950/30 transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
              >
                <span>Khám phá hương vị</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5] transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              {/* Video Play Button */}
              <button
                onClick={onOpenVideo}
                className="group inline-flex items-center gap-3 text-white font-medium hover:text-white/90 transition-all duration-200 cursor-pointer"
              >
                <div className="w-11 h-11 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/40 flex items-center justify-center transition-all duration-200 group-hover:scale-105 shadow-sm">
                  <Play className="w-4 h-4 fill-white text-white ml-0.5" />
                </div>
                <span className="text-[15px] font-medium tracking-wide">Xem video</span>
              </button>
            </div>
          </div>

          {/* Right Column: Prominent Beverage Can Visual & Splash */}
          <div className="lg:col-span-7 relative flex items-center justify-center lg:justify-end min-h-[340px] sm:min-h-[420px] lg:min-h-[480px]">
            {/* White Handwritten Cursive Note */}
            <div className="absolute top-2 sm:top-6 right-2 sm:right-6 z-20 pointer-events-none transform -rotate-[8deg]">
              <div className="font-handwriting text-white text-2xl sm:text-[32px] lg:text-[36px] leading-[1.1] font-bold drop-shadow-[0_2px_8px_rgba(0,0,0,0.25)] text-right">
                {current.handwriting.map((line, idx) => (
                  <div key={idx}>{line}</div>
                ))}
              </div>
            </div>

            {/* Glowing Backdrop behind can */}
            <div className="absolute w-[280px] sm:w-[420px] h-[280px] sm:h-[420px] rounded-full bg-gradient-to-tr from-amber-400/30 to-white/25 blur-2xl" />

            {/* Beverage Can Artwork Container */}
            <div className="relative z-10 w-full max-w-[420px] sm:max-w-[480px] lg:max-w-[530px] transition-all duration-500 transform hover:scale-[1.02]">
              <img
                src={current.image}
                alt={`${current.title1} ${current.title2} Nước trái cây`}
                className="w-full h-auto object-contain rounded-2xl drop-shadow-[0_20px_40px_rgba(0,0,0,0.28)]"
              />
            </div>
          </div>
        </div>

        {/* Bottom Pagination Dots */}
        <div className="relative z-20 flex items-center justify-center gap-2 pt-4">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveSlide(idx)}
              aria-label={`Chuyển slide ${idx + 1}`}
              className={`transition-all duration-300 rounded-full ${
                activeSlide === idx
                  ? 'w-7 h-2 bg-white'
                  : 'w-2 h-2 bg-white/50 hover:bg-white/80'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
