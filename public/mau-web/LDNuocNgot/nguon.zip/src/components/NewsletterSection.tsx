import React, { useState } from 'react';
import { ArrowRight, CheckCircle, Facebook, Instagram, Youtube, Music2 } from 'lucide-react';

export const NewsletterSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setError('Vui lòng nhập địa chỉ email hợp lệ');
      return;
    }

    try {
      const existing = JSON.parse(
        localStorage.getItem('zest_newsletter_emails') || '[]'
      );
      if (!existing.includes(email.trim())) {
        existing.push(email.trim());
        localStorage.setItem(
          'zest_newsletter_emails',
          JSON.stringify(existing)
        );
      }
    } catch {
      // ignore
    }

    setSubscribed(true);
    setError('');
  };

  return (
    <section className="py-8 sm:py-12 max-w-[1360px] mx-auto px-3 sm:px-6 lg:px-8">
      {/* Curved Green Banner */}
      <div className="relative rounded-[28px] sm:rounded-[36px] overflow-hidden bg-gradient-to-r from-[#177227] via-[#2F9329] to-[#68BA27] text-white shadow-xl shadow-green-950/15 p-6 sm:p-10 lg:p-12">
        {/* Decorative Sliced Orange & Leaf SVGs in background */}
        <div className="absolute -left-12 -bottom-16 w-48 h-48 sm:w-64 sm:h-64 opacity-25 pointer-events-none">
          <svg viewBox="0 0 100 100" fill="none" className="w-full h-full">
            <circle cx="50" cy="50" r="45" stroke="#FFA500" strokeWidth="8" />
            <path d="M50 50 L50 10 A40 40 0 0 1 85 50 Z" fill="#FF8C00" />
            <path d="M50 50 L85 50 A40 40 0 0 1 50 90 Z" fill="#FFA500" />
            <path d="M50 50 L50 90 A40 40 0 0 1 15 50 Z" fill="#FF8C00" />
            <path d="M50 50 L15 50 A40 40 0 0 1 50 10 Z" fill="#FFA500" />
          </svg>
        </div>
        <div className="absolute -right-10 -top-10 w-44 h-44 opacity-20 pointer-events-none">
          <svg viewBox="0 0 100 100" fill="none" className="w-full h-full">
            <circle cx="50" cy="50" r="45" stroke="#FFA500" strokeWidth="8" />
            <path d="M50 50 L50 10 A40 40 0 0 1 85 50 Z" fill="#FF8C00" />
            <path d="M50 50 L85 50 A40 40 0 0 1 50 90 Z" fill="#FFA500" />
          </svg>
        </div>

        {/* Content Layout */}
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Heading & Info */}
          <div className="lg:col-span-7">
            {/* Tag / Brand Label */}
            <div className="inline-flex items-center gap-2 mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FF8909]" />
              <span className="text-[13px] sm:text-[14px] font-bold text-white/90">
                Zest Citrus
              </span>
            </div>

            {/* Title */}
            <h2 className="font-display font-black text-[28px] sm:text-[38px] lg:text-[44px] leading-[1.1] text-white tracking-tight drop-shadow-sm">
              Cùng Zest Citrus<br />lan tỏa năng lượng tươi mát!
            </h2>

            {/* Description */}
            <p className="mt-3 text-white/90 text-[14px] sm:text-[16px] max-w-lg font-medium">
              Theo dõi chúng tôi để cập nhật sản phẩm mới và ưu đãi hấp dẫn.
            </p>
          </div>

          {/* Right Column: Email Subscription & Social Icons */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            {subscribed ? (
              <div className="bg-white/20 backdrop-blur-md rounded-full px-6 py-4 flex items-center gap-3 text-white font-medium">
                <CheckCircle className="w-6 h-6 text-emerald-300 shrink-0" />
                <span>Cảm ơn bạn! Chúng tôi đã lưu email của bạn thành công.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="relative">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center bg-white rounded-[999px] p-1.5 shadow-lg border border-white/40">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Nhập email của bạn"
                    className="flex-1 px-5 py-3 text-[14px] sm:text-[15px] text-[#1A211A] placeholder:text-gray-400 rounded-full focus:outline-none bg-transparent"
                  />
                  <button
                    type="submit"
                    className="shrink-0 px-6 py-3 bg-[#FF8909] hover:bg-[#F37B03] text-white font-bold text-[14px] sm:text-[15px] rounded-full transition-all duration-200 shadow-sm flex items-center justify-center gap-1.5 cursor-pointer mt-2 sm:mt-0"
                  >
                    <span>Theo dõi</span>
                    <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                  </button>
                </div>
                {error && (
                  <p className="text-xs text-rose-200 mt-2 px-4 font-semibold">
                    {error}
                  </p>
                )}
              </form>
            )}

            {/* Social Icons */}
            <div className="flex items-center justify-center lg:justify-end gap-3.5 mt-6">
              {[
                { icon: Facebook, label: 'Facebook' },
                { icon: Instagram, label: 'Instagram' },
                { icon: Youtube, label: 'YouTube' },
                { icon: Music2, label: 'TikTok' },
              ].map((soc, idx) => {
                const Icon = soc.icon;
                return (
                  <a
                    key={idx}
                    href="#"
                    onClick={(e) => e.preventDefault()}
                    aria-label={soc.label}
                    className="w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-all duration-200 transform hover:scale-110 shadow-xs"
                  >
                    <Icon className="w-4 h-4 stroke-[2.2]" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
