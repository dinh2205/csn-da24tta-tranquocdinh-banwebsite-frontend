import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
}) => {
  return (
    <div
      onClick={() => onSelect(product)}
      className="group relative rounded-[26px] p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-2 hover:shadow-xl cursor-pointer select-none"
      style={{
        background: product.theme.cardGradient,
      }}
    >
      {/* Product Image Area */}
      <div className="relative w-full aspect-square flex items-center justify-center overflow-hidden rounded-[20px] mb-4 bg-white/40 backdrop-blur-xs">
        <img
          src={product.image}
          alt={`${product.name} - ${product.flavor}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108 group-hover:rotate-1"
        />
        {/* Subtle glass reflection effect */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/30 pointer-events-none" />
      </div>

      {/* Card Footer: Product Name, Flavor description, and Round Action Button */}
      <div className="flex items-center justify-between gap-3 px-1 pt-1">
        <div>
          <h3 className="text-[20px] sm:text-[22px] font-black text-[#1A211A] tracking-tight group-hover:text-[#218D28] transition-colors">
            {product.name}
          </h3>
          <p className="text-[13px] sm:text-[14px] text-[#637063] font-medium mt-0.5">
            {product.flavor}
          </p>
        </div>

        {/* Round Arrow Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSelect(product);
          }}
          aria-label={`Xem chi tiết ${product.name}`}
          className="w-11 h-11 shrink-0 rounded-full flex items-center justify-center text-white transition-all duration-200 transform group-hover:scale-110 shadow-md"
          style={{ backgroundColor: product.theme.buttonBg }}
        >
          <ArrowRight className="w-5 h-5 stroke-[2.5] transition-transform duration-200 group-hover:translate-x-0.5" />
        </button>
      </div>
    </div>
  );
};
