import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingCart, Check, Sparkles, ShieldCheck } from 'lucide-react';
import { Product } from '../types';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 1200);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(price);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-2xl bg-white rounded-[28px] overflow-hidden shadow-2xl border border-white/40 animate-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Đóng"
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-gray-700 hover:text-black flex items-center justify-center shadow-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="overflow-y-auto p-6 sm:p-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8 items-center">
            {/* Left: Product Artwork Container */}
            <div
              className="rounded-[22px] p-5 flex items-center justify-center relative overflow-hidden shadow-inner"
              style={{ background: product.theme.cardGradient }}
            >
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-auto max-h-[300px] object-contain drop-shadow-xl"
              />
              <div className="absolute top-3 left-3 px-3 py-1 bg-white/90 backdrop-blur-xs rounded-full text-xs font-bold text-[#1A211A] shadow-xs flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-[#FF8909]" />
                <span>{product.volume}</span>
              </div>
            </div>

            {/* Right: Info & Nutrition */}
            <div className="flex flex-col">
              <span
                className="text-xs font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-full w-fit mb-2"
                style={{
                  backgroundColor: product.theme.secondary,
                  color: product.theme.primary,
                }}
              >
                {product.theme.badge}
              </span>

              <h3 className="text-2xl sm:text-3xl font-black text-[#1A211A] leading-tight">
                {product.name}
              </h3>
              <p className="text-sm font-semibold text-[#5B6B5B] mt-0.5">
                {product.flavor}
              </p>

              <div className="text-2xl font-black text-[#FF8909] mt-3">
                {formatPrice(product.price)}
              </div>

              <p className="text-[13.5px] text-[#556355] mt-3 leading-relaxed">
                {product.description}
              </p>

              {/* Nutrition Snapshot */}
              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-gray-100 text-center">
                <div className="bg-[#F8FAF7] p-2 rounded-xl">
                  <div className="text-[11px] text-gray-500 font-medium">Năng lượng</div>
                  <div className="text-[13px] font-bold text-[#1A211A]">{product.nutrition.calories}</div>
                </div>
                <div className="bg-[#F8FAF7] p-2 rounded-xl">
                  <div className="text-[11px] text-gray-500 font-medium">Vitamin C</div>
                  <div className="text-[13px] font-bold text-[#218D28]">{product.nutrition.vitaminC}</div>
                </div>
                <div className="bg-[#F8FAF7] p-2 rounded-xl">
                  <div className="text-[11px] text-gray-500 font-medium">Đường tự nhiên</div>
                  <div className="text-[13px] font-bold text-[#1A211A]">{product.nutrition.sugar}</div>
                </div>
              </div>

              {/* Ingredients list */}
              <div className="mt-4">
                <div className="text-xs font-bold text-gray-700 flex items-center gap-1 mb-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#218D28]" />
                  <span>Thành phần chọn lọc:</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {product.ingredients.map((ing, i) => (
                    <span
                      key={i}
                      className="text-[11.5px] bg-[#EAF8E8] text-[#1E7724] px-2.5 py-0.5 rounded-full font-medium"
                    >
                      {ing}
                    </span>
                  ))}
                </div>
              </div>

              {/* Quantity selector & Add to Cart button */}
              <div className="mt-6 flex items-center gap-3">
                <div className="flex items-center border border-gray-200 rounded-full bg-gray-50 p-1">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-gray-600 hover:bg-white hover:shadow-xs transition-colors"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-8 text-center font-bold text-sm text-[#1A211A]">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-gray-600 hover:bg-white hover:shadow-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={handleAdd}
                  disabled={added}
                  className={`flex-1 py-3 px-5 rounded-full font-bold text-[14px] flex items-center justify-center gap-2 shadow-md transition-all duration-200 ${
                    added
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#FF8909] hover:bg-[#F37B03] text-white hover:shadow-lg'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Đã thêm vào giỏ!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4 stroke-[2.5]" />
                      <span>Thêm vào giỏ • {formatPrice(product.price * quantity)}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
