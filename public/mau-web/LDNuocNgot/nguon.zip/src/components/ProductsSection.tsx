import React from 'react';
import { Leaf } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { Product } from '../types';

interface ProductsSectionProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
}) => {
  return (
    <section id="products" className="py-12 sm:py-16 lg:py-20 max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
        <div className="inline-flex items-center gap-1.5 text-[#218D28] font-bold text-sm tracking-wide mb-2">
          <Leaf className="w-4 h-4 fill-[#218D28]" />
          <span>Sản phẩm</span>
        </div>
        <h2 className="text-[#1A211A] text-2xl sm:text-3xl lg:text-[38px] font-black tracking-tight leading-tight">
          Bộ sưu tập hương vị tươi mát
        </h2>
        <p className="mt-3 text-[#586558] text-[15px] sm:text-[16px] leading-relaxed">
          Khám phá các hương vị trái cây tự nhiên, mang đến trải nghiệm tuyệt vời cho mọi khẩu vị.
        </p>
      </div>

      {/* 3 Flavors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onSelect={onSelectProduct}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>
    </section>
  );
};
