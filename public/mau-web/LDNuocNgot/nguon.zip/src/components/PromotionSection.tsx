import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';

export const PromotionSection: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) {
      setErrorMessage('Vui lòng nhập họ và tên của bạn.');
      return;
    }
    if (!formData.email.trim() || !formData.email.includes('@')) {
      setErrorMessage('Vui lòng nhập địa chỉ email hợp lệ.');
      return;
    }

    // Save to LocalStorage
    try {
      const existing = JSON.parse(
        localStorage.getItem('zest_promotion_signups') || '[]'
      );
      existing.push({
        ...formData,
        date: new Date().toISOString(),
        coupon: 'ZESTBERRY20',
      });
      localStorage.setItem('zest_promotion_signups', JSON.stringify(existing));
    } catch {
      // LocalStorage fallback
    }

    setSubmitted(true);
    setErrorMessage('');
  };

  const scrollToForm = () => {
    const input = document.getElementById('promo-name-input');
    if (input) {
      input.focus();
    }
  };

  return (
    <section className="py-8 sm:py-12 max-w-[1360px] mx-auto px-3 sm:px-6 lg:px-8">
      {/* Pink Promotion Banner Container */}
      <div className="relative rounded-[28px] sm:rounded-[36px] overflow-hidden bg-gradient-to-r from-[#F56794] via-[#F86F9A] to-[#FFA1B9] text-white shadow-xl shadow-pink-900/10 min-h-[460px] flex flex-col justify-center">
        {/* Ambient Glows */}
        <div className="absolute top-0 right-1/4 w-[450px] h-[450px] bg-white/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-[350px] h-[350px] bg-rose-700/25 rounded-full blur-3xl pointer-events-none" />

        {/* Dynamic Background / Center Artwork */}
        <div className="absolute inset-0 z-0 flex items-center justify-center opacity-70 lg:opacity-85 mix-blend-screen pointer-events-none overflow-hidden">
          <img
            src="./assets/berry-promotion-composite.jpg"
            alt="Ưu đãi nước trái cây Berry Bliss"
            className="w-full h-full object-cover object-center scale-105"
          />
        </div>

        {/* Foreground Content Grid */}
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center p-6 sm:p-10 lg:p-12">
          {/* Left Column: Heading & Promo Info */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            {/* Tag */}
            <div className="flex items-center gap-3 mb-3">
              <span className="text-[12px] sm:text-[13px] font-bold tracking-[0.25em] text-white uppercase drop-shadow-sm">
                ƯU ĐÃI ĐẶC BIỆT
              </span>
              <div className="flex items-center text-white">
                <span className="w-10 sm:w-14 h-[1.5px] bg-white inline-block" />
                <span className="text-sm font-bold -ml-1">→</span>
              </div>
            </div>

            {/* Headline */}
            <h2 className="font-display font-black text-[38px] sm:text-[50px] lg:text-[58px] leading-[1.05] tracking-tight text-white drop-shadow-md">
              <div>Chọn hương vị</div>
              <div>Yêu cuộc sống</div>
            </h2>

            {/* Subtitle */}
            <p className="mt-4 text-white text-[16px] sm:text-[18px] font-semibold max-w-md drop-shadow leading-relaxed">
              Đăng ký ngay để nhận ưu đãi mới nhất từ Zest Citrus
            </p>

            {/* Quick Action Button */}
            <div className="mt-7">
              <button
                onClick={scrollToForm}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-white text-[#E93F68] hover:bg-rose-50 text-[14px] sm:text-[15px] font-bold rounded-full shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer"
              >
                <span>Đăng ký ngay</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Spacer / Center visual focus */}
          <div className="hidden lg:block lg:col-span-2" />

          {/* Right Column: Embedded Signup Form Card */}
          <div className="lg:col-span-4 w-full">
            <div className="bg-white/95 backdrop-blur-md rounded-[24px] p-6 sm:p-7 shadow-2xl text-[#1A211A] border border-white/60">
              {submitted ? (
                <div className="py-6 text-center animate-in zoom-in-95 duration-200">
                  <div className="w-14 h-14 bg-emerald-100 text-[#218D28] rounded-full flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-[#1A211A]">Đăng ký thành công!</h3>
                  <p className="text-sm text-[#5C685C] mt-2 leading-relaxed">
                    Mã ưu đãi giảm 20% cho đơn hàng đầu tiên của bạn:
                  </p>
                  <div className="mt-3.5 px-4 py-2 bg-pink-50 border border-pink-200 rounded-xl inline-flex items-center gap-2 text-pink-700 font-mono font-bold text-base">
                    <Sparkles className="w-4 h-4" />
                    <span>ZESTBERRY20</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-3">
                    Mã đã được lưu và tự động áp dụng khi thanh toán.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="mt-4 text-xs font-semibold text-[#E93F68] hover:underline"
                  >
                    Đăng ký cho email khác
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
                  <h3 className="text-[19px] sm:text-[21px] font-black text-[#1A211A] mb-1">
                    Nhận ưu đãi độc quyền
                  </h3>

                  {errorMessage && (
                    <div className="text-xs font-semibold text-rose-600 bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                      {errorMessage}
                    </div>
                  )}

                  <div>
                    <input
                      id="promo-name-input"
                      type="text"
                      placeholder="Họ và tên"
                      value={formData.fullName}
                      onChange={(e) =>
                        setFormData({ ...formData, fullName: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-[#F8FAF6] border border-[#E2E8DE] focus:border-[#FF8909] focus:bg-white rounded-[14px] text-[14px] text-[#1A211A] placeholder:text-[#9AA69A] outline-none transition-all"
                    />
                  </div>

                  <div>
                    <input
                      type="email"
                      placeholder="Email của bạn"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-[#F8FAF6] border border-[#E2E8DE] focus:border-[#FF8909] focus:bg-white rounded-[14px] text-[14px] text-[#1A211A] placeholder:text-[#9AA69A] outline-none transition-all"
                    />
                  </div>

                  <div>
                    <input
                      type="tel"
                      placeholder="Số điện thoại (tùy chọn)"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="w-full px-4 py-3 bg-[#F8FAF6] border border-[#E2E8DE] focus:border-[#FF8909] focus:bg-white rounded-[14px] text-[14px] text-[#1A211A] placeholder:text-[#9AA69A] outline-none transition-all"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full mt-2 py-3.5 bg-[#FF8909] hover:bg-[#F37B03] text-white font-bold text-[15px] rounded-[14px] shadow-md hover:shadow-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Đăng ký ngay</span>
                    <ArrowRight className="w-4 h-4 stroke-[2.5]" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
