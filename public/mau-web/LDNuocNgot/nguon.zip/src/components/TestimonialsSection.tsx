import React from 'react';
import { Leaf, Star } from 'lucide-react';
import { Review } from '../types';

interface TestimonialsSectionProps {
  reviews: Review[];
}

export const TestimonialsSection: React.FC<TestimonialsSectionProps> = ({
  reviews,
}) => {
  return (
    <section className="py-12 sm:py-16 lg:py-20 max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
        <div className="inline-flex items-center gap-1.5 text-[#218D28] font-bold text-sm tracking-wide mb-2">
          <Leaf className="w-4 h-4 fill-[#218D28]" />
          <span>Khách hàng nói gì?</span>
        </div>
        <p className="text-[#5B675B] text-[15px] sm:text-[16px] font-medium">
          Hàng ngàn khách hàng đã lựa chọn và yêu thích Zest Citrus
        </p>
      </div>

      {/* 3 Reviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
        {reviews.map((rev) => (
          <div
            key={rev.id}
            className="bg-white rounded-[22px] p-6 sm:p-7 shadow-[0_8px_24px_rgba(33,70,30,0.06)] border border-[#EDF2EB] flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_12px_32px_rgba(33,70,30,0.1)]"
          >
            {/* Top row: Avatar + Quote text */}
            <div className="flex items-start gap-4 mb-5">
              <img
                src={rev.image}
                alt={rev.name}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-full object-cover shrink-0 ring-2 ring-[#EAF8E8] shadow-xs"
              />
              <p className="text-[#3F4B3F] text-[13.5px] sm:text-[14px] leading-relaxed italic">
                “{rev.content}”
              </p>
            </div>

            {/* Bottom row: Name + Stars */}
            <div className="pt-2 border-t border-gray-50 flex flex-col items-start">
              <span className="font-bold text-[15px] text-[#1A211A]">
                {rev.name}
              </span>
              <div className="flex items-center gap-1 mt-1 text-[#FF9200]">
                {[...Array(rev.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-[#FF9200] stroke-none"
                  />
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
