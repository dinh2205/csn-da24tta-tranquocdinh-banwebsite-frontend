import React from 'react';
import { X, Sparkles, Volume2, Play } from 'lucide-react';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-3xl bg-[#141E14] rounded-[28px] overflow-hidden shadow-2xl border border-white/20 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Đóng video"
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center shadow-lg transition-colors border border-white/20"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Video Canvas / Showcase Player */}
        <div className="relative aspect-video w-full bg-gradient-to-tr from-green-950 via-emerald-900 to-amber-900 flex items-center justify-center overflow-hidden">
          {/* Simulated Brand Cinematic Video Loop / Preview */}
          <div className="absolute inset-0">
            <img
              src="./assets/hero-citrus-composite.jpg"
              alt="Video quảng cáo Zest Citrus"
              className="w-full h-full object-cover opacity-60 scale-105 animate-pulse"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/50" />
          </div>

          {/* Central Play / Branding Overlay */}
          <div className="relative z-10 text-center text-white px-6">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#FF8909] to-[#FFB74D] flex items-center justify-center mx-auto mb-4 shadow-xl cursor-pointer hover:scale-110 transition-transform">
              <Play className="w-8 h-8 fill-white ml-1 text-white" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold text-amber-300 mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Hành trình tươi mát 100% tự nhiên</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-black font-display tracking-tight">
              Zest Citrus – Đánh thức mọi giác quan
            </h3>
            <p className="text-sm text-gray-300 mt-2 max-w-md mx-auto">
              Từ nông trại trù phú đến lon nước giải khát thơm lừng vị cam bưởi nguyên bản.
            </p>
          </div>

          {/* Bottom Control Bar */}
          <div className="absolute bottom-4 left-6 right-6 flex items-center justify-between text-xs text-white/80 bg-black/40 backdrop-blur-md px-4 py-2.5 rounded-full border border-white/10">
            <div className="flex items-center gap-3">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span className="font-semibold">0:45 / 1:30 • Full HD 1080p</span>
            </div>
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4" />
              <span>Âm thanh sống động</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
