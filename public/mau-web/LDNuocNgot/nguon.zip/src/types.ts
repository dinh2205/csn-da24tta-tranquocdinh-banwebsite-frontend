export interface Product {
  id: string;
  name: string;
  flavor: string;
  shortDescription: string;
  tagline: string;
  description: string;
  image: string;
  heroImage?: string;
  theme: {
    primary: string;
    buttonBg: string;
    secondary: string;
    background: string;
    cardGradient: string;
    badge: string;
  };
  price: number;
  volume: string;
  ingredients: string[];
  nutrition: {
    calories: string;
    vitaminC: string;
    sugar: string;
    [key: string]: string | undefined;
  };
}

export interface Review {
  id: string;
  name: string;
  role: string;
  image: string;
  rating: number;
  content: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
