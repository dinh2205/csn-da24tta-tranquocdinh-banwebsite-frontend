import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { BrandStrip } from './components/BrandStrip';
import { AboutSection } from './components/AboutSection';
import { RecentProjects } from './components/RecentProjects';
import { ServicesSection } from './components/ServicesSection';
import { SkillsSection } from './components/SkillsSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import { AllProjectsModal } from './components/AllProjectsModal';
import { ServiceModal } from './components/ServiceModal';
import { ContactModal } from './components/ContactModal';
import { BookingModal } from './components/BookingModal';
import { AssetNoticeModal } from './components/AssetNoticeModal';
import { Project, Service, portfolioData } from './data/portfolioData';
import { ArrowUp, Sparkles } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');

  // Modals state
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isAllProjectsOpen, setIsAllProjectsOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [contactSubject, setContactSubject] = useState('');
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isAssetNoticeOpen, setIsAssetNoticeOpen] = useState(false);

  // Custom portrait image URLs (with localStorage persistence)
  const [customHeroUrl, setCustomHeroUrl] = useState<string | null>(() => {
    return localStorage.getItem('nova_custom_hero_url') || null;
  });
  const [customAboutUrl, setCustomAboutUrl] = useState<string | null>(() => {
    return localStorage.getItem('nova_custom_about_url') || null;
  });

  const [showFloatingTop, setShowFloatingTop] = useState(false);

  // Sync custom image URLs to localStorage
  const handleUpdateHeroUrl = (url: string | null) => {
    setCustomHeroUrl(url);
    if (url) {
      localStorage.setItem('nova_custom_hero_url', url);
    } else {
      localStorage.removeItem('nova_custom_hero_url');
    }
  };

  const handleUpdateAboutUrl = (url: string | null) => {
    setCustomAboutUrl(url);
    if (url) {
      localStorage.setItem('nova_custom_about_url', url);
    } else {
      localStorage.removeItem('nova_custom_about_url');
    }
  };

  // Scroll spy to highlight active header navigation item
  useEffect(() => {
    const sectionIds = ['home', 'about', 'projects', 'services', 'contact'];
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;
      setShowFloatingTop(window.scrollY > 400);

      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const el = document.getElementById(sectionIds[i]);
        if (el) {
          const top = el.offsetTop;
          if (scrollPosition >= top) {
            setActiveSection(sectionIds[i]);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenContactWithTopic = (topic: string) => {
    setContactSubject(`Trao đổi về: ${topic}`);
    setIsContactOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#031426] text-[#F5F9FF] font-['Inter',sans-serif] selection:bg-[#168FFF] selection:text-white flex flex-col relative">
      {/* 1. Header (Sticky) */}
      <Header
        activeSection={activeSection}
        onOpenContact={() => {
          setContactSubject('Kết nối ngay - Cơ hội hợp tác');
          setIsContactOpen(true);
        }}
        onOpenAssetNotice={() => setIsAssetNoticeOpen(true)}
      />

      {/* Main Content Sections strictly in order */}
      <main className="flex-1 w-full">
        {/* 2. Hero Section */}
        <HeroSection
          customHeroUrl={customHeroUrl}
          onOpenContact={() => {
            setContactSubject('Cùng nhau hợp tác');
            setIsContactOpen(true);
          }}
        />

        {/* 3. Trusted By Amazing Brands */}
        <BrandStrip />

        {/* 4. About Me */}
        <AboutSection
          customAboutUrl={customAboutUrl}
          onOpenContact={() => {
            setContactSubject('Đồng hành dự án thiết kế');
            setIsContactOpen(true);
          }}
        />

        {/* 5. Recent Projects */}
        <RecentProjects
          onOpenProjectModal={(project) => setSelectedProject(project)}
          onOpenAllProjects={() => setIsAllProjectsOpen(true)}
        />

        {/* 6. My Services */}
        <ServicesSection
          onOpenServiceModal={(service) => setSelectedService(service)}
        />

        {/* 7. Tools & Skills */}
        <SkillsSection />

        {/* 8. Client Testimonials */}
        <TestimonialsSection />

        {/* 9. Contact CTA */}
        <ContactSection
          onOpenEmail={() => {
            setContactSubject('Yêu cầu tư vấn dự án mới');
            setIsContactOpen(true);
          }}
          onOpenBooking={() => setIsBookingOpen(true)}
        />
      </main>

      {/* 10. Footer */}
      <Footer />

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-center gap-3">
        {/* Floating Asset Manifest / Customizer Tooltip Button */}
        <button
          onClick={() => setIsAssetNoticeOpen(true)}
          className="group relative px-3.5 py-2 bg-[#062441]/90 hover:bg-[#0A335C] border border-[#168FFF]/50 hover:border-[#168FFF] text-white text-xs font-semibold rounded-full shadow-xl backdrop-blur-md flex items-center gap-2 transition-all hover:scale-105"
          title="Tài nguyên giao diện & Tùy biến"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#43B4FF]" />
          <span className="hidden sm:inline">Tài nguyên giao diện</span>
        </button>

        {/* Floating Back to Top Button */}
        {showFloatingTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            aria-label="Cuộn lên đầu trang"
            className="w-10 h-10 rounded-full bg-[#168FFF] hover:bg-[#0875E4] text-white flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95 animate-in fade-in"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Interactive Modals */}
      {/* 1. Project Details Modal with Lightbox */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onOpenContact={handleOpenContactWithTopic}
      />

      {/* 2. All Projects Gallery Modal with Filters */}
      <AllProjectsModal
        isOpen={isAllProjectsOpen}
        onClose={() => setIsAllProjectsOpen(false)}
        projects={portfolioData.projects}
        onSelectProject={(project) => setSelectedProject(project)}
      />

      {/* 3. Service Scope Details Modal */}
      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onOpenContact={handleOpenContactWithTopic}
      />

      {/* 4. Contact Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
        initialSubject={contactSubject}
      />

      {/* 5. Booking Modal */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
      />

      {/* 6. Asset Notice & Live Customizer Modal */}
      <AssetNoticeModal
        isOpen={isAssetNoticeOpen}
        onClose={() => setIsAssetNoticeOpen(false)}
        customHeroUrl={customHeroUrl}
        customAboutUrl={customAboutUrl}
        onUpdateHeroUrl={handleUpdateHeroUrl}
        onUpdateAboutUrl={handleUpdateAboutUrl}
      />
    </div>
  );
}
