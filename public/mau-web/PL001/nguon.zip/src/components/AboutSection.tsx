import React, { useState } from 'react';
import { portfolioData } from '../data/portfolioData';
import { NovaPortrait } from './NovaPortrait';
import { BlueSphere, DotPattern, RadialSunburst, ConcentricCircleBadge } from './SpheresAndDecorations';
import { ArrowRight, CheckCircle2, X } from 'lucide-react';

interface AboutSectionProps {
  customAboutUrl?: string | null;
  onOpenContact: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({
  customAboutUrl,
  onOpenContact,
}) => {
  const { about } = portfolioData;
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  return (
    <section id="about" className="relative py-20 lg:py-28 bg-[#031426] overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/2 -right-40 w-[500px] h-[500px] rounded-full bg-[#168FFF]/10 blur-3xl pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-16">
          {/* Left Column: Framed Portrait & Floating Quote */}
          <div className="w-full lg:w-[46%] flex justify-center relative">
            {/* Background Sunburst Lines radiating at the bottom-left */}
            <div className="absolute -bottom-16 -left-16 z-0 pointer-events-none opacity-80">
              <RadialSunburst size={320} />
            </div>

            {/* Dotted Pattern in upper-left corner */}
            <div className="absolute -top-6 -left-6 z-0 hidden sm:block pointer-events-none">
              <DotPattern rows={5} cols={5} gap={14} />
            </div>

            {/* 3D Floating Blue Sphere */}
            <div className="absolute -top-4 -right-4 z-20">
              <BlueSphere size={48} />
            </div>

            {/* Portrait Container Frame (380x400 standard) */}
            <div className="relative z-10 w-full max-w-[380px] h-[400px] sm:h-[420px] rounded-[24px] bg-gradient-to-b from-[#13385E] to-[#0A2645] border-2 border-[#1C6595]/80 shadow-[0_12px_36px_rgba(2,14,28,0.7)] p-2 overflow-hidden flex items-end justify-center">
              <NovaPortrait
                type="about"
                customUrl={customAboutUrl}
                className="w-full h-full object-cover rounded-[20px]"
              />
            </div>

            {/* Floating Quote Card on the left side */}
            <div className="absolute -bottom-6 -left-4 sm:-left-8 z-20 max-w-[230px] bg-[#0B2541]/95 backdrop-blur-md border border-[#1F5484] rounded-xl p-3.5 shadow-2xl">
              <p className="text-xs sm:text-[13px] font-medium text-[#E2ECF6] leading-snug italic">
                {about.quote}
              </p>
            </div>
          </div>

          {/* Right Column: Bio & Statistics */}
          <div className="w-full lg:w-[54%] space-y-6">
            {/* Top Row with Eyebrow and Concentric Circle Badge */}
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[#43B4FF] text-xs sm:text-sm font-bold tracking-[2px] uppercase block mb-2">
                  {about.eyebrow}
                </span>
                <h2 className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl lg:text-[34px] leading-tight text-white tracking-tight uppercase">
                  {about.title}
                </h2>
              </div>

              {/* Concentric Target Badge */}
              <div className="hidden sm:block shrink-0 ml-4">
                <ConcentricCircleBadge size={80} />
              </div>
            </div>

            {/* Paragraph Bio */}
            <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
              {about.bio}
            </p>

            {/* 4 Statistics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-3">
              {about.statistics.map((stat, idx) => (
                <div
                  key={idx}
                  className="p-3.5 bg-[#071F39] rounded-xl border border-[#163D62] text-left hover:border-[#168FFF]/50 transition-colors"
                >
                  <div className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl text-white tracking-tight">
                    {stat.value}
                  </div>
                  <div className="text-[11px] sm:text-xs text-[#8299B3] font-medium mt-1 leading-snug">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

            {/* Action Button: "Tìm hiểu thêm →" */}
            <div className="pt-2">
              <button
                onClick={() => setShowDetailsModal(true)}
                className="inline-flex items-center gap-2.5 px-7 py-3 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs sm:text-sm font-bold rounded-full shadow-[0_4px_16px_rgba(22,143,255,0.35)] hover:shadow-[0_6px_22px_rgba(22,143,255,0.5)] active:scale-95 transition-all duration-200 group"
              >
                <span>Tìm hiểu thêm</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* More About Me Details Modal */}
      {showDetailsModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
          onClick={() => setShowDetailsModal(false)}
        >
          <div
            className="relative w-full max-w-xl bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl p-6 sm:p-8 space-y-5 text-[#F5F9FF]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#163D62] pb-4">
              <h3 className="font-['Montserrat',sans-serif] font-bold text-xl text-white">
                Về nhà thiết kế Nova Lee
              </h3>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="w-8 h-8 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-[#A8B9CD] leading-relaxed">
              {about.extendedBio}
            </p>

            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#43B4FF]">
                Năng lực & Phương pháp chuyên môn
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#BACCE0]">
                {about.skillsSummary.map((skill, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 bg-[#0A2645] rounded-lg">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#34D399] shrink-0" />
                    <span>{skill}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-between items-center border-t border-[#163D62]">
              <button
                onClick={() => setShowDetailsModal(false)}
                className="text-xs text-[#8299B3] hover:text-white"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  setShowDetailsModal(false);
                  onOpenContact();
                }}
                className="px-5 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all"
              >
                Liên hệ trực tiếp với Nova
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
