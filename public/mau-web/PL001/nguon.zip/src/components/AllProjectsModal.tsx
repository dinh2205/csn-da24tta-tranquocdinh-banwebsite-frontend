import React, { useState } from 'react';
import { Project } from '../data/portfolioData';
import { ProjectCard } from './ProjectCard';
import { X, Filter } from 'lucide-react';

interface AllProjectsModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  onSelectProject: (project: Project) => void;
}

export const AllProjectsModal: React.FC<AllProjectsModalProps> = ({
  isOpen,
  onClose,
  projects,
  onSelectProject,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('Tất cả');

  if (!isOpen) return null;

  const categories = [
    { label: 'Tất cả', value: 'all' },
    { label: 'Ứng dụng di động', value: 'mobile' },
    { label: 'Website', value: 'website' },
    { label: 'Design System', value: 'design system' },
  ];

  const filteredProjects = activeCategory === 'Tất cả'
    ? projects
    : projects.filter(p => {
        const cat = categories.find(c => c.label === activeCategory)?.value || '';
        return p.platform.toLowerCase().includes(cat) || p.title.toLowerCase().includes(cat);
      });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-6xl bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-6 py-5 border-b border-[#163D62] bg-[#041629] gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#43B4FF]">Tuyển tập dự án</span>
            <h2 className="font-['Montserrat',sans-serif] font-extrabold text-2xl text-white tracking-tight">
              Toàn Bộ Dự Án Portfolio ({projects.length})
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Filter Pills */}
            <div className="flex items-center gap-1.5 p-1 bg-[#0A2645] rounded-full border border-[#163D62] overflow-x-auto">
              <span className="pl-2 pr-1 text-[#8299B3]">
                <Filter className="w-3.5 h-3.5" />
              </span>
              {categories.map((cat) => (
                <button
                  key={cat.label}
                  onClick={() => setActiveCategory(cat.label)}
                  className={`px-3.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    activeCategory === cat.label
                      ? 'bg-[#168FFF] text-white shadow-md'
                      : 'text-[#A8B9CD] hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors shrink-0"
              aria-label="Đóng"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Project Grid */}
        <div className="p-6 sm:p-8 overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((proj) => (
              <ProjectCard
                key={proj.id}
                project={proj}
                onOpenDetails={(p) => {
                  onClose();
                  onSelectProject(p);
                }}
              />
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-16 text-[#8299B3]">
              <p>Không tìm thấy dự án nào trong danh mục này.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#163D62] bg-[#041629] flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all shadow-md"
          >
            Đóng danh mục
          </button>
        </div>
      </div>
    </div>
  );
};
