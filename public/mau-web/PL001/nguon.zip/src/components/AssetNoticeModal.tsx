import React, { useState } from 'react';
import { portfolioData } from '../data/portfolioData';
import { X, Image as ImageIcon, AlertCircle, Upload, Check, RefreshCw } from 'lucide-react';

interface AssetNoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
  customHeroUrl: string | null;
  customAboutUrl: string | null;
  onUpdateHeroUrl: (url: string | null) => void;
  onUpdateAboutUrl: (url: string | null) => void;
}

export const AssetNoticeModal: React.FC<AssetNoticeModalProps> = ({
  isOpen,
  onClose,
  customHeroUrl,
  customAboutUrl,
  onUpdateHeroUrl,
  onUpdateAboutUrl,
}) => {
  const [heroInput, setHeroInput] = useState(customHeroUrl || '');
  const [aboutInput, setAboutInput] = useState(customAboutUrl || '');
  const [savedMessage, setSavedMessage] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateHeroUrl(heroInput.trim() ? heroInput.trim() : null);
    onUpdateAboutUrl(aboutInput.trim() ? aboutInput.trim() : null);
    setSavedMessage(true);
    setTimeout(() => setSavedMessage(false), 2500);
  };

  const handleResetToVector = () => {
    setHeroInput('');
    setAboutInput('');
    onUpdateHeroUrl(null);
    onUpdateAboutUrl(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'hero' | 'about') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        if (target === 'hero') {
          setHeroInput(base64);
          onUpdateHeroUrl(base64);
        } else {
          setAboutInput(base64);
          onUpdateAboutUrl(base64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#163D62] bg-[#041629]">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-[#168FFF] text-white flex items-center justify-center">
              <ImageIcon className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-['Montserrat',sans-serif] font-bold text-base text-white">
                Danh Mục Tài Nguyên & Tùy Biến Giao Diện
              </h3>
              <p className="text-[11px] text-[#8299B3]">Đảm bảo chuẩn xác quy cách kích thước và tỷ lệ hiển thị</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Missing Assets Status Banner */}
          <div className="p-4 bg-[#0A2645] rounded-xl border border-[#164166] flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#43B4FF] shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="font-bold text-white uppercase tracking-wider">Thông báo tài nguyên (Nguyên tắc 4)</div>
              <p className="text-[#A8B9CD] leading-relaxed">
                Theo yêu cầu, hệ thống nhận được ảnh chụp toàn trang tham chiếu duy nhất. Nhằm tránh việc thay thế người mẫu khác ngoài ý muốn, chân dung Nova Lee và các mockup dự án đã được kết xuất đồ họa vector độ nét cao bám sát từng đặc điểm (đeo kính, tóc búi nhỏ, áo hoodie trắng) và tỷ lệ 16:10.
              </p>
            </div>
          </div>

          {/* Missing Assets Table */}
          <div>
            <h4 className="font-['Montserrat',sans-serif] font-bold text-xs uppercase tracking-wider text-[#43B4FF] mb-3">
              Danh Sách Tài Nguyên & Quy Chuẩn Kích Thước
            </h4>
            <div className="space-y-2.5">
              {portfolioData.missingAssets.map((asset) => (
                <div
                  key={asset.id}
                  className="p-3 bg-[#081F38] rounded-lg border border-[#153D64] text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="pr-2">
                    <div className="font-bold text-white">{asset.name}</div>
                    <div className="text-[11px] text-[#8299B3] mt-0.5">{asset.spec}</div>
                  </div>
                  <div className="shrink-0 text-[10px] px-2.5 py-1 rounded bg-[#0E2D4F] text-[#43B4FF] border border-[#194E7E]">
                    {asset.recommendedResolution}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Image URL / Upload inputs */}
          <div className="p-4 bg-[#081F38] rounded-xl border border-[#163D62] space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-['Montserrat',sans-serif] font-bold text-xs uppercase tracking-wider text-white">
                Thay Thế Ảnh Trực Tiếp (Tùy Chọn)
              </h4>
              <button
                type="button"
                onClick={handleResetToVector}
                className="text-[11px] text-[#43B4FF] hover:underline flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Khôi phục đồ họa Vector mặc định</span>
              </button>
            </div>

            {/* Hero portrait input */}
            <div className="space-y-1.5">
              <label className="text-xs text-[#A8B9CD] font-medium flex items-center justify-between">
                <span>Chân dung Hero (Đường dẫn URL hoặc Tải tệp lên)</span>
                <span className="text-[10px] text-[#8299B3]">Nên dùng PNG nền trong suốt</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Dán https://.../nova-hero.png"
                  value={heroInput}
                  onChange={(e) => setHeroInput(e.target.value)}
                  className="flex-1 px-3 py-2 bg-[#05172A] border border-[#163D62] rounded-lg text-xs text-white placeholder-[#4E6B8C] focus:outline-none focus:border-[#168FFF]"
                />
                <label className="px-3 py-2 bg-[#0E2F52] hover:bg-[#16416E] border border-[#1A4C7A] text-xs text-white font-medium rounded-lg cursor-pointer flex items-center gap-1.5 shrink-0">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Tải tệp</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'hero')}
                  />
                </label>
              </div>
            </div>

            {/* About portrait input */}
            <div className="space-y-1.5">
              <label className="text-xs text-[#A8B9CD] font-medium flex items-center justify-between">
                <span>Chân dung About Me (Đường dẫn URL hoặc Tải tệp lên)</span>
                <span className="text-[10px] text-[#8299B3]">Khung tỷ lệ 380x400</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Dán https://.../nova-about.png"
                  value={aboutInput}
                  onChange={(e) => setAboutInput(e.target.value)}
                  className="flex-1 px-3 py-2 bg-[#05172A] border border-[#163D62] rounded-lg text-xs text-white placeholder-[#4E6B8C] focus:outline-none focus:border-[#168FFF]"
                />
                <label className="px-3 py-2 bg-[#0E2F52] hover:bg-[#16416E] border border-[#1A4C7A] text-xs text-white font-medium rounded-lg cursor-pointer flex items-center gap-1.5 shrink-0">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Tải tệp</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileUpload(e, 'about')}
                  />
                </label>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              {savedMessage ? (
                <span className="text-xs text-[#34D399] flex items-center gap-1 font-semibold">
                  <Check className="w-3.5 h-3.5" />
                  <span>Đã cập nhật hình ảnh thành công!</span>
                </span>
              ) : <div />}
              <button
                type="button"
                onClick={handleSave}
                className="px-5 py-2 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full shadow-md transition-all"
              >
                Áp dụng cài đặt hình ảnh
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#163D62] bg-[#041629] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#0E2D4F] hover:bg-[#153D66] text-[#BACCE0] text-xs font-semibold rounded-full transition-colors"
          >
            Đóng bảng quản lý
          </button>
        </div>
      </div>
    </div>
  );
};
