import React, { useState } from 'react';
import { X, Calendar as CalendarIcon, Clock, CheckCircle2, Video } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const [selectedDate, setSelectedDate] = useState<string>('tomorrow');
  const [selectedTime, setSelectedTime] = useState<string>('02:00 CH');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  const dates = [
    { id: 'today', label: 'Hôm nay', date: '17/10/2026' },
    { id: 'tomorrow', label: 'Ngày mai', date: '18/10/2026' },
    { id: 'monday', label: 'Thứ Hai', date: '20/10/2026' },
    { id: 'tuesday', label: 'Thứ Ba', date: '21/10/2026' },
  ];

  const timeSlots = [
    '10:00 SÁNG',
    '11:30 SÁNG',
    '02:00 CH',
    '03:30 CH',
    '05:00 CH',
  ];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmed(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#163D62] bg-[#041629]">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-[#168FFF] text-white flex items-center justify-center">
              <CalendarIcon className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-['Montserrat',sans-serif] font-bold text-lg text-white">
                Đặt Lịch Trao Đổi
              </h3>
              <p className="text-[11px] text-[#43B4FF]">Buổi tư vấn 1-1 kéo dài 30 phút qua Google Meet cùng Nova</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors"
            aria-label="Đóng"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {confirmed ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#10B981]/20 border border-[#10B981]/40 text-[#10B981] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="font-['Montserrat',sans-serif] font-bold text-xl text-white">
                Đã xếp lịch thành công!
              </h4>
              <p className="text-sm text-[#A8B9CD] max-w-sm mx-auto leading-relaxed">
                Thư mời lịch hẹn kèm liên kết Google Meet đã được chuẩn bị và gửi tới <strong className="text-white">{email}</strong> vào lúc <strong className="text-white">{selectedTime}</strong>.
              </p>
              <div className="p-3 bg-[#0A2542] rounded-xl border border-[#163D62] text-xs text-[#8299B3] flex items-center justify-center gap-2">
                <Video className="w-4 h-4 text-[#168FFF]" />
                <span>Đường link Google Meet sẽ có trong email xác nhận của bạn.</span>
              </div>
              <div className="pt-2">
                <button
                  onClick={() => {
                    setConfirmed(false);
                    onClose();
                  }}
                  className="px-6 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all"
                >
                  Hoàn tất
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleBooking} className="space-y-4">
              {/* Date selection */}
              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5 text-[#168FFF]" />
                  <span>Chọn ngày họp</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {dates.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => setSelectedDate(d.id)}
                      className={`p-2.5 rounded-xl border text-center transition-all ${
                        selectedDate === d.id
                          ? 'bg-[#168FFF] border-[#168FFF] text-white shadow-md'
                          : 'bg-[#0A2542] border-[#163D62] text-[#BACCE0] hover:border-[#1E5487]'
                      }`}
                    >
                      <div className="text-xs font-bold">{d.label}</div>
                      <div className="text-[10px] opacity-80">{d.date}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time selection */}
              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#168FFF]" />
                  <span>Chọn khung giờ (Múi giờ của bạn)</span>
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  {timeSlots.map((time) => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setSelectedTime(time)}
                      className={`py-2 px-1 rounded-lg text-xs font-semibold transition-all ${
                        selectedTime === time
                          ? 'bg-[#43B4FF] text-[#031426] font-bold shadow'
                          : 'bg-[#0A2542] border border-[#163D62] text-[#A8B9CD] hover:text-white'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              {/* User info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1">
                    Họ và tên *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ví dụ: Lê Tuấn Anh"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#0A2542] border border-[#163D62] rounded-xl text-xs text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1">
                    Email công việc *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="tuananh@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#0A2542] border border-[#163D62] rounded-xl text-xs text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF]"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-[#168FFF] hover:bg-[#0875E4] text-white font-bold text-xs rounded-full shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span>Xác nhận lịch trao đổi</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
