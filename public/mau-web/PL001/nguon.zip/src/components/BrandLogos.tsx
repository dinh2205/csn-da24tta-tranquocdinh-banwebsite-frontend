import React from 'react';

export const BrandLogos: React.FC = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 lg:gap-8 items-center justify-items-center">
      {/* 1. logoipsum */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="2.5" />
          <path d="M11 16C11 13.2386 13.2386 11 16 11C18.7614 11 21 13.2386 21 16C21 18.7614 18.7614 21 16 21" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="16" cy="16" r="2.5" fill="currentColor" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">logoipsum</span>
      </div>

      {/* 2. Spherule */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="16" cy="16" r="6" fill="currentColor" />
          <ellipse cx="16" cy="16" rx="14" ry="6" stroke="currentColor" strokeWidth="2" transform="rotate(-30 16 16)" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">Spherule</span>
      </div>

      {/* 3. Lightbox */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="5" y="5" width="22" height="22" rx="4" stroke="currentColor" strokeWidth="2.5" />
          <path d="M16 5V27M5 16H27" stroke="currentColor" strokeWidth="2" strokeDasharray="3 2" />
          <circle cx="16" cy="16" r="4" fill="#168FFF" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">Lightbox</span>
      </div>

      {/* 4. GlobalBank */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="16" cy="16" r="13" stroke="currentColor" strokeWidth="2.5" />
          <ellipse cx="16" cy="16" rx="6" ry="13" stroke="currentColor" strokeWidth="2" />
          <path d="M4 16H28" stroke="currentColor" strokeWidth="2" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">GlobalBank</span>
      </div>

      {/* 5. Nietzsche */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M7 25V7L25 25V7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">Nietzsche</span>
      </div>

      {/* 6. PixelHub */}
      <div className="flex items-center gap-2.5 text-[#BACCE0] hover:text-white transition-colors duration-200">
        <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Isometric cube with pixel notches */}
          <path d="M16 4L27 10.5V21.5L16 28L5 21.5V10.5L16 4Z" stroke="currentColor" strokeWidth="2" />
          <path d="M16 4V16M27 10.5L16 16M5 10.5L16 16M16 16V28" stroke="currentColor" strokeWidth="2" />
          <rect x="13.5" y="10" width="5" height="5" fill="#168FFF" />
        </svg>
        <span className="font-['Montserrat',sans-serif] font-bold text-base tracking-tight">PixelHub</span>
      </div>
    </div>
  );
};
