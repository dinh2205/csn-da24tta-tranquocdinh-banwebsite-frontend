import React from 'react';
import { BrandLogos } from './BrandLogos';

export const BrandStrip: React.FC = () => {
  return (
    <section className="relative z-10 py-10 bg-[#062441] border-y border-[#0E355C]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <h3 className="text-center text-[11px] sm:text-xs font-bold uppercase tracking-[2.5px] text-[#A8B9CD] mb-8">
          ĐƯỢC CÁC THƯƠNG HIỆU TIN TƯỞNG
        </h3>

        {/* 6 Aligned Brands */}
        <BrandLogos />
      </div>
    </section>
  );
};
