import React, { useState } from 'react';
import { X, Send, Mail, CheckCircle2 } from 'lucide-react';
import { portfolioData } from '../data/portfolioData';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSubject?: string;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  isOpen,
  onClose,
  initialSubject = '',
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState(initialSubject || 'Yêu cầu tư vấn dự án mới');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 800);
  };

  const mailtoLink = `mailto:${portfolioData.personal.email}?subject=${encodeURIComponent(
    subject
  )}&body=${encodeURIComponent(
    `Xin chào Nova,\n\nTôi tên là ${name || '[Tên của bạn]'}.\n\n${message || 'Tôi muốn thảo luận cùng bạn về một dự án thiết kế mới.'}`
  )}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#163D62] bg-[#041629]">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-lg bg-[#168FFF] text-white flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </span>
            <h3 className="font-['Montserrat',sans-serif] font-bold text-lg text-white">
              Gửi Email Cho Tôi
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors"
            aria-label="Đóng"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {isSuccess ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#10B981]/20 border border-[#10B981]/40 text-[#10B981] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="font-['Montserrat',sans-serif] font-bold text-xl text-white">
                Đã gửi tin nhắn thành công!
              </h4>
              <p className="text-sm text-[#A8B9CD] max-w-xs mx-auto">
                Cảm ơn bạn, {name || 'bạn'}! Tôi đã nhận được thư và sẽ liên hệ lại với bạn trong vòng 24 giờ.
              </p>
              <div className="pt-2">
                <button
                  onClick={() => {
                    setIsSuccess(false);
                    onClose();
                  }}
                  className="px-6 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all"
                >
                  Hoàn tất
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1.5">
                  Họ và tên của bạn *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Hoàng Minh"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#0A2542] border border-[#163D62] rounded-xl text-sm text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1.5">
                  Địa chỉ Email *
                </label>
                <input
                  type="email"
                  required
                  placeholder="hoangminh@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#0A2542] border border-[#163D62] rounded-xl text-sm text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1.5">
                  Chủ đề / Dự án
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#0A2542] border border-[#163D62] rounded-xl text-sm text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF] transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#A8B9CD] uppercase tracking-wider mb-1.5">
                  Nội dung trao đổi *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Hãy chia sẻ đôi nét về sản phẩm, kế hoạch triển khai hoặc phạm vi công việc dự kiến..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#0A2542] border border-[#163D62] rounded-xl text-sm text-white placeholder-[#5D7A9C] focus:outline-none focus:border-[#168FFF] transition-colors resize-none"
                />
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:flex-1 py-3 bg-[#168FFF] hover:bg-[#0875E4] disabled:opacity-50 text-white font-bold text-xs rounded-full shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Đang gửi...' : 'Gửi tin nhắn'}</span>
                </button>

                <a
                  href={mailtoLink}
                  className="w-full sm:w-auto px-4 py-3 bg-[#0A2645] hover:bg-[#103358] border border-[#163D62] text-xs font-semibold text-[#A8B9CD] hover:text-white rounded-full transition-colors text-center"
                >
                  Mở ứng dụng Mail
                </a>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
