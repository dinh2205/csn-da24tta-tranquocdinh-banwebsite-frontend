import React from 'react';
import { BlueSphere, DotPattern } from './SpheresAndDecorations';
import { Mail, Calendar as CalendarIcon, ArrowRight } from 'lucide-react';

interface ContactSectionProps {
  onOpenEmail: () => void;
  onOpenBooking: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  onOpenEmail,
  onOpenBooking,
}) => {
  return (
    <section id="contact" className="relative py-20 lg:py-28 overflow-hidden bg-gradient-to-r from-[#082D51] via-[#05203C] to-[#03162C] border-t border-[#133E67]">
      {/* 3D Blue Spheres on the left edge */}
      <div className="absolute -bottom-10 -left-10 z-0 pointer-events-none">
        <BlueSphere size={160} glow={true} />
      </div>
      <div className="absolute top-12 left-1/3 z-0 pointer-events-none hidden sm:block">
        <BlueSphere size={42} glow={false} />
      </div>

      {/* Blue Dot Matrix pattern on the right */}
      <div className="absolute top-1/2 right-12 -translate-y-1/2 z-0 hidden lg:block pointer-events-none opacity-40">
        <DotPattern rows={6} cols={6} gap={16} />
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10 lg:gap-14">
          {/* Left Column: Heading & Description */}
          <div className="w-full lg:w-[62%] space-y-4">
            <span className="text-[#43B4FF] text-xs sm:text-sm font-bold tracking-[2.5px] uppercase block">
              CÙNG NHAU HỢP TÁC
            </span>

            <h2 className="font-['Montserrat',sans-serif] font-black text-3xl sm:text-4xl lg:text-[44px] text-white tracking-tight leading-tight">
              Bạn đang có một dự án?
            </h2>

            <p className="font-['Montserrat',sans-serif] font-bold text-lg sm:text-xl text-[#82BFFF] tracking-tight">
              Hãy cùng nhau kiến tạo những sản phẩm tuyệt vời!
            </p>

            <p className="text-sm sm:text-base text-[#A8B9CD] max-w-xl leading-relaxed pt-1">
              Tôi luôn sẵn sàng đón nhận các dự án mới và những cơ hội hợp tác sáng tạo. Đừng ngần ngại liên hệ — tôi rất mong được lắng nghe về ý tưởng của bạn.
            </p>
          </div>

          {/* Right Column: 2 Call to Action Buttons */}
          <div className="w-full lg:w-[38%] flex flex-col items-stretch sm:items-center lg:items-end justify-center gap-3.5">
            {/* Primary Email Pill Button */}
            <button
              onClick={onOpenEmail}
              className="w-full sm:w-[280px] py-3.5 px-6 bg-[#168FFF] hover:bg-[#0875E4] text-white text-sm font-bold rounded-full shadow-[0_4px_20px_rgba(22,143,255,0.45)] hover:shadow-[0_6px_28px_rgba(22,143,255,0.6)] active:scale-95 transition-all duration-200 flex items-center justify-center gap-2.5 group"
            >
              <Mail className="w-4 h-4 shrink-0" />
              <span>Gửi email cho tôi</span>
              <ArrowRight className="w-4 h-4 shrink-0 transform group-hover:translate-x-1 transition-transform" />
            </button>

            {/* "hoặc" Divider */}
            <span className="text-xs font-semibold text-[#8299B3] uppercase tracking-wider text-center py-0.5">
              hoặc
            </span>

            {/* Outlined Booking Pill Button */}
            <button
              onClick={onOpenBooking}
              className="w-full sm:w-[280px] py-3.5 px-6 bg-[#04162B]/80 hover:bg-[#082240] border border-[#168FFF]/70 hover:border-[#168FFF] text-white text-sm font-semibold rounded-full shadow-md active:scale-95 transition-all duration-200 flex items-center justify-center gap-2.5"
            >
              <CalendarIcon className="w-4 h-4 text-[#43B4FF] shrink-0" />
              <span>Đặt lịch trao đổi</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
