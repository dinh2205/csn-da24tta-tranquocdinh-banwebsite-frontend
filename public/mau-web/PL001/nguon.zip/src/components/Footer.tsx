import React from 'react';
import { portfolioData } from '../data/portfolioData';
import { ArrowUp, Linkedin, Dribbble, Instagram, Github } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getSocialIcon = (name: string) => {
    switch (name.toLowerCase()) {
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'dribbble':
        return <Dribbble className="w-4 h-4" />;
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'github':
        return <Github className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const navLinks = [
    { label: 'Trang chủ', href: '#home' },
    { label: 'Giới thiệu', href: '#about' },
    { label: 'Dự án', href: '#projects' },
    { label: 'Dịch vụ', href: '#services' },
    { label: 'Liên hệ', href: '#contact' },
  ];

  return (
    <footer className="relative bg-[#020E1C] border-t border-[#09223D] text-[#BACCE0] pt-14 pb-8">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-10 border-b border-[#0A2645]">
          {/* Brand Info */}
          <div className="max-w-xs space-y-2.5">
            <a href="#home" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#168FFF] to-[#0A4B8A] flex items-center justify-center shadow-md">
                <span className="font-['Montserrat',sans-serif] font-black text-white text-lg tracking-tighter">
                  N
                </span>
              </div>
              <span className="font-['Montserrat',sans-serif] font-black text-xl tracking-wider text-white">
                NOVA
              </span>
            </a>
            <p className="text-xs text-[#8299B3] leading-relaxed">
              Thiết kế những trải nghiệm số cho một tương lai tốt đẹp hơn.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Liên kết nhanh
            </h4>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="text-[#8299B3] hover:text-[#43B4FF] transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Follow Me Social Links */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Mạng xã hội
            </h4>
            <div className="flex items-center gap-2.5">
              {portfolioData.personal.socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.name}
                  className="w-9 h-9 rounded-full bg-[#081F38] hover:bg-[#168FFF] border border-[#163D62] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-all duration-200 hover:scale-105"
                >
                  {getSocialIcon(social.name)}
                </a>
              ))}
            </div>
          </div>

          {/* Back To Top Button */}
          <div className="shrink-0 flex items-center">
            <button
              onClick={scrollToTop}
              aria-label="Cuộn lên đầu trang"
              className="w-11 h-11 rounded-full bg-[#0A2645] hover:bg-[#168FFF] border border-[#163D62] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-all duration-200 shadow-md group"
            >
              <ArrowUp className="w-5 h-5 transform group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#6B85A3] gap-2">
          <p>© 2026 NOVA. Bảo lưu mọi quyền.</p>
          <p className="text-[11px] text-[#4E6B8C]">
            Thiết kế chuẩn mực dành cho Portfolio UI/UX chuyên nghiệp
          </p>
        </div>
      </div>
    </footer>
  );
};
