import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X, Sparkles } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  onOpenContact: () => void;
  onOpenAssetNotice: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  onOpenContact,
  onOpenAssetNotice,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Trang chủ', href: '#home', id: 'home' },
    { label: 'Giới thiệu', href: '#about', id: 'about' },
    { label: 'Dự án', href: '#projects', id: 'projects' },
    { label: 'Dịch vụ', href: '#services', id: 'services' },
    { label: 'Liên hệ', href: '#contact', id: 'contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#031426]/95 backdrop-blur-md shadow-lg border-b border-[#163D62]/50 py-3.5'
          : 'bg-[#031426] py-5'
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a href="#home" className="flex items-center gap-2.5 group">
          {/* Stylized N Logo */}
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#168FFF] to-[#0A4B8A] flex items-center justify-center shadow-[0_0_15px_rgba(22,143,255,0.4)] group-hover:shadow-[0_0_20px_rgba(22,143,255,0.7)] transition-all">
            <span className="font-['Montserrat',sans-serif] font-black text-white text-lg tracking-tighter">
              N
            </span>
          </div>
          <span className="font-['Montserrat',sans-serif] font-black text-xl tracking-wider text-white">
            NOVA
          </span>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.id}
                href={link.href}
                className={`relative text-sm font-medium transition-colors duration-200 py-1 ${
                  isActive
                    ? 'text-white font-semibold'
                    : 'text-[#A8B9CD] hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#168FFF] rounded-full shadow-[0_0_8px_#168FFF]" />
                )}
              </a>
            );
          })}
        </nav>

        {/* Right CTA Actions */}
        <div className="hidden md:flex items-center gap-3">
          {/* Asset Info / Customizer button */}
          <button
            onClick={onOpenAssetNotice}
            title="Tùy biến & Quản lý tài nguyên giao diện"
            className="p-2 rounded-full bg-[#0A2645] hover:bg-[#113860] border border-[#163D62] text-[#8299B3] hover:text-[#43B4FF] transition-colors"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          {/* Let's Talk CTA */}
          <button
            onClick={onOpenContact}
            className="inline-flex items-center gap-1.5 px-6 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] active:scale-95 text-white text-sm font-semibold rounded-full shadow-[0_4px_16px_rgba(22,143,255,0.35)] hover:shadow-[0_6px_22px_rgba(22,143,255,0.5)] transition-all duration-200"
          >
            <span>Kết nối ngay</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            onClick={onOpenAssetNotice}
            title="Quản lý tài nguyên"
            className="p-2 rounded-full bg-[#0A2645] text-[#8299B3]"
          >
            <Sparkles className="w-4 h-4" />
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-[#0A2645] text-white hover:bg-[#113860] transition-colors"
            aria-label="Mở menu điều hướng"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#031426] border-b border-[#163D62] px-6 py-5 space-y-4 animate-in slide-in-from-top-4 duration-200 shadow-2xl">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`text-base font-medium py-1.5 ${
                  activeSection === link.id
                    ? 'text-[#168FFF] font-bold'
                    : 'text-[#A8B9CD] hover:text-white'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-2 border-t border-[#163D62]">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full py-3 bg-[#168FFF] hover:bg-[#0875E4] text-white font-semibold text-sm rounded-full shadow-lg flex items-center justify-center gap-2"
            >
              <span>Kết nối ngay</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
