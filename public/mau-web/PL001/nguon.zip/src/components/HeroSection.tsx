import React from 'react';
import { portfolioData } from '../data/portfolioData';
import { NovaPortrait } from './NovaPortrait';
import { BlueSphere, DotPattern, HeroGlowLines } from './SpheresAndDecorations';
import { ArrowRight, Linkedin, Dribbble, Instagram, Github } from 'lucide-react';

interface HeroSectionProps {
  customHeroUrl?: string | null;
  onOpenContact: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  customHeroUrl,
  onOpenContact,
}) => {
  const { personal } = portfolioData;

  const getSocialIcon = (name: string) => {
    switch (name.toLowerCase()) {
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      case 'dribbble':
        return <Dribbble className="w-4 h-4" />;
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'github':
        return <Github className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[640px] lg:min-h-[740px] pt-28 lg:pt-32 pb-0 overflow-hidden bg-gradient-to-br from-[#031426] via-[#051C36] to-[#062441] flex flex-col justify-between"
    >
      {/* Background Ambient Glows & Dot Matrix */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 rounded-full bg-[#168FFF]/10 blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-[450px] h-[450px] rounded-full bg-[#168FFF]/15 blur-3xl pointer-events-none" />
      <div className="absolute top-36 left-4 lg:left-12 hidden sm:block pointer-events-none">
        <DotPattern rows={5} cols={5} gap={14} />
      </div>

      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 w-full flex-1 flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-4 relative z-10">
        {/* Left Column: Typography & CTAs */}
        <div className="w-full lg:w-[48%] py-4 lg:py-10 space-y-6 text-left">
          {/* Eyebrow */}
          <div className="flex items-center gap-2">
            <span className="text-[#43B4FF] text-xs sm:text-sm font-bold tracking-[3px] uppercase">
              {personal.eyebrow}
            </span>
          </div>

          {/* Massive Headline */}
          <h1 className="font-['Montserrat',sans-serif] font-black tracking-tight leading-[1.08] text-white">
            <span className="block text-4xl sm:text-5xl lg:text-[68px] xl:text-[76px] drop-shadow-sm">
              {personal.name}
            </span>
            <span className="block text-3xl sm:text-4xl lg:text-[54px] xl:text-[62px] text-[#168FFF] drop-shadow-[0_2px_20px_rgba(22,143,255,0.3)] mt-1 sm:mt-2">
              {personal.profession}
            </span>
          </h1>

          {/* Description */}
          <p className="text-sm sm:text-base text-[#A8B9CD] max-w-[480px] leading-relaxed">
            {personal.description}
          </p>

          {/* CTA & Social Icons */}
          <div className="pt-2 flex flex-wrap items-center gap-5">
            {/* Primary Action Button */}
            <button
              onClick={onOpenContact}
              className="inline-flex items-center gap-2.5 px-7 py-3.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-sm font-bold rounded-full shadow-[0_4px_20px_rgba(22,143,255,0.4)] hover:shadow-[0_6px_28px_rgba(22,143,255,0.6)] active:scale-95 transition-all duration-200 group"
            >
              <span>Cùng hợp tác</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Social Icons Row */}
            <div className="flex items-center gap-2.5">
              {personal.socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.name}
                  className="w-10 h-10 rounded-full bg-[#0A2645] hover:bg-[#168FFF] border border-[#163D62] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-all duration-200 hover:scale-110 shadow-sm"
                >
                  {getSocialIcon(social.name)}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Hero Portrait & 3D Elements */}
        <div className="w-full lg:w-[52%] relative flex items-end justify-center self-end h-[460px] sm:h-[540px] lg:h-[640px] min-h-[460px]">
          {/* Horizontal Glowing Lines behind Head */}
          <div className="absolute top-[28%] left-[10%] w-[80%] z-0 pointer-events-none opacity-75">
            <HeroGlowLines />
          </div>

          {/* 3D Blue Spheres */}
          <div className="absolute top-[16%] left-[8%] sm:left-[14%] z-10 animate-pulse duration-1000">
            <BlueSphere size={54} />
          </div>

          <div className="absolute top-[32%] right-[4%] sm:right-[10%] z-10">
            <BlueSphere size={44} />
          </div>

          <div className="absolute bottom-[28%] left-[4%] z-10 hidden sm:block">
            <BlueSphere size={36} />
          </div>

          {/* Handwritten Note (Top-Right): "Thiết kế trải nghiệm tốt hơn" */}
          <div className="absolute top-[8%] sm:top-[12%] right-[4%] sm:right-[10%] z-20 pointer-events-none transform -rotate-6 select-none text-right">
            <span className="font-['Caveat',cursive] text-2xl sm:text-3xl font-bold text-[#43B4FF] drop-shadow-[0_2px_8px_rgba(67,180,255,0.4)] whitespace-nowrap block">
              {personal.handwrittenNote}
            </span>
            {/* Curved handwritten-style arrow */}
            <svg
              width="45"
              height="35"
              viewBox="0 0 50 40"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="inline-block mt-0.5 text-[#43B4FF] mr-4"
            >
              <path
                d="M10 5 C25 8 38 18 36 32"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                fill="none"
              />
              <path
                d="M28 26 L36 33 L40 23"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

          {/* Floating Badge (Lower Right): "3+ / Năm kinh nghiệm" */}
          <div className="absolute bottom-[16%] sm:bottom-[22%] right-[4%] sm:right-[8%] z-30 bg-[#0B2544]/90 backdrop-blur-md border border-[#1E507D] rounded-xl px-4 py-3 shadow-[0_8px_24px_rgba(2,14,28,0.7)] flex flex-col items-start min-w-[125px]">
            <span className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl text-white tracking-tight leading-none">
              {personal.experienceYears}
            </span>
            <span className="text-[10px] sm:text-[11px] font-medium text-[#8299B3] mt-1 leading-tight">
              {personal.experienceLabel}
            </span>
          </div>

          {/* The Large Portrait Sits Right on the Bottom Edge */}
          <div className="relative z-20 w-[90%] sm:w-[82%] lg:w-[86%] h-full flex items-end justify-center pointer-events-auto">
            <NovaPortrait
              type="hero"
              customUrl={customHeroUrl}
              className="w-full h-full object-contain object-bottom"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
