import React from 'react';

interface NovaPortraitProps {
  type: 'hero' | 'about';
  customUrl?: string | null;
  className?: string;
}

export const NovaPortrait: React.FC<NovaPortraitProps> = ({
  type,
  customUrl,
  className = '',
}) => {
  // If the user or template buyer provided a real image photo URL:
  if (customUrl) {
    return (
      <img
        src={customUrl}
        alt="Nova Lee - UI/UX Designer"
        className={`w-full h-full object-contain ${
          type === 'hero' ? 'object-bottom' : 'object-cover'
        } ${className}`}
      />
    );
  }

  // High-fidelity vector illustration matching Nova Lee:
  // Young Asian female designer, round glasses, dark hair with top bun,
  // clean white hoodie, warm natural smile.
  if (type === 'hero') {
    return (
      <div className={`relative w-full h-full flex items-end justify-center select-none ${className}`}>
        <svg
          viewBox="0 0 540 680"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full max-h-[660px] drop-shadow-2xl"
          preserveAspectRatio="xMidYMax meet"
        >
          <defs>
            {/* Skin gradient */}
            <linearGradient id="skinGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFE0D2" />
              <stop offset="50%" stopColor="#FAD0BE" />
              <stop offset="100%" stopColor="#EABCA4" />
            </linearGradient>

            {/* Hair gradient */}
            <linearGradient id="hairGrad" x1="0%" y1="0%" x2="50%" y2="100%">
              <stop offset="0%" stopColor="#3C2417" />
              <stop offset="70%" stopColor="#22130C" />
              <stop offset="100%" stopColor="#150B07" />
            </linearGradient>

            {/* Hair highlight */}
            <linearGradient id="hairHighlight" x1="0%" y1="0%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="#5A3928" />
              <stop offset="50%" stopColor="#7B4E36" />
              <stop offset="100%" stopColor="#482D1F" />
            </linearGradient>

            {/* Hoodie White Gradient */}
            <linearGradient id="hoodieGrad" x1="20%" y1="0%" x2="80%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="50%" stopColor="#F2F6FA" />
              <stop offset="85%" stopColor="#DEE5ED" />
              <stop offset="100%" stopColor="#CBD6E2" />
            </linearGradient>

            {/* Glasses metallic frame */}
            <linearGradient id="glassesGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1C2E42" />
              <stop offset="50%" stopColor="#314B68" />
              <stop offset="100%" stopColor="#132130" />
            </linearGradient>

            {/* Soft shadow */}
            <filter id="softShadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="0" dy="6" stdDeviation="8" floodColor="#020C17" floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Top Bun */}
          <ellipse cx="270" cy="95" rx="42" ry="38" fill="url(#hairGrad)" />
          <ellipse cx="270" cy="88" rx="36" ry="30" fill="url(#hairHighlight)" opacity="0.6" />
          {/* Hair tie */}
          <ellipse cx="270" cy="122" rx="14" ry="5" fill="#4B5563" />

          {/* Back Hair Flowing Down */}
          <path
            d="M175 220 C160 300 150 430 140 540 C140 550 160 550 170 530 C190 420 195 310 200 240 Z"
            fill="url(#hairGrad)"
          />
          <path
            d="M365 220 C380 300 390 430 400 540 C400 550 380 550 370 530 C350 420 345 310 340 240 Z"
            fill="url(#hairGrad)"
          />

          {/* White Hoodie Torso & Shoulders */}
          <g filter="url(#softShadow)">
            <path
              d="M100 680 C110 520 145 440 200 400 C215 390 235 385 270 385 C305 385 325 390 340 400 C395 440 430 520 440 680 Z"
              fill="url(#hoodieGrad)"
            />

            {/* Hoodie Hood Drape & Collar */}
            <path
              d="M190 390 C220 375 250 370 270 370 C290 370 320 375 350 390 C340 435 320 465 270 470 C220 465 200 435 190 390 Z"
              fill="#E5ECF4"
            />
            {/* Inner neck collar shadow */}
            <path
              d="M210 395 C230 425 250 435 270 435 C290 435 310 425 330 395 C310 405 290 410 270 410 C250 410 230 405 210 395 Z"
              fill="#CBD5E1"
            />

            {/* Hoodie Drawstrings */}
            <path d="M245 420 Q240 490 242 530" stroke="#CBD5E1" strokeWidth="5" strokeLinecap="round" />
            <circle cx="242" cy="532" r="4" fill="#94A3B8" />
            <path d="M295 420 Q300 490 298 528" stroke="#CBD5E1" strokeWidth="5" strokeLinecap="round" />
            <circle cx="298" cy="530" r="4" fill="#94A3B8" />

            {/* Hoodie seams & creases */}
            <path d="M150 560 Q180 520 220 500" stroke="#CBD5E1" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.6" />
            <path d="M390 560 Q360 520 320 500" stroke="#CBD5E1" strokeWidth="2.5" strokeLinecap="round" fill="none" opacity="0.6" />
          </g>

          {/* Neck */}
          <path
            d="M240 320 L240 395 C250 400 270 402 275 402 C285 402 300 400 300 395 L300 320 Z"
            fill="url(#skinGrad)"
          />
          {/* Neck shadow under chin */}
          <path
            d="M240 320 C255 350 285 350 300 320 C285 332 255 332 240 320 Z"
            fill="#D9A992"
            opacity="0.7"
          />

          {/* Head & Face base */}
          <path
            d="M205 210 C205 145 235 125 270 125 C305 125 335 145 335 210 C335 275 315 325 270 325 C225 325 205 275 205 210 Z"
            fill="url(#skinGrad)"
          />

          {/* Hair - Main Volume framing face */}
          <path
            d="M195 215 C190 145 225 110 270 110 C315 110 350 145 345 215 C345 225 335 200 325 185 C300 150 240 150 215 185 C205 200 195 225 195 215 Z"
            fill="url(#hairGrad)"
          />
          {/* Hair bangs / soft strands */}
          <path
            d="M210 160 Q240 185 260 175 Q285 170 325 162 C300 145 240 145 210 160 Z"
            fill="url(#hairHighlight)"
            opacity="0.8"
          />
          <path
            d="M195 210 C190 280 200 340 215 370 C220 372 225 365 222 350 C210 310 208 260 212 215 Z"
            fill="url(#hairGrad)"
          />
          <path
            d="M345 210 C350 280 340 340 325 370 C320 372 315 365 318 350 C330 310 332 260 328 215 Z"
            fill="url(#hairGrad)"
          />

          {/* Eyebrows */}
          <path d="M230 202 Q245 197 258 202" stroke="#2B1810" strokeWidth="3" strokeLinecap="round" />
          <path d="M282 202 Q295 197 310 202" stroke="#2B1810" strokeWidth="3" strokeLinecap="round" />

          {/* Eyes with cheerful spark */}
          <ellipse cx="245" cy="216" rx="9" ry="6" fill="#1C110A" />
          <circle cx="243" cy="214" r="2.5" fill="#FFFFFF" />
          <ellipse cx="295" cy="216" rx="9" ry="6" fill="#1C110A" />
          <circle cx="293" cy="214" r="2.5" fill="#FFFFFF" />
          {/* Eyelids / lashes */}
          <path d="M234 214 Q245 209 256 214" stroke="#1C110A" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <path d="M284 214 Q295 209 306 214" stroke="#1C110A" strokeWidth="2.5" strokeLinecap="round" fill="none" />

          {/* Glasses Frame (Round trendy dark frames like in screenshot) */}
          <g filter="url(#softShadow)">
            {/* Left lens frame */}
            <circle cx="244" cy="218" r="22" stroke="url(#glassesGrad)" strokeWidth="3.5" fill="none" />
            <circle cx="244" cy="218" r="21" stroke="#43B4FF" strokeWidth="0.8" strokeOpacity="0.4" fill="none" />
            {/* Right lens frame */}
            <circle cx="296" cy="218" r="22" stroke="url(#glassesGrad)" strokeWidth="3.5" fill="none" />
            <circle cx="296" cy="218" r="21" stroke="#43B4FF" strokeWidth="0.8" strokeOpacity="0.4" fill="none" />
            {/* Bridge */}
            <path d="M266 215 Q270 212 274 215" stroke="url(#glassesGrad)" strokeWidth="3.5" strokeLinecap="round" fill="none" />
            {/* Temples */}
            <path d="M222 216 L205 212" stroke="url(#glassesGrad)" strokeWidth="3" strokeLinecap="round" />
            <path d="M318 216 L335 212" stroke="url(#glassesGrad)" strokeWidth="3" strokeLinecap="round" />
            {/* Glass sheen highlight */}
            <path d="M232 208 Q248 212 254 228" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" strokeOpacity="0.5" fill="none" />
            <path d="M284 208 Q300 212 306 228" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" strokeOpacity="0.5" fill="none" />
          </g>

          {/* Nose */}
          <path d="M269 224 L271 242 Q269 246 265 245" stroke="#D59B80" strokeWidth="2.5" strokeLinecap="round" fill="none" />

          {/* Warm Rosy Cheeks */}
          <ellipse cx="230" cy="242" rx="14" ry="7" fill="#F87171" opacity="0.25" />
          <ellipse cx="310" cy="242" rx="14" ry="7" fill="#F87171" opacity="0.25" />

          {/* Friendly Smile */}
          <path
            d="M252 265 Q270 282 288 265"
            stroke="#BD5648"
            strokeWidth="3"
            strokeLinecap="round"
            fill="#991B1B"
          />
          {/* Teeth shine */}
          <path
            d="M256 266 Q270 274 284 266"
            fill="#FFFFFF"
          />

          {/* Chin rest hand (pose in hero reference: hand near chin/cheek) */}
          <g filter="url(#softShadow)">
            {/* Forearm & sleeve in white hoodie */}
            <path
              d="M320 480 C325 430 335 380 345 340 C355 330 375 330 380 350 C370 410 360 490 350 540 Z"
              fill="url(#hoodieGrad)"
            />
            {/* Hand resting near cheek */}
            <path
              d="M312 315 C310 295 320 285 330 288 C338 290 342 305 340 325 C336 345 322 345 315 335 Z"
              fill="url(#skinGrad)"
            />
            {/* Fingers curved elegantly */}
            <path d="M316 295 C312 305 314 318 318 328" stroke="#D59B80" strokeWidth="2" strokeLinecap="round" fill="none" />
            <path d="M324 290 C322 302 324 316 328 326" stroke="#D59B80" strokeWidth="2" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      </div>
    );
  }

  // About Pose: Standing with arms crossed, smiling
  return (
    <div className={`relative w-full h-full flex items-center justify-center select-none overflow-hidden ${className}`}>
      <svg
        viewBox="0 0 400 480"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full object-cover"
      >
        <defs>
          <linearGradient id="aboutSkin" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFE0D2" />
            <stop offset="60%" stopColor="#FAD0BE" />
            <stop offset="100%" stopColor="#EABCA4" />
          </linearGradient>

          <linearGradient id="aboutHair" x1="0%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#3C2417" />
            <stop offset="70%" stopColor="#22130C" />
            <stop offset="100%" stopColor="#150B07" />
          </linearGradient>

          <linearGradient id="aboutHoodie" x1="20%" y1="0%" x2="80%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="50%" stopColor="#F4F8FC" />
            <stop offset="90%" stopColor="#DFE7F0" />
            <stop offset="100%" stopColor="#CAD5E2" />
          </linearGradient>
        </defs>

        {/* Top Bun */}
        <ellipse cx="200" cy="55" rx="34" ry="28" fill="url(#aboutHair)" />

        {/* Back Hair */}
        <path d="M130 150 C120 220 115 320 110 390 C125 390 135 340 145 220 Z" fill="url(#aboutHair)" />
        <path d="M270 150 C280 220 285 320 290 390 C275 390 265 340 255 220 Z" fill="url(#aboutHair)" />

        {/* Torso & White Hoodie with Crossed Arms */}
        <path
          d="M70 480 C75 360 110 290 150 260 C170 250 230 250 250 260 C290 290 325 360 330 480 Z"
          fill="url(#aboutHoodie)"
        />

        {/* Crossed Arms fold */}
        <g>
          {/* Left arm crossing over right */}
          <path
            d="M95 340 C110 370 150 400 230 395 C250 395 270 380 290 350 C280 330 250 340 220 345 C170 350 120 330 95 340 Z"
            fill="#E2EBF4"
          />
          {/* Hand tucked under arm */}
          <path
            d="M260 365 C275 365 290 355 295 340 C285 340 270 350 260 365 Z"
            fill="url(#aboutSkin)"
          />
          {/* Right arm folded */}
          <path
            d="M305 340 C290 375 250 410 170 410 C145 410 120 395 105 370 C120 360 150 375 190 375 C240 375 285 350 305 340 Z"
            fill="#D5E2EE"
          />
        </g>

        {/* Neck */}
        <path d="M175 200 L175 260 C185 265 215 265 225 260 L225 200 Z" fill="url(#aboutSkin)" />
        <path d="M175 200 C190 215 210 215 225 200 C210 208 190 208 175 200 Z" fill="#D9A992" opacity="0.6" />

        {/* Head */}
        <path
          d="M150 140 C150 85 172 70 200 70 C228 70 250 85 250 140 C250 195 235 225 200 225 C165 225 150 195 150 140 Z"
          fill="url(#aboutSkin)"
        />

        {/* Hair front */}
        <path
          d="M142 145 C138 90 165 60 200 60 C235 60 262 90 258 145 C255 125 240 100 200 100 C160 100 145 125 142 145 Z"
          fill="url(#aboutHair)"
        />

        {/* Eyebrows */}
        <path d="M168 132 Q180 128 190 132" stroke="#2B1810" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M210 132 Q220 128 232 132" stroke="#2B1810" strokeWidth="2.5" strokeLinecap="round" />

        {/* Eyes */}
        <ellipse cx="180" cy="144" rx="7" ry="5" fill="#1C110A" />
        <circle cx="178" cy="142" r="2" fill="#FFFFFF" />
        <ellipse cx="220" cy="144" rx="7" ry="5" fill="#1C110A" />
        <circle cx="218" cy="142" r="2" fill="#FFFFFF" />

        {/* Glasses */}
        <circle cx="180" cy="146" r="17" stroke="#24384D" strokeWidth="2.8" fill="none" />
        <circle cx="220" cy="146" r="17" stroke="#24384D" strokeWidth="2.8" fill="none" />
        <path d="M197 143 Q200 141 203 143" stroke="#24384D" strokeWidth="2.8" strokeLinecap="round" fill="none" />
        <path d="M163 144 L152 140" stroke="#24384D" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M237 144 L248 140" stroke="#24384D" strokeWidth="2.5" strokeLinecap="round" />

        {/* Nose */}
        <path d="M200 152 L201 166 Q199 169 196 168" stroke="#D59B80" strokeWidth="2" strokeLinecap="round" fill="none" />

        {/* Cheeks */}
        <ellipse cx="168" cy="166" rx="10" ry="5" fill="#F87171" opacity="0.25" />
        <ellipse cx="232" cy="166" rx="10" ry="5" fill="#F87171" opacity="0.25" />

        {/* Friendly smile */}
        <path d="M186 184 Q200 196 214 184" stroke="#BD5648" strokeWidth="2.5" strokeLinecap="round" fill="#991B1B" />
        <path d="M189 185 Q200 190 211 185" fill="#FFFFFF" />
      </svg>
    </div>
  );
};
