import React from 'react';
import { Project } from '../data/portfolioData';
import { ProjectThumbnail } from './ProjectThumbnails';
import { ArrowRight } from 'lucide-react';

interface ProjectCardProps {
  project: Project;
  onOpenDetails: (project: Project) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, onOpenDetails }) => {
  return (
    <div
      onClick={() => onOpenDetails(project)}
      className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1.5 flex flex-col cursor-pointer border border-white/20"
    >
      {/* 16:10 Aspect Ratio Image Section */}
      <div className="w-full relative overflow-hidden bg-slate-50">
        <ProjectThumbnail project={project} />
      </div>

      {/* Card Footer Info */}
      <div className="p-4 sm:p-5 flex items-center justify-between bg-white text-[#111827]">
        <div className="pr-3">
          <h3 className="font-['Montserrat',sans-serif] font-bold text-[17px] sm:text-[18px] text-[#0F172A] tracking-tight group-hover:text-[#168FFF] transition-colors">
            {project.title}
          </h3>
          <p className="text-xs sm:text-[13px] text-[#64748B] font-medium mt-0.5">
            {project.category} • {project.platform}
          </p>
        </div>

        {/* Circular Blue Action Button */}
        <button
          type="button"
          aria-label={`Xem chi tiết dự án ${project.title}`}
          className="w-10 h-10 rounded-full bg-[#168FFF] hover:bg-[#0875E4] text-white flex items-center justify-center shrink-0 shadow-md transition-all duration-200 group-hover:scale-110 active:scale-95"
        >
          <ArrowRight className="w-4 h-4 transform group-hover:translate-x-0.5 transition-transform" />
        </button>
      </div>
    </div>
  );
};
