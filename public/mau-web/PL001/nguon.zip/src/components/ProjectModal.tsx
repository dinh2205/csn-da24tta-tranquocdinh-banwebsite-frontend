import React, { useState } from 'react';
import { Project } from '../data/portfolioData';
import { ProjectThumbnail } from './ProjectThumbnails';
import { X, ExternalLink, Calendar, User, Layers, CheckCircle2, ZoomIn, ArrowRight } from 'lucide-react';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
  onOpenContact: (projectTitle: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  project,
  onClose,
  onOpenContact,
}) => {
  const [isZoomed, setIsZoomed] = useState(false);

  if (!project) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#163D62] bg-[#041629]">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-xs font-semibold rounded-full bg-[#168FFF]/20 text-[#43B4FF] border border-[#168FFF]/40">
              {project.category}
            </span>
            <span className="text-xs text-[#8299B3]">• {project.platform}</span>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors"
            aria-label="Đóng cửa sổ"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-7">
          {/* Headline & Title */}
          <div>
            <h2 className="font-['Montserrat',sans-serif] font-extrabold text-2xl sm:text-3xl text-white tracking-tight mb-2">
              {project.title}
            </h2>
            <p className="text-base text-[#43B4FF] font-medium">
              {project.headline} — {project.tagline}
            </p>
          </div>

          {/* Interactive Project Visual / Lightbox trigger */}
          <div className="relative rounded-xl overflow-hidden border border-[#1A4B78] shadow-lg group">
            <ProjectThumbnail project={project} />
            <button
              onClick={() => setIsZoomed(true)}
              className="absolute top-3 right-3 px-3 py-1.5 bg-[#031426]/80 hover:bg-[#031426] backdrop-blur-sm text-xs font-medium text-white rounded-lg flex items-center gap-1.5 transition-all opacity-90 group-hover:opacity-100 shadow"
            >
              <ZoomIn className="w-3.5 h-3.5" />
              <span>Xem phóng to</span>
            </button>
          </div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-[#0A2542] rounded-xl border border-[#163D62]">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#8299B3] mb-1">
                <User className="w-3.5 h-3.5 text-[#168FFF]" />
                <span>Khách hàng</span>
              </div>
              <div className="font-semibold text-sm text-white">{project.client}</div>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#8299B3] mb-1">
                <Calendar className="w-3.5 h-3.5 text-[#168FFF]" />
                <span>Thời gian</span>
              </div>
              <div className="font-semibold text-sm text-white">{project.year}</div>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#8299B3] mb-1">
                <Layers className="w-3.5 h-3.5 text-[#168FFF]" />
                <span>Nền tảng</span>
              </div>
              <div className="font-semibold text-sm text-white">{project.platform}</div>
            </div>

            <div>
              <div className="flex items-center gap-1.5 text-xs text-[#8299B3] mb-1">
                <ExternalLink className="w-3.5 h-3.5 text-[#168FFF]" />
                <span>Vai trò</span>
              </div>
              <div className="font-semibold text-sm text-[#43B4FF]">Chủ trì UI/UX</div>
            </div>
          </div>

          {/* Full Overview */}
          <div>
            <h4 className="font-['Montserrat',sans-serif] font-bold text-lg text-white mb-2">Tổng quan dự án</h4>
            <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
              {project.fullOverview}
            </p>
          </div>

          {/* Problem & Solution Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 bg-[#09223D] rounded-xl border border-[#163D62]">
              <h5 className="font-bold text-sm text-[#F87171] uppercase tracking-wider mb-2 flex items-center gap-2">
                <span>Bài toán & Thách thức</span>
              </h5>
              <p className="text-sm text-[#A8B9CD] leading-relaxed">{project.challenge}</p>
            </div>

            <div className="p-5 bg-[#09223D] rounded-xl border border-[#163D62]">
              <h5 className="font-bold text-sm text-[#34D399] uppercase tracking-wider mb-2 flex items-center gap-2">
                <span>Giải pháp thiết kế</span>
              </h5>
              <p className="text-sm text-[#A8B9CD] leading-relaxed">{project.solution}</p>
            </div>
          </div>

          {/* Measurable Results */}
          <div>
            <h4 className="font-['Montserrat',sans-serif] font-bold text-lg text-white mb-3">Kết quả & Tác động thực tế</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {project.results.map((res, i) => (
                <div key={i} className="p-4 bg-[#0A2645] rounded-xl border border-[#174877] flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />
                  <span className="text-sm font-medium text-white">{res}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Deliverables & Tools */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <h5 className="text-xs uppercase tracking-wider text-[#8299B3] font-bold mb-2">Sản phẩm bàn giao</h5>
              <ul className="space-y-1.5 text-sm text-[#A8B9CD]">
                {project.deliverables.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#168FFF]" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h5 className="text-xs uppercase tracking-wider text-[#8299B3] font-bold mb-2">Công cụ & Phương pháp</h5>
              <div className="flex flex-wrap gap-2">
                {project.tools.map((t, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-[#0E2F52] text-[#43B4FF] text-xs font-semibold rounded-lg border border-[#1A4C78]"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#163D62] bg-[#041629] flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs text-[#8299B3]">
            Bạn ấn tượng với giải pháp này? Hãy cùng bắt tay thực hiện dự án của bạn.
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-[#A8B9CD] hover:text-white rounded-full transition-colors"
            >
              Đóng
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenContact(project.title);
              }}
              className="px-5 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all shadow-lg flex items-center gap-2"
            >
              <span>Trao đổi về dự án này</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Lightbox Zoom Overlay */}
      {isZoomed && (
        <div
          className="fixed inset-0 z-60 bg-black/95 flex items-center justify-center p-4 cursor-zoom-out"
          onClick={() => setIsZoomed(false)}
        >
          <div className="relative max-w-5xl w-full">
            <ProjectThumbnail project={project} className="rounded-xl shadow-2xl" />
            <p className="text-center text-xs text-white/70 mt-3">Nhấp vào bất kỳ đâu để quay lại trang chi tiết</p>
          </div>
        </div>
      )}
    </div>
  );
};
