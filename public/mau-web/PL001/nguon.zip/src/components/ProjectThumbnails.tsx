import React from 'react';
import { Project } from '../data/portfolioData';

interface ProjectThumbnailProps {
  project: Project;
  className?: string;
  onClick?: () => void;
}

export const ProjectThumbnail: React.FC<ProjectThumbnailProps> = ({
  project,
  className = '',
  onClick,
}) => {
  if (project.image) {
    return (
      <div
        className={`relative w-full aspect-[16/10] overflow-hidden bg-slate-100 ${className}`}
        onClick={onClick}
      >
        <img
          src={project.image}
          alt={project.title}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
      </div>
    );
  }

  // 1. Finance App Design ("Smarter Banking for a Brighter Future")
  if (project.previewType === 'finance') {
    return (
      <div
        className={`relative w-full aspect-[16/10] overflow-hidden select-none bg-gradient-to-br from-[#EBF2FE] via-[#E5EEFF] to-[#DFDEFF] p-4 sm:p-5 flex items-center justify-between group cursor-pointer ${className}`}
        onClick={onClick}
      >
        {/* Soft background glow */}
        <div className="absolute top-0 right-0 w-44 h-44 rounded-full bg-[#388CFF]/15 blur-2xl pointer-events-none" />

        {/* Left text mockup */}
        <div className="relative z-10 w-[55%] pr-2">
          <div className="flex items-center gap-1.5 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#168FFF]" />
            <span className="text-[10px] font-bold tracking-wider text-[#476082] uppercase">VaultPay Toàn Cầu</span>
          </div>
          <h4 className="font-['Montserrat',sans-serif] font-extrabold text-[15px] sm:text-[18px] leading-tight text-[#0A1A2F] mb-2 tracking-tight">
            Smarter Banking for a Brighter Future
          </h4>
          <p className="text-[11px] sm:text-[12px] text-[#475569] leading-snug line-clamp-2 mb-3 hidden sm:block">
            Giao dịch đa tiền tệ mượt mà cùng dự báo chi tiêu thông minh.
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#168FFF] text-white text-[10px] sm:text-[11px] font-semibold rounded-full shadow-sm">
            <span>Bắt đầu ngay</span>
            <span>→</span>
          </div>
        </div>

        {/* Right angled iPhone mockup */}
        <div className="relative z-10 w-[42%] h-[120%] -mb-4 flex items-end justify-center transform group-hover:-translate-y-1 transition-transform duration-300">
          <div className="w-[130px] sm:w-[150px] bg-[#0E1E35] rounded-t-2xl p-2 border-t-2 border-x-2 border-white/80 shadow-2xl">
            {/* Notch */}
            <div className="w-10 h-1.5 bg-black/60 rounded-full mx-auto mb-2" />
            {/* Phone Screen UI */}
            <div className="bg-[#11233E] rounded-lg p-2 text-white">
              <div className="text-[8px] text-[#8299B3]">Số dư hiện tại</div>
              <div className="text-[13px] font-bold text-white">$14,820.50</div>

              {/* Mini Trend Graph */}
              <div className="my-2 h-7 w-full flex items-end">
                <svg viewBox="0 0 100 35" fill="none" className="w-full h-full">
                  <path
                    d="M0 28 Q20 22 35 25 T70 12 T100 6"
                    stroke="#43B4FF"
                    strokeWidth="2.5"
                    fill="none"
                  />
                  <path
                    d="M0 28 Q20 22 35 25 T70 12 T100 6 L100 35 L0 35 Z"
                    fill="url(#financeGradient)"
                    opacity="0.3"
                  />
                  <defs>
                    <linearGradient id="financeGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#43B4FF" />
                      <stop offset="100%" stopColor="#43B4FF" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              {/* Action buttons */}
              <div className="grid grid-cols-2 gap-1 mb-1.5">
                <div className="bg-[#1C3E69] text-center text-[7px] py-1 rounded font-medium text-white">Chuyển</div>
                <div className="bg-[#1C3E69] text-center text-[7px] py-1 rounded font-medium text-white">Yêu cầu</div>
              </div>

              {/* Transactions */}
              <div className="space-y-1">
                <div className="flex justify-between items-center text-[7px] bg-[#0A1729]/60 px-1 py-0.5 rounded">
                  <span className="text-[#A8B9CD]">Apple Store</span>
                  <span className="text-white font-medium">-$199.00</span>
                </div>
                <div className="flex justify-between items-center text-[7px] bg-[#0A1729]/60 px-1 py-0.5 rounded">
                  <span className="text-[#A8B9CD]">Thu nhập Freelance</span>
                  <span className="text-[#34D399] font-medium">+$2,400.00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. SaaS Website Design ("The All-in-One Platform for Modern Teams")
  if (project.previewType === 'saas') {
    return (
      <div
        className={`relative w-full aspect-[16/10] overflow-hidden select-none bg-gradient-to-br from-[#061B30] via-[#0A2645] to-[#041222] p-4 sm:p-5 flex flex-col justify-between group cursor-pointer border border-[#163D62]/40 ${className}`}
        onClick={onClick}
      >
        {/* Glow */}
        <div className="absolute -top-10 -right-10 w-48 h-48 rounded-full bg-[#168FFF]/25 blur-3xl pointer-events-none" />

        {/* Header mockup inside */}
        <div className="relative z-10 flex items-center justify-between border-b border-[#1A4269] pb-2">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded bg-[#168FFF]" />
            <span className="text-[10px] font-bold text-white tracking-wider">Spherule Cloud</span>
          </div>
          <div className="flex items-center gap-1 text-[8px] text-[#A8B9CD]">
            <span className="px-1.5 py-0.5 rounded bg-[#103358] text-[#43B4FF]">Chỉ số trực tiếp</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
          </div>
        </div>

        {/* Main Content Title */}
        <div className="relative z-10 my-2">
          <h4 className="font-['Montserrat',sans-serif] font-extrabold text-[14px] sm:text-[17px] text-white leading-tight mb-1">
            The All-in-One Platform for Modern Teams
          </h4>
          <p className="text-[10px] sm:text-[11px] text-[#8BA4C4] line-clamp-1">
            Theo dõi hiệu năng hạ tầng, phân tích dữ liệu và tự động phục hồi sự cố.
          </p>
        </div>

        {/* Dashboard Panels */}
        <div className="relative z-10 grid grid-cols-3 gap-2">
          <div className="bg-[#0B2544] p-1.5 rounded border border-[#174877]">
            <div className="text-[7px] text-[#8BA4C4]">Thời gian Uptime</div>
            <div className="text-[11px] font-bold text-white">99.99%</div>
            <div className="text-[6px] text-[#34D399] font-medium">↑ Ổn định</div>
          </div>
          <div className="bg-[#0B2544] p-1.5 rounded border border-[#174877]">
            <div className="text-[7px] text-[#8BA4C4]">Lượt truy vấn/giây</div>
            <div className="text-[11px] font-bold text-[#43B4FF]">48.2k</div>
            <div className="text-[6px] text-[#34D399] font-medium">↑ Lưu lượng cao</div>
          </div>
          <div className="bg-[#0B2544] p-1.5 rounded border border-[#174877]">
            <div className="text-[7px] text-[#8BA4C4]">Máy chủ Node</div>
            <div className="text-[11px] font-bold text-white">128 / 128</div>
            <div className="text-[6px] text-[#A8B9CD] font-medium">0 cảnh báo</div>
          </div>
        </div>

        {/* Chart Bar */}
        <div className="relative z-10 mt-1 flex items-end gap-1 h-8 w-full bg-[#081E38]/80 rounded p-1">
          {[40, 65, 45, 80, 55, 90, 70, 85, 95, 60, 75, 100].map((h, idx) => (
            <div
              key={idx}
              className="flex-1 bg-gradient-to-t from-[#0F5EA8] to-[#168FFF] rounded-t-sm group-hover:brightness-125 transition-all"
              style={{ height: `${h}%` }}
            />
          ))}
        </div>
      </div>
    );
  }

  // 3. E-commerce Website ("Premium Essentials For a Better You")
  if (project.previewType === 'ecommerce') {
    return (
      <div
        className={`relative w-full aspect-[16/10] overflow-hidden select-none bg-gradient-to-br from-[#F8FAFC] via-[#F1F5F9] to-[#E2E8F0] p-4 sm:p-5 flex items-center justify-between group cursor-pointer ${className}`}
        onClick={onClick}
      >
        {/* Left details */}
        <div className="relative z-10 w-[55%] pr-2">
          <div className="flex items-center gap-1.5 mb-2">
            <span className="text-[10px] font-bold tracking-widest text-[#64748B] uppercase">Aura Acoustics</span>
          </div>
          <h4 className="font-['Montserrat',sans-serif] font-extrabold text-[15px] sm:text-[18px] leading-tight text-[#0F172A] mb-2 tracking-tight">
            Premium Essentials For a Better You
          </h4>
          <p className="text-[11px] sm:text-[12px] text-[#475569] leading-snug line-clamp-2 mb-3 hidden sm:block">
            Tai nghe không dây chuẩn phòng thu với âm thanh không gian cá nhân hóa.
          </p>
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#0F172A] text-[13px] sm:text-[14px]">$349</span>
            <span className="px-2.5 py-1 bg-[#0F172A] text-white text-[10px] font-medium rounded-full">Mua ngay</span>
          </div>
        </div>

        {/* Right headphones SVG representation */}
        <div className="relative z-10 w-[42%] flex items-center justify-center transform group-hover:scale-105 transition-transform duration-300">
          <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto drop-shadow-2xl">
            <path
              d="M30 90 C30 35 130 35 130 90"
              stroke="#1E293B"
              strokeWidth="12"
              strokeLinecap="round"
            />
            <path
              d="M45 75 C45 45 115 45 115 75"
              stroke="#334155"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <rect x="24" y="80" width="12" height="18" rx="3" fill="#64748B" />
            <rect x="124" y="80" width="12" height="18" rx="3" fill="#64748B" />

            <ellipse cx="30" cy="105" rx="18" ry="26" fill="#0F172A" />
            <ellipse cx="30" cy="105" rx="14" ry="21" fill="#1E293B" stroke="#334155" strokeWidth="2" />
            <circle cx="30" cy="105" r="7" fill="#0F172A" />
            <circle cx="30" cy="105" r="3" fill="#168FFF" />

            <ellipse cx="130" cy="105" rx="18" ry="26" fill="#0F172A" />
            <ellipse cx="130" cy="105" rx="14" ry="21" fill="#1E293B" stroke="#334155" strokeWidth="2" />
            <circle cx="130" cy="105" r="7" fill="#0F172A" />
            <circle cx="130" cy="105" r="3" fill="#168FFF" />
          </svg>
        </div>
      </div>
    );
  }

  // Generic / Custom Project Thumbnail
  return (
    <div
      className={`relative w-full aspect-[16/10] overflow-hidden select-none bg-gradient-to-br from-[#0B2544] to-[#041427] p-4 flex flex-col justify-between group cursor-pointer border border-[#163D62]/40 ${className}`}
      onClick={onClick}
    >
      <div className="relative z-10 flex items-center justify-between">
        <span className="text-[10px] font-bold text-[#43B4FF] uppercase tracking-wider">{project.platform}</span>
        <span className="text-[10px] text-[#A8B9CD]">{project.year}</span>
      </div>
      <div className="relative z-10 my-auto">
        <h4 className="font-['Montserrat',sans-serif] font-bold text-base text-white">{project.headline}</h4>
        <p className="text-xs text-[#A8B9CD] line-clamp-2 mt-1">{project.description}</p>
      </div>
      <div className="relative z-10 flex gap-1.5 flex-wrap">
        {project.tools.slice(0, 3).map((tool, i) => (
          <span key={i} className="text-[9px] px-2 py-0.5 rounded bg-[#103358] text-[#8BA4C4]">
            {tool}
          </span>
        ))}
      </div>
    </div>
  );
};
