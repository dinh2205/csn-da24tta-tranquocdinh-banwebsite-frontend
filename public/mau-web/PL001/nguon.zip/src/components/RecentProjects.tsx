import React from 'react';
import { portfolioData, Project } from '../data/portfolioData';
import { ProjectCard } from './ProjectCard';
import { ArrowRight } from 'lucide-react';

interface RecentProjectsProps {
  onOpenProjectModal: (project: Project) => void;
  onOpenAllProjects: () => void;
}

export const RecentProjects: React.FC<RecentProjectsProps> = ({
  onOpenProjectModal,
  onOpenAllProjects,
}) => {
  const featuredProjects = portfolioData.projects.slice(0, 3);

  return (
    <section id="projects" className="relative py-20 lg:py-28 bg-[#062441] border-t border-[#0C3257]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div className="max-w-xl">
            <h2 className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl lg:text-[34px] leading-tight text-white tracking-tight uppercase mb-3">
              DỰ ÁN NỔI BẬT
            </h2>
            <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
              Tuyển tập những dự án mới nhất của tôi. Mỗi dự án đều được chăm chút tỉ mỉ đến từng chi tiết và lấy nhu cầu thực tế của người dùng làm trọng tâm.
            </p>
          </div>

          {/* Right Action: "Xem tất cả dự án →" */}
          <div className="shrink-0">
            <button
              onClick={onOpenAllProjects}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full border border-[#168FFF] text-[#43B4FF] hover:bg-[#168FFF] hover:text-white text-xs sm:text-sm font-semibold transition-all duration-200 group shadow-sm"
            >
              <span>Xem tất cả dự án</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* 3 Project Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
          {featuredProjects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onOpenDetails={onOpenProjectModal}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
