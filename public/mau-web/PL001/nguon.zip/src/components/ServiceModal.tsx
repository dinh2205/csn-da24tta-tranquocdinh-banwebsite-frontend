import React from 'react';
import { Service } from '../data/portfolioData';
import { X, CheckCircle, ArrowRight, Sparkles, Wrench } from 'lucide-react';

interface ServiceModalProps {
  service: Service | null;
  onClose: () => void;
  onOpenContact: (serviceTitle: string) => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({
  service,
  onClose,
  onOpenContact,
}) => {
  if (!service) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl bg-[#061D35] border border-[#163D62] rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col text-[#F5F9FF]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#163D62] bg-[#041629]">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-[#168FFF] text-white flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5" />
            </span>
            <div>
              <span className="text-xs font-bold text-[#43B4FF] uppercase tracking-wider">Phạm vi dịch vụ</span>
              <h3 className="font-['Montserrat',sans-serif] font-bold text-xl text-white">
                {service.title}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#0A2645] hover:bg-[#10345A] text-[#A8B9CD] hover:text-white flex items-center justify-center transition-colors"
            aria-label="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
          <p className="text-base text-[#D0E0F2] leading-relaxed">
            {service.fullDescription}
          </p>

          {/* Deliverables */}
          <div className="p-5 bg-[#09233F] rounded-xl border border-[#164166]">
            <h4 className="font-['Montserrat',sans-serif] font-bold text-sm text-[#43B4FF] uppercase tracking-wider mb-3">
              Sản phẩm bàn giao chi tiết
            </h4>
            <div className="space-y-2.5">
              {service.deliverables.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-sm text-[#A8B9CD]">
                  <CheckCircle className="w-4 h-4 text-[#168FFF] shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Workflow & Process */}
          <div>
            <h4 className="font-['Montserrat',sans-serif] font-bold text-sm text-white uppercase tracking-wider mb-3">
              Quy trình thực hiện & Cột mốc
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {service.process.map((step, idx) => (
                <div key={idx} className="p-3 bg-[#0A2542] rounded-lg border border-[#17446E] text-xs font-medium text-[#BACCE0]">
                  {step}
                </div>
              ))}
            </div>
          </div>

          {/* Tools Used */}
          <div>
            <h4 className="font-['Montserrat',sans-serif] font-bold text-sm text-white uppercase tracking-wider mb-2 flex items-center gap-2">
              <Wrench className="w-4 h-4 text-[#168FFF]" />
              <span>Công cụ chuyên dụng</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {service.tools.map((t, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 bg-[#0F3156] text-[#43B4FF] text-xs font-semibold rounded-lg border border-[#1B5288]"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#163D62] bg-[#041629] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-[#A8B9CD] hover:text-white"
          >
            Đóng
          </button>
          <button
            onClick={() => {
              onClose();
              onOpenContact(service.title);
            }}
            className="px-5 py-2.5 bg-[#168FFF] hover:bg-[#0875E4] text-white text-xs font-bold rounded-full transition-all shadow-md flex items-center gap-2"
          >
            <span>Nhận tư vấn {service.title}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
