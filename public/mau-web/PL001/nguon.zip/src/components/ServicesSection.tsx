import React from 'react';
import { portfolioData, Service } from '../data/portfolioData';
import { LayoutDashboard, SearchCheck, Gem, Monitor, ArrowRight } from 'lucide-react';

interface ServicesSectionProps {
  onOpenServiceModal: (service: Service) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onOpenServiceModal }) => {
  const { services } = portfolioData;

  const renderIcon = (iconName: string) => {
    const props = { className: "w-6 h-6 text-white" };
    switch (iconName) {
      case 'LayoutDashboard':
        return <LayoutDashboard {...props} />;
      case 'SearchCheck':
        return <SearchCheck {...props} />;
      case 'Gem':
        return <Gem {...props} />;
      case 'Monitor':
        return <Monitor {...props} />;
      default:
        return <LayoutDashboard {...props} />;
    }
  };

  return (
    <section id="services" className="relative py-20 lg:py-28 bg-[#031426] border-t border-[#09223D]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <h2 className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl lg:text-[34px] leading-tight text-white tracking-tight uppercase mb-2">
            DỊCH VỤ THIẾT KẾ
          </h2>
          <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
            Các giải pháp thiết kế toàn diện giúp nâng tầm thương hiệu và tạo dựng trải nghiệm ý nghĩa cho khách hàng.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {services.map((service) => (
            <div
              key={service.id}
              onClick={() => onOpenServiceModal(service)}
              className="group p-6 sm:p-7 rounded-xl bg-gradient-to-b from-[#0B2C4E] to-[#081D35] border border-[#164166] hover:border-[#168FFF] transition-all duration-300 transform hover:-translate-y-1.5 flex flex-col justify-between cursor-pointer shadow-lg hover:shadow-[0_12px_30px_rgba(22,143,255,0.15)]"
            >
              <div>
                {/* Icon in electric blue container */}
                <div className="w-12 h-12 rounded-xl bg-[#168FFF] flex items-center justify-center mb-6 shadow-[0_4px_16px_rgba(22,143,255,0.4)] group-hover:scale-105 transition-transform duration-200">
                  {renderIcon(service.iconName)}
                </div>

                {/* Title */}
                <h3 className="font-['Montserrat',sans-serif] font-bold text-lg text-white mb-2.5 group-hover:text-[#43B4FF] transition-colors">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-[13px] text-[#A8B9CD] leading-relaxed">
                  {service.shortDescription}
                </p>
              </div>

              {/* Action Link: Xem chi tiết → */}
              <div className="pt-6">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#168FFF] group-hover:text-[#43B4FF] transition-colors">
                  <span>Xem chi tiết</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
