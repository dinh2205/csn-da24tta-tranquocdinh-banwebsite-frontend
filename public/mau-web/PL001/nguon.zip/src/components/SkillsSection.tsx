import React from 'react';
import { portfolioData } from '../data/portfolioData';

export const SkillsSection: React.FC = () => {
  const { skills } = portfolioData;

  const renderSkillBadge = (name: string) => {
    switch (name) {
      case 'Figma':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#1E2638] flex items-center justify-center shrink-0 border border-[#2B3852]">
            <svg width="22" height="22" viewBox="0 0 38 57" fill="none">
              <path d="M19 28.5C19 23.2533 23.2533 19 28.5 19C33.7467 19 38 23.2533 38 28.5C38 33.7467 33.7467 38 28.5 38C23.2533 38 19 33.7467 19 28.5Z" fill="#1ABCFE"/>
              <path d="M0 47.5C0 42.2533 4.25329 38 9.5 38H19V47.5C19 52.7467 14.7467 57 9.5 57C4.25329 57 0 52.7467 0 47.5Z" fill="#0ACF83"/>
              <path d="M19 0V19H28.5C33.7467 19 38 14.7467 38 9.5C38 4.25329 33.7467 0 28.5 0H19Z" fill="#FF7262"/>
              <path d="M0 9.5C0 14.7467 4.25329 19 9.5 19H19V0H9.5C4.25329 0 0 4.25329 0 9.5Z" fill="#F24E1E"/>
              <path d="M0 28.5C0 33.7467 4.25329 38 9.5 38H19V19H9.5C4.25329 19 0 23.2533 0 28.5Z" fill="#A259FF"/>
            </svg>
          </div>
        );
      case 'Adobe XD':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#470137] flex items-center justify-center shrink-0 border border-[#7D0C64]">
            <span className="font-['Montserrat',sans-serif] font-black text-sm text-[#FF61F6]">Xd</span>
          </div>
        );
      case 'Photoshop':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#001E36] flex items-center justify-center shrink-0 border border-[#00528F]">
            <span className="font-['Montserrat',sans-serif] font-black text-sm text-[#31A8FF]">Ps</span>
          </div>
        );
      case 'Illustrator':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#331E00] flex items-center justify-center shrink-0 border border-[#8C5200]">
            <span className="font-['Montserrat',sans-serif] font-black text-sm text-[#FF9A00]">Ai</span>
          </div>
        );
      case 'HTML / CSS':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#2E1812] flex items-center justify-center shrink-0 border border-[#6B3224]">
            <div className="flex gap-0.5 font-['Montserrat',sans-serif] font-black text-[9px] text-[#FF5722]">
              <span>&lt;/&gt;</span>
            </div>
          </div>
        );
      case 'React':
        return (
          <div className="w-10 h-10 rounded-xl bg-[#082736] flex items-center justify-center shrink-0 border border-[#10567A]">
            <svg width="22" height="22" viewBox="0 0 100 100" fill="none">
              <ellipse cx="50" cy="50" rx="42" ry="16" stroke="#61DAFB" strokeWidth="4" />
              <ellipse cx="50" cy="50" rx="42" ry="16" stroke="#61DAFB" strokeWidth="4" transform="rotate(60 50 50)" />
              <ellipse cx="50" cy="50" rx="42" ry="16" stroke="#61DAFB" strokeWidth="4" transform="rotate(120 50 50)" />
              <circle cx="50" cy="50" r="8" fill="#61DAFB" />
            </svg>
          </div>
        );
      default:
        return (
          <div className="w-10 h-10 rounded-xl bg-[#0A2645] flex items-center justify-center shrink-0 border border-[#163D62]">
            <span className="font-bold text-xs text-white">{name.slice(0, 2)}</span>
          </div>
        );
    }
  };

  return (
    <section className="relative py-16 lg:py-24 bg-[#031426] border-t border-[#09223D]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-12">
          <h2 className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl lg:text-[34px] leading-tight text-white tracking-tight uppercase mb-2">
            CÔNG CỤ & KỸ NĂNG
          </h2>
          <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
            Những công cụ và nền tảng tôi sử dụng để hiện thực hóa các ý tưởng.
          </p>
        </div>

        {/* 6 Skills in Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-7">
          {skills.map((skill) => (
            <div key={skill.name} className="flex items-center gap-4">
              {/* Badge */}
              {renderSkillBadge(skill.name)}

              {/* Bar and Labels */}
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-['Montserrat',sans-serif] font-bold text-sm sm:text-base text-white tracking-tight">
                    {skill.name}
                  </span>
                  <span className="text-xs font-semibold text-[#8299B3]">
                    {skill.percentage}%
                  </span>
                </div>

                {/* Progress Track & Fill */}
                <div className="w-full h-2 rounded-full bg-[#284866] overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#168FFF] transition-all duration-1000 ease-out shadow-[0_0_8px_rgba(22,143,255,0.6)]"
                    style={{ width: `${skill.percentage}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
