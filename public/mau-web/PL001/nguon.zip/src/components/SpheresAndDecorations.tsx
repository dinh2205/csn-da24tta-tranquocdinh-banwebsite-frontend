import React from 'react';

/**
 * High-fidelity 3D Blue Sphere with realistic specular highlight and rim lighting
 * matching the NOVA portfolio reference design.
 */
export const BlueSphere: React.FC<{
  size?: number;
  className?: string;
  glow?: boolean;
}> = ({ size = 80, className = '', glow = true }) => {
  const sphereId = React.useId().replace(/:/g, '');

  return (
    <div
      className={`relative inline-block pointer-events-none select-none ${className}`}
      style={{ width: size, height: size }}
    >
      {glow && (
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-40 scale-125"
          style={{
            background: 'radial-gradient(circle, #168FFF 0%, rgba(22,143,255,0) 70%)',
          }}
        />
      )}
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 w-full h-full drop-shadow-xl"
      >
        <defs>
          {/* Main 3D gradient */}
          <radialGradient
            id={`sphere-body-${sphereId}`}
            cx="32%"
            cy="28%"
            r="65%"
            fx="30%"
            fy="25%"
          >
            <stop offset="0%" stopColor="#43B4FF" />
            <stop offset="18%" stopColor="#168FFF" />
            <stop offset="48%" stopColor="#0B3E74" />
            <stop offset="80%" stopColor="#052243" />
            <stop offset="100%" stopColor="#020E1C" />
          </radialGradient>

          {/* Glossy top-left highlight */}
          <radialGradient
            id={`sphere-specular-${sphereId}`}
            cx="32%"
            cy="28%"
            r="22%"
          >
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.85" />
            <stop offset="50%" stopColor="#8ED5FF" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#168FFF" stopOpacity="0" />
          </radialGradient>

          {/* Subtle bottom-right rim bounce */}
          <radialGradient
            id={`sphere-rim-${sphereId}`}
            cx="80%"
            cy="82%"
            r="35%"
          >
            <stop offset="0%" stopColor="#168FFF" stopOpacity="0.45" />
            <stop offset="60%" stopColor="#0B3E74" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Sphere Base */}
        <circle cx="50" cy="50" r="48" fill={`url(#sphere-body-${sphereId})`} />
        {/* Rim bounce */}
        <circle cx="50" cy="50" r="48" fill={`url(#sphere-rim-${sphereId})`} />
        {/* Specular Highlight */}
        <circle cx="35" cy="32" r="18" fill={`url(#sphere-specular-${sphereId})`} />
      </svg>
    </div>
  );
};

/**
 * Subtle Dot Matrix Pattern
 */
export const DotPattern: React.FC<{
  rows?: number;
  cols?: number;
  className?: string;
  gap?: number;
}> = ({ rows = 6, cols = 6, className = '', gap = 16 }) => {
  return (
    <div
      className={`grid pointer-events-none select-none opacity-40 ${className}`}
      style={{
        gridTemplateColumns: `repeat(${cols}, 4px)`,
        gap: `${gap}px`,
      }}
    >
      {Array.from({ length: rows * cols }).map((_, i) => (
        <span
          key={i}
          className="w-1 h-1 rounded-full bg-[#387CB8]"
          style={{
            opacity: Math.sin(i * 0.4) * 0.3 + 0.7,
          }}
        />
      ))}
    </div>
  );
};

/**
 * Concentric Radial Lines / Sunburst decoration behind About section
 */
export const RadialSunburst: React.FC<{
  className?: string;
  size?: number;
}> = ({ className = '', size = 260 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`pointer-events-none select-none ${className}`}
    >
      {/* Outer to inner concentric rings */}
      {[90, 80, 70, 60, 50, 40, 30].map((radius, idx) => (
        <circle
          key={idx}
          cx="100"
          cy="100"
          r={radius}
          stroke="#168FFF"
          strokeOpacity={0.06 + idx * 0.03}
          strokeWidth="1"
          strokeDasharray={idx % 2 === 0 ? "4 4" : undefined}
        />
      ))}
      {/* Radiating ticks */}
      {Array.from({ length: 36 }).map((_, i) => {
        const angle = (i * 10 * Math.PI) / 180;
        const x1 = 100 + 45 * Math.cos(angle);
        const y1 = 100 + 45 * Math.sin(angle);
        const x2 = 100 + 88 * Math.cos(angle);
        const y2 = 100 + 88 * Math.sin(angle);
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="#19609E"
            strokeOpacity="0.4"
            strokeWidth="0.8"
          />
        );
      })}
    </svg>
  );
};

/**
 * Concentric Target Badge (top right of About section in reference)
 */
export const ConcentricCircleBadge: React.FC<{
  className?: string;
  size?: number;
}> = ({ className = '', size = 90 }) => {
  return (
    <div
      className={`relative rounded-full flex items-center justify-center pointer-events-none select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="50" cy="50" r="48" stroke="#168FFF" strokeOpacity="0.25" strokeWidth="1" />
        <circle cx="50" cy="50" r="40" stroke="#168FFF" strokeOpacity="0.35" strokeWidth="1" strokeDasharray="3 3" />
        <circle cx="50" cy="50" r="32" stroke="#168FFF" strokeOpacity="0.5" strokeWidth="1.5" />
        <circle cx="50" cy="50" r="24" stroke="#43B4FF" strokeOpacity="0.7" strokeWidth="2" />
        <circle cx="50" cy="50" r="14" fill="#0A2C50" stroke="#168FFF" strokeWidth="2" />
        <circle cx="50" cy="50" r="6" fill="#168FFF" />
      </svg>
    </div>
  );
};

/**
 * Glowing Horizontal Lines behind Hero portrait
 */
export const HeroGlowLines: React.FC<{
  className?: string;
}> = ({ className = '' }) => {
  return (
    <div className={`space-y-3 pointer-events-none select-none ${className}`}>
      {[100, 85, 95, 70, 90, 60].map((width, idx) => (
        <div
          key={idx}
          className="h-[1.5px] rounded-full"
          style={{
            width: `${width}%`,
            background: 'linear-gradient(90deg, rgba(22,143,255,0) 0%, rgba(22,143,255,0.7) 40%, rgba(67,180,255,0.9) 65%, rgba(22,143,255,0) 100%)',
            opacity: 0.85 - idx * 0.1,
          }}
        />
      ))}
    </div>
  );
};
