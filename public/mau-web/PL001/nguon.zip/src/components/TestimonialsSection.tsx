import React, { useState } from 'react';
import { portfolioData } from '../data/portfolioData';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const { testimonials } = portfolioData;
  const [startIndex, setStartIndex] = useState(0);

  const handlePrev = () => {
    setStartIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setStartIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const renderClientAvatar = (seed: string) => {
    const avatarGradients: Record<string, string> = {
      Daniel: 'from-[#1E3A8A] to-[#2563EB]',
      Sarah: 'from-[#831843] to-[#DB2777]',
      Michael: 'from-[#065F46] to-[#059669]',
      Elena: 'from-[#4C1D95] to-[#7C3AED]',
    };

    const gradient = avatarGradients[seed] || 'from-[#164E63] to-[#0891B2]';

    return (
      <div
        className={`w-11 h-11 rounded-full bg-gradient-to-br ${gradient} flex items-center justify-center shrink-0 border-2 border-[#1E5283] shadow-md`}
      >
        <span className="font-['Montserrat',sans-serif] font-bold text-sm text-white">
          {seed.slice(0, 1)}
        </span>
      </div>
    );
  };

  const visibleTestimonials = [
    testimonials[startIndex % testimonials.length],
    testimonials[(startIndex + 1) % testimonials.length],
    testimonials[(startIndex + 2) % testimonials.length],
  ];

  return (
    <section className="relative py-20 lg:py-28 bg-[#031426] border-t border-[#09223D]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header with Navigation Arrows */}
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="font-['Montserrat',sans-serif] font-black text-2xl sm:text-3xl lg:text-[34px] leading-tight text-white tracking-tight uppercase mb-2">
              ĐÁNH GIÁ TỪ KHÁCH HÀNG
            </h2>
            <p className="text-sm sm:text-base text-[#A8B9CD] leading-relaxed">
              Những phản hồi chân thành từ các đối tác và khách hàng tôi từng có cơ hội đồng hành.
            </p>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrev}
              aria-label="Đánh giá trước đó"
              className="w-10 h-10 rounded-full border border-[#164166] bg-[#071F38] hover:bg-[#103458] hover:border-[#168FFF] text-[#BACCE0] hover:text-white flex items-center justify-center transition-all duration-200"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              aria-label="Đánh giá kế tiếp"
              className="w-10 h-10 rounded-full border border-[#164166] bg-[#071F38] hover:bg-[#103458] hover:border-[#168FFF] text-[#BACCE0] hover:text-white flex items-center justify-center transition-all duration-200"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {visibleTestimonials.map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className="p-6 rounded-xl bg-[#09233F] border border-[#164166] flex flex-col justify-between shadow-lg hover:border-[#168FFF]/60 transition-all duration-300"
            >
              <div className="flex items-start gap-3.5 mb-6">
                {renderClientAvatar(item.avatarSeed)}
                <p className="text-xs sm:text-[13px] text-[#BACCE0] leading-relaxed italic">
                  "{item.text}"
                </p>
              </div>

              <div className="flex items-end justify-between pt-4 border-t border-[#123659]">
                <div>
                  <h4 className="font-['Montserrat',sans-serif] font-bold text-sm text-white">
                    {item.name}
                  </h4>
                  <p className="text-xs text-[#8299B3] mt-0.5">
                    {item.role}
                  </p>
                </div>

                <div className="flex items-center gap-0.5 text-[#FFB800]">
                  {Array.from({ length: item.rating }).map((_, starIndex) => (
                    <Star key={starIndex} className="w-3.5 h-3.5 fill-[#FFB800]" />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
