export interface Project {
  id: string;
  title: string;
  category: string;
  platform: string;
  headline: string;
  tagline: string;
  description: string;
  fullOverview: string;
  challenge: string;
  solution: string;
  results: string[];
  tools: string[];
  previewType: 'finance' | 'saas' | 'ecommerce' | 'custom';
  image?: string;
  client: string;
  year: string;
  deliverables: string[];
}

export interface Service {
  id: string;
  iconName: 'LayoutDashboard' | 'SearchCheck' | 'Gem' | 'Monitor';
  title: string;
  shortDescription: string;
  fullDescription: string;
  deliverables: string[];
  process: string[];
  tools: string[];
}

export interface Skill {
  name: string;
  iconLabel: string;
  percentage: number;
  category: 'Design' | 'Development';
  color: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  rating: number;
  text: string;
  avatarSeed: string;
}

export interface Brand {
  name: string;
  category: string;
}

export const portfolioData = {
  personal: {
    name: "NOVA LEE.",
    profession: "NHÀ THIẾT KẾ UI/UX",
    eyebrow: "XIN CHÀO, TÔI LÀ",
    description: "Tôi chuyên thiết kế những trải nghiệm số hiện đại, trực quan và lấy người dùng làm trung tâm. Tôi giúp các thương hiệu biến ý tưởng thành những sản phẩm có giá trị thông qua tư duy thiết kế sáng tạo và giao diện tinh tế.",
    handwrittenNote: "Thiết kế trải nghiệm tốt hơn",
    experienceYears: "3+",
    experienceLabel: "Năm kinh nghiệm",
    email: "nova.lee.design@example.com",
    calendarUrl: "https://calendar.google.com",
    socialLinks: [
      { name: "LinkedIn", icon: "Linkedin", url: "https://linkedin.com" },
      { name: "Dribbble", icon: "Dribbble", url: "https://dribbble.com" },
      { name: "Instagram", icon: "Instagram", url: "https://instagram.com" },
      { name: "GitHub", icon: "Github", url: "https://github.com" },
    ],
  },
  about: {
    eyebrow: "GIỚI THIỆU BẢN THÂN",
    title: "MỘT NHÀ THIẾT KẾ TẬN TÂM VỚI CON NGƯỜI VÀ TỪNG CHI TIẾT",
    quote: "“ Biến ý tưởng thành những trải nghiệm số có sức lan tỏa mạnh mẽ. ”",
    bio: "Tôi là Nova, một nhà thiết kế UI/UX làm việc với các đối tác toàn cầu. Tôi chuyên xây dựng các sản phẩm kỹ thuật số tinh gọn, hiện đại và lấy người dùng làm trọng tâm. Với nền tảng vững chắc về thiết kế thị giác cùng niềm đam mê giải quyết vấn đề, tôi luôn hào hứng chuyển hóa những ý tưởng phức tạp thành những trải nghiệm đơn giản và đẹp mắt.",
    extendedBio: "Trong hơn 3 năm qua, tôi đã đồng hành cùng các startup công nghệ, các công ty fintech phát triển nhanh và những agency định hướng thiết kế hàng đầu. Quy trình làm việc của tôi cân bằng giữa nghiên cứu người dùng thấu cảm và sự trau chuốt tỉ mỉ về kiểu chữ, bố cục và hệ thống thị giác. Tôi tin rằng một phần mềm tốt không chỉ cần vận hành hiệu quả mà còn phải mang lại niềm vui thực sự cho người sử dụng.",
    statistics: [
      { value: "3+", label: "Năm kinh nghiệm" },
      { value: "50+", label: "Dự án hoàn thành" },
      { value: "30+", label: "Khách hàng hài lòng" },
      { value: "5★", label: "Đánh giá trung bình" },
    ],
    skillsSummary: [
      "Hệ thống thiết kế Figma (Design Systems)",
      "Bản đồ hành trình người dùng (Journey Mapping)",
      "Tạo mẫu tương tác nhanh (Interactive Prototyping)",
      "Thiết kế kỹ thuật (Design Engineering)",
      "Tiêu chuẩn tiếp cận toàn diện (WCAG 2.1)"
    ],
  },
  brands: [
    { name: "logoipsum", category: "Công nghệ" },
    { name: "Spherule", category: "Fintech" },
    { name: "Lightbox", category: "Phân tích dữ liệu" },
    { name: "GlobalBank", category: "Ngân hàng" },
    { name: "Nietzsche", category: "Phòng nghiên cứu thiết kế" },
    { name: "PixelHub", category: "Studio truyền thông" },
  ] as Brand[],
  projects: [
    {
      id: "finance-app",
      title: "Thiết Kế Ứng Dụng Tài Chính",
      category: "Thiết kế UI/UX",
      platform: "Ứng dụng di động",
      headline: "Smarter Banking for a Brighter Future",
      tagline: "Ứng dụng quản lý tài chính và tài sản cá nhân thế hệ mới",
      description: "Trải nghiệm ngân hàng di động hiện đại với giao dịch trực quan và thông tin tài chính rõ ràng, minh bạch.",
      fullOverview: "Dự án tái thiết kế toàn diện ứng dụng fintech phục vụ hơn 250.000 người dùng tích cực. Trọng tâm nhằm đơn giản hóa việc quản lý danh mục tài chính phức tạp, tăng tốc thao tác chuyển tiền tức thời và cung cấp biểu đồ chi tiêu thông minh kèm bảo mật sinh trắc học mượt mà.",
      challenge: "Người dùng cảm thấy ngợp trước hệ thống danh mục ngân hàng rườm rà, thông báo xác nhận giao dịch chậm trễ và số dư đa tiền tệ phân tán.",
      solution: "Xây dựng hệ thống ví thẻ dạng vuốt trực quan, chuyển tiền nhanh chỉ với một chạm, và dự báo chi tiêu tự động với biểu đồ tương phản cao đạt chuẩn trợ năng.",
      results: [
        "+38% lượng giao dịch hàng ngày tăng trưởng",
        "4.9/5 sao đánh giá từ hơn 15.000 lượt nhận xét trên App Store",
        "-45% yêu cầu hỗ trợ khách hàng về tra cứu số dư"
      ],
      tools: ["Figma", "Thiết kế UI", "Tạo mẫu Prototype", "Nguyên tắc iOS Human Interface", "Vi tương tác"],
      previewType: "finance",
      client: "GlobalBank & VaultPay",
      year: "2025",
      deliverables: ["Giao diện Mobile App hoàn chỉnh", "Prototype Figma tương tác", "Hệ thống Design System (hơn 50 components)", "Báo cáo thử nghiệm người dùng"]
    },
    {
      id: "saas-platform",
      title: "Thiết Kế Nền Tảng SaaS",
      category: "Thiết kế UI/UX",
      platform: "Website",
      headline: "The All-in-One Platform for Modern Teams",
      tagline: "Cổng giám sát hạ tầng đám mây và phân tích chỉ số vận hành",
      description: "Nền tảng SaaS đám mây hiện đại với giao diện tương thích đa thiết bị và biểu đồ phân tích trực quan.",
      fullOverview: "Dashboard doanh nghiệp cấp cao được thiết kế riêng cho các đội ngũ kỹ thuật và DevOps đám mây. Tích hợp dữ liệu giám sát máy chủ thời gian thực, bảng điều khiển dạng module linh hoạt và không gian làm việc nhóm gắn kết.",
      challenge: "Sản phẩm cũ có tỷ lệ rời bỏ cao do giao diện tải chậm, phân cấp thông tin biểu đồ chưa khoa học và điều hướng đa người dùng phức tạp.",
      solution: "Thiết lập hệ thống thiết kế ưu tiên giao diện Dark Mode với các thành phần biểu đồ tùy biến module, thẻ cảnh báo thông minh và bảng làm việc cá nhân hóa cho từng kỹ sư.",
      results: [
        "+52% tỷ lệ hoàn tất quy trình onboarding người dùng mới",
        "Giảm 40% thời gian tiếp cận thông tin cho kỹ sư DevOps",
        "Được áp dụng làm Design System chuẩn mực cho 4 dòng sản phẩm chính"
      ],
      tools: ["Figma", "Design System", "Dashboard UI", "Trực quan hóa dữ liệu", "Tailwind CSS"],
      previewType: "saas",
      client: "Spherule Cloud Systems",
      year: "2024",
      deliverables: ["Giao diện Web Application", "Bộ thư viện Component", "Quy chuẩn trực quan hóa dữ liệu", "Trang Landing Page truyền thông"]
    },
    {
      id: "ecommerce",
      title: "Website Thương Mại Điện Tử",
      category: "Thiết kế UI/UX",
      platform: "Website",
      headline: "Premium Essentials For a Better You",
      tagline: "Gian hàng trực tuyến đẳng cấp dành cho dòng tai nghe phòng thu không dây",
      description: "Trải nghiệm mua sắm trực tuyến cao cấp, mượt mà dành cho các thiết bị âm thanh thế hệ mới.",
      fullOverview: "Cửa hàng thương mại điện tử phong cách sống sang trọng dành cho thương hiệu âm thanh chuẩn phòng thu. Tích hợp không gian trưng bày sản phẩm 360 độ sống động, công cụ so sánh cấu hình âm học và quy trình thanh toán siêu tốc không rào cản.",
      challenge: "Tỷ lệ bỏ rơi giỏ hàng trên di động còn cao và người dùng ít tương tác với các thông số kỹ thuật âm thanh chuyên sâu của sản phẩm.",
      solution: "Thiết kế bố cục thị giác tối giản ưu tiên hình ảnh chất lượng cao, biểu đồ dải tần âm thanh trực quan và nút mua nhanh cố định trên màn hình di động.",
      results: [
        "+64% tỷ lệ chuyển đổi thanh toán trên thiết bị di động",
        "Tăng 2.4 lần thời gian lưu lại trung bình trên trang chi tiết sản phẩm",
        "Được đề cử trong danh sách Site of the Day của Awwwards"
      ],
      tools: ["Figma", "Thương mại điện tử", "Responsive Design", "Phối cảnh sản phẩm 3D", "Chiến lược UX"],
      previewType: "ecommerce",
      client: "Aura Acoustic Labs",
      year: "2024",
      deliverables: ["Giao diện Web tương thích mọi thiết bị", "Quy trình thanh toán di động", "Trình tùy biến âm thanh", "Mẫu Email marketing chuẩn thương hiệu"]
    },
    {
      id: "crypto-wallet",
      title: "Ví Web3 & Sàn Giao Dịch DeFi",
      category: "Thiết kế UI/UX",
      platform: "Ứng dụng di động",
      headline: "Decentralized Wealth, Simplified",
      tagline: "Trình quản lý tài sản kỹ thuật số bảo mật chuẩn phi tập trung",
      description: "Giao diện ví Web3 thân thiện, ưu tiên bảo mật hàng đầu giúp tài chính phi tập trung trở nên dễ tiếp cận với mọi người.",
      fullOverview: "Ứng dụng quản lý tài sản mã hóa tinh giản giúp loại bỏ các chuỗi địa chỉ hash phức tạp bằng tên người dùng thân thiện và xác thực giao dịch sinh trắc học.",
      challenge: "Người dùng thường cảm thấy lo lắng và dễ gặp lỗi thao tác khi tương tác với các hợp đồng thông minh (smart contracts).",
      solution: "Thiết kế bảng xem trước giao dịch trực quan, thang đo mức độ rủi ro rõ ràng và quy trình sao lưu khôi phục cụm từ khóa dễ hiểu.",
      results: [
        "Bảo vệ hơn 120 triệu USD khối lượng tài sản luân chuyển",
        "Không ghi nhận sự cố thất thoát nào do lỗi thao tác giao diện"
      ],
      tools: ["Figma", "Giao diện di động", "Sơ đồ luồng người dùng", "Bảo mật UI"],
      previewType: "custom",
      client: "CipherLabs",
      year: "2024",
      deliverables: ["UI iOS/Android", "Design Tokens", "Hướng dẫn an toàn giao dịch"]
    },
    {
      id: "healthcare-telemed",
      title: "Hệ Thống Y Tế Từ Xa PulseHealth",
      category: "Thiết kế UI/UX",
      platform: "Website",
      headline: "Healthcare Anywhere, Anytime",
      tagline: "Tư vấn sức khỏe trực tuyến và quản lý hồ sơ y khoa số",
      description: "Cổng y tế từ xa tiện lợi, kết nối bệnh nhân với các bác sĩ chuyên khoa chỉ trong vòng vài phút.",
      fullOverview: "Giao diện y tế ưu tiên bệnh nhân được thiết kế đáp ứng tiêu chuẩn tương phản khắt khe WCAG AAA, hỗ trợ tối đa cho người lớn tuổi và người không rành công nghệ.",
      challenge: "Bệnh nhân gặp khó khăn khi thiết lập cuộc gọi video khám bệnh và khó tìm lại đơn thuốc kỹ thuật số của mình.",
      solution: "Tạo các nút điều hướng kích thước lớn, trình hướng dẫn kiểm tra âm thanh - camera từng bước và liên kết lấy thuốc trực tiếp tại nhà thuốc gần nhất.",
      results: [
        "98.4% điểm hài lòng từ bệnh nhân",
        "Giảm thời gian trễ bắt đầu cuộc tư vấn từ 6 phút xuống còn 45 giây"
      ],
      tools: ["Figma", "Healthcare UX", "Tiêu chuẩn tiếp cận (WCAG)", "Prototyping"],
      previewType: "custom",
      client: "Pulse Health Group",
      year: "2025",
      deliverables: ["Cổng bệnh nhân", "Dashboard bác sĩ", "Kiểm định tiếp cận WCAG"]
    },
    {
      id: "ai-copilot-design",
      title: "Không Gian Sáng Tạo Synthetix AI",
      category: "Thiết kế UI/UX",
      platform: "Design System",
      headline: "Generative AI For Enterprise Creators",
      tagline: "Không gian làm việc cộng tác sáng tạo tích hợp AI doanh nghiệp",
      description: "Không gian vẽ vô hạn (infinite canvas) nơi đội ngũ marketing cùng đồng sáng tạo nội dung, hình ảnh và chiến dịch với mô hình ngôn ngữ lớn.",
      fullOverview: "Thiết kế mô hình tương tác kết nối dạng nút (node-based) cho chuỗi prompt và hiển thị kết quả tạo mẫu thời gian thực.",
      challenge: "Kỹ thuật prompt AI quá phức tạp và thiếu cấu trúc trực quan đối với các giám đốc sáng tạo.",
      solution: "Xây dựng các khối ghép prompt trực quan, tính năng tua lại lịch sử chỉnh sửa và xuất tài nguyên sang Figma chỉ với một cú nhấp chuột.",
      results: [
        "Được 85 thương hiệu doanh nghiệp ứng dụng ngay trong 60 ngày thử nghiệm đầu tiên"
      ],
      tools: ["Figma", "Hệ thống thiết kế", "Mẫu tương tác AI", "Giao diện Canvas"],
      previewType: "custom",
      client: "Synthetix Technologies",
      year: "2025",
      deliverables: ["Giao diện Canvas", "Bộ thành phần Prompt Engine", "Design Tokens"]
    }
  ] as Project[],
  services: [
    {
      id: "ui-design",
      iconName: "LayoutDashboard",
      title: "Thiết Kế UI",
      shortDescription: "Giao diện người dùng tinh tế, hiện đại và chuẩn xác đến từng pixel cho ứng dụng web và di động.",
      fullDescription: "Tôi xây dựng các giao diện kỹ thuật số kết hợp hài hòa giữa nét thẩm mỹ sang trọng và tính thực dụng cao. Từng pixel, tỷ lệ phân cấp chữ, khoảng cách đệm và trạng thái tương tác đều được căn chỉnh tỉ mỉ nhằm đem đến trải nghiệm trực quan, tôn vinh thương hiệu của bạn ở tầm cao nhất.",
      deliverables: [
        "Thiết kế UI độ trung thực cao (Mobile & Desktop)",
        "Hệ thống Design System & Tokens toàn diện trên Figma",
        "Mẫu Prototype tương tác với hiệu ứng chuyển cảnh mượt mà",
        "Tài liệu thông số kỹ thuật chuẩn sẵn sàng bàn giao lập trình"
      ],
      process: [
        "1. Xây dựng Moodboard & Định hướng thị giác",
        "2. Thiết kế Wireframe & Phân cấp cấu trúc",
        "3. Hoàn thiện giao diện UI chi tiết cao",
        "4. Tạo mẫu Prototype & Bàn giao phát triển"
      ],
      tools: ["Figma", "Tokens Studio", "Adobe Illustrator", "Principle"]
    },
    {
      id: "ux-research",
      iconName: "SearchCheck",
      title: "Nghiên Cứu UX",
      shortDescription: "Nghiên cứu và chiến lược lấy người dùng làm trung tâm để kiến tạo những sản phẩm được yêu thích.",
      fullDescription: "Một thiết kế xuất sắc luôn bắt đầu từ sự thấu cảm sâu sắc với người dùng. Thông qua việc phân tích số liệu hành vi định lượng kết hợp phỏng vấn sâu định tính, tôi giúp xác định chính xác điểm nghẽn trải nghiệm, kiểm chứng giả thuyết và định hình kiến trúc sản phẩm biến khách ghé thăm thành khách hàng trung thành.",
      deliverables: [
        "Hồ sơ chân dung người dùng (User Personas) & Bản đồ thấu cảm",
        "Kiến trúc thông tin (IA) & Sơ đồ luồng người dùng",
        "Báo cáo kiểm thử khả năng sử dụng & Điểm ma sát trải nghiệm",
        "Phân tích đối thủ cạnh tranh & Đánh giá khoảng trống thị trường"
      ],
      process: [
        "1. Phỏng vấn khám phá cùng các bên liên quan",
        "2. Khảo sát người dùng & Kiểm toán hành vi thực tế",
        "3. Tổng hợp dữ liệu & Xây dựng bản đồ hành trình",
        "4. Kiểm định giả thuyết & Thử nghiệm khả năng sử dụng"
      ],
      tools: ["Miro", "Hotjar", "Maze", "UserTesting", "Figma"]
    },
    {
      id: "branding",
      iconName: "Gem",
      title: "Nhận Diện Thương Hiệu",
      shortDescription: "Hệ thống nhận diện thương hiệu ấn tượng, nhất quán và để lại dấu ấn sâu sắc.",
      fullDescription: "Chuyển hóa sứ mệnh và giá trị cốt lõi của doanh nghiệp thành một hệ thống nhận diện thị giác không thể hòa lẫn. Tôi sáng tạo những biểu tượng thương hiệu cuốn hút, tỏa sáng đồng bộ trên mọi nền tảng từ ứng dụng di động, mạng xã hội đến ấn phẩm truyền thông.",
      deliverables: [
        "Hệ thống Logo chính và phụ định dạng chuẩn Vector (SVG/AI)",
        "Bộ cẩm nang quy chuẩn nhận diện thương hiệu (Brand Guidelines)",
        "Bảng màu sắc, quy chuẩn kiểu chữ và bộ biểu tượng đồng bộ",
        "Bộ mẫu thiết kế mạng xã hội và slide thuyết trình chuyên nghiệp"
      ],
      process: [
        "1. Khám phá thương hiệu & Phân tích bối cảnh ngành",
        "2. Phác thảo ý tưởng & Khám phá biểu tượng",
        "3. Tinh chỉnh và hoàn thiện hệ thống nhận diện",
        "4. Đóng gói cẩm nang thương hiệu & Bàn giao tài nguyên"
      ],
      tools: ["Adobe Illustrator", "Photoshop", "Figma", "FontLab"]
    },
    {
      id: "web-design",
      iconName: "Monitor",
      title: "Thiết Kế Website",
      shortDescription: "Website thích ứng đa nền tảng, tốc độ cao và tối ưu tỷ lệ chuyển đổi theo mục tiêu của bạn.",
      fullDescription: "Kiến tạo các trang đích (landing page), website doanh nghiệp và cổng thông tin hiện đại với tỷ lệ chuyển đổi cao. Được thiết kế chuẩn SEO, tối ưu tốc độ tải trang vượt trội và hiển thị mượt mà trên mọi kích thước màn hình từ điện thoại đến màn hình siêu rộng.",
      deliverables: [
        "Giao diện Web thích ứng toàn diện (Desktop, Tablet, Mobile)",
        "Bố cục trang đích tối ưu hóa chuyển đổi (Conversion-focused)",
        "Vi tương tác và kịch bản hoạt họa cuộn trang sinh động",
        "Cấu trúc thành phần sẵn sàng chuyển giao mã nguồn Tailwind CSS / React"
      ],
      process: [
        "1. Lên khung Wireframe chiến lược & Kế hoạch chuyển đổi",
        "2. Thiết kế thị giác & Chỉ đạo phong cách nghệ thuật",
        "3. Tạo mẫu tương tác người dùng",
        "4. Chuyển ngữ sang cấu trúc mã nguồn tối ưu"
      ],
      tools: ["Figma", "Tailwind CSS", "React", "Framer Motion", "Lottie"]
    }
  ] as Service[],
  skills: [
    { name: "Figma", iconLabel: "Figma", percentage: 95, category: "Design", color: "#0ACF83" },
    { name: "Adobe XD", iconLabel: "Xd", percentage: 90, category: "Design", color: "#FF61F6" },
    { name: "Photoshop", iconLabel: "Ps", percentage: 85, category: "Design", color: "#31A8FF" },
    { name: "Illustrator", iconLabel: "Ai", percentage: 80, category: "Design", color: "#FF9A00" },
    { name: "HTML / CSS", iconLabel: "HTML CSS", percentage: 85, category: "Development", color: "#E44D26" },
    { name: "React", iconLabel: "React", percentage: 75, category: "Development", color: "#61DAFB" },
  ] as Skill[],
  testimonials: [
    {
      id: "daniel-kim",
      name: "Daniel Kim",
      role: "CEO, Spherule",
      company: "Spherule",
      rating: 5,
      text: "Nova đã mang đến một hệ thống thiết kế xuất sắc vượt ngoài mong đợi cho sản phẩm của chúng tôi. Tác phong cực kỳ chuyên nghiệp, sáng tạo và rất ăn ý trong suốt quá trình hợp tác!",
      avatarSeed: "Daniel"
    },
    {
      id: "sarah-chen",
      name: "Sarah Chen",
      role: "Giám đốc Sản phẩm, Lightbox",
      company: "Lightbox",
      rating: 5,
      text: "Sự tỉ mỉ đến từng chi tiết và khả năng thấu hiểu người dùng của Nova thật sự đáng kinh ngạc. Tỷ lệ chuyển đổi của chúng tôi đã tăng trưởng tới 40% sau khi áp dụng thiết kế mới!",
      avatarSeed: "Sarah"
    },
    {
      id: "michael-torres",
      name: "Michael Torres",
      role: "Nhà sáng lập, PixelHub",
      company: "PixelHub",
      rating: 5,
      text: "Làm việc cùng Nova là một trải nghiệm tuyệt vời. Các bản thiết kế vừa hiện đại, sang trọng lại vừa lấy trải nghiệm của người dùng làm trung tâm một cách thực thụ.",
      avatarSeed: "Michael"
    },
    {
      id: "elena-rostova",
      name: "Elena Rostova",
      role: "Trưởng bộ phận Sản phẩm, VaultPay",
      company: "VaultPay",
      rating: 5,
      text: "Nova đã biến luồng nghiệp vụ tài chính phức tạp thành một trải nghiệm ngân hàng nhẹ nhàng, trực quan. Tỷ lệ giữ chân người dùng của chúng tôi tăng rõ rệt chỉ sau vài tuần triển khai.",
      avatarSeed: "Elena"
    }
  ] as Testimonial[],
  missingAssets: [
    {
      id: "heroPortrait",
      name: "Ảnh chân dung Hero của Nova Lee",
      spec: "Nữ thiết kế trẻ, đeo kính, áo hoodie trắng, tóc dài búi nhỏ, tư thế chống cằm, nền trong suốt",
      status: "Hiện được kết xuất dưới dạng đồ họa vector SVG độ nét cao đúng tư thế, trang phục và kích thước hiển thị.",
      recommendedResolution: "1000 x 1200 px (PNG nền trong suốt alpha)"
    },
    {
      id: "aboutPortrait",
      name: "Ảnh chân dung About Me của Nova Lee",
      spec: "Cùng nhân vật nữ đứng khoanh tay mỉm cười, đeo kính, áo hoodie trắng, đặt trong khung 380x400",
      status: "Hiện được kết xuất đồng bộ phong cách với ảnh Hero ở tư thế khoanh tay chuẩn xác.",
      recommendedResolution: "800 x 900 px (PNG/WebP)"
    },
    {
      id: "projectFinance",
      name: "Mockup Ứng dụng Tài chính (Smarter Banking for a Brighter Future)",
      spec: "Tỷ lệ khung hình 16:10, màn hình ngân hàng di động, số dư, đồ thị và dải gradient xanh tím thanh lịch",
      status: "Được xây dựng dưới dạng thumbnail UI vector tương tác chuẩn 16:10 đúng thiết kế tham chiếu.",
      recommendedResolution: "1280 x 800 px (WebP 16:10)"
    },
    {
      id: "projectSaas",
      name: "Mockup Bảng điều khiển SaaS (The All-in-One Platform for Modern Teams)",
      spec: "Tỷ lệ khung hình 16:10, dashboard phân tích dữ liệu nền navy đậm với biểu đồ xanh dương sắc nét",
      status: "Được xây dựng dưới dạng thumbnail UI vector tương tác chuẩn 16:10 đúng thiết kế tham chiếu.",
      recommendedResolution: "1280 x 800 px (WebP 16:10)"
    },
    {
      id: "projectEcommerce",
      name: "Mockup Thương mại điện tử (Premium Essentials For a Better You)",
      spec: "Tỷ lệ khung hình 16:10, gian hàng tai nghe sang trọng với kiểu chữ tinh tế và nút đặt mua",
      status: "Được xây dựng dưới dạng thumbnail UI vector tương tác chuẩn 16:10 đúng thiết kế tham chiếu.",
      recommendedResolution: "1280 x 800 px (WebP 16:10)"
    }
  ]
};
