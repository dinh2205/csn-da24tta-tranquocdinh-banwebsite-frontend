/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CategoryId, Article, HotNewsItem } from './types';
import {
  CATEGORIES,
  ARTICLES,
  HOME_HOT_NEWS,
  TECH_HOT_NEWS,
  EDU_HOT_NEWS,
  TAGS_HOME,
  TAGS_TECH,
  TAGS_EDU,
} from './data/newsData';
import { TopBar } from './components/TopBar';
import { MainHeader } from './components/MainHeader';
import { MainNavigation } from './components/MainNavigation';
import { HomeView } from './components/HomeView';
import { CategoryView } from './components/CategoryView';
import { ArticleDetailModal } from './components/ArticleDetailModal';
import { MainFooter } from './components/MainFooter';
import { BookmarksModal } from './components/BookmarksModal';
import { InfoModal } from './components/InfoModal';
import { SearchResultsModal } from './components/SearchResultsModal';
import { Toast } from './components/Toast';

export default function App() {
  const [currentCategory, setCurrentCategory] = useState<CategoryId>('home');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Article[]>([]);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [bookmarks, setBookmarks] = useState<Article[]>(() => {
    try {
      const saved = localStorage.getItem('bt24h_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [showBookmarksModal, setShowBookmarksModal] = useState(false);
  const [infoModalType, setInfoModalType] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync bookmarks to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bt24h_bookmarks', JSON.stringify(bookmarks));
    } catch {
      // Ignore localStorage errors
    }
  }, [bookmarks]);

  // Handle Category Switch
  const handleSelectCategory = (catId: CategoryId) => {
    setCurrentCategory(catId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle Search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setSearchResults([]);
      setShowSearchModal(false);
      return;
    }
    const q = query.toLowerCase().trim();
    const matches = ARTICLES.filter(
      (a) =>
        a.title.toLowerCase().includes(q) ||
        a.excerpt.toLowerCase().includes(q) ||
        (a.subCategory && a.subCategory.toLowerCase().includes(q)) ||
        (a.tags && a.tags.some((t) => t.toLowerCase().includes(q)))
    );
    setSearchResults(matches);
    setShowSearchModal(true);
  };

  // Handle Tag Selection from Sidebar or Footer
  const handleSelectTag = (tag: string) => {
    if (tag === 'tin-nong') {
      showToast('Đang hiển thị các bài viết dòng sự kiện nóng nhất');
      return;
    }
    const cleanTag = tag.replace('#', '');
    handleSearch(cleanTag);
  };

  // Handle Hot News Selection
  const handleSelectHotNews = (item: HotNewsItem) => {
    // Find matching article or create viewable article from item
    const match = ARTICLES.find((a) => a.title.includes(item.title.substring(0, 20))) || {
      id: `hn-${item.id}`,
      title: item.title,
      excerpt: `Tin nóng cập nhật: ${item.title}. Đang thu hút sự quan tâm lớn của bạn đọc.`,
      category: item.category || 'thoi-su',
      categoryLabel: 'TIN NÓNG',
      imageUrl:
        item.category === 'cong-nghe'
          ? 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_6fR99syqZ2XtTTcCkyrem7pcdcRTGpqJ0xokZ-f_n18iQxh-nWFrCuRmyeza47eN1_vcNIIjno2aPmKccrsa-xdsvFbQL2JlBayFKBE4KkWzxEJvgL5tbzCTm__WQNOGmG7m95frI0OAUysb_VOl_HGffBWYrgfglH2zDH5JVe0X2Xft7gFKbLozZfv8qLFpY9Hg-Z22_eFj-GpydpLQXGJB5iRhmxXZIGo0Epr7WwZsFfBKwP14'
          : 'https://lh3.googleusercontent.com/aida-public/AB6AXuCYVOfqLYxhSzkYI99NDdgR12C3_4oIuAAU8Rkl1QYia91qXma5xSgs-0Tly_gxny-mnr8tLl3w2EUH6qyB3G9BZqghFex1Rqa0NLguAZHy8D4zNTSSfYWX-avynntjkWjze6Bc2an0Klh__k8dnDAp57tPelAq3XU5YZW72dnZQhN5FlID5wwic_z_thNhipQARu6HBFXe_m--H-V998Y8xnh__AVCxFwLTWvNhd0xppDSzGaBsFb5',
      imageAlt: item.title,
      publishedAt: item.timeAgo,
      commentsCount: 15,
      content: [
        `Nội dung tiêu điểm: ${item.title}.`,
        'Các cơ quan chức năng và đơn vị liên quan đang khẩn trương triển khai các biện pháp nghiệp vụ, bảo đảm thông tin thông suốt và kịp thời.',
        'Bản Tin 24H sẽ tiếp tục cập nhật những diễn biến mới nhất của sự việc đến quý độc giả.',
      ],
    };
    setSelectedArticle(match);
  };

  // Bookmark Toggle
  const handleToggleBookmark = (art: Article) => {
    const exists = bookmarks.some((b) => b.id === art.id);
    if (exists) {
      setBookmarks(bookmarks.filter((b) => b.id !== art.id));
      showToast('Đã bỏ lưu bài viết');
    } else {
      setBookmarks([art, ...bookmarks]);
      showToast('Đã lưu bài viết vào danh sách đọc sau');
    }
  };

  const handleRemoveBookmark = (artId: string) => {
    setBookmarks(bookmarks.filter((b) => b.id !== artId));
    showToast('Đã xóa khỏi bài viết đã lưu');
  };

  const handleClearAllBookmarks = () => {
    setBookmarks([]);
    showToast('Đã xóa toàn bộ bài viết đã lưu');
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Articles filtered by current category
  const currentCategoryData = CATEGORIES.find((c) => c.id === currentCategory) || CATEGORIES[1];

  const getCategoryArticles = () => {
    if (currentCategory === 'cong-nghe') {
      const hero = ARTICLES.find((a) => a.id === 'art-tech-hero');
      const list = ARTICLES.filter((a) => a.category === 'cong-nghe' && a.id !== 'art-tech-hero');
      return {
        hero,
        list,
        hotNews: TECH_HOT_NEWS,
        tags: TAGS_TECH,
        totalCount: 128,
      };
    }

    if (currentCategory === 'giao-duc') {
      const hero = ARTICLES.find((a) => a.id === 'art-edu-hero');
      const list = ARTICLES.filter((a) => a.category === 'giao-duc' && a.id !== 'art-edu-hero');
      return {
        hero,
        list,
        hotNews: EDU_HOT_NEWS,
        tags: TAGS_EDU,
        totalCount: 142,
      };
    }

    // For other categories (thoi-su, doi-song, etc.)
    const categoryMatches = ARTICLES.filter((a) => a.category === currentCategory);
    const hero = categoryMatches.find((a) => a.isHero) || categoryMatches[0] || ARTICLES[0];
    const list = categoryMatches.length > 1 ? categoryMatches.filter((a) => a.id !== hero.id) : ARTICLES.slice(1, 5);

    return {
      hero,
      list,
      hotNews: HOME_HOT_NEWS,
      tags: TAGS_HOME,
      totalCount: 96,
    };
  };

  const { hero, list, hotNews, tags, totalCount } = getCategoryArticles();

  // Home specific content
  const homeHero = ARTICLES.find((a) => a.id === 'art-home-hero') || ARTICLES[0];
  const homeStacked = [
    ARTICLES.find((a) => a.id === 'art-home-stack-1')!,
    ARTICLES.find((a) => a.id === 'art-home-stack-2')!,
    ARTICLES.find((a) => a.id === 'art-home-stack-3')!,
  ].filter(Boolean);

  const homeFeatured = [
    ARTICLES.find((a) => a.id === 'art-home-feat-1')!,
    ARTICLES.find((a) => a.id === 'art-home-feat-2')!,
    ARTICLES.find((a) => a.id === 'art-home-feat-3')!,
    ARTICLES.find((a) => a.id === 'art-home-feat-4')!,
  ].filter(Boolean);

  // Quick switch buttons bar for reviewing all 3 user screens directly
  return (
    <div className="bg-slate-50 min-h-screen flex flex-col antialiased text-slate-800 font-sans">
      {/* Top Banner Quick View Selector (Helps user instantly view the 3 provided screen templates) */}
      <div className="bg-[#081a31] text-slate-300 py-1 px-4 text-[11px] border-b border-slate-700/80">
        <div className="max-w-[1400px] mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white">Chuyển nhanh giao diện mẫu:</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleSelectCategory('cong-nghe')}
              className={`px-2.5 py-0.5 rounded cursor-pointer transition-all ${
                currentCategory === 'cong-nghe'
                  ? 'bg-red-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Màn hình 1: Chuyên mục Công nghệ
            </button>
            <button
              onClick={() => handleSelectCategory('giao-duc')}
              className={`px-2.5 py-0.5 rounded cursor-pointer transition-all ${
                currentCategory === 'giao-duc'
                  ? 'bg-red-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Màn hình 2: Chuyên mục Giáo dục
            </button>
            <button
              onClick={() => handleSelectCategory('home')}
              className={`px-2.5 py-0.5 rounded cursor-pointer transition-all ${
                currentCategory === 'home'
                  ? 'bg-red-600 text-white font-bold'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Màn hình 3: Trang chủ Bản Tin 24H
            </button>
          </div>
        </div>
      </div>

      {/* Top utility bar */}
      <TopBar
        onOpenBookmarks={() => setShowBookmarksModal(true)}
        bookmarksCount={bookmarks.length}
        onOpenAbout={() => setInfoModalType('about')}
        onOpenContact={() => setInfoModalType('contact')}
        onOpenAds={() => setInfoModalType('ads')}
      />

      {/* Main Header with Logo & Search */}
      <MainHeader
        onSearch={handleSearch}
        onNavigateHome={() => handleSelectCategory('home')}
        searchQuery={searchQuery}
      />

      {/* Main Sticky Navigation */}
      <MainNavigation
        currentCategory={currentCategory}
        onSelectCategory={handleSelectCategory}
      />

      {/* Main Content Body */}
      <main className="max-w-[1400px] mx-auto px-4 lg:px-8 py-6 flex-grow w-full">
        {currentCategory === 'home' ? (
          <HomeView
            heroArticle={homeHero}
            stackedArticles={homeStacked}
            featuredArticles={homeFeatured}
            onSelectArticle={(art) => setSelectedArticle(art)}
            onSelectTag={handleSelectTag}
            onSelectHotNews={handleSelectHotNews}
            onSubscribeNewsletter={() =>
              showToast('Đăng ký nhận bản tin thành công! Cảm ơn bạn.')
            }
            onViewAllFeatured={() => handleSelectCategory('kinh-te')}
          />
        ) : (
          <CategoryView
            category={currentCategoryData}
            heroArticle={hero}
            articles={list}
            hotNews={hotNews}
            tags={tags}
            totalArticlesCount={totalCount}
            onSelectArticle={(art) => setSelectedArticle(art)}
            onNavigateHome={() => handleSelectCategory('home')}
            onSelectTag={handleSelectTag}
            onSelectHotNews={handleSelectHotNews}
            onSubscribeNewsletter={() =>
              showToast('Đăng ký nhận bản tin thành công! Cảm ơn bạn.')
            }
          />
        )}
      </main>

      {/* Main Footer */}
      <MainFooter
        onSelectCategory={handleSelectCategory}
        onOpenPolicy={(type) => setInfoModalType(type)}
      />

      {/* Article Detail Reader Modal */}
      {selectedArticle && (
        <ArticleDetailModal
          article={selectedArticle}
          onClose={() => setSelectedArticle(null)}
          onSelectArticle={(art) => setSelectedArticle(art)}
          isBookmarked={bookmarks.some((b) => b.id === selectedArticle.id)}
          onToggleBookmark={handleToggleBookmark}
          relatedArticles={ARTICLES.filter(
            (a) => a.id !== selectedArticle.id && a.category === selectedArticle.category
          )}
        />
      )}

      {/* Bookmarks Modal */}
      {showBookmarksModal && (
        <BookmarksModal
          bookmarks={bookmarks}
          onClose={() => setShowBookmarksModal(false)}
          onSelectArticle={(art) => setSelectedArticle(art)}
          onRemoveBookmark={handleRemoveBookmark}
          onClearAll={handleClearAllBookmarks}
        />
      )}

      {/* Search Results Modal */}
      {showSearchModal && (
        <SearchResultsModal
          query={searchQuery}
          results={searchResults}
          onClose={() => setShowSearchModal(false)}
          onSelectArticle={(art) => setSelectedArticle(art)}
        />
      )}

      {/* Information / Policy Modal */}
      {infoModalType && (
        <InfoModal type={infoModalType} onClose={() => setInfoModalType(null)} />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
      )}
    </div>
  );
}
