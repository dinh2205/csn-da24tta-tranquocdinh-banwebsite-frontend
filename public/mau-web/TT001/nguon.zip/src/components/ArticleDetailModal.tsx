import React, { useState, useEffect } from 'react';
import { Article, Comment } from '../types';
import { Bookmark, Share2, Volume2, VolumeX, Heart, MessageSquare, ArrowLeft } from 'lucide-react';

interface ArticleDetailModalProps {
  article: Article;
  onClose: () => void;
  onSelectArticle: (article: Article) => void;
  isBookmarked: boolean;
  onToggleBookmark: (article: Article) => void;
  relatedArticles: Article[];
}

export const ArticleDetailModal: React.FC<ArticleDetailModalProps> = ({
  article,
  onClose,
  onSelectArticle,
  isBookmarked,
  onToggleBookmark,
  relatedArticles,
}) => {
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [comments, setComments] = useState<Comment[]>(
    article.comments || [
      {
        id: 'c-default-1',
        author: 'Độc giả 24H',
        content: 'Bài viết rất chất lượng, phân tích sâu sắc và bám sát thực tiễn hiện nay.',
        timestamp: 'Vừa xong',
        likes: 5,
      },
    ]
  );
  const [authorName, setAuthorName] = useState('');
  const [commentText, setCommentText] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const newComment: Comment = {
      id: `c-${Date.now()}`,
      author: authorName.trim() || 'Bạn đọc ẩn danh',
      content: commentText.trim(),
      timestamp: 'Vừa xong',
      likes: 0,
    };

    setComments([newComment, ...comments]);
    setCommentText('');
  };

  const handleLikeComment = (commentId: string) => {
    setComments((prev) =>
      prev.map((c) => (c.id === commentId ? { ...c, likes: c.likes + 1 } : c))
    );
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const fontSizeClass =
    fontSize === 'normal'
      ? 'text-base leading-relaxed'
      : fontSize === 'large'
      ? 'text-lg leading-loose'
      : 'text-xl leading-loose';

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs overflow-y-auto flex justify-center p-2 sm:p-4 md:p-6">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Top Sticky Bar */}
        <div className="bg-white border-b border-slate-200 px-4 sm:px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <button
            onClick={onClose}
            className="flex items-center space-x-1.5 text-slate-600 hover:text-red-600 font-medium text-xs sm:text-sm cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Quay lại trang tin</span>
          </button>

          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Audio Reader Toggle */}
            <button
              onClick={() => setIsPlayingAudio(!isPlayingAudio)}
              className={`flex items-center space-x-1 text-xs px-2.5 py-1.5 rounded-lg border font-medium cursor-pointer transition-colors ${
                isPlayingAudio
                  ? 'bg-red-50 text-red-600 border-red-200'
                  : 'text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
              title="Nghe đọc bài viết"
            >
              {isPlayingAudio ? (
                <>
                  <VolumeX className="w-3.5 h-3.5 animate-pulse text-red-600" />
                  <span className="hidden sm:inline">Dừng đọc</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Nghe đọc</span>
                </>
              )}
            </button>

            {/* Font size adjuster */}
            <div className="flex items-center border border-slate-200 rounded-lg p-0.5 text-xs text-slate-600">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  fontSize === 'normal' ? 'bg-slate-200 font-bold' : 'hover:bg-slate-100'
                }`}
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  fontSize === 'large' ? 'bg-slate-200 font-bold text-sm' : 'hover:bg-slate-100'
                }`}
              >
                A+
              </button>
              <button
                onClick={() => setFontSize('xlarge')}
                className={`px-2 py-0.5 rounded cursor-pointer ${
                  fontSize === 'xlarge' ? 'bg-slate-200 font-bold text-base' : 'hover:bg-slate-100'
                }`}
              >
                A++
              </button>
            </div>

            {/* Bookmark button */}
            <button
              onClick={() => onToggleBookmark(article)}
              className={`p-2 rounded-lg border transition-colors cursor-pointer ${
                isBookmarked
                  ? 'bg-red-50 text-red-600 border-red-200'
                  : 'text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
              title={isBookmarked ? 'Bỏ lưu bài viết' : 'Lưu bài viết'}
            >
              <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current text-red-600' : ''}`} />
            </button>

            {/* Share button */}
            <button
              onClick={handleCopyLink}
              className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer relative"
              title="Sao chép liên kết bài viết"
            >
              <Share2 className="w-4 h-4" />
              {copiedLink && (
                <span className="absolute -bottom-8 right-0 bg-slate-900 text-white text-[10px] px-2 py-1 rounded shadow-md whitespace-nowrap">
                  Đã chép link!
                </span>
              )}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer ml-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Scrollable Article Body */}
        <div className="p-4 sm:p-8 overflow-y-auto space-y-6">
          {/* Audio playing banner if active */}
          {isPlayingAudio && (
            <div className="bg-red-50 border border-red-200 p-3 rounded-xl flex items-center justify-between text-xs text-red-700">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                <span className="font-semibold">Đang phát âm thanh đọc báo tự động...</span>
              </div>
              <button
                onClick={() => setIsPlayingAudio(false)}
                className="underline text-red-800 cursor-pointer"
              >
                Tắt
              </button>
            </div>
          )}

          {/* Category Badge & Meta */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <span className="category-badge bg-red-600">
              {article.subCategory || article.categoryLabel}
            </span>
            <div className="text-xs text-slate-400 font-medium flex items-center space-x-3">
              <span>{article.publishedAt}</span>
              <span>•</span>
              <span>{article.author || 'Ban Biên tập'}</span>
              <span>•</span>
              <span className="flex items-center">
                <MessageSquare className="w-3.5 h-3.5 mr-1" />
                {comments.length} bình luận
              </span>
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
            {article.title}
          </h1>

          {/* Lead / Excerpt */}
          <div className="border-l-4 border-red-600 pl-4 py-1">
            <p className="text-slate-700 font-semibold text-base sm:text-lg leading-relaxed italic">
              {article.excerpt}
            </p>
          </div>

          {/* Featured Image */}
          <div className="rounded-xl overflow-hidden shadow-sm border border-slate-200">
            <img
              src={article.imageUrl}
              alt={article.imageAlt}
              className="w-full max-h-[460px] object-cover"
            />
            <p className="text-xs text-slate-500 bg-slate-50 p-2.5 text-center italic border-t border-slate-100">
              Hình ảnh: {article.imageAlt} - Nguồn: Bản Tin 24H
            </p>
          </div>

          {/* Article Full Paragraphs */}
          <div className={`text-slate-800 space-y-4 font-normal ${fontSizeClass}`}>
            {article.content && article.content.length > 0 ? (
              article.content.map((p, idx) => <p key={idx}>{p}</p>)
            ) : (
              <>
                <p>
                  Theo báo cáo cập nhật từ các chuyên gia hàng đầu trong ngành, những biến chuyển nhanh
                  chóng của công nghệ và xu hướng toàn cầu đang mở ra những vận hội phát triển chưa từng có
                  tại Việt Nam.
                </p>
                <p>
                  Sự đồng thuận cao giữa chính sách quản lý, định hướng chiến lược quốc gia và nỗ lực
                  vượt bậc từ cộng đồng doanh nghiệp cùng các cơ sở đào tạo đang tạo nên xung lực mạnh mẽ.
                </p>
                <p>
                  Trong thời gian tới, việc tiếp tục đẩy mạnh hoàn thiện khung thể chế, nâng cấp hạ tầng
                  số và chú trọng đào tạo nguồn nhân lực chất lượng cao sẽ là chìa khóa mở ra tương lai bền
                  vững cho đất nước.
                </p>
              </>
            )}
          </div>

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="pt-4 border-t border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase mr-2">Từ khóa:</span>
              <div className="inline-flex flex-wrap gap-1.5">
                {article.tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-slate-100 text-slate-700 hover:bg-slate-200 px-2.5 py-1 rounded-md"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Comments Section */}
          <section className="pt-6 border-t border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 flex items-center">
                <MessageSquare className="w-5 h-5 mr-2 text-red-600" />
                Ý kiến bạn đọc ({comments.length})
              </h3>
            </div>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Họ và tên của bạn..."
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="text-xs p-2.5 rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-red-600"
                />
              </div>
              <textarea
                placeholder="Chia sẻ quan điểm của bạn về bài viết này..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                rows={3}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-1 focus:ring-red-600"
                required
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors cursor-pointer"
                >
                  Gửi bình luận
                </button>
              </div>
            </form>

            {/* Comments List */}
            <div className="space-y-3 pt-2">
              {comments.map((comment) => (
                <div key={comment.id} className="bg-white p-3.5 rounded-lg border border-slate-100 shadow-xs">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                    <span className="font-bold text-slate-800">{comment.author}</span>
                    <span>{comment.timestamp}</span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">{comment.content}</p>
                  <div className="mt-2 flex items-center space-x-2 text-[11px] text-slate-400">
                    <button
                      onClick={() => handleLikeComment(comment.id)}
                      className="flex items-center space-x-1 hover:text-red-600 cursor-pointer"
                    >
                      <Heart className="w-3 h-3" />
                      <span>Thích ({comment.likes})</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Related Articles */}
          {relatedArticles.length > 0 && (
            <section className="pt-6 border-t border-slate-200">
              <h3 className="text-base font-extrabold text-slate-900 uppercase tracking-wide mb-4">
                BÀI VIẾT LIÊN QUAN
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {relatedArticles.slice(0, 3).map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => onSelectArticle(rel)}
                    className="bg-slate-50 rounded-xl overflow-hidden border border-slate-200 hover:shadow-md transition-shadow cursor-pointer flex flex-col group"
                  >
                    <div className="h-28 overflow-hidden">
                      <img
                        src={rel.imageUrl}
                        alt={rel.imageAlt}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-3 flex-1 flex flex-col justify-between">
                      <span className="category-badge bg-red-600 mb-1 text-[9px] self-start">
                        {rel.subCategory || rel.categoryLabel}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 line-clamp-2 leading-snug">
                        {rel.title}
                      </h4>
                      <span className="text-[10px] text-slate-400 mt-2">{rel.publishedAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
