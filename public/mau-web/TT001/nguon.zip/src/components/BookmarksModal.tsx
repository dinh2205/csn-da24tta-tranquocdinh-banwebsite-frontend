import React from 'react';
import { Article } from '../types';
import { Bookmark, Trash2, ArrowRight } from 'lucide-react';

interface BookmarksModalProps {
  bookmarks: Article[];
  onClose: () => void;
  onSelectArticle: (article: Article) => void;
  onRemoveBookmark: (articleId: string) => void;
  onClearAll: () => void;
}

export const BookmarksModal: React.FC<BookmarksModalProps> = ({
  bookmarks,
  onClose,
  onSelectArticle,
  onRemoveBookmark,
  onClearAll,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-center items-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center space-x-2">
            <Bookmark className="w-5 h-5 text-red-600 fill-current" />
            <h3 className="font-extrabold text-slate-900 text-base uppercase">
              BÀI VIẾT ĐÃ LƯU ({bookmarks.length})
            </h3>
          </div>
          <div className="flex items-center space-x-2">
            {bookmarks.length > 0 && (
              <button
                onClick={onClearAll}
                className="text-xs text-red-600 hover:text-red-700 font-medium px-2 py-1 rounded hover:bg-red-50 cursor-pointer"
              >
                Xóa tất cả
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1">
          {bookmarks.length === 0 ? (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <Bookmark className="w-10 h-10 mx-auto text-slate-300 stroke-[1.5]" />
              <p className="font-medium text-slate-700">Chưa có bài viết nào được lưu</p>
              <p className="text-xs text-slate-400">
                Hãy nhấn vào biểu tượng dấu trang khi đọc bất kỳ bài báo nào để lưu lại xem sau.
              </p>
            </div>
          ) : (
            bookmarks.map((art) => (
              <div
                key={art.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-3 hover:border-slate-300 transition-all group"
              >
                <div
                  onClick={() => {
                    onSelectArticle(art);
                    onClose();
                  }}
                  className="flex items-center space-x-3 cursor-pointer flex-1 min-w-0"
                >
                  <img
                    src={art.imageUrl}
                    alt={art.imageAlt}
                    className="w-16 h-12 object-cover rounded-md flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="category-badge bg-red-600 text-[8px] mb-1">
                      {art.subCategory || art.categoryLabel}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate leading-snug">
                      {art.title}
                    </h4>
                    <span className="text-[10px] text-slate-400">{art.publishedAt}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-1 flex-shrink-0">
                  <button
                    onClick={() => {
                      onSelectArticle(art);
                      onClose();
                    }}
                    className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg cursor-pointer"
                    title="Đọc ngay"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRemoveBookmark(art.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                    title="Bỏ lưu"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
