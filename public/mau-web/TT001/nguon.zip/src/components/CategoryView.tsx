import React, { useState } from 'react';
import { Article, Category, HotNewsItem } from '../types';
import { Sidebar } from './Sidebar';

interface CategoryViewProps {
  category: Category;
  heroArticle?: Article;
  articles: Article[];
  hotNews: HotNewsItem[];
  tags: string[];
  totalArticlesCount: number;
  onSelectArticle: (article: Article) => void;
  onNavigateHome: () => void;
  onSelectTag: (tag: string) => void;
  onSelectHotNews: (item: HotNewsItem) => void;
  onSubscribeNewsletter: (email: string) => void;
}

export const CategoryView: React.FC<CategoryViewProps> = ({
  category,
  heroArticle,
  articles,
  hotNews,
  tags,
  totalArticlesCount,
  onSelectArticle,
  onNavigateHome,
  onSelectTag,
  onSelectHotNews,
  onSubscribeNewsletter,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedHotTopic, setSelectedHotTopic] = useState<string | null>(null);

  // Filter articles if a hot topic is clicked
  const displayedArticles = selectedHotTopic
    ? articles.filter((a) => {
        const query = selectedHotTopic.toLowerCase();
        return (
          a.title.toLowerCase().includes(query) ||
          a.excerpt.toLowerCase().includes(query) ||
          (a.subCategory && a.subCategory.toLowerCase().includes(query)) ||
          (a.tags && a.tags.some((t) => t.toLowerCase().includes(query)))
        );
      })
    : articles;

  const totalPages = Math.max(1, Math.ceil(totalArticlesCount / 5));

  return (
    <>
      {/* Breadcrumb + Hot topics row */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-6 border-b border-slate-200">
        <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
          <button
            onClick={onNavigateHome}
            className="hover:text-[#0056b3] transition-colors flex items-center gap-1 cursor-pointer"
          >
            <svg className="w-3.5 h-3.5 fill-current inline-block" viewBox="0 0 24 24">
              <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
            </svg>
            Trang chủ
          </button>
          <span className="text-slate-300">/</span>
          <span className="text-red-600 font-bold uppercase tracking-wider">
            {category.badgeName || category.name}
          </span>
        </div>

        {/* Hot topics pills */}
        {category.hotTopics && category.hotTopics.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <span className="text-xs font-semibold text-slate-400 whitespace-nowrap hidden sm:inline">
              Chủ đề hot:
            </span>
            {category.hotTopics.map((topic, idx) => {
              const isSelected = selectedHotTopic === topic;
              return (
                <button
                  key={idx}
                  onClick={() => setSelectedHotTopic(isSelected ? null : topic)}
                  className={`px-2.5 py-1 text-xs rounded-full transition-colors font-medium whitespace-nowrap cursor-pointer ${
                    isSelected
                      ? 'bg-red-600 text-white'
                      : 'bg-slate-100 hover:bg-red-600 hover:text-white text-slate-700'
                  }`}
                >
                  {topic}
                </button>
              );
            })}
          </div>
        )}
      </div>

      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-10">
        {/* Left & Middle: Hero Feature + Articles List */}
        <div className="lg:col-span-8 xl:col-span-9 flex flex-col space-y-8">
          {/* Primary Hero for Category */}
          {heroArticle && (
            <article
              onClick={() => onSelectArticle(heroArticle)}
              className="relative rounded-xl overflow-hidden shadow-md group bg-slate-900 flex flex-col justify-end min-h-[380px] md:min-h-[440px] cursor-pointer"
            >
              <img
                alt={heroArticle.imageAlt}
                className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-80"
                src={heroArticle.imageUrl}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent" />
              <div className="relative p-5 sm:p-7 z-10 text-white">
                <span className="category-badge bg-red-600 mb-3 font-semibold tracking-wider">
                  {heroArticle.categoryLabel}
                </span>
                <h1 className="text-xl sm:text-2xl xl:text-3xl font-extrabold leading-tight tracking-tight hover:text-amber-300 transition-colors">
                  <span className="cursor-pointer">{heroArticle.title}</span>
                </h1>
                <p className="mt-3 text-slate-200 text-sm sm:text-base leading-relaxed line-clamp-3 font-normal">
                  {heroArticle.excerpt}
                </p>
                <div className="mt-4 flex items-center space-x-5 text-xs text-slate-300 font-medium">
                  <span className="flex items-center">
                    <svg className="w-3.5 h-3.5 mr-1.5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      />
                    </svg>
                    {heroArticle.publishedAt}
                  </span>
                  <span className="flex items-center">
                    <svg className="w-3.5 h-3.5 mr-1.5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      />
                    </svg>
                    {heroArticle.commentsCount} bình luận
                  </span>
                </div>
              </div>
            </article>
          )}

          {/* Articles list */}
          <div className="space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h2 className="text-base font-extrabold text-slate-900 uppercase tracking-wide flex items-center">
                <span className="w-1.5 h-5 bg-red-600 inline-block rounded-full mr-2.5" />
                DANH SÁCH BÀI VIẾT {category.badgeName || category.name}
              </h2>
              <span className="text-xs text-slate-500 font-medium">
                Hiển thị 1 - {displayedArticles.length} trong {totalArticlesCount} bài viết
              </span>
            </div>

            {displayedArticles.length === 0 ? (
              <div className="bg-white rounded-xl p-8 text-center text-slate-500 border border-slate-200">
                <p>Không có bài viết nào phù hợp với chủ đề đã chọn.</p>
                <button
                  onClick={() => setSelectedHotTopic(null)}
                  className="mt-3 px-4 py-1.5 bg-red-600 text-white rounded text-xs font-semibold cursor-pointer"
                >
                  Xem tất cả bài viết
                </button>
              </div>
            ) : (
              displayedArticles.map((art) => (
                <article
                  key={art.id}
                  onClick={() => onSelectArticle(art)}
                  className="bg-white rounded-xl overflow-hidden shadow-xs border border-slate-200/80 hover:shadow-md transition-all p-4 flex flex-col sm:flex-row gap-4 group cursor-pointer"
                >
                  <div className="sm:w-64 h-44 flex-shrink-0 relative overflow-hidden rounded-lg bg-slate-100">
                    <img
                      alt={art.imageAlt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      src={art.imageUrl}
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="category-badge bg-red-600 text-[10px]">
                          {art.subCategory || art.categoryLabel}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900 group-hover:text-[#0056b3] transition-colors leading-snug line-clamp-2">
                        <span className="cursor-pointer">{art.title}</span>
                      </h3>
                      <p className="text-slate-600 text-xs sm:text-sm mt-2 leading-relaxed line-clamp-2 font-normal">
                        {art.excerpt}
                      </p>
                    </div>
                    <div className="mt-3 flex items-center space-x-4 text-xs text-slate-400 font-medium border-t border-slate-100 pt-2.5">
                      <span className="flex items-center">
                        <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                          />
                        </svg>
                        {art.publishedAt}
                      </span>
                      <span className="flex items-center">
                        <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path
                            d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                          />
                        </svg>
                        {art.commentsCount} bình luận
                      </span>
                    </div>
                  </div>
                </article>
              ))
            )}
          </div>

          {/* Pagination */}
          <div className="flex justify-center items-center space-x-1.5 pt-6 pb-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center cursor-pointer ${
                currentPage === 1
                  ? 'text-slate-300 bg-slate-50 border-slate-200 cursor-not-allowed'
                  : 'text-slate-500 bg-white border-slate-200 hover:bg-slate-100'
              }`}
            >
              « Trang trước
            </button>

            {[1, 2, 3, 4].map((page) => {
              const isActive = currentPage === page;
              return (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`w-8 h-8 text-xs font-bold rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                    isActive
                      ? 'text-white bg-[#0b2341] shadow-xs'
                      : 'text-slate-700 bg-white border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {page}
                </button>
              );
            })}

            <span className="px-1 text-slate-400 text-xs">...</span>

            <button
              onClick={() => setCurrentPage(totalPages)}
              className={`w-8 h-8 text-xs font-semibold rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                currentPage === totalPages
                  ? 'text-white bg-[#0b2341]'
                  : 'text-slate-700 bg-white border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {totalPages}
            </button>

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center cursor-pointer ${
                currentPage === totalPages
                  ? 'text-slate-300 bg-slate-50 border-slate-200 cursor-not-allowed'
                  : 'text-slate-700 bg-white border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Trang sau »
            </button>
          </div>
        </div>

        {/* Right Column: Sidebar */}
        <Sidebar
          hotNews={hotNews}
          tags={tags}
          onSelectHotNews={onSelectHotNews}
          onSelectTag={onSelectTag}
          onSubscribeNewsletter={onSubscribeNewsletter}
        />
      </section>
    </>
  );
};
