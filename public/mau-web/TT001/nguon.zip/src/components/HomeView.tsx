import React from 'react';
import { Article, HotNewsItem } from '../types';
import { Sidebar } from './Sidebar';
import { HOME_HOT_NEWS, TAGS_HOME } from '../data/newsData';

interface HomeViewProps {
  heroArticle: Article;
  stackedArticles: Article[];
  featuredArticles: Article[];
  onSelectArticle: (article: Article) => void;
  onSelectTag: (tag: string) => void;
  onSelectHotNews: (item: HotNewsItem) => void;
  onSubscribeNewsletter: (email: string) => void;
  onViewAllFeatured: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  heroArticle,
  stackedArticles,
  featuredArticles,
  onSelectArticle,
  onSelectTag,
  onSelectHotNews,
  onSubscribeNewsletter,
  onViewAllFeatured,
}) => {
  return (
    <>
      {/* Top Grid: Primary Hero + Secondary Stack + Right Sidebar (Tin Nóng) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-10">
        {/* Left & Middle: Hero Feature + Secondary Articles (9 Cols on Large Screens) */}
        <div className="lg:col-span-8 xl:col-span-9 grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Large Featured Story (Hero) */}
          <article className="md:col-span-7 xl:col-span-8 relative rounded-xl overflow-hidden shadow-md group bg-slate-900 flex flex-col justify-end min-h-[380px] md:min-h-[460px] h-full cursor-pointer">
            {/* Featured Background Image */}
            <img
              alt={heroArticle.imageAlt}
              className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-80"
              src={heroArticle.imageUrl}
            />
            {/* Gradient Overlay for readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent" />

            {/* Hero Content */}
            <div className="relative p-5 sm:p-7 z-10 text-white">
              <span className="category-badge bg-red-600 mb-3 font-semibold tracking-wider">
                {heroArticle.categoryLabel}
              </span>
              <h1 className="text-xl sm:text-2xl xl:text-3xl font-extrabold leading-tight tracking-tight hover:text-amber-300 transition-colors">
                <button
                  onClick={() => onSelectArticle(heroArticle)}
                  className="text-left font-inherit cursor-pointer hover:underline"
                >
                  {heroArticle.title}
                </button>
              </h1>
              <p className="mt-3 text-slate-200 text-sm sm:text-base leading-relaxed line-clamp-3 font-normal">
                {heroArticle.excerpt}
              </p>
              <div className="mt-4 flex items-center space-x-5 text-xs text-slate-300 font-medium">
                <span className="flex items-center">
                  <svg className="w-3.5 h-3.5 mr-1.5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                  {heroArticle.publishedAt}
                </span>
                <span className="flex items-center">
                  <svg className="w-3.5 h-3.5 mr-1.5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                  {heroArticle.commentsCount} bình luận
                </span>
              </div>
            </div>
          </article>

          {/* Secondary Column (3 Stacked Stories) */}
          <div className="md:col-span-5 xl:col-span-4 flex flex-col justify-between space-y-4">
            {stackedArticles.map((art) => (
              <article
                key={art.id}
                onClick={() => onSelectArticle(art)}
                className="bg-white rounded-xl overflow-hidden shadow-xs border border-slate-200/80 hover:shadow-md transition-shadow flex flex-col group cursor-pointer"
              >
                <div className="relative h-32 w-full overflow-hidden">
                  <img
                    alt={art.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    src={art.imageUrl}
                  />
                </div>
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="category-badge bg-red-600 mb-1.5 text-[10px]">
                      {art.subCategory || art.categoryLabel}
                    </span>
                    <h2 className="text-sm font-bold text-slate-900 group-hover:text-[#0056b3] leading-snug line-clamp-2">
                      <span className="cursor-pointer">{art.title}</span>
                    </h2>
                  </div>
                  <div className="mt-2 text-[11px] text-slate-400 flex items-center">
                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      />
                    </svg>
                    {art.publishedAt}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* Right Column: Sidebar (TIN NÓNG, Newsletter, Tags) */}
        <Sidebar
          hotNews={HOME_HOT_NEWS}
          tags={TAGS_HOME}
          onSelectHotNews={onSelectHotNews}
          onSelectTag={onSelectTag}
          onSubscribeNewsletter={onSubscribeNewsletter}
        />
      </section>

      {/* BEGIN: FeaturedNewsRow (TIN TỨC NỔI BẬT - 4 Cards across) */}
      <section className="mt-4 pt-6 border-t border-slate-200">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-3">
            <span className="w-1.5 h-6 bg-red-600 inline-block rounded-full" />
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight uppercase">
              TIN TỨC NỔI BẬT
            </h2>
          </div>
          <button
            onClick={onViewAllFeatured}
            className="text-xs font-bold text-[#0056b3] hover:text-red-600 flex items-center transition-colors cursor-pointer"
          >
            Xem tất cả <span className="ml-1">→</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {featuredArticles.map((art) => (
            <article
              key={art.id}
              onClick={() => onSelectArticle(art)}
              className="bg-white rounded-xl overflow-hidden shadow-xs border border-slate-200/80 hover:shadow-lg transition-all duration-300 flex flex-col group cursor-pointer"
            >
              <div className="relative h-44 w-full overflow-hidden bg-slate-100">
                <img
                  alt={art.imageAlt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  src={art.imageUrl}
                />
                <span className="category-badge bg-red-600 absolute bottom-3 left-3 text-[10px]">
                  {art.categoryLabel}
                </span>
              </div>
              <div className="p-4 flex-1 flex flex-col justify-between">
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-[#0056b3] leading-snug line-clamp-2">
                  <span className="cursor-pointer">{art.title}</span>
                </h3>
                <div className="mt-4 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-100 pt-2.5">
                  <span className="flex items-center">
                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      />
                    </svg>
                    {art.publishedAt}
                  </span>
                  <span className="flex items-center">
                    <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                      />
                    </svg>
                    {art.commentsCount} bình luận
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </>
  );
};
