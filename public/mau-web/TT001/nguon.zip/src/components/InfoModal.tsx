import React from 'react';

interface InfoModalProps {
  type: string;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ type, onClose }) => {
  const getModalContent = () => {
    switch (type) {
      case 'about':
        return {
          title: 'VỀ CHÚNG TÔI - BẢN TIN 24H',
          content: (
            <div className="space-y-3 text-slate-700 text-sm leading-relaxed">
              <p>
                <strong>Bản Tin 24H</strong> là cơ quan báo chí điện tử hiện đại, cập nhật liên tục 24/7 các dòng thời sự nóng bỏng, chuyển động công nghệ số, giáo dục và đời sống xã hội.
              </p>
              <p>
                Với phương châm <em>“Thông tin hôm nay vì một ngày mai tốt đẹp hơn”</em>, chúng tôi cam kết mang lại nguồn tin tức chuẩn xác, khách quan, có chiều sâu và truyền tải giá trị tích cực đến cộng đồng.
              </p>
              <p>
                Tòa soạn: Tầng 8, Tòa nhà Công nghệ số, Quận Cầu Giấy, Hà Nội.
              </p>
            </div>
          ),
        };
      case 'contact':
        return {
          title: 'LIÊN HỆ TÒA SOẠN',
          content: (
            <div className="space-y-3 text-slate-700 text-sm leading-relaxed">
              <p><strong>Ban Biên Tập Bản Tin 24H:</strong></p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Đường dây nóng (Hotline): 1900 6868 (24/7)</li>
                <li>Email tòa soạn: toasoan@bantin24h.vn</li>
                <li>Email gửi bài & cộng tác: banbientap@bantin24h.vn</li>
                <li>Địa chỉ: Số 24 Đường Hòa Bình, TP. Hà Nội</li>
              </ul>
            </div>
          ),
        };
      case 'ads':
        return {
          title: 'HỢP TÁC TRUYỀN THÔNG & QUẢNG CÁO',
          content: (
            <div className="space-y-3 text-slate-700 text-sm leading-relaxed">
              <p>
                Bản Tin 24H cung cấp các giải pháp truyền thông toàn diện: Banner hiển thị, bài viết PR chuyên sâu, Multimedia, Podcast thương hiệu và bảo trợ truyền thông sự kiện.
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Phòng Quảng cáo & Tiếp thị: (024) 3888 9999</li>
                <li>Email báo giá: quangcao@bantin24h.vn</li>
                <li>Hơn 15 triệu lượt truy cập độc giả mỗi tháng.</li>
              </ul>
            </div>
          ),
        };
      case 'terms':
        return {
          title: 'ĐIỀU KHOẢN SỬ DỤNG',
          content: (
            <div className="space-y-3 text-slate-700 text-sm leading-relaxed">
              <p>1. Tất cả nội dung xuất bản trên Bản Tin 24H thuộc bản quyền sở hữu trí tuệ của tòa soạn.</p>
              <p>2. Mọi hành vi trích dẫn, sao chép phải ghi rõ nguồn trích dẫn từ Bản Tin 24H.</p>
              <p>3. Người dùng tuân thủ các quy tắc văn hóa ứng xử khi bình luận.</p>
            </div>
          ),
        };
      case 'privacy':
        return {
          title: 'CHÍNH SÁCH BẢO MẬT',
          content: (
            <div className="space-y-3 text-slate-700 text-sm leading-relaxed">
              <p>Chúng tôi tôn trọng quyền riêng tư của độc giả. Mọi thông tin email đăng ký nhận bản tin được mã hóa an toàn và cam kết không chia sẻ với bên thứ ba vì mục đích thương mại.</p>
            </div>
          ),
        };
      default:
        return {
          title: 'THÔNG TIN BẢN TIN 24H',
          content: <p className="text-slate-700 text-sm">Nội dung đang được cập nhật.</p>,
        };
    }
  };

  const { title, content } = getModalContent();

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-center items-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
          <h3 className="font-extrabold text-slate-900 text-base uppercase">{title}</h3>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            ✕
          </button>
        </div>
        <div className="py-2">{content}</div>
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-900 transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
