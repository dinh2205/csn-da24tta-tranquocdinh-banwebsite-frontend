import React from 'react';
import { CategoryId } from '../types';

interface MainFooterProps {
  onSelectCategory: (catId: CategoryId) => void;
  onOpenPolicy: (type: string) => void;
}

export const MainFooter: React.FC<MainFooterProps> = ({
  onSelectCategory,
  onOpenPolicy,
}) => {
  return (
    <footer className="bg-[#0b2341] text-white pt-10 pb-6 border-t-4 border-red-600 mt-12">
      <div className="max-w-[1400px] mx-auto px-4 lg:px-8">
        {/* Upper Footer */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center pb-8 border-b border-slate-700/60 gap-6">
          {/* Logo on Dark */}
          <div>
            <div className="flex items-center">
              <span className="text-2xl lg:text-3xl font-black text-white tracking-tighter uppercase">
                BẢN TIN
              </span>
              <span className="text-2xl lg:text-3xl font-black text-[#e52424] ml-1.5 tracking-tighter">
                24H
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Cập nhật liên tục - Kết nối mọi chặng đường
            </p>
          </div>

          {/* Quick Nav in Footer */}
          <nav className="flex flex-wrap gap-y-2 gap-x-5 text-xs text-slate-300 font-medium">
            <button
              onClick={() => onSelectCategory('thoi-su')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Thời sự
            </button>
            <button
              onClick={() => onSelectCategory('cong-nghe')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Công nghệ
            </button>
            <button
              onClick={() => onSelectCategory('giao-duc')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Giáo dục
            </button>
            <button
              onClick={() => onSelectCategory('doi-song')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Đời sống
            </button>
            <button
              onClick={() => onSelectCategory('the-thao')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Thể thao
            </button>
            <button
              onClick={() => onSelectCategory('giai-tri')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Giải trí
            </button>
            <button
              onClick={() => onSelectCategory('kinh-te')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Kinh tế
            </button>
            <button
              onClick={() => onSelectCategory('suc-khoe')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Sức khỏe
            </button>
            <button
              onClick={() => onSelectCategory('du-lich')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Du lịch
            </button>
            <button
              onClick={() => onSelectCategory('podcast')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Podcast
            </button>
          </nav>

          {/* Social Icons Footer */}
          <div className="flex items-center space-x-3 text-slate-400">
            {/* Facebook */}
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="hover:text-white transition-colors"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="hover:text-white transition-colors"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </a>

            {/* TikTok */}
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="TikTok"
              className="hover:text-white transition-colors"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </a>

            {/* X / Twitter */}
            <a
              href="https://x.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="X"
              className="hover:text-white transition-colors"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>

            {/* Instagram */}
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="hover:text-white transition-colors"
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>
          </div>
        </div>

        {/* Lower Footer: Copyright & Legal */}
        <div className="flex flex-col sm:flex-row justify-between items-center pt-6 text-[11px] text-slate-400 gap-3">
          <p>© 2025 Bản Tin 24H. Tất cả quyền được bảo lưu.</p>
          <div className="flex items-center space-x-4 flex-wrap justify-center">
            <button
              onClick={() => onOpenPolicy('terms')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Điều khoản sử dụng
            </button>
            <span>|</span>
            <button
              onClick={() => onOpenPolicy('privacy')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Chính sách bảo mật
            </button>
            <span>|</span>
            <button
              onClick={() => onOpenPolicy('cookie')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Cookie
            </button>
            <span>|</span>
            <button
              onClick={() => onOpenPolicy('sitemap')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Sơ đồ trang
            </button>
            <span>|</span>
            <button
              onClick={() => onOpenPolicy('contact')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Liên hệ
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
