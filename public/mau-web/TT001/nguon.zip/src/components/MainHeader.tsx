import React, { useState } from 'react';

interface MainHeaderProps {
  onSearch: (query: string) => void;
  onNavigateHome: () => void;
  searchQuery: string;
}

export const MainHeader: React.FC<MainHeaderProps> = ({
  onSearch,
  onNavigateHome,
  searchQuery,
}) => {
  const [localQuery, setLocalQuery] = useState(searchQuery);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(localQuery.trim());
  };

  return (
    <header className="w-full bg-white shadow-xs border-b border-slate-100">
      <div className="max-w-[1400px] mx-auto px-4 lg:px-8 py-5 flex flex-col md:flex-row justify-between items-center gap-4">
        {/* Logo Branding */}
        <button
          onClick={onNavigateHome}
          className="flex flex-col group text-left items-start cursor-pointer hover:opacity-95 transition-opacity"
        >
          <div className="flex items-center tracking-tight">
            <span className="text-3xl lg:text-4xl font-black text-[#0051a8] tracking-tighter uppercase font-sans">
              BẢN TIN
            </span>
            <span className="text-3xl lg:text-4xl font-black text-[#e52424] ml-1.5 tracking-tighter">
              24H
            </span>
          </div>
          <span className="text-[11px] lg:text-xs font-semibold tracking-wider text-slate-500 uppercase mt-0.5">
            Cập nhật liên tục - Kết nối mọi chặng đường
          </span>
        </button>

        {/* Search Box */}
        <div className="w-full md:w-[460px] relative">
          <form onSubmit={handleSubmit} className="relative">
            <input
              type="text"
              value={localQuery}
              onChange={(e) => {
                setLocalQuery(e.target.value);
                if (e.target.value === '') {
                  onSearch('');
                }
              }}
              placeholder="Tìm kiếm tin tức, chủ đề, tác giả..."
              className="w-full bg-slate-100/90 border border-slate-200 rounded-full py-2.5 pl-5 pr-11 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#0056b3]/30 focus:border-[#0056b3] focus:bg-white transition-all shadow-inner"
            />
            {localQuery && (
              <button
                type="button"
                onClick={() => {
                  setLocalQuery('');
                  onSearch('');
                }}
                className="absolute right-10 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 text-xs"
                title="Xóa tìm kiếm"
              >
                ✕
              </button>
            )}
            <button
              type="submit"
              aria-label="Tìm kiếm"
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0056b3] transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                />
              </svg>
            </button>
          </form>
        </div>

        {/* Slogan / Motto right aligned */}
        <div className="hidden xl:flex flex-col text-right italic text-slate-600 font-medium">
          <span className="text-sm">“Thông tin hôm nay</span>
          <span className="text-xs text-[#0056b3] font-semibold">vì một ngày mai tốt đẹp hơn”</span>
        </div>
      </div>
    </header>
  );
};
