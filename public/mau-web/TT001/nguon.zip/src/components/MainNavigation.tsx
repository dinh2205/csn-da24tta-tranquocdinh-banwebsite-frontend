import React, { useState } from 'react';
import { CategoryId } from '../types';
import { CATEGORIES } from '../data/newsData';

interface MainNavigationProps {
  currentCategory: CategoryId;
  onSelectCategory: (catId: CategoryId) => void;
}

export const MainNavigation: React.FC<MainNavigationProps> = ({
  currentCategory,
  onSelectCategory,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      <nav className="bg-[#0b2341] text-white sticky top-0 z-40 shadow-md">
        <div className="max-w-[1400px] mx-auto px-4 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-1 overflow-x-auto no-scrollbar py-1">
            {/* Home Icon */}
            <button
              onClick={() => onSelectCategory('home')}
              aria-label="Trang chủ"
              className={`p-2.5 rounded transition-colors cursor-pointer ${
                currentCategory === 'home'
                  ? 'bg-red-600 text-white'
                  : 'text-white/90 hover:text-white hover:bg-white/10'
              }`}
            >
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" />
              </svg>
            </button>

            {/* Category Links */}
            {CATEGORIES.filter((c) => c.id !== 'home').map((cat) => {
              const isActive = currentCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`px-3 py-2.5 text-[13.5px] font-semibold tracking-wide uppercase rounded transition-colors whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-red-600 text-white shadow-xs font-bold'
                      : 'hover:bg-white/10 text-white/90 hover:text-white'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>

          {/* Hamburger / Menu Icon */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Danh mục mở rộng"
            className="p-2 text-white/90 hover:text-white hover:bg-white/10 rounded transition-colors ml-2 cursor-pointer"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                d={mobileMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'}
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2.5"
              />
            </svg>
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-xs bg-white h-full shadow-2xl p-6 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center">
                  <span className="text-2xl font-black text-[#0051a8] uppercase">BẢN TIN</span>
                  <span className="text-2xl font-black text-[#e52424] ml-1">24H</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-full text-slate-500 hover:bg-slate-100"
                >
                  ✕
                </button>
              </div>

              <div className="py-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  TẤT CẢ CHUYÊN MỤC
                </p>
                <div className="flex flex-col space-y-1">
                  {CATEGORIES.map((cat) => {
                    const isActive = currentCategory === cat.id;
                    return (
                      <button
                        key={cat.id}
                        onClick={() => {
                          onSelectCategory(cat.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`text-left px-3 py-2 text-sm font-semibold rounded-lg transition-colors flex items-center justify-between ${
                          isActive
                            ? 'bg-red-600 text-white'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <span>{cat.name}</span>
                        {isActive && <span className="text-xs bg-white/20 px-2 py-0.5 rounded">Đang xem</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="border-t border-slate-200 pt-4 text-xs text-slate-500">
              <p className="font-semibold text-slate-700 mb-1">Bản Tin 24H</p>
              <p>Cập nhật liên tục - Kết nối mọi chặng đường</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
