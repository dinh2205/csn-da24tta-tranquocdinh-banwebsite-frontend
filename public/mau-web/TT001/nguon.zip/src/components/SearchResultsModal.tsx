import React from 'react';
import { Article } from '../types';
import { Search, ArrowRight } from 'lucide-react';

interface SearchResultsModalProps {
  query: string;
  results: Article[];
  onClose: () => void;
  onSelectArticle: (article: Article) => void;
}

export const SearchResultsModal: React.FC<SearchResultsModalProps> = ({
  query,
  results,
  onClose,
  onSelectArticle,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-center items-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center space-x-2">
            <Search className="w-5 h-5 text-red-600" />
            <h3 className="font-extrabold text-slate-900 text-base uppercase">
              KẾT QUẢ TÌM KIẾM CHO "{query}" ({results.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1">
          {results.length === 0 ? (
            <div className="text-center py-12 text-slate-500 space-y-2">
              <p className="font-medium text-slate-700">Không tìm thấy bài viết nào phù hợp</p>
              <p className="text-xs text-slate-400">
                Hãy thử lại với các từ khóa phổ biến như: AI, Bán dẫn, Giáo dục, Học bổng, iPhone, Việt Nam...
              </p>
            </div>
          ) : (
            results.map((art) => (
              <div
                key={art.id}
                onClick={() => {
                  onSelectArticle(art);
                  onClose();
                }}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-3 hover:border-slate-300 transition-all cursor-pointer group"
              >
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <img
                    src={art.imageUrl}
                    alt={art.imageAlt}
                    className="w-18 h-14 object-cover rounded-md flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <span className="category-badge bg-red-600 text-[8px] mb-1">
                      {art.subCategory || art.categoryLabel}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 line-clamp-1 leading-snug">
                      {art.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{art.excerpt}</p>
                    <span className="text-[10px] text-slate-400 mt-1 block">{art.publishedAt}</span>
                  </div>
                </div>

                <div className="p-2 text-slate-400 group-hover:text-blue-600">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
