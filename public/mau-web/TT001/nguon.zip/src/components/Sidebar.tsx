import React, { useState } from 'react';
import { HotNewsItem } from '../types';

interface SidebarProps {
  hotNews: HotNewsItem[];
  tags: string[];
  onSelectHotNews: (item: HotNewsItem) => void;
  onSelectTag: (tag: string) => void;
  onSubscribeNewsletter: (email: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  hotNews,
  tags,
  onSelectHotNews,
  onSelectTag,
  onSubscribeNewsletter,
}) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      alert('Vui lòng nhập địa chỉ email hợp lệ!');
      return;
    }
    onSubscribeNewsletter(email.trim());
    setSubscribed(true);
    setEmail('');
    setTimeout(() => setSubscribed(false), 5000);
  };

  return (
    <aside className="lg:col-span-4 xl:col-span-3 space-y-6">
      {/* Box: TIN NÓNG */}
      <div className="bg-white rounded-xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <h2 className="flex items-center text-base font-extrabold text-slate-900 uppercase tracking-wide">
            <svg className="w-5 h-5 text-red-600 mr-2 fill-current" viewBox="0 0 20 20">
              <path
                clipRule="evenodd"
                d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.316.492-.533 1.035-.722 1.572-.27.766-.472 1.543-.67 2.31l-.01.039c-.16.63-.328 1.25-.522 1.803a17.977 17.977 0 01-.9-3.08 1 1 0 00-1.923-.394 11.398 11.398 0 00-.57 2.61c-.07.7-.08 1.4-.02 2.11.02.26.06.52.11.78a6.99 6.99 0 00-2.88 5.748C2 15.34 5.134 18.5 9 18.5c3.834 0 7-3.14 7-6.953a7.05 7.05 0 00-3.605-6.244zM9 16.5c-2.73 0-5-2.228-5-4.953 0-1.15.385-2.22 1.042-3.082.26.83.65 1.62 1.157 2.338a1 1 0 001.666-.086c.4-.644.732-1.325 1.01-2.028.167-.424.316-.856.452-1.295.27-.882.493-1.782.673-2.695.534.613.978 1.31 1.305 2.062.484 1.11.733 2.316.733 3.541 0 2.725-2.258 4.953-5 4.953z"
                fillRule="evenodd"
              />
            </svg>
            TIN NÓNG
          </h2>
          <button
            onClick={() => onSelectTag('tin-nong')}
            className="text-xs font-semibold text-[#0056b3] hover:text-red-600 flex items-center transition-colors cursor-pointer"
          >
            Xem tất cả <span className="ml-1 font-bold">→</span>
          </button>
        </div>

        {/* Hot News Ordered List */}
        <ul className="space-y-4">
          {hotNews.map((item) => (
            <li key={item.id} className="flex items-start space-x-3 group">
              <span className="flex-shrink-0 w-6 h-6 rounded bg-red-600 text-white text-xs font-bold flex items-center justify-center shadow-xs">
                {item.order}
              </span>
              <div>
                <button
                  onClick={() => onSelectHotNews(item)}
                  className="text-left text-xs font-semibold text-slate-900 group-hover:text-[#0056b3] leading-snug line-clamp-2 transition-colors cursor-pointer"
                >
                  {item.title}
                </button>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {item.timeAgo}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Box: ĐĂNG KÝ NHẬN BẢN TIN */}
      <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex items-center space-x-2 text-red-600 font-bold text-sm uppercase mb-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            />
          </svg>
          <span>ĐĂNG KÝ NHẬN BẢN TIN</span>
        </div>
        <p className="text-xs text-slate-600 mb-3.5 leading-relaxed">
          Nhận <strong className="text-slate-800">tin tức mới nhất</strong> mỗi ngày qua email của bạn.
        </p>

        {subscribed ? (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3 rounded-lg flex items-center space-x-2">
            <svg className="w-4 h-4 text-emerald-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
            <span>Cảm ơn bạn! Đã đăng ký nhận bản tin thành công.</span>
          </div>
        ) : (
          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Nhập địa chỉ email..."
              className="text-xs flex-1 rounded-lg border border-slate-300 focus:ring-[#0056b3] focus:border-[#0056b3] py-2 px-3 bg-white"
              required
            />
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold py-2 px-4 rounded-lg transition-colors shadow-xs cursor-pointer whitespace-nowrap"
            >
              Đăng ký
            </button>
          </form>
        )}

        <span className="text-[10px] text-slate-400 block mt-2">
          Chúng tôi cam kết không gửi spam. Bạn có thể hủy đăng ký bất cứ lúc nào.
        </span>
      </div>

      {/* Box: CHỦ ĐỀ ĐƯỢC QUAN TÂM */}
      <div className="bg-white rounded-xl p-5 border border-slate-200/80 shadow-xs">
        <h2 className="flex items-center text-sm font-bold text-slate-900 uppercase tracking-wide mb-3.5">
          <svg className="w-4 h-4 text-red-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
            />
          </svg>
          CHỦ ĐỀ ĐƯỢC QUAN TÂM
        </h2>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, idx) => (
            <button
              key={idx}
              onClick={() => onSelectTag(tag)}
              className="px-2.5 py-1 text-xs bg-blue-50 text-[#0056b3] hover:bg-[#0056b3] hover:text-white rounded-full transition-all font-medium cursor-pointer"
            >
              {tag}
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
};
