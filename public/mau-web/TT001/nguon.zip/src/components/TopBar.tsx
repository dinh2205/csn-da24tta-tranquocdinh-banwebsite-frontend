import React, { useState } from 'react';
import { Bookmark, Sun, CloudSun, CloudRain, Check } from 'lucide-react';

interface TopBarProps {
  onOpenBookmarks: () => void;
  bookmarksCount: number;
  onOpenContact: () => void;
  onOpenAbout: () => void;
  onOpenAds: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onOpenBookmarks,
  bookmarksCount,
  onOpenContact,
  onOpenAbout,
  onOpenAds,
}) => {
  const [selectedCity, setSelectedCity] = useState<'hanoi' | 'hcm' | 'danang'>('hanoi');

  const weatherData = {
    hanoi: { city: 'Hà Nội', temp: '28°C', desc: 'Trời nắng nhẹ', icon: Sun },
    hcm: { city: 'TP.HCM', temp: '33°C', desc: 'Nắng nóng', icon: CloudSun },
    danang: { city: 'Đà Nẵng', temp: '30°C', desc: 'Mây thay đổi', icon: CloudRain },
  };

  const currentWeather = weatherData[selectedCity];

  return (
    <div className="w-full bg-white border-b border-slate-200 text-xs text-slate-600" data-purpose="top-utility-bar">
      <div className="max-w-[1400px] mx-auto px-4 lg:px-8 py-1.5 flex flex-wrap justify-between items-center gap-2">
        {/* Date & Weather Info */}
        <div className="flex items-center space-x-3 sm:space-x-4 flex-wrap">
          <span className="font-medium text-slate-700">Thứ Sáu, 25 tháng 4 năm 2025</span>
          <span className="text-slate-300">|</span>
          <div className="flex items-center space-x-1.5 font-medium">
            <select
              aria-label="Chọn địa điểm thời tiết"
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value as 'hanoi' | 'hcm' | 'danang')}
              className="bg-transparent border-0 font-medium text-slate-800 cursor-pointer focus:ring-0 focus:outline-none pr-1 py-0 text-xs"
            >
              <option value="hanoi">Hà Nội</option>
              <option value="hcm">TP.HCM</option>
              <option value="danang">Đà Nẵng</option>
            </select>
            <svg className="w-4 h-4 text-amber-500 fill-current inline-block" viewBox="0 0 24 24">
              <path d="M12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C15.3137 6 18 8.68629 18 12C18 15.3137 15.3137 18 12 18ZM12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16ZM11 1H13V4H11V1ZM11 20H13V23H11V20ZM3.51472 4.92893L4.92893 3.51472L7.05025 5.63604L5.63604 7.05025L3.51472 4.92893ZM16.9497 18.364L18.364 16.9497L20.4853 19.0711L19.0711 20.4853L16.9497 18.364ZM19.0711 3.51472L20.4853 4.92893L18.364 7.05025L16.9497 5.63604L19.0711 3.51472ZM5.63604 16.9497L7.05025 18.364L4.92893 20.4853L3.51472 19.0711L5.63604 16.9497ZM1 11H4V13H1V11ZM20 11H23V13H20V11Z" />
            </svg>
            <span className="text-slate-800 font-semibold">{currentWeather.temp}</span>
            <span className="text-slate-500 hidden sm:inline">{currentWeather.desc}</span>
          </div>
        </div>

        {/* Quick Utility Links, Bookmarks & Social */}
        <div className="flex items-center space-x-3 sm:space-x-4">
          <button
            onClick={onOpenBookmarks}
            className="flex items-center space-x-1 text-slate-600 hover:text-red-600 transition-colors font-medium bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded"
            title="Xem tin đã lưu"
          >
            <Bookmark className="w-3.5 h-3.5 text-red-600" />
            <span>Đã lưu ({bookmarksCount})</span>
          </button>

          <div className="hidden sm:flex items-center space-x-3 text-slate-500">
            <button onClick={onOpenAbout} className="hover:text-blue-700 transition-colors">Về chúng tôi</button>
            <span>|</span>
            <button onClick={onOpenContact} className="hover:text-blue-700 transition-colors">Liên hệ</button>
            <span>|</span>
            <button onClick={onOpenAds} className="hover:text-blue-700 transition-colors">Quảng cáo</button>
          </div>

          <div className="flex items-center space-x-1.5 sm:space-x-2 text-slate-600 border-l pl-3 sm:pl-4 border-slate-200">
            {/* Facebook */}
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
              className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </a>

            {/* TikTok */}
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="TikTok"
              className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center hover:bg-black hover:text-white transition-colors"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </a>

            {/* X / Twitter */}
            <a
              href="https://x.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="X"
              className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-800 hover:text-white transition-colors"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
