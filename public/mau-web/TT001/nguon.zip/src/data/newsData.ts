import { Article, Category, HotNewsItem } from '../types';

export const CATEGORIES: Category[] = [
  { id: 'home', name: 'Trang chủ' },
  {
    id: 'thoi-su',
    name: 'Thời sự',
    badgeName: 'THỜI SỰ',
    hotTopics: ['Chính sách mới', 'Kinh tế vĩ mô', 'Quy hoạch đô thị', 'Hạ tầng giao thông', 'Đối ngoại'],
  },
  {
    id: 'cong-nghe',
    name: 'Công nghệ',
    badgeName: 'CÔNG NGHỆ',
    hotTopics: ['Trí tuệ nhân tạo (AI)', 'Bán dẫn & Chip', 'Thiết bị di động', 'An ninh mạng', 'Xe thông minh'],
  },
  {
    id: 'giao-duc',
    name: 'Giáo dục',
    badgeName: 'GIÁO DỤC',
    hotTopics: ['Tuyển sinh 2025', 'Du học & Học bổng', 'Đổi mới giáo dục', 'Giáo dục STEM', 'Hướng nghiệp & Việc làm', 'Kỹ năng số'],
  },
  {
    id: 'doi-song',
    name: 'Đời sống',
    badgeName: 'ĐỜI SỐNG',
    hotTopics: ['Giới trẻ & Gen Z', 'Sức khỏe tinh thần', 'Nhà ở & Không gian sống', 'Môi trường xanh', 'Ẩm thực'],
  },
  {
    id: 'the-thao',
    name: 'Thể thao',
    badgeName: 'THỂ THAO',
    hotTopics: ['Bóng đá Việt Nam', 'Vòng loại World Cup', 'Ngoại hạng Anh', 'Thể thao điện tử (Esports)', 'Tennis'],
  },
  {
    id: 'giai-tri',
    name: 'Giải trí',
    badgeName: 'GIẢI TRÍ',
    hotTopics: ['Âm nhạc V-Pop', 'Điện ảnh chiếu rạp', 'Nghệ sĩ & Showbiz', 'Truyền hình thực tế', 'Văn hóa nghệ thuật'],
  },
  {
    id: 'kinh-te',
    name: 'Kinh tế',
    badgeName: 'KINH TẾ',
    hotTopics: ['Thị trường vàng', 'Bất động sản', 'Chứng khoán', 'Xuất nhập khẩu', 'Doanh nghiệp khởi nghiệp'],
  },
  {
    id: 'suc-khoe',
    name: 'Sức khỏe',
    badgeName: 'SỨC KHỎE',
    hotTopics: ['Dinh dưỡng lành mạnh', 'Y học cổ truyền & hiện đại', 'Phòng chống dịch bệnh', 'Tập luyện thể thao'],
  },
  {
    id: 'du-lich',
    name: 'Du lịch',
    badgeName: 'DU LỊCH',
    hotTopics: ['Kỳ nghỉ 30/4 - 1/5', 'Điểm đến trong nước', 'Du lịch quốc tế', 'Trải nghiệm văn hóa', 'Khách sạn & Resort'],
  },
  {
    id: 'podcast',
    name: 'Podcast',
    badgeName: 'PODCAST',
    hotTopics: ['Đối thoại 24H', 'Góc nhìn chuyên gia', 'Chuyện làm nghề', 'Sách & Cuộc sống'],
  },
  {
    id: 'multimedia',
    name: 'Multimedia',
    badgeName: 'MULTIMEDIA',
    hotTopics: ['Infographic', 'Phóng sự ảnh', 'Video tương tác', 'Longform'],
  },
];

export const HOME_HOT_NEWS: HotNewsItem[] = [
  {
    id: 'h-1',
    order: 1,
    title: 'Giá vàng trong nước tiếp tục tăng mạnh, lập đỉnh mới',
    timeAgo: '2 giờ trước',
    category: 'kinh-te',
  },
  {
    id: 'h-2',
    order: 2,
    title: 'Hà Nội đề xuất mở rộng vùng phát thải thấp từ năm 2026',
    timeAgo: '4 giờ trước',
    category: 'thoi-su',
  },
  {
    id: 'h-3',
    order: 3,
    title: 'Cảnh báo thủ đoạn lừa đảo mới qua tin nhắn giả mạo ngân hàng',
    timeAgo: '6 giờ trước',
    category: 'cong-nghe',
  },
  {
    id: 'h-4',
    order: 4,
    title: 'Du lịch Việt Nam bứt phá dịp lễ 30/4 - 1/5',
    timeAgo: '8 giờ trước',
    category: 'du-lich',
  },
  {
    id: 'h-5',
    order: 5,
    title: 'Apple chuẩn bị ra mắt iPhone thế hệ mới vào tháng 9',
    timeAgo: '10 giờ trước',
    category: 'cong-nghe',
  },
];

export const TECH_HOT_NEWS: HotNewsItem[] = [
  {
    id: 'tech-hn-1',
    order: 1,
    title: 'OpenAI giới thiệu mô hình suy luận đa phương thức nâng cấp',
    timeAgo: '30 phút trước',
    category: 'cong-nghe',
  },
  {
    id: 'tech-hn-2',
    order: 2,
    title: 'Nvidia công bố hợp tác mở rộng hạ tầng AI quy mô lớn tại Việt Nam',
    timeAgo: '2 giờ trước',
    category: 'cong-nghe',
  },
  {
    id: 'tech-hn-3',
    order: 3,
    title: 'Apple chuẩn bị ra mắt iPhone thế hệ mới với phím bấm AI chuyên biệt',
    timeAgo: '4 giờ trước',
    category: 'cong-nghe',
  },
  {
    id: 'tech-hn-4',
    order: 4,
    title: 'Cảnh báo chiến dịch tấn công giả mạo ứng dụng sinh trắc học',
    timeAgo: '6 giờ trước',
    category: 'cong-nghe',
  },
  {
    id: 'tech-hn-5',
    order: 5,
    title: 'Thử nghiệm mạng 5.5G đạt tốc độ kỷ lục 10Gbps tại TP.HCM',
    timeAgo: '9 giờ trước',
    category: 'cong-nghe',
  },
];

export const EDU_HOT_NEWS: HotNewsItem[] = [
  {
    id: 'edu-hn-1',
    order: 1,
    title: 'Đại học Quốc gia Hà Nội và TP.HCM mở đăng ký đợt thi ĐGNL mới',
    timeAgo: '30 phút trước',
    category: 'giao-duc',
  },
  {
    id: 'edu-hn-2',
    order: 2,
    title: 'Bổ sung môn thi tự chọn trong kỳ thi tuyển sinh lớp 10',
    timeAgo: '2 giờ trước',
    category: 'giao-duc',
  },
  {
    id: 'edu-hn-3',
    order: 3,
    title: 'Cơ hội nhận 100 suất học bổng toàn phần chính phủ Úc',
    timeAgo: '4 giờ trước',
    category: 'giao-duc',
  },
  {
    id: 'edu-hn-4',
    order: 4,
    title: 'Cảnh báo các trang web giả mạo kỳ thi lấy chứng chỉ quốc tế',
    timeAgo: '6 giờ trước',
    category: 'giao-duc',
  },
  {
    id: 'edu-hn-5',
    order: 5,
    title: 'Thí điểm mô hình trường học số thông minh tại 10 tỉnh thành',
    timeAgo: '9 giờ trước',
    category: 'giao-duc',
  },
];

export const TAGS_HOME = [
  '#Việt Nam',
  '#Chuyển đổi số',
  '#Giáo dục',
  '#Kinh tế xanh',
  '#Sức khỏe',
  '#Du lịch',
  '#AI',
  '#World Cup',
  '#iPhone',
  '#Lối sống tích cực',
];

export const TAGS_TECH = [
  '#AI',
  '#BanDan',
  '#ChuyenDoiSo',
  '#5G',
  '#CyberSecurity',
  '#XeDien',
  '#Apple',
  '#Chatbot',
];

export const TAGS_EDU = [
  '#TuyenSinh2025',
  '#DiemThi',
  '#HocBong',
  '#DuHoc',
  '#DanhGiaNangLuc',
  '#STEM',
  '#GiaoDucSo',
  '#DaiHoc',
];

export const ARTICLES: Article[] = [
  // Home Hero Story
  {
    id: 'art-home-hero',
    title: 'Việt Nam hướng tới mục tiêu trở thành nước phát triển vào năm 2045',
    excerpt: 'Thủ tướng khẳng định Việt Nam kiên định với mục tiêu phát triển nhanh, bền vững, đổi mới sáng tạo và chuyển đổi xanh, hướng tới trở thành nước phát triển, thu nhập cao vào năm 2045.',
    category: 'thoi-su',
    categoryLabel: 'THỜI SỰ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC4tJAuA_sXy5qJ0mPqZxOjkP3Mk4P_QPcwP603iMA2YRvPJCciCgaff5A7gEd9g6Mo5J-S0zGtji2rTSTQkFlyY5WsaqNz18LimhweuhmT91lKxjuvlhEijfF_ESAx832kcrwx75BSV0kywpN6xDip82z4T5D-FyU9ccmQA46Gim567mPGd1BkX1MyY3YLSADaJgmhDmO6As5CfSJJjm9EmSQH_NTEICamT25uXWuNr0lNoFC4mYTn',
    imageAlt: 'Việt Nam hướng tới mục tiêu phát triển',
    publishedAt: '25/04/2025',
    author: 'Nguyễn Thành Nam',
    commentsCount: 12,
    isHero: true,
    tags: ['#Việt Nam', '#Chuyển đổi số', '#Kinh tế xanh'],
    content: [
      'Phát biểu tại phiên họp toàn thể về chiến lược phát triển kinh tế xã hội tầm nhìn dài hạn, người đứng đầu Chính phủ nhấn mạnh Việt Nam đang đứng trước những vận hội lịch sử để bứt phá thần tốc.',
      'Trọng tâm chiến lược dựa trên 3 trụ cột đột phá: hoàn thiện thể chế đồng bộ minh bạch, phát triển hạ tầng giao thông kết nối liên vùng hiện đại (đặc biệt là đường sắt tốc độ cao Bắc - Nam), và đào tạo nguồn nhân lực chất lượng cao trong các ngành công nghệ lõi như bán dẫn, trí tuệ nhân tạo và kinh tế xanh.',
      'Với quy mô nền kinh tế đang mở rộng nhanh chóng và độ mở thương mại thuộc hàng cao nhất thế giới, Việt Nam tiếp tục là điểm đến tin cậy của dòng vốn FDI toàn cầu, hướng đến mục tiêu GDP bình quân đầu người vượt ngưỡng 18.000 USD vào năm 2045.'
    ],
    comments: [
      { id: 'c-1', author: 'Lê Văn An', content: 'Chiến lược rất rõ ràng và truyền cảm hứng. Thế hệ trẻ chúng tôi rất tin tưởng vào tương lai đất nước.', timestamp: '1 giờ trước', likes: 24 },
      { id: 'c-2', author: 'Hoàng Minh Tuấn', content: 'Đặc biệt đồng tình với định hướng tập trung vào bán dẫn và AI. Cần đẩy mạnh hơn nữa liên kết đại học - doanh nghiệp.', timestamp: '35 phút trước', likes: 11 },
    ],
  },

  // Home Stacked 1
  {
    id: 'art-home-stack-1',
    title: 'Nhiều trường đại học công bố phương án tuyển sinh năm 2025',
    excerpt: 'Hàng loạt trường đại học lớn thông báo điều chỉnh tỷ lệ tuyển sinh sớm và tăng cường sử dụng kết quả kỳ thi đánh giá năng lực của hai ĐHQG.',
    category: 'giao-duc',
    categoryLabel: 'GIÁO DỤC',
    subCategory: 'TUYỂN SINH',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCy2mmqZ9jKcjfLgvljiSYLR75MhQIs0v7Ccrd_nsEq01Z1GRdtoOgsKiWBGn8mtA2qVnW19BJ4RplhErVxDX3chIgIj7fh_6emorHN1EzLLL0wk_IPHYz-gkz0IA3BlB_ZGc286OlSlAl1i5f1F0bcVD02M_GQHugmhD5_OzRSGNZ6Bz9sJF8ra0iZfPJjvsqWs2wRRx32LsN_jfqo5f5xQU1dijDY5WWBRlzKBRmy1ViTLkyXPjUT',
    imageAlt: 'Tuyển sinh đại học',
    publishedAt: '25/04/2025',
    author: 'Vũ Lan Phương',
    commentsCount: 16,
    tags: ['#TuyenSinh2025', '#DaiHoc', '#DanhGiaNangLuc'],
    content: [
      'Năm 2025 đánh dấu kỳ thi tốt nghiệp THPT đầu tiên theo chương trình Giáo dục phổ thông 2018. Theo đó, phương án tuyển sinh của các trường đại học cũng có những bước ngoặt quan trọng.',
      'Các trường tốp đầu như Bách Khoa Hà Nội, ĐHQG TP.HCM, Ngoại thương và Kinh tế Quốc dân đều giảm chỉ tiêu xét tuyển bằng học bạ THPT đơn thuần, thay vào đó kết hợp chứng chỉ ngoại ngữ quốc tế cùng điểm thi đánh giá tư duy.',
      'Thí sinh cần sớm định hình tổ hợp môn thế mạnh và theo dõi sát sao đề án tuyển sinh chi tiết của từng ngành học mong muốn.'
    ],
  },

  // Home Stacked 2
  {
    id: 'art-home-stack-2',
    title: 'AI đang thay đổi cách con người làm việc như thế nào?',
    excerpt: 'Từ lập trình viên, nhân viên văn phòng đến kiến trúc sư, công cụ AI tạo sinh đang rút ngắn tới 40% thời gian xử lý các tác vụ lặp lại.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'TRÍ TUỆ NHÂN TẠO',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_6fR99syqZ2XtTTcCkyrem7pcdcRTGpqJ0xokZ-f_n18iQxh-nWFrCuRmyeza47eN1_vcNIIjno2aPmKccrsa-xdsvFbQL2JlBayFKBE4KkWzxEJvgL5tbzCTm__WQNOGmG7m95frI0OAUysb_VOl_HGffBWYrgfglH2zDH5JVe0X2Xft7gFKbLozZfv8qLFpY9Hg-Z22_eFj-GpydpLQXGJB5iRhmxXZIGo0Epr7WwZsFfBKwP14',
    imageAlt: 'Trí tuệ nhân tạo',
    publishedAt: '24/04/2025',
    author: 'Đỗ Quốc Đạt',
    commentsCount: 9,
    tags: ['#AI', '#ChuyenDoiSo', '#Chatbot'],
    content: [
      'Báo cáo mới nhất về thị trường lao động số cho thấy hơn 65% doanh nghiệp tại Việt Nam đã tích hợp ít nhất một giải pháp AI vào quy trình vận hành hàng ngày.',
      'Không chỉ đơn thuần là tự động hóa tác vụ cơ bản, các trợ lý AI thông minh đang đóng vai trò cộng sự đắc lực trong phân tích dữ liệu chuyên sâu, phác thảo chiến lược kinh doanh và sáng tạo nội dung đa phương tiện.',
      'Yếu tố then chốt cho người lao động hiện nay là kỹ năng làm chủ công cụ (AI literacy) và khả năng đặt câu hỏi chính xác (prompt engineering).'
    ],
  },

  // Home Stacked 3
  {
    id: 'art-home-stack-3',
    title: 'Đội tuyển Việt Nam rộng cửa dự vòng loại thứ 3 World Cup',
    excerpt: 'Chiến thắng thuyết phục trên sân nhà trước đối thủ trực tiếp giúp thầy trò huấn luyện viên nắm quyền tự quyết tấm vé đi tiếp.',
    category: 'the-thao',
    categoryLabel: 'THỂ THAO',
    subCategory: 'BÓNG ĐÁ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD9vERE652Dq9tWrm8jaTtL4uSijP3yUeSwFcHTQoD8WpZ0TiWApq0ymFWC20dek-uKIaftW7P7MXr5DbDTf-msea1CxS5iSFOtZZObKo2hBbonMPhaPN8Q_VUGMTDYuyVX15_G31uolfLBGLY5GpC8eQkoLXkKmQMucbSLqqY5ByoJKF9L29F4LiSjkW8h25eRqmy3XqWnwzgE_d2N70X_DUIg235Jo52lULFmaKyV_JEapmPI4cux',
    imageAlt: 'Đội tuyển Việt Nam',
    publishedAt: '24/04/2025',
    author: 'Trần Quang Huy',
    commentsCount: 31,
    tags: ['#World Cup', '#Bóng đá', '#Việt Nam'],
    content: [
      'Trận cầu rực lửa tối qua tại sân vận động Mỹ Đình đã làm nức lòng hàng triệu người hâm mộ cả nước khi các chiến binh sao vàng thi đấu kỷ luật, khoa học và bản lĩnh.',
      'Sự tỏa sáng của các gương mặt trẻ kết hợp cùng dàn cựu binh giàu kinh nghiệm đã bẻ gãy mọi đợt phản công của đối thủ, mang về 3 điểm trọn vẹn.',
      'Ở lượt trận quyết định sắp tới, đội tuyển chỉ cần một kết quả hòa là chính thức ghi tên vào vòng loại cuối cùng khu vực châu Á.'
    ],
  },

  // Home Featured 4 cards across
  {
    id: 'art-home-feat-1',
    title: 'Việt Nam thu hút hơn 10 tỷ USD vốn đầu tư xanh trong quý I/2025',
    excerpt: 'Dòng vốn FDI tập trung mạnh mẽ vào năng lượng tái tạo, khu công nghiệp sinh thái và hạ tầng sản xuất thông minh đạt chuẩn Net-Zero.',
    category: 'kinh-te',
    categoryLabel: 'KINH TẾ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmk5vi2tYcFEf_iGDuSan-NrZiNnemKeufk_0dzWwJURAr_qDrcV5BMH9pc5cjQ7-UAv78ya4EtPdqtGqYZK7_W0AlXAM1ThwdvPg3LfvAxfWvDJAFrBWPO5LRLbpDLHLkH8FURmABA396S-umBHgBbAP0lKcg_Ch7b0wgPuYtYCC_IoDxCEwC5Zv_X2uxTg2ECVzbtDAdyx47KrNjAE9Q2CU3TP2fnZNO2kD-m6v6FZuyUmSvpMd0',
    imageAlt: 'Việt Nam thu hút đầu tư xanh',
    publishedAt: '25/04/2025',
    commentsCount: 5,
    tags: ['#Kinh tế xanh', '#FDI', '#NetZero'],
    content: [
      'Sự dịch chuyển mạnh mẽ của chuỗi cung ứng toàn cầu sang tiêu chuẩn ESG (Môi trường - Xã hội - Quản trị) đang biến Việt Nam thành thỏi nam châm thu hút các nhà đầu tư chiến lược.',
      'Nhiều dự án nhà máy sản xuất linh kiện điện tử hoạt động 100% bằng điện năng lượng mặt trời áp mái và điện gió ngoài khơi đã được cấp phép nhanh chóng.',
      'Chính phủ cam kết tiếp tục tạo hành lang pháp lý thông thoáng và hạ tầng điện xanh ổn định để đón làn sóng công nghệ bán dẫn và hydrogen xanh.'
    ],
  },
  {
    id: 'art-home-feat-2',
    title: 'Gen Z thay đổi thói quen sống: Ưu tiên sức khỏe và trải nghiệm',
    excerpt: 'Khái niệm thành công đối với thế hệ trẻ không chỉ nằm ở tài chính mà gắn liền với sức khỏe thể chất, cân bằng nội tâm và bảo vệ thiên nhiên.',
    category: 'doi-song',
    categoryLabel: 'ĐỜI SỐNG',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJFHu8UYp4Kc8YtLT9IVXOHZ8yDr0LYGw5sgqZNHLTYWRvalCqt1vhv-u3NmldGKzs67AneZU47Vivnq09YibXKRfiw5_AkpIHByRBkKFpUyuw2I3L4KX_7kqcvNAN6Bd-4zTV_vBIcY67cLPuJueiC6HIXGxdz28Tzg1E_j2MZa1c_FUDp41PLzjE1FpexuBL5ojIGTw6-MsSQD-3yNn5XrWjBnyg-qD91QcPeYEjySPD2hsjnLPU',
    imageAlt: 'Gen Z thay đổi lối sống',
    publishedAt: '24/04/2025',
    commentsCount: 8,
    tags: ['#Lối sống tích cực', '#GenZ', '#Sức khỏe'],
    content: [
      'Một khảo sát xã hội học diện rộng vừa công bố cho thấy xu hướng tiêu dùng và phong cách sống của người trẻ dưới 28 tuổi đang có sự chuyển dịch sâu sắc.',
      'Các câu lạc bộ chạy bộ sáng sớm, chế độ ăn thuần chay lành mạnh và lối sống tối giản (minimalism) ngày càng nhận được sự hưởng ứng nồng nhiệt.',
      'Người trẻ sẵn sàng chi tiêu cho những chuyến du lịch khám phá văn hóa bản địa hơn là sở hữu những món đồ hiệu xa xỉ.'
    ],
  },
  {
    id: 'art-home-feat-3',
    title: 'Việt Nam lọt top 10 điểm đến thân thiện nhất thế giới 2025',
    excerpt: 'Tạp chí du lịch danh tiếng toàn cầu vinh danh sự hiếu khách, ẩm thực phong phú và cảnh quan kỳ vĩ của dải đất hình chữ S.',
    category: 'du-lich',
    categoryLabel: 'DU LỊCH',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCtg8mn3KVsjaQeOmbw5NNjN8fJdP-idH6vVq957-pw0cM-72EseO0S949IStqkW5HAVIMvgWGjkJhHWfpjbC36twzuUMY6e_92nuetJA520UEPTdWlRjOxOZFHfrZH9lC-cWxs29j7r5g5PdrJxO01t4lcSruCAJz3TK0OjG0Q4mKwW2-cE8TiUpeAvI28IT7DzCdmLvy1nyj9W_o69u3zBNQDfn9U41HcyeTYo5VRDRh9VN9jZg56',
    imageAlt: 'Điểm đến Việt Nam',
    publishedAt: '24/04/2025',
    commentsCount: 3,
    tags: ['#Du lịch', '#Việt Nam', '#Kỳ nghỉ'],
    content: [
      'Nụ cười nồng hậu của người dân địa phương, nét đẹp cổ kính của phố cổ Hội An, sự hùng vĩ của vịnh Hạ Long và Tràng An đã chinh phục hàng triệu độc giả quốc tế.',
      'Chính sách thị thực điện tử thông thoáng, thuận tiện cùng chi phí du lịch hợp lý tiếp tục tạo động lực tăng trưởng vượt bậc cho ngành du lịch Việt Nam trong năm 2025.',
      'Dự kiến dịp nghỉ lễ 30/4 - 1/5 tới đây sẽ chứng kiến lượng khách nội địa và quốc tế tăng hơn 30% so với cùng kỳ năm trước.'
    ],
  },
  {
    id: 'art-home-feat-4',
    title: 'Sơn Tùng M-TP trở lại với dự án âm nhạc mới sau 2 năm vắng bóng',
    excerpt: 'Đoạn teaser bí ẩn vừa ra mắt lập tức leo thẳng top 1 trending YouTube và thu hút hàng triệu lượt thảo luận trên mạng xã hội.',
    category: 'giai-tri',
    categoryLabel: 'GIẢI TRÍ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDZQWAREru8B8HZoCFMgQyTUbu9uHj5Zk7kM94fTUzal7zTyPc1wM8JlZq60RFkgUnSVQrO1yRhE2mi3wWS6xaWzwjNNNz1TXXryMxsQDt4JzpoaVAgLPOFyOCrl5kPwXhoz36odJ3CvTlAPG2koNeLfwSwrKNWFXTkiCMGzuUf23esiSPQB3htRrQaWiNI1oWUz9b43ZgQeyxkOQ2F6b9z7RiG681e-uuko_TOP1LT-7yFTOG9Hjqz',
    imageAlt: 'Sơn Tùng M-TP',
    publishedAt: '23/04/2025',
    commentsCount: 12,
    tags: ['#VPop', '#Âm nhạc', '#Giải trí'],
    content: [
      'Sau chuỗi ngày kín tiếng và tập trung nghiên cứu chất liệu âm nhạc mới, Sơn Tùng M-TP đã chính thức xác nhận việc phát hành album phòng thu được đầu tư công phu bậc nhất trong sự nghiệp.',
      'Dự án có sự hợp tác với các nhà sản xuất âm nhạc quốc tế từng đoạt giải Grammy, hứa hẹn mang đến sự kết hợp độc đáo giữa âm hưởng nhạc cụ dân tộc Việt Nam và giai điệu R&B hiện đại.',
      'Sự kiện công chiếu MV mới sẽ được phát sóng đồng thời tại nhiều quảng trường lớn ở Hà Nội và TP.HCM.'
    ],
  },

  // Tech Page Articles
  {
    id: 'art-tech-hero',
    title: 'Làn sóng AI thế hệ mới tái định hình hạ tầng số và sản xuất tại Việt Nam',
    excerpt: 'Các tập đoàn công nghệ hàng đầu liên tục rót hàng trăm triệu USD xây dựng trung tâm dữ liệu và phát triển mô hình ngôn ngữ lớn bản địa hóa, mở ra kỷ nguyên đột phá cho nền kinh tế số.',
    category: 'cong-nghe',
    categoryLabel: 'TIÊU ĐIỂM CÔNG NGHỆ',
    subCategory: 'TIÊU ĐIỂM CÔNG NGHỆ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC_6fR99syqZ2XtTTcCkyrem7pcdcRTGpqJ0xokZ-f_n18iQxh-nWFrCuRmyeza47eN1_vcNIIjno2aPmKccrsa-xdsvFbQL2JlBayFKBE4KkWzxEJvgL5tbzCTm__WQNOGmG7m95frI0OAUysb_VOl_HGffBWYrgfglH2zDH5JVe0X2Xft7gFKbLozZfv8qLFpY9Hg-Z22_eFj-GpydpLQXGJB5iRhmxXZIGo0Epr7WwZsFfBKwP14',
    imageAlt: 'Làn sóng AI thế hệ mới',
    publishedAt: '25/04/2025 - 45 phút trước',
    author: 'Đặng Tuấn Hưng',
    commentsCount: 18,
    isHero: true,
    tags: ['#AI', '#ChuyenDoiSo', '#HaTangSo'],
    content: [
      'Chỉ trong 6 tháng đầu năm 2025, Việt Nam đã đón nhận các cam kết đầu tư hạ tầng tính toán đám mây và trung tâm siêu dữ liệu (Hyperscale Datacenter) quy mô kỷ lục từ các tập đoàn công nghệ toàn cầu.',
      'Sự hiện diện của các cụm máy chủ trang bị GPU xử lý AI tiên tiến nhất cho phép các kỹ sư Việt Nam huấn luyện những mô hình ngôn ngữ lớn tiếng Việt chuyên biệt, phục vụ giải quyết bài toán ngành y tế, giáo dục, tài chính và quản trị hành chính công.',
      'Đại diện Hiệp hội Phần mềm và Dịch vụ CNTT Việt Nam (VINASA) nhận định đây là bước đệm lịch sử giúp nền kinh tế số Việt Nam đạt tỷ trọng 30% GDP vào năm 2030.'
    ],
    comments: [
      { id: 'c-tech-1', author: 'Trần Văn Minh', content: 'Thật tự hào khi Việt Nam đang trở thành điểm nóng về hạ tầng AI của khu vực Đông Nam Á!', timestamp: '30 phút trước', likes: 19 },
      { id: 'c-tech-2', author: 'Lê Thuỳ Dung', content: 'Quan trọng nhất vẫn là đào tạo nguồn nhân lực chất lượng cao để làm chủ các công nghệ này.', timestamp: '12 phút trước', likes: 7 },
    ],
  },
  {
    id: 'art-tech-1',
    title: 'Apple đẩy mạnh hợp tác chuỗi cung ứng linh kiện và nghiên cứu AI tại Đông Nam Á',
    excerpt: 'Chiến lược đa dạng hóa chuỗi giá trị mở ra cơ hội vàng cho các đối tác công nghệ phụ trợ và kỹ sư phần mềm Việt Nam tham gia trực tiếp hệ sinh thái toàn cầu.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'TRÍ TUỆ NHÂN TẠO',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCy2mmqZ9jKcjfLgvljiSYLR75MhQIs0v7Ccrd_nsEq01Z1GRdtoOgsKiWBGn8mtA2qVnW19BJ4RplhErVxDX3chIgIj7fh_6emorHN1EzLLL0wk_IPHYz-gkz0IA3BlB_ZGc286OlSlAl1i5f1F0bcVD02M_GQHugmhD5_OzRSGNZ6Bz9sJF8ra0iZfPJjvsqWs2wRRx32LsN_jfqo5f5xQU1dijDY5WWBRlzKBRmy1ViTLkyXPjUT',
    imageAlt: 'Chuỗi cung ứng AI',
    publishedAt: '25/04/2025 - 1 giờ trước',
    commentsCount: 14,
    tags: ['#Apple', '#AI', '#ChuoiCungUng'],
    content: [
      'Chuyến thăm và làm việc gần đây của lãnh đạo cấp cao Apple đã khẳng định vị thế của Việt Nam như một trung tâm sản xuất thiết bị phần cứng chủ lực toàn cầu.',
      'Không chỉ dừng lại ở lắp ráp iPad, AirPods hay Apple Watch, hãng quả táo khuyết đang mở rộng các phòng nghiên cứu R&D kiểm thử tính năng AI tích hợp trên hệ điều hành iOS mới.',
      'Các nhà máy đối tác tại Bắc Giang, Bắc Ninh và Bình Dương đều đang nâng cấp dây chuyền sản xuất tự động hóa đạt chuẩn khắt khe.'
    ],
  },
  {
    id: 'art-tech-2',
    title: 'Việt Nam đặt mục tiêu đào tạo 50.000 kỹ sư bán dẫn: Bước chuẩn bị cho kỷ nguyên chip vi mạch',
    excerpt: 'Chính sách ưu đãi vượt trội và các chương trình liên kết cùng đại học danh tiếng quốc tế đang tạo bàn đạp phát triển nguồn nhân lực chất lượng cao.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'BÁN DẪN',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmk5vi2tYcFEf_iGDuSan-NrZiNnemKeufk_0dzWwJURAr_qDrcV5BMH9pc5cjQ7-UAv78ya4EtPdqtGqYZK7_W0AlXAM1ThwdvPg3LfvAxfWvDJAFrBWPO5LRLbpDLHLkH8FURmABA396S-umBHgBbAP0lKcg_Ch7b0wgPuYtYCC_IoDxCEwC5Zv_X2uxTg2ECVzbtDAdyx47KrNjAE9Q2CU3TP2fnZNO2kD-m6v6FZuyUmSvpMd0',
    imageAlt: 'Kỹ sư bán dẫn',
    publishedAt: '25/04/2025 - 3 giờ trước',
    commentsCount: 9,
    tags: ['#BanDan', '#KysuBanDan', '#CongNghe'],
    content: [
      'Đề án quốc gia về đào tạo nhân lực ngành công nghiệp bán dẫn đến năm 2030 đã chính thức bước vào giai đoạn tăng tốc với ngân sách hỗ trợ học bổng đặc biệt.',
      'Các liên minh trường đại học công nghệ hàng đầu tại Hà Nội, Đà Nẵng và TP.HCM đã trang bị phòng thí nghiệm thiết kế vi mạch chuyên sâu với bản quyền phần mềm thiết kế chip quốc tế.',
      'Doanh nghiệp cam kết bao tiêu đầu ra cho các sinh viên tốt nghiệp loại khá giỏi với mức lương khởi điểm cực kỳ cạnh tranh.'
    ],
  },
  {
    id: 'art-tech-3',
    title: 'Cảnh báo thủ đoạn tấn công mã độc thế hệ mới nhắm vào tài khoản ngân hàng số',
    excerpt: 'Các chuyên gia an ninh mạng khuyến cáo người dùng không cài đặt tệp APK không rõ nguồn gốc và thường xuyên cập nhật bản vá bảo mật trên smartphone.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'AN TOÀN MẠNG',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDZQWAREru8B8HZoCFMgQyTUbu9uHj5Zk7kM94fTUzal7zTyPc1wM8JlZq60RFkgUnSVQrO1yRhE2mi3wWS6xaWzwjNNNz1TXXryMxsQDt4JzpoaVAgLPOFyOCrl5kPwXhoz36odJ3CvTlAPG2koNeLfwSwrKNWFXTkiCMGzuUf23esiSPQB3htRrQaWiNI1oWUz9b43ZgQeyxkOQ2F6b9z7RiG681e-uuko_TOP1LT-7yFTOG9Hjqz',
    imageAlt: 'An ninh mạng số',
    publishedAt: '24/04/2025',
    commentsCount: 26,
    tags: ['#CyberSecurity', '#AnNinhMang', '#NganHangSo'],
    content: [
      'Cục An toàn thông tin vừa phát đi cảnh báo đỏ về một biến thể trojan ngân hàng tinh vi có khả năng tự động vượt qua lớp bảo vệ sinh trắc học khuôn mặt trên các thiết bị Android đã bị bẻ khóa (root).',
      'Kẻ gian lợi dụng các tin nhắn mời chào việc làm online hoặc giả danh cán bộ cơ quan nhà nước để dụ nạn nhân cài ứng dụng dịch vụ công giả mạo.',
      'Người dân tuyệt đối không cấp quyền Trợ năng (Accessibility Service) cho các ứng dụng ngoài kho chính thức Google Play và App Store.'
    ],
  },
  {
    id: 'art-tech-4',
    title: 'Đánh giá chi tiết mẫu smartphone trang bị vi xử lý tích hợp NPU xử lý tác vụ ngoại tuyến',
    excerpt: 'Khả năng dịch thuật thời gian thực và chỉnh sửa ảnh xóa vật thể siêu nhanh mà không cần kết nối mạng internet mang lại trải nghiệm tiện dụng tối đa.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'THIẾT BỊ',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJFHu8UYp4Kc8YtLT9IVXOHZ8yDr0LYGw5sgqZNHLTYWRvalCqt1vhv-u3NmldGKzs67AneZU47Vivnq09YibXKRfiw5_AkpIHByRBkKFpUyuw2I3L4KX_7kqcvNAN6Bd-4zTV_vBIcY67cLPuJueiC6HIXGxdz28Tzg1E_j2MZa1c_FUDp41PLzjE1FpexuBL5ojIGTw6-MsSQD-3yNn5XrWjBnyg-qD91QcPeYEjySPD2hsjnLPU',
    imageAlt: 'Smartphone NPU',
    publishedAt: '24/04/2025',
    commentsCount: 7,
    tags: ['#NPU', '#Smartphone', '#OnDeviceAI'],
    content: [
      'Việc đưa các mô hình AI trực tiếp xuống phần cứng điện thoại (On-device AI) với nhân NPU hiệu năng cao lên tới 45 TOPS đã xóa bỏ hoàn toàn độ trễ khi xử lý dữ liệu.',
      'Trong các bài thử nghiệm thực tế, máy có thể bóc tách âm thanh, nhận diện người nói và tóm tắt cuộc họp dài 60 phút chỉ trong vòng chưa đầy 15 giây mà không tiêu hao nhiều pin.',
      'Đây hứa hẹn sẽ là tiêu chuẩn cấu hình bắt buộc cho mọi dòng smartphone phân khúc cận cao cấp và cao cấp trong nửa cuối năm 2025.'
    ],
  },
  {
    id: 'art-tech-5',
    title: 'Công nghệ pin thể rắn đột phá: Xe điện có thể chạy hơn 1.000 km sau một lần sạc',
    excerpt: 'Thời gian sạc đầy được rút ngắn xuống dưới 12 phút cùng độ bền vượt trội mở ra tương lai giao thông xanh không phát thải trên diện rộng.',
    category: 'cong-nghe',
    categoryLabel: 'CÔNG NGHỆ',
    subCategory: 'XE THÔNG MINH',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCtg8mn3KVsjaQeOmbw5NNjN8fJdP-idH6vVq957-pw0cM-72EseO0S949IStqkW5HAVIMvgWGjkJhHWfpjbC36twzuUMY6e_92nuetJA520UEPTdWlRjOxOZFHfrZH9lC-cWxs29j7r5g5PdrJxO01t4lcSruCAJz3TK0OjG0Q4mKwW2-cE8TiUpeAvI28IT7DzCdmLvy1nyj9W_o69u3zBNQDfn9U41HcyeTYo5VRDRh9VN9jZg56',
    imageAlt: 'Xe điện pin thể rắn',
    publishedAt: '23/04/2025',
    commentsCount: 11,
    tags: ['#XeDien', '#PinTheRan', '#GiaoThongXanh'],
    content: [
      'Rào cản lớn nhất của người tiêu dùng đối với xe thuần điện là quãng đường di chuyển và nguy cơ cháy nổ nhiệt đã được giải quyết triệt để bằng chất điện phân rắn thế hệ mới.',
      'Các bài thử nghiệm va đập và quá nhiệt ở mức 200 độ C cho thấy pin thể rắn không hề sinh khói hay bốc cháy, đảm bảo an toàn tối đa cho hành khách.',
      'Dây chuyền sản xuất thương mại hàng loạt dự kiến sẽ chính thức đi vào hoạt động từ quý 4 năm nay.'
    ],
  },

  // Education Page Articles
  {
    id: 'art-edu-hero',
    title: 'Phương án thi tốt nghiệp THPT và xét tuyển đại học 2025: Những điều chỉnh bước ngoặt thí sinh cần biết',
    excerpt: 'Bộ Giáo dục và Đào tạo công bố định dạng đề thi mới chú trọng năng lực tư duy thực tiễn, các trường đại học tốp đầu đồng loạt điều chỉnh tỷ lệ chỉ tiêu xét tuyển học bạ và tăng chỉ tiêu thi đánh giá năng lực.',
    category: 'giao-duc',
    categoryLabel: 'TIÊU ĐIỂM GIÁO DỤC',
    subCategory: 'TIÊU ĐIỂM GIÁO DỤC',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCYVOfqLYxhSzkYI99NDdgR12C3_4oIuAAU8Rkl1QYia91qXma5xSgs-0Tly_gxny-mnr8tLl3w2EUH6qyB3G9BZqghFex1Rqa0NLguAZHy8D4zNTSSfYWX-avynntjkWjze6Bc2an0Klh__k8dnDAp57tPelAq3XU5YZW72dnZQhN5FlID5wwic_z_thNhipQARu6HBFXe_m--H-V998Y8xnh__AVCxFwLTWvNhd0xppDSzGaBsFb5',
    imageAlt: 'Kỳ thi tốt nghiệp THPT và xét tuyển đại học 2025',
    publishedAt: '25/04/2025 - 30 phút trước',
    author: 'Nguyễn Bích Ngọc',
    commentsCount: 24,
    isHero: true,
    tags: ['#TuyenSinh2025', '#DiemThi', '#DaiHoc'],
    content: [
      'Kỳ thi tốt nghiệp THPT năm 2025 có cấu trúc đề thi hoàn toàn mới với các dạng câu hỏi trắc nghiệm đúng/sai và trả lời ngắn, hạn chế tối đa tình trạng khoanh bừa may rủi.',
      'Thí sinh chỉ phải thi 4 môn bắt buộc gồm Toán, Ngữ văn và 2 môn tự chọn trong số các môn học ở cấp THPT, giúp giảm áp lực thi cử đáng kể và cho phép học sinh phát huy tối đa sở trường.',
      'Các trường đại học cũng nhanh chóng cập nhật ma trận xét tuyển, trong đó điểm thi tốt nghiệp và kỳ thi đánh giá năng lực tiếp tục giữ vai trò xương sống trong công tác tuyển sinh.'
    ],
    comments: [
      { id: 'c-edu-1', author: 'Phan Minh Hằng', content: 'Cấu trúc đề mới đòi hỏi học sinh phải hiểu sâu bản chất, không thể học vẹt theo khuôn mẫu cũ được nữa.', timestamp: '20 phút trước', likes: 15 },
      { id: 'c-edu-2', author: 'Trần Đức Long', content: 'Chúc các sĩ tử 2007 tự tin và có sự chuẩn bị chu đáo nhất cho bước ngoặt quan trọng này.', timestamp: '10 phút trước', likes: 8 },
    ],
  },
  {
    id: 'art-edu-1',
    title: 'Bí quyết săn học bổng toàn phần Châu Âu của nữ sinh chuyên ngữ: Khởi đầu từ những dự án cộng đồng',
    excerpt: 'Không chỉ sở hữu bảng điểm IELTS và SAT ấn tượng, bài luận phản biện xã hội sắc sảo chính là chìa khóa mở cánh cửa đại học danh tiếng.',
    category: 'giao-duc',
    categoryLabel: 'GIÁO DỤC',
    subCategory: 'DU HỌC & HỌC BỔNG',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCvzOvn07y0pX_-nLa4bC1Qzd9v9Cea4BgcLMas8q8yGGrV11TAlwQ976CWuGdfueLvAqRmpMAvu3f7dbt3U7xnLbuCV3rm0Ym0qceht0BA_3q7eZ_lIhEaX6eBoRoafSW_jBYNiM8Re5XalLWsR45fGA0oBnAhedm3l4RCw2hY64560Raww9fpIAe_WGyCLx57_IGCS_7rutaVnSsdvEnjXGGBE6GxEr0FarK6K3ua006-UMXUH1Z3',
    imageAlt: 'Săn học bổng toàn phần Châu Âu',
    publishedAt: '25/04/2025 - 1 giờ trước',
    commentsCount: 19,
    tags: ['#HocBong', '#DuHoc', '#ChauAu'],
    content: [
      'Nguyễn Mai Chi, nữ sinh lớp 12 chuyên Anh Trường THPT Chuyên Hà Nội - Amsterdam vừa xuất sắc giành được 4 gói học bổng toàn phần từ các trường đại học tại Hà Lan, Đức và Pháp.',
      'Chi chia sẻ rằng các hội đồng tuyển sinh quốc tế đánh giá rất cao tính chân thực và sự bền bỉ trong các dự án thiện nguyện dạy tiếng Anh cho trẻ em vùng cao mà em đã khởi xướng từ năm lớp 10.',
      'Bài luận của em tập trung vào góc nhìn đa chiều về bình đẳng tiếp cận công nghệ thông tin trong thời đại số hóa giáo dục.'
    ],
  },
  {
    id: 'art-edu-2',
    title: 'Đưa mô hình STEM và Trí tuệ nhân tạo vào trường phổ thông: Học sinh hào hứng chế tạo robot thực tế',
    excerpt: 'Các tiết học lý thuyết khô khan được thay thế bằng trải nghiệm lắp ráp thiết bị, lập trình ứng dụng giải quyết bài toán môi trường học đường.',
    category: 'giao-duc',
    categoryLabel: 'GIÁO DỤC',
    subCategory: 'ĐỔI MỚI GIẢNG DẠY',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC0b6SBfAKzLd1gkT6Hx8KcoPVVNNIFW3-c6QMEwNjvnu0C7zdU5wzzJ3-vOgHL9oEGdxNJEuksIz81a_HSiJBtEWv8LjJNbH9GRhqF9y6HGeHeYlq_3x8pH4SH1CYdBd2La5lufMoBnOAYqWBQsVGxVaTc4msyv4b8JgRtYxwdzrKOrr-YnJd-ClFR_fWSUf2XhHtS1GUSn9LauuENkqLDV5udfeVnbL8nYBBeq95ZN-4PLhGIh46q',
    imageAlt: 'STEM và Trí tuệ nhân tạo',
    publishedAt: '25/04/2025 - 3 giờ trước',
    commentsCount: 15,
    tags: ['#STEM', '#Robot', '#GiaoDucSo'],
    content: [
      'Tại các trường THCS và THPT ở nhiều tỉnh thành, câu lạc bộ Robotics và Sáng tạo khoa học kỹ thuật đang trở thành sân chơi ngoại khóa sôi nổi nhất.',
      'Học sinh được tự tay thiết kế bảng mạch điều khiển, hàn linh kiện cảm biến và viết code Python để vận hành cánh tay robot tự động phân loại rác thải nhựa tại căng-tin trường.',
      'Phương pháp học qua dự án (Project-Based Learning) giúp các em rèn luyện tư duy phản biện và khả năng phối hợp làm việc nhóm rất hiệu quả.'
    ],
  },
  {
    id: 'art-edu-3',
    title: 'Hơn 50 trường đại học công bố học phí và chính sách miễn giảm cho tân sinh viên tài năng năm 2025',
    excerpt: 'Nhiều quỹ tín dụng hỗ trợ lãi suất 0% và học bổng doanh nghiệp được triển khai nhằm đảm bảo cơ hội tiếp cận giảng đường cho sinh viên khó khăn.',
    category: 'giao-duc',
    categoryLabel: 'GIÁO DỤC',
    subCategory: 'ĐẠI HỌC',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBD2imEFaDr0kxdu-BLCU7sIdGCjYRMHVyk2CxoN5R6z5Q2tKzfyweMqZifeXGOJWdH3VvEGDUuzaJG-kH38ODifuPQbmFWYrZXOdLUiaNNpvDKT96rjPOYBRjPU25zCZ1jOxKfnzaGF_UivNNvt3UyYCTcnKB7P9vT927kuAvd6cTf9MUlTmIynWjE_ZQ7etoTDpzHhXH4iqdcI1-We6zL8va-XvMD3FENBe4HTN5ZU7dcyey4bWW-',
    imageAlt: 'Học phí và học bổng đại học',
    publishedAt: '24/04/2025',
    commentsCount: 28,
    tags: ['#DaiHoc', '#HocPhi', '#TuyenSinh2025'],
    content: [
      'Nhằm san sẻ gánh nặng tài chính với các gia đình học sinh, hàng loạt trường đại học lớn đã công bố mức học phí ổn định, không tăng so với năm học trước.',
      'Đặc biệt, chương trình học bổng "Thắp sáng tương lai" từ các tập đoàn công nghệ và ngân hàng sẽ cấp toàn bộ chi phí học tập và sinh hoạt phí cho các thủ khoa, á khoa đầu vào.',
      'Bộ Giáo dục và Đào tạo cũng yêu cầu các trường công khai minh bạch mọi khoản phụ phí và điều kiện duy trì học bổng trong suốt khóa học.'
    ],
  },
  {
    id: 'art-edu-4',
    title: 'Dự báo xu hướng dịch chuyển ngành nghề 5 năm tới: Công nghệ bán dẫn và Khoa học dữ liệu dẫn đầu nhu cầu nhân lực',
    excerpt: 'Các chuyên gia tuyển dụng khuyến nghị sinh viên cần trang bị tư duy liên ngành và khả năng thích ứng linh hoạt trước làn sóng tự động hóa.',
    category: 'giao-duc',
    categoryLabel: 'GIÁO DỤC',
    subCategory: 'KỸ NĂNG & HƯỚNG NGHIỆP',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAu3Y9sRnNbqDCimkVq1Eo2IRsHOjmwFpeS2aBkI3aOY-IsNNF6FtuSElEP1BG6u4gdWlm24MI0xI89HhYlwQdVv9fydKVDhLL_mtq9TZo-rUdcHRKts4NCBGnk8uPKgL1CBnhVE9qKt0FahMUAurX7zLX_rJwZiOGISUX8y2KLQ9syDNNhdXvlwRbxtHRYr07RulekETB4H23shllUmHF0_SjoJKb40dGP3JTvsCW0O-TCL50DwOZp',
    imageAlt: 'Kỹ năng và hướng nghiệp',
    publishedAt: '24/04/2025',
    commentsCount: 12,
    tags: ['#HuongNghiep', '#KyNangSo', '#BanDan'],
    content: [
      'Diễn đàn Hướng nghiệp và Thị trường việc làm vừa công bố danh sách 10 nhóm ngành nghề có tốc độ tăng trưởng nhu cầu tuyển dụng mạnh mẽ nhất trong giai đoạn 2025 - 2030.',
      'Đứng đầu bảng là các vị trí kỹ sư thiết kế vật lý vi mạch (Physical Design Engineer), chuyên gia bảo mật điện toán đám mây và chuyên viên phân tích dữ liệu kinh doanh.',
      'Bên cạnh chuyên môn kỹ thuật vững vàng, khả năng giao tiếp tiếng Anh lưu loát và kỹ năng làm việc trong môi trường đa văn hóa sẽ là lợi thế cạnh tranh mang tính quyết định.'
    ],
  },
];
