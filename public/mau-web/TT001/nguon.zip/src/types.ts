export type CategoryId =
  | 'home'
  | 'thoi-su'
  | 'cong-nghe'
  | 'giao-duc'
  | 'doi-song'
  | 'the-thao'
  | 'giai-tri'
  | 'kinh-te'
  | 'suc-khoe'
  | 'du-lich'
  | 'podcast'
  | 'multimedia';

export interface Category {
  id: CategoryId;
  name: string;
  badgeName?: string;
  hotTopics?: string[];
}

export interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  likes: number;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content?: string[];
  category: CategoryId;
  categoryLabel: string;
  subCategory?: string;
  imageUrl: string;
  imageAlt: string;
  publishedAt: string;
  author?: string;
  commentsCount: number;
  comments?: Comment[];
  isHero?: boolean;
  tags?: string[];
}

export interface HotNewsItem {
  id: string;
  order: number;
  title: string;
  timeAgo: string;
  category?: CategoryId;
}
