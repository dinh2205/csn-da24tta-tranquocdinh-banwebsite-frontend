import { useState, useEffect } from 'react';
import { PageRoute, Product, CartItem } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { AccountModal } from './components/AccountModal';
import { OrderTrackModal } from './components/OrderTrackModal';
import { Toast } from './components/Toast';

import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { PromotionsPage } from './pages/PromotionsPage';
import { BlogPage } from './pages/BlogPage';
import { ContactPage } from './pages/ContactPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageRoute>('trang-chu');
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      product: {
        id: 'init-p1',
        name: 'Bút gel Thiên Long TL-08',
        brand: 'Thiên Long',
        category: 'but-viet',
        price: 16000,
        originalPrice: 20000,
        rating: 4.5,
        reviewCount: 125,
        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBWvO5uD-tOMN49O5rNAUswmf4ZRCyN__GnHjmcJcyDneQ3tdwkHKGk38crZIn4ZX8g5x54-XBth5mxPx_d1gsbomC4rYyALcXOzocjsUP6c65kzBiri3xH0evEF_MWVpdMwtu1nYbF8HUP7JnafCNficpT17R08gCoi_V2VeTJ_Ui3z_aQRWcxBTqv7rM1X_1kH3PlG-CAIapVeVBCcCC3BqiQ4K4VOhaV7_qkgBZhsiOQ2gbF8CrJ6Q'
      },
      quantity: 2
    }
  ]);
  const [wishlist, setWishlist] = useState<string[]>(['p1', 'p6']);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>('FREESHIP');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState('all');

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isOrderTrackOpen, setIsOrderTrackOpen] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ message: string | null; icon: string; visible: boolean }>({
    message: null,
    icon: 'check_circle',
    visible: false,
  });

  const showToast = (message: string, icon = 'check_circle') => {
    setToast({ message, icon, visible: true });
    setTimeout(() => {
      setToast((prev) => ({ ...prev, visible: false }));
    }, 2800);
  };

  const navigateTo = (page: PageRoute) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    showToast(`Đã thêm "${product.name}" vào giỏ hàng!`, 'shopping_bag');
  };

  const handleUpdateQty = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Đã xóa sản phẩm khỏi giỏ hàng', 'delete');
  };

  const handleFilterCategory = (catSlug: string) => {
    setSelectedCategorySlug(catSlug);
    setCurrentPage('san-pham');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    setCurrentPage('san-pham');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  // Sync hash if present
  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (['trang-chu', 'san-pham', 'danh-muc', 'khuyen-mai', 'blog', 'lien-he'].includes(hash)) {
      setCurrentPage(hash as PageRoute);
    }
  }, []);

  return (
    <div className="min-h-screen bg-surface flex flex-col font-sans">
      {/* Universal Header */}
      <Header
        currentPage={currentPage}
        onNavigate={navigateTo}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        wishlistCount={wishlist.length}
        onOpenWishlist={() => {
          showToast(`Bạn đang có ${wishlist.length} sản phẩm trong danh sách yêu thích!`, 'favorite');
        }}
        onOpenAccount={() => setIsAccountOpen(true)}
        onOpenOrderTrack={() => setIsOrderTrackOpen(true)}
        onSearch={handleSearch}
        searchQuery={searchQuery}
      />

      {/* Main Content View with top offset for fixed header */}
      <main className="w-full pt-[135px] bg-surface flex-1">
        {currentPage === 'trang-chu' && (
          <HomePage
            onNavigate={navigateTo}
            onAddToCart={handleAddToCart}
            onShowToast={showToast}
            onFilterCategory={handleFilterCategory}
          />
        )}

        {currentPage === 'san-pham' && (
          <ProductsPage
            onNavigate={navigateTo}
            onAddToCart={handleAddToCart}
            onShowToast={showToast}
            searchQuery={searchQuery}
            selectedCategorySlug={selectedCategorySlug}
          />
        )}

        {currentPage === 'danh-muc' && (
          <CategoriesPage
            onNavigate={navigateTo}
            onAddToCart={handleAddToCart}
            onShowToast={showToast}
            onSelectCategory={handleFilterCategory}
          />
        )}

        {currentPage === 'khuyen-mai' && (
          <PromotionsPage
            onNavigate={navigateTo}
            onAddToCart={handleAddToCart}
            onShowToast={showToast}
            onApplyCoupon={(code) => setAppliedCoupon(code)}
            appliedCoupon={appliedCoupon}
          />
        )}

        {currentPage === 'blog' && (
          <BlogPage onNavigate={navigateTo} onShowToast={showToast} />
        )}

        {currentPage === 'lien-he' && (
          <ContactPage onNavigate={navigateTo} onShowToast={showToast} />
        )}
      </main>

      {/* Universal Footer */}
      <Footer onNavigate={navigateTo} onShowToast={showToast} />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        appliedCoupon={appliedCoupon}
        onApplyCoupon={(code) => setAppliedCoupon(code)}
        onShowToast={showToast}
      />

      {/* Account Modal */}
      <AccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        onShowToast={showToast}
      />

      {/* Order Tracking Modal */}
      <OrderTrackModal
        isOpen={isOrderTrackOpen}
        onClose={() => setIsOrderTrackOpen(false)}
        onShowToast={showToast}
      />

      {/* Interactive Toast Notifications */}
      <Toast
        message={toast.message}
        icon={toast.icon}
        visible={toast.visible}
      />
    </div>
  );
}
