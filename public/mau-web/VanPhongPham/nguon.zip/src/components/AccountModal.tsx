import React, { useState } from 'react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({ isOpen, onClose, onShowToast }) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tab === 'login') {
      onShowToast(`Chào mừng ${email.split('@')[0]} quay trở lại!`, 'account_circle');
    } else {
      onShowToast(`Đăng ký tài khoản thành công cho ${name || email}!`, 'verified');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div onClick={onClose} className="fixed inset-0 bg-on-surface/40 backdrop-blur-xs" />
      <div className="relative bg-surface-container-lowest w-full max-w-md rounded-2xl p-6 shadow-2xl z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-surface-container">
          <h3 className="font-headline-sm text-on-surface font-bold">
            {tab === 'login' ? 'Đăng nhập tài khoản' : 'Đăng ký thành viên'}
          </h3>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex bg-surface-container-low p-1 rounded-xl my-4">
          <button
            onClick={() => setTab('login')}
            className={`flex-1 py-2 rounded-lg font-label-md text-sm font-semibold transition-all ${
              tab === 'login'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Đăng nhập
          </button>
          <button
            onClick={() => setTab('register')}
            className={`flex-1 py-2 rounded-lg font-label-md text-sm font-semibold transition-all ${
              tab === 'register'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Tạo tài khoản
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {tab === 'register' && (
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">Họ và tên</label>
              <input
                required
                type="text"
                placeholder="Nguyễn Văn An"
                className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-on-surface mb-1">Địa chỉ Email</label>
            <input
              required
              type="email"
              placeholder="youremail@gmail.com"
              className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-sm focus:ring-2 focus:ring-primary focus:outline-none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs font-semibold text-on-surface">Mật khẩu</label>
              {tab === 'login' && (
                <button
                  type="button"
                  onClick={() => onShowToast('Mã khôi phục đã gửi vào email!', 'mail')}
                  className="text-xs text-primary hover:underline"
                >
                  Quên mật khẩu?
                </button>
              )}
            </div>
            <input
              required
              type="password"
              placeholder="••••••••"
              className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-sm focus:ring-2 focus:ring-primary focus:outline-none"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            className="w-full mt-3 py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-bold shadow-md transition-all cursor-pointer"
          >
            {tab === 'login' ? 'Đăng nhập ngay' : 'Đăng ký nhận voucher 20K'}
          </button>
        </form>

        <div className="mt-4 pt-3 border-t border-surface-container text-center text-xs text-on-surface-variant">
          Đăng ký tài khoản để tích điểm học sinh - sinh viên và nhận voucher độc quyền mỗi tuần!
        </div>
      </div>
    </div>
  );
};
