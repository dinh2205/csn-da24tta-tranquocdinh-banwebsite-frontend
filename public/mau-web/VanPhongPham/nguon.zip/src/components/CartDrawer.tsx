import React, { useState } from 'react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQty: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  appliedCoupon: string | null;
  onApplyCoupon: (code: string) => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQty,
  onRemoveItem,
  appliedCoupon,
  onApplyCoupon,
  onShowToast,
}) => {
  const [couponInput, setCouponInput] = useState('');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const [orderInfo, setOrderInfo] = useState({ name: '', phone: '', address: '' });

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Discount calculation
  let discountAmount = 0;
  if (appliedCoupon === 'VPP15K' && subtotal >= 149000) discountAmount = 15000;
  else if (appliedCoupon === 'VPP30K' && subtotal >= 299000) discountAmount = 30000;
  else if (appliedCoupon === 'HSSV50K' && subtotal >= 450000) discountAmount = 50000;
  else if (appliedCoupon === 'HOCVUIVE') discountAmount = Math.round(subtotal * 0.1);

  const freeShippingThreshold = 199000;
  const isFreeShip = subtotal >= freeShippingThreshold || appliedCoupon === 'FREESHIP';
  const shippingFee = isFreeShip ? 0 : 25000;
  const total = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const code = couponInput.trim().toUpperCase();
    if (!code) return;

    if (['VPP15K', 'VPP30K', 'FREESHIP', 'HSSV50K', 'HOCVUIVE'].includes(code)) {
      onApplyCoupon(code);
      onShowToast(`Đã áp dụng mã giảm giá ${code}!`, 'loyalty');
      setCouponInput('');
    } else {
      onShowToast(`Mã ${code} không hợp lệ hoặc đã hết hạn!`, 'error');
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutSuccess(true);
    onShowToast('Đặt hàng thành công! Mã đơn #STN' + Math.floor(100000 + Math.random() * 900000), 'verified');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-on-surface/40 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-md bg-surface-container-lowest h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-4 border-b border-surface-container flex items-center justify-between bg-surface-container-low/50">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[24px]">shopping_bag</span>
            <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Giỏ hàng của bạn ({items.reduce((s, i) => s + i.quantity, 0)})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Free shipping progress bar */}
        <div className="px-4 py-2.5 bg-surface-container text-body-sm font-body-sm">
          {subtotal >= freeShippingThreshold ? (
            <div className="flex items-center gap-1.5 text-primary font-medium text-[13px]">
              <span className="material-symbols-outlined text-[18px]">verified</span>
              <span>Đơn hàng của bạn đã đủ điều kiện <strong>Miễn phí vận chuyển</strong>!</span>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between text-[12px] mb-1 text-on-surface-variant">
                <span>
                  Mua thêm{' '}
                  <strong className="text-primary font-bold">
                    {(freeShippingThreshold - subtotal).toLocaleString('vi-VN')}đ
                  </strong>{' '}
                  để được Freeship
                </span>
                <span className="font-bold text-primary">
                  {Math.round((subtotal / freeShippingThreshold) * 100)}%
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-surface-container-high overflow-hidden">
                <div
                  className="bg-primary h-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Drawer Content */}
        {checkoutSuccess ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center gap-4">
            <div className="w-16 h-16 rounded-full bg-surface-container-high text-primary flex items-center justify-center shadow-md">
              <span className="material-symbols-outlined text-[36px]">check_circle</span>
            </div>
            <h3 className="font-headline-md text-headline-md text-primary font-bold">
              Đặt hàng thành công!
            </h3>
            <p className="font-body-sm text-on-surface-variant max-w-xs leading-relaxed">
              Cảm ơn bạn {orderInfo.name || 'bạn'}! Mã đơn hàng <strong>#STN{Math.floor(100000 + Math.random() * 900000)}</strong> đã được ghi nhận. Chúng tôi sẽ liên hệ qua số điện thoại sớm nhất.
            </p>
            <div className="w-full bg-surface-container-low p-4 rounded-xl text-left text-body-sm text-on-surface-variant">
              <p><strong>Người nhận:</strong> {orderInfo.name || 'Khách hàng'}</p>
              <p><strong>Số điện thoại:</strong> {orderInfo.phone || '0901234567'}</p>
              <p><strong>Địa chỉ:</strong> {orderInfo.address || 'Giao tận nơi'}</p>
              <p className="mt-2 text-primary font-bold">
                Tổng thanh toán: {total.toLocaleString('vi-VN')}đ (COD)
              </p>
            </div>
            <button
              onClick={() => {
                setCheckoutSuccess(false);
                setIsCheckingOut(false);
                onClose();
              }}
              className="mt-2 px-6 py-2.5 rounded-full bg-primary text-on-primary font-label-md hover:bg-primary-container transition-colors"
            >
              Tiếp tục mua sắm
            </button>
          </div>
        ) : isCheckingOut ? (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsCheckingOut(false)}
                className="text-primary flex items-center gap-1 font-label-md text-sm hover:underline"
              >
                <span className="material-symbols-outlined text-[16px]">arrow_back</span>
                <span>Quay lại giỏ</span>
              </button>
            </div>
            <h3 className="font-headline-sm text-on-surface font-bold">Thông tin giao hàng (COD)</h3>
            <form onSubmit={handleCheckoutSubmit} className="flex flex-col gap-3">
              <div>
                <label className="block text-[12px] font-semibold text-on-surface mb-1">
                  Họ và tên người nhận *
                </label>
                <input
                  required
                  type="text"
                  placeholder="Nguyễn Văn A"
                  className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-body-sm focus:ring-2 focus:ring-primary focus:outline-none"
                  value={orderInfo.name}
                  onChange={(e) => setOrderInfo({ ...orderInfo, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-on-surface mb-1">
                  Số điện thoại nhận hàng *
                </label>
                <input
                  required
                  type="tel"
                  placeholder="0912 345 678"
                  className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-body-sm focus:ring-2 focus:ring-primary focus:outline-none"
                  value={orderInfo.phone}
                  onChange={(e) => setOrderInfo({ ...orderInfo, phone: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-[12px] font-semibold text-on-surface mb-1">
                  Địa chỉ giao hàng chi tiết *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                  className="w-full p-3 rounded-lg bg-surface-container-low text-on-surface text-body-sm focus:ring-2 focus:ring-primary focus:outline-none resize-none"
                  value={orderInfo.address}
                  onChange={(e) => setOrderInfo({ ...orderInfo, address: e.target.value })}
                />
              </div>
              <div className="bg-surface-container-low p-3 rounded-lg text-[12px] text-on-surface-variant flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[18px]">local_shipping</span>
                <span>Phương thức: <strong>Thanh toán khi nhận hàng (COD)</strong>, kiểm tra hàng thoải mái trước khi thanh toán.</span>
              </div>
              <button
                type="submit"
                className="w-full mt-2 py-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-bold shadow-md transition-all cursor-pointer"
              >
                Xác nhận đặt hàng • {total.toLocaleString('vi-VN')}đ
              </button>
            </form>
          </div>
        ) : items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center gap-3">
            <span className="material-symbols-outlined text-[64px] text-outline-variant">
              production_quantity_limits
            </span>
            <p className="font-headline-sm text-headline-sm text-on-surface">Giỏ hàng đang trống</p>
            <p className="font-body-sm text-on-surface-variant text-[13px] max-w-xs">
              Hãy chọn những món văn phòng phẩm dễ thương để lấp đầy giỏ hàng bạn nhé!
            </p>
            <button
              onClick={onClose}
              className="mt-2 px-5 py-2.5 rounded-full bg-primary text-on-primary font-label-md text-label-md hover:bg-primary-container transition-all"
            >
              Khám phá sản phẩm ngay
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 divide-y divide-surface-container/60">
            {items.map((item) => (
              <div key={item.product.id} className="pt-3 first:pt-0 flex gap-3 items-center">
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-16 h-16 rounded-lg object-cover bg-surface-container-low shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-label-md text-label-md text-on-surface font-semibold line-clamp-1">
                    {item.product.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-primary font-bold text-sm">
                      {item.product.price.toLocaleString('vi-VN')}đ
                    </span>
                    {item.product.originalPrice && (
                      <span className="text-outline text-xs line-through">
                        {item.product.originalPrice.toLocaleString('vi-VN')}đ
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center rounded-lg border border-outline-variant bg-surface-container-lowest">
                      <button
                        onClick={() => onUpdateQty(item.product.id, -1)}
                        className="w-6 h-6 flex items-center justify-center text-on-surface-variant hover:text-on-surface font-bold text-sm"
                      >
                        -
                      </button>
                      <span className="w-8 text-center text-xs font-semibold">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQty(item.product.id, 1)}
                        className="w-6 h-6 flex items-center justify-center text-on-surface-variant hover:text-on-surface font-bold text-sm"
                      >
                        +
                      </button>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.product.id)}
                      className="text-tertiary hover:opacity-80 p-1"
                      title="Xóa sản phẩm"
                    >
                      <span className="material-symbols-outlined text-[18px]">delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer calculation when items exist and not checked out */}
        {items.length > 0 && !checkoutSuccess && !isCheckingOut && (
          <div className="p-4 border-t border-surface-container bg-surface-container-lowest flex flex-col gap-3">
            {/* Coupon input */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <input
                className="flex-1 h-9 px-3 rounded-lg bg-surface-container-low text-on-surface text-body-sm placeholder:text-outline uppercase font-mono focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="Mã voucher (VD: VPP15K, FREESHIP...)"
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value)}
              />
              <button
                type="submit"
                className="px-3.5 h-9 rounded-lg bg-surface-container-high hover:bg-primary hover:text-on-primary text-primary font-label-md text-sm transition-colors font-semibold"
              >
                Áp dụng
              </button>
            </form>

            {appliedCoupon && (
              <div className="flex items-center justify-between text-xs bg-surface-container-high/60 px-3 py-1.5 rounded-lg text-primary">
                <span className="flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-[15px]">confirmation_number</span>
                  Đã áp dụng mã: <strong>{appliedCoupon}</strong>
                </span>
                <button
                  onClick={() => onApplyCoupon('')}
                  className="text-tertiary hover:underline text-[11px]"
                >
                  Gỡ mã
                </button>
              </div>
            )}

            {/* Calculations breakdown */}
            <div className="flex flex-col gap-1 text-body-sm text-on-surface-variant text-[13px]">
              <div className="flex justify-between">
                <span>Tạm tính:</span>
                <span className="font-semibold text-on-surface">{subtotal.toLocaleString('vi-VN')}đ</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-tertiary">
                  <span>Giảm giá voucher:</span>
                  <span>-{discountAmount.toLocaleString('vi-VN')}đ</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Phí vận chuyển:</span>
                <span>{shippingFee === 0 ? <strong className="text-primary font-bold">Miễn phí</strong> : `${shippingFee.toLocaleString('vi-VN')}đ`}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-on-surface pt-2 border-t border-surface-container">
                <span>Tổng thanh toán:</span>
                <span className="text-primary text-lg">{total.toLocaleString('vi-VN')}đ</span>
              </div>
            </div>

            <button
              onClick={() => setIsCheckingOut(true)}
              className="w-full py-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-lg font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.99] cursor-pointer"
            >
              <span>Tiến hành đặt hàng</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
