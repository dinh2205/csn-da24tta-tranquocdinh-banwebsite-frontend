import React, { useState } from 'react';
import { LOGO_URL } from '../data/mockData';
import { PageRoute } from '../types';

interface FooterProps {
  onNavigate: (page: PageRoute) => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onShowToast }) => {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onShowToast(`Đã đăng ký nhận tin cho ${email}!`, 'mark_email_read');
      setEmail('');
    }
  };

  return (
    <footer className="w-full bg-surface-container-low mt-space-2xl pt-space-2xl pb-space-xl text-on-surface-variant border-t border-surface-container">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-space-xl pb-space-2xl">
          {/* Col 1: Brand & Social */}
          <div className="lg:col-span-1 flex flex-col gap-space-md">
            <div
              onClick={() => onNavigate('trang-chu')}
              className="flex items-center gap-2 cursor-pointer select-none"
            >
              <img
                alt="Stationery Shop Logo"
                className="h-7 w-auto object-contain"
                src={LOGO_URL}
              />
              <span className="font-headline-sm text-headline-sm text-primary leading-tight font-bold">
                Stationery
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
              Cùng bạn kiến tạo không gian học tập và làm việc hiệu quả hơn mỗi ngày.
            </p>
            <div className="flex items-center gap-2 mt-1">
              <a
                aria-label="Facebook"
                href="#facebook"
                onClick={(e) => { e.preventDefault(); onShowToast('Facebook Stationery Shop: @stationeryshop.vn'); }}
                className="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-primary hover:text-on-primary text-on-surface-variant flex items-center justify-center transition-all shadow-[0_1px_4px_rgba(0,0,0,0.05)]"
              >
                <span className="material-symbols-outlined text-[18px]">public</span>
              </a>
              <a
                aria-label="Instagram"
                href="#instagram"
                onClick={(e) => { e.preventDefault(); onShowToast('Instagram Stationery Shop: @stationery.vn'); }}
                className="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-primary hover:text-on-primary text-on-surface-variant flex items-center justify-center transition-all shadow-[0_1px_4px_rgba(0,0,0,0.05)]"
              >
                <span className="material-symbols-outlined text-[18px]">photo_camera</span>
              </a>
              <a
                aria-label="YouTube"
                href="#youtube"
                onClick={(e) => { e.preventDefault(); onShowToast('Kênh Youtube Stationery Official'); }}
                className="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-primary hover:text-on-primary text-on-surface-variant flex items-center justify-center transition-all shadow-[0_1px_4px_rgba(0,0,0,0.05)]"
              >
                <span className="material-symbols-outlined text-[18px]">smart_display</span>
              </a>
              <a
                aria-label="TikTok"
                href="#tiktok"
                onClick={(e) => { e.preventDefault(); onShowToast('TikTok Stationery Shop: @stationery_vibes'); }}
                className="w-8 h-8 rounded-full bg-surface-container-lowest hover:bg-primary hover:text-on-primary text-on-surface-variant flex items-center justify-center transition-all shadow-[0_1px_4px_rgba(0,0,0,0.05)]"
              >
                <span className="material-symbols-outlined text-[18px]">music_note</span>
              </a>
            </div>
          </div>

          {/* Col 2: Thông tin */}
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-label-lg text-label-lg text-on-surface font-bold">Thông tin</h3>
            <ul className="flex flex-col gap-2 font-body-sm text-body-sm">
              <li>
                <button
                  onClick={() => onNavigate('blog')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Giới thiệu
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('blog')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Blog
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('khuyen-mai')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Tin tức - Khuyến mãi
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('lien-he')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Liên hệ
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Chính sách */}
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-label-lg text-label-lg text-on-surface font-bold">Chính sách</h3>
            <ul className="flex flex-col gap-2 font-body-sm text-body-sm">
              <li>
                <button
                  onClick={() => onShowToast('Chính sách mua hàng: Đổi trả trong 7 ngày, kiểm hàng trước khi thanh toán.', 'verified')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Chính sách mua hàng
                </button>
              </li>
              <li>
                <button
                  onClick={() => onShowToast('Chính sách đổi trả 7 ngày miễn phí toàn quốc.', 'swap_horiz')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Chính sách đổi trả
                </button>
              </li>
              <li>
                <button
                  onClick={() => onShowToast('Cam kết bảo mật thông tin cá nhân khách hàng.', 'security')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Chính sách bảo mật
                </button>
              </li>
              <li>
                <button
                  onClick={() => onShowToast('Điều khoản dịch vụ Stationery Shop.', 'gavel')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Điều khoản sử dụng
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Hỗ trợ khách hàng */}
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-label-lg text-label-lg text-on-surface font-bold">Hỗ trợ khách hàng</h3>
            <ul className="flex flex-col gap-2 font-body-sm text-body-sm">
              <li>
                <button
                  onClick={() => onNavigate('lien-he')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Hướng dẫn đặt hàng
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('lien-he')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Hướng dẫn thanh toán
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('lien-he')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Theo dõi đơn hàng
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('lien-he')}
                  className="hover:text-primary transition-colors text-left"
                >
                  Câu hỏi thường gặp
                </button>
              </li>
            </ul>
          </div>

          {/* Col 5: Liên hệ */}
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-label-lg text-label-lg text-on-surface font-bold">Liên hệ</h3>
            <div className="flex flex-col gap-2 font-body-sm text-body-sm leading-relaxed">
              <p className="flex items-start gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-primary shrink-0 mt-0.5">location_on</span>
                <span>123 Nguyễn Văn Cừ, Quận 5, TP. Hồ Chí Minh</span>
              </p>
              <p className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-primary shrink-0">call</span>
                <span>1900 1234</span>
              </p>
              <p className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[16px] text-primary shrink-0">mail</span>
                <span>cskh@stationeryshop.vn</span>
              </p>
            </div>
          </div>

          {/* Col 6: Đăng ký nhận ưu đãi */}
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-label-lg text-label-lg text-on-surface font-bold">Đăng ký nhận ưu đãi</h3>
            <p className="font-body-sm text-body-sm">Nhận thông báo voucher sớm nhất từ chúng tôi.</p>
            <form onSubmit={handleSubscribe} className="flex flex-col gap-2 mt-1">
              <input
                className="w-full h-9 px-3 rounded-lg bg-surface-container-lowest text-on-surface placeholder:text-outline text-body-sm focus:outline-none focus:ring-1 focus:ring-primary border border-outline-variant/50"
                placeholder="Nhập email của bạn..."
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button
                className="w-full h-9 rounded-lg bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-colors cursor-pointer font-semibold shadow-xs"
                type="submit"
              >
                Đăng ký
              </button>
            </form>
            <div className="mt-2">
              <span className="text-[11px] block mb-1.5 text-outline">Phương thức thanh toán</span>
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-2 py-0.5 rounded bg-surface-container-lowest text-[11px] font-bold text-on-surface shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                  VISA
                </span>
                <span className="px-2 py-0.5 rounded bg-surface-container-lowest text-[11px] font-bold text-on-surface shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                  Mastercard
                </span>
                <span className="px-2 py-0.5 rounded bg-surface-container-lowest text-[11px] font-bold text-[#A50064] shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                  MoMo
                </span>
                <span className="px-2 py-0.5 rounded bg-surface-container-lowest text-[11px] font-bold text-primary shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                  ZaloPay
                </span>
                <span className="px-2 py-0.5 rounded bg-surface-container-lowest text-[11px] font-bold text-tertiary shadow-[0_1px_2px_rgba(0,0,0,0.05)]">
                  VNPay
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div className="pt-space-lg border-t border-surface-container flex flex-col md:flex-row items-center justify-between gap-4 text-body-sm font-body-sm">
          <p>Copyright © 2024 Stationery Shop. All rights reserved.</p>
          <p className="text-outline">Designed with care for study and office excellence</p>
        </div>
      </div>
    </footer>
  );
};
