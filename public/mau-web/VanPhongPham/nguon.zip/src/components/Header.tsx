import React, { useState } from 'react';
import { PageRoute } from '../types';
import { LOGO_URL, USER_AVATAR } from '../data/mockData';

interface HeaderProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
  cartCount: number;
  onOpenCart: () => void;
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenAccount: () => void;
  onOpenOrderTrack: () => void;
  onSearch: (query: string) => void;
  searchQuery: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  cartCount,
  onOpenCart,
  wishlistCount,
  onOpenWishlist,
  onOpenAccount,
  onOpenOrderTrack,
  onSearch,
  searchQuery,
}) => {
  const [searchInput, setSearchInput] = useState(searchQuery);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchInput);
    onNavigate('san-pham');
  };

  const navItems: { label: string; path: PageRoute; isHot?: boolean }[] = [
    { label: 'Trang chủ', path: 'trang-chu' },
    { label: 'Sản phẩm', path: 'san-pham' },
    { label: 'Danh mục', path: 'danh-muc' },
    { label: 'Khuyến mãi', path: 'khuyen-mai', isHot: true },
    { label: 'Blog', path: 'blog' },
    { label: 'Liên hệ', path: 'lien-he' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-surface-container-lowest shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
      {/* Top Announcement Bar */}
      <div className="bg-surface-container-low h-7 px-4 sm:px-8">
        <div className="max-w-[1320px] mx-auto h-full flex items-center justify-between text-body-sm text-on-surface-variant text-[12px]">
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[15px] text-primary">local_shipping</span>
              <span>Miễn phí giao hàng cho đơn từ 199.000đ</span>
            </span>
            <span className="items-center gap-1.5 hidden md:flex">
              <span className="material-symbols-outlined text-[15px] text-primary">redeem</span>
              <span>Nhiều ưu đãi dành cho học sinh - sinh viên</span>
            </span>
            <span className="items-center gap-1.5 hidden lg:flex">
              <span className="material-symbols-outlined text-[15px] text-primary">call</span>
              <span>Hotline: 1900 1234 (8:00 - 22:00)</span>
            </span>
          </div>

          <div className="flex items-center gap-5">
            <button
              onClick={onOpenOrderTrack}
              className="hover:text-primary transition-colors cursor-pointer"
            >
              Theo dõi đơn hàng
            </button>
            <button
              onClick={() => onNavigate('lien-he')}
              className="hover:text-primary transition-colors cursor-pointer hidden sm:inline"
            >
              Hỗ trợ
            </button>
            <div className="flex items-center gap-1 cursor-pointer hover:text-primary transition-colors">
              <span>Tiếng Việt 🇻🇳</span>
              <span className="material-symbols-outlined text-[14px]">expand_more</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Logo & Search Bar */}
      <div className="h-16 px-4 sm:px-8 bg-surface-container-lowest border-b border-surface-container/60">
        <div className="max-w-[1320px] mx-auto h-full flex items-center justify-between gap-4 sm:gap-8">
          {/* Logo Brand */}
          <div
            onClick={() => onNavigate('trang-chu')}
            className="flex items-center gap-3 shrink-0 cursor-pointer select-none"
          >
            <img
              alt="Stationery Shop Logo"
              className="h-8 w-auto object-contain"
              src={LOGO_URL}
            />
            <div className="flex flex-col">
              <span className="font-headline-sm text-[18px] text-primary leading-tight tracking-tight font-bold">
                Stationery Shop
              </span>
              <span className="text-[11px] leading-3 text-on-surface-variant font-normal">
                Văn phòng phẩm cho mọi người
              </span>
            </div>
          </div>

          {/* Search Box */}
          <div className="flex-1 max-w-2xl px-2 hidden sm:block">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                className="w-full h-10 pl-4 pr-12 rounded-full bg-surface-container-low text-on-surface placeholder:text-outline text-body-sm focus:outline-none focus:ring-2 focus:ring-primary focus:bg-surface-container-lowest transition-all"
                placeholder="Bạn đang tìm gì? (bút, sổ tay, balo, giấy note, ...)"
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
              />
              <button
                type="submit"
                aria-label="Tìm kiếm"
                className="absolute right-1 w-8 h-8 rounded-full bg-primary hover:bg-primary-container text-on-primary flex items-center justify-center transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">search</span>
              </button>
            </form>
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-3 sm:gap-5 shrink-0">
            {/* Account */}
            <div
              onClick={onOpenAccount}
              className="flex items-center gap-2 cursor-pointer hover:opacity-90 transition-opacity"
            >
              <img
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover border border-outline-variant"
                src={USER_AVATAR}
              />
              <div className="hidden md:flex flex-col text-left">
                <span className="text-[11px] text-on-surface-variant leading-none">Tài khoản</span>
                <span className="font-label-md text-[13px] text-on-surface leading-tight font-semibold">
                  Đăng nhập / Đăng ký
                </span>
              </div>
            </div>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              aria-label="Yêu thích"
              className="relative p-2 text-on-surface-variant hover:text-primary transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[22px]">favorite</span>
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-0 min-w-[18px] h-[18px] rounded-full bg-primary text-on-primary font-bold text-[10px] flex items-center justify-center px-1">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart */}
            <button
              onClick={onOpenCart}
              aria-label="Giỏ hàng"
              className="relative p-2 text-on-surface-variant hover:text-primary transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[22px]">shopping_bag</span>
              <span className="absolute top-1 right-0 min-w-[18px] h-[18px] rounded-full bg-tertiary-container text-on-tertiary font-bold text-[10px] flex items-center justify-center px-1">
                {cartCount}
              </span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 sm:hidden text-on-surface-variant hover:text-primary"
              aria-label="Menu"
            >
              <span className="material-symbols-outlined text-[24px]">
                {mobileMenuOpen ? 'close' : 'menu'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="bg-surface-container-lowest px-4 sm:px-8 shadow-[0_2px_4px_rgba(0,0,0,0.02)]">
        <div className="max-w-[1320px] mx-auto flex items-center justify-between h-11">
          <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-none py-1">
            {navItems.map((item) => {
              const isActive = currentPage === item.path;
              return (
                <div key={item.path} className="relative flex items-center shrink-0">
                  <button
                    onClick={() => {
                      onNavigate(item.path);
                      setMobileMenuOpen(false);
                    }}
                    className={`px-3 py-1.5 rounded-lg font-label-md text-label-md transition-colors cursor-pointer whitespace-nowrap ${
                      item.isHot ? 'pr-8' : ''
                    } ${
                      isActive
                        ? 'bg-primary text-on-primary font-bold shadow-xs'
                        : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container-low'
                    }`}
                  >
                    {item.label}
                  </button>
                  {item.isHot && (
                    <span
                      className={`absolute right-1 top-1.5 font-label-sm text-[9px] px-1 py-0.5 rounded uppercase font-bold tracking-wider leading-none pointer-events-none ${
                        isActive
                          ? 'bg-secondary-container text-on-secondary-container'
                          : 'bg-tertiary-container text-on-tertiary-container'
                      }`}
                    >
                      HOT
                    </span>
                  )}
                </div>
              );
            })}
          </nav>

          <div className="hidden xl:flex items-center gap-2 text-body-sm font-body-sm text-primary font-medium shrink-0">
            <span className="material-symbols-outlined text-[18px]">verified</span>
            <span>Hàng chính hãng 100% - Đổi trả 7 ngày</span>
          </div>
        </div>
      </div>

      {/* Mobile search bar when collapsed */}
      {mobileMenuOpen && (
        <div className="sm:hidden px-4 py-3 bg-surface-container-low border-b border-surface-container">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              className="w-full h-9 pl-3 pr-10 rounded-full bg-surface-container-lowest text-on-surface placeholder:text-outline text-body-sm focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Tìm kiếm sản phẩm..."
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
            <button
              type="submit"
              className="absolute right-1 w-7 h-7 rounded-full bg-primary text-on-primary flex items-center justify-center"
            >
              <span className="material-symbols-outlined text-[16px]">search</span>
            </button>
          </form>
        </div>
      )}
    </header>
  );
};
