import React, { useState } from 'react';

interface OrderTrackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const OrderTrackModal: React.FC<OrderTrackModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  const [orderCode, setOrderCode] = useState('');
  const [phone, setPhone] = useState('');
  const [result, setResult] = useState<null | {
    code: string;
    status: string;
    steps: { title: string; time: string; done: boolean }[];
  }>(null);

  if (!isOpen) return null;

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderCode && !phone) {
      onShowToast('Vui lòng nhập mã đơn hoặc số điện thoại', 'error');
      return;
    }

    setResult({
      code: orderCode ? orderCode.toUpperCase() : '#STN849120',
      status: 'Đang vận chuyển giao hàng',
      steps: [
        { title: 'Đặt hàng thành công', time: '08:30 - Hôm qua', done: true },
        { title: 'Đã đóng gói kiện hàng', time: '14:20 - Hôm qua', done: true },
        { title: 'Bàn giao đơn vị vận chuyển', time: '18:00 - Hôm qua', done: true },
        { title: 'Shipper đang trên đường giao đến bạn', time: 'Dự kiến hôm nay', done: true },
      ],
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div onClick={onClose} className="fixed inset-0 bg-on-surface/40 backdrop-blur-xs" />
      <div className="relative bg-surface-container-lowest w-full max-w-lg rounded-2xl p-6 shadow-2xl z-10 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-surface-container">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[24px]">local_shipping</span>
            <h3 className="font-headline-sm text-on-surface font-bold">Tra cứu tiến độ đơn hàng</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-on-surface"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleLookup} className="flex flex-col gap-3 my-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">Mã đơn hàng</label>
              <input
                type="text"
                placeholder="VD: STN123456"
                className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-sm uppercase focus:ring-2 focus:ring-primary focus:outline-none"
                value={orderCode}
                onChange={(e) => setOrderCode(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-on-surface mb-1">Số điện thoại đặt</label>
              <input
                type="tel"
                placeholder="VD: 0901234567"
                className="w-full h-10 px-3 rounded-lg bg-surface-container-low text-on-surface text-sm focus:ring-2 focus:ring-primary focus:outline-none"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-bold shadow-sm transition-all cursor-pointer"
          >
            Tra cứu đơn ngay
          </button>
        </form>

        {result && (
          <div className="mt-3 p-4 bg-surface-container-low rounded-xl flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-surface-container pb-2">
              <span className="font-bold text-sm text-primary">Mã đơn: {result.code}</span>
              <span className="px-2 py-0.5 rounded-full bg-surface-container-high text-primary font-bold text-xs">
                {result.status}
              </span>
            </div>
            <div className="space-y-3 pt-1">
              {result.steps.map((st, i) => (
                <div key={i} className="flex items-start gap-3 text-xs">
                  <div className="w-5 h-5 rounded-full bg-primary text-on-primary flex items-center justify-center shrink-0 mt-0.5">
                    <span className="material-symbols-outlined text-[14px]">check</span>
                  </div>
                  <div>
                    <p className="font-semibold text-on-surface text-sm">{st.title}</p>
                    <p className="text-outline text-xs">{st.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
