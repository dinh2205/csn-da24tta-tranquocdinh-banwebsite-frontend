import React from 'react';

interface ToastProps {
  message: string | null;
  icon?: string;
  visible: boolean;
}

export const Toast: React.FC<ToastProps> = ({ message, icon = 'check_circle', visible }) => {
  if (!message) return null;

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 transform transition-all duration-300 pointer-events-none ${
        visible ? 'translate-y-0 opacity-100' : 'translate-y-32 opacity-0'
      }`}
    >
      <div className="bg-inverse-surface text-inverse-on-surface px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-outline/30 backdrop-blur-md">
        <span className="material-symbols-outlined text-secondary-container text-[22px]">
          {icon}
        </span>
        <span className="font-label-md text-label-md text-[14px] font-medium">
          {message}
        </span>
      </div>
    </div>
  );
};
