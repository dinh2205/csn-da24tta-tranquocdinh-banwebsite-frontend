import { Product, Voucher, BlogPost, StoreLocation } from '../types';

export const LOGO_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDX0_P8410tHWBL_s7EPoIg592ReGolQEC8bZE8hkOfBu_YPljK1RjPhtlvlXnXySbNfjqRuEUh0xRdNUio_5BOQtBovN7ZYFzRbW-cOGB09yKZtVd2FE6Ff9lNA6k7MUU9PfYHJAaht82yGyNbsSFnrJaUpD3nOQQreB39KoEPAz2K2SJ8yUXZlrLQC8804IqKWj4xLpGqq7cZ-ftjTf3HtQYuZmqytn1dtxYmuKiIVe8gE6xhtuougw';
export const USER_AVATAR = 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3wbbPEZxbd5kTzRYNin9WNwWYRzptD-inoyhqNw6bfE1onT2_LUu0_KfWJJY4HIFNncIkXB8V0JbPkI0lRJWha9z30ckzfrMzGu-XXR0AXMsZUrKLY7VPWNCt2XVOgbJ6bc-6120Mx1FIktLfHovLFrLaAqs60ORxSj6zJrTge3n5GMcEwuW9Mpbc_aiXNmUZK3px6dF26zrjOSmb2hsPjd9gQfz2yb1lReEeTLIr_FEeWBKuqUtsQA';
export const MAP_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuA_pJjD8wzn4LD37GDvYQBajJQFcMxcECEni1PB9O5G8aDBIUiUDAPhWtGuIV9nQI-Sot2BB_Gn2vQ_iaDQTh_SenEu2Bu56Z0_TRhDoQBT5CXDwdOg03ZHBcR9r-IhP2n6ctuUwTDmc6svD_qNefsSKolGJx0stBpO9HR7_DOMFSc9wn9pNPbdDEQFxjFbfNw5Wa9pAdeaXKnO660nSr6Zff2v1t8-sQ15o-jMVQHDlseWfVs-RZj7fw';

// Products for Catalog (12 products as shown in Page 6)
export const ALL_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Bút highlight pastel Pastel Maker 6 cây dịu mắt',
    brand: 'Deli',
    category: 'but-viet',
    price: 36000,
    originalPrice: 45000,
    discountPercent: 20,
    rating: 4.5,
    reviewCount: 142,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDNIhZH28vto_B9qK05aXBIF_vhP05FkMsmH6gbQAopXYCMvrtgSZ4h1K_ucF5DC8zENtAKwT3cfLJ_x4J13oimqBgDchXVs04JgrdDfsroCYyty1bPMgCuR05v9rSDHpLO8C6vZocyYogUbadDVEObvtfOKqSShURPmiS-EafZsnxsMJ03q_1htrpTFrei6HU1ndui81PjUdO2tlaKLhDpMCOmParqZsKAI_GXE8VlGXi3ZSCYZDMkLw'
  },
  {
    id: 'p2',
    name: 'Sổ còng Klong Dot Grid A5 120 trang giấy dày chống thấm',
    brand: 'Klong Journal',
    category: 'so-tay',
    price: 48000,
    isNew: true,
    rating: 5,
    reviewCount: 89,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDPlLWMQz6-GTbamj-pN4v5WjF5V2nLh8L1tvXAeonqD4l0kLdy6eR5o-7mxRg-g3x2oDUDeVy8aywU_EVtFfCUgj-2r7Kza4B4cZgEk3D1C_2YiTNp_n0i6GgDdAObn1xg_sEQbtAq0b7yDRPzor-Rx_dsPkWJgBT4ZDpQjXr0DNS9e-WLGNQMLry_CPphu1uY3SklKe3Xs4AH2vVY0JLzp0R6lI7avLrjZneB9VG0EGAv8jGcNciCfA'
  },
  {
    id: 'p3',
    name: 'Bút xóa kéo Plus Whiper MR 5mm x 6m tiện dụng',
    brand: 'Plus',
    category: 'dung-cu-hoc-tap',
    price: 22000,
    originalPrice: 26000,
    discountPercent: 15,
    rating: 5,
    reviewCount: 230,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCz3UTqxtcMl_Qfw8Uiu9ujNVmP5r6T_C2C_FujUAEhaSM5REnPajfTVBXH9Hxnyqe0sqYdz_aw3saQ5TMjyJLRfMhBlXS40kgp_FK7AZmfk4-juwalIUSQW2jPhiFMqCU-5pTNWAShRmvUjPj2jKVqLJ-QuZqST3VKIMqCFnsEBsEh7PgyFQHWkt-xjVJE_EfGWUttKvOTpgbCqws4zgG_8L2McpW384L2CxMqBG7O4YwuG6ZnXN2Wsw'
  },
  {
    id: 'p4',
    name: 'Hộp màu nước Deli 24 màu cao cấp kèm cọ vẽ',
    brand: 'Deli',
    category: 'dung-cu-ve',
    price: 115000,
    originalPrice: 140000,
    discountPercent: 18,
    rating: 4,
    reviewCount: 64,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCBxl25C016h7VL2QN7qH-3wGQB-wpsmLntkAPtoTumvrJ391SWcYC7Yucol9hqhNVpU-wU71cea27oV58cUxShNPTB8A_7ym3HRYlJpkWz7BnrgyeBQjaJ_PqpHRUSe_sKBqc_OGc5PfGZ0CcKXkXZx6iZSLMbXp9Iwehl3cOPXX6FbACrgR5UIQmlQfmiUnxGPw6Ys6W4kKHqmj6_SNdo76aDYM2G__1WHFg_VH0mazXkRew573qOCw'
  },
  {
    id: 'p5',
    name: 'Tập vở sinh viên Campus 200 trang kẻ ngang gáy dán ép',
    brand: 'Campus',
    category: 'so-tay',
    price: 28000,
    rating: 5,
    reviewCount: 185,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCjx1rvZNUnkaoSn2sIJqkDS2wpJTUt-iW-5YsC0xaMmZK6SZCAtZg5hxeDApXA5LW6DkTogD9ckRNjKbTBvaileQDn-8yGicN8te5O1tbUbEKgrnQIcalujiEJv8j0hSUyjX7jWfkBzkcUUWrqGU8RjphjkFeJ-xLufW_-xX0isIlQUBV3-YyaBtXJuoqV9qKNZC9mRzK4L2OQeuxx108EoVUFAXCf3GPMEiT7b5nWxajhZHTxfJjPVw'
  },
  {
    id: 'p6',
    name: 'Máy tính khoa học Casio FX-580VN X chính hãng Bitex',
    brand: 'Casio',
    category: 'may-tinh',
    price: 570000,
    originalPrice: 650000,
    discountPercent: 12,
    isHot: true,
    rating: 5,
    reviewCount: 520,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCNDPE1A5j1EPgD5dWNNLTxlfMiXwYSzOun_V8gpV-dT1mBqTY1EyZXoQB3j8uv22YlkePrdKxes_0sd5_CT_rX5_VxVDpYQn4ij2QXKPU4PWgknj_4XpmzHd8-RRceURycXKWth5GSO6eYgn0vbVKcLeMRohojUvqhq3SaDRnTWhbWaPkFcRnU9OvVzrvKFnNx3y5seiXxcKQi24BCKqPNtRTPiEhihNR_92shifHwepGzRoD-mJqDpg'
  },
  {
    id: 'p7',
    name: 'Balo laptop đi học chống gù thời trang phong cách Hàn Quốc',
    brand: 'Stationery Bags',
    category: 'balo-hop-but',
    price: 320000,
    originalPrice: 420000,
    discountPercent: 25,
    rating: 4.5,
    reviewCount: 89,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB3EVVHTmQPpws2XaXewISNkRU0CLDZAV4-UjdEOSXpdvqpqKJ7OZVfbXn-JzWew_xjVGO5IjjtJ29bS0HoukSCDgyV9P11gX3DWraxuRCsYdOV5x1ZB0PSertP5D2kIE8iyC7Z3ZtVcH4fVMpxiCO2ds3Gspii5dX0hNRuasaEzE_sxFMFixzlJmy7uPxlkIu8iKrfFPxfCPhM3UIHuh2zNFR14ULo0kVgGzH-U0GZATeuaWR0F-qwtw'
  },
  {
    id: 'p8',
    name: 'Kéo cắt thủ công an toàn cho học sinh lưỡi thép không gỉ',
    brand: 'Deli',
    category: 'dung-cu-hoc-tap',
    price: 15000,
    rating: 4,
    reviewCount: 45,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAE3uhUa0FmMbbp3971StK67quex8ELs-gCXQCCnbapqP4gB7xbkZ1_nlIymkotmBZItQTd2vqRFtiARwpIbHLVs-2ZUZ0KnxR6LfPbvfFiurHkR00eyP2JXCoRveLHKQr1LFgYFwqPMeKXSyBqacX4EFHSOBmHEqd54Y0TEA9urw9-wUGGLwUQfd75VtqfVIvvEphSWMn7TQdZLGQdKuH6KyobthtnazdFjmA_WHm52AYvz01s7EKKCw'
  },
  {
    id: 'p9',
    name: 'Thước kẻ nhôm định lượng 20cm chống trầy bền bỉ',
    brand: 'Thiên Long',
    category: 'dung-cu-hoc-tap',
    price: 12000,
    rating: 5,
    reviewCount: 78,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC28s4RIagSHuDbTFQaNFzqCQjUzUQr0bja2BC-L5IkqBnlDdIkFskq-6Gtp5uCWc91s9DNqrr3UyM-nZE6drK60uuOQXnWxIYZ_X7UxrviRpTjXesBlrucRVIzAi9prTlv5QmfmK0aojOaCZoBKW2iduVCm94T6JqQSFugDHygA202RdUVArpj57sbqgVDoOxzuPiFSRS4b-56pDw8SygM5EdKRQMspNQ9GQX2-PzeSVMTC4E2VbIdbQ'
  },
  {
    id: 'p10',
    name: 'Bút bi bấm Thiên Long 0.5mm mực trơn êm đều nét (Hộp 10 cây)',
    brand: 'Thiên Long',
    category: 'but-viet',
    price: 45000,
    originalPrice: 50000,
    discountPercent: 10,
    rating: 5,
    reviewCount: 340,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCx4SUQiJco5zVW3PSq6I6UYX8olv7XOiU2pIxQ1zddCZjOIOlDX4HyLfkiQOvUi8wX4ffMOe1jTAbwu3Gs8ltszG-TdAjW0YzBxdmQMpRW8gJ-Tk78NZen1b9rlESQ3wNmu5x_ItDtLRGS1LCTp5po2CXpi6QmX5TLh3AyE8TczeAiWGBEQnbQRXkr5sz2QByvqmmVwk0WyviHJYaid6utAkmBoBG-mScvYf5qRTxFNLdc4CedPp2B_w'
  },
  {
    id: 'p11',
    name: 'Băng dính Washi tape họa tiết vintage trang trí sổ tay (Set 5 cuộn)',
    brand: 'Deco Art',
    category: 'giay-note',
    price: 35000,
    isNew: true,
    rating: 4.5,
    reviewCount: 67,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDBF0A59PZ01sRZ_RYOTO3LlS5EV0wSgZb3I-h5ZXvwhI2wCNxh7V8RmVv6PH9gcUw-tM88ULmguHCQLWl_036ZxvdYwBqtZXFhLMiTZiGZXibjLOyEqrnLl_65nRLExh0ZG1gcDfnFtwdXvHHlkQMGs1CLOr9NsYWDgo-Q2ElaHbiJbP4FpBcz3NgwVsF7h1g1EVvCNl1SuGUocAYR-LgknMFtEqumPzfHM_dBd9paSiAVLPle-ZA-TQ'
  },
  {
    id: 'p12',
    name: 'Bộ giấy note vuông 4 màu pastel 400 tờ keo dính chắc chắn',
    brand: 'Post-it Pro',
    category: 'giay-note',
    price: 24000,
    originalPrice: 28000,
    discountPercent: 14,
    rating: 5,
    reviewCount: 112,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBaPlQvtugKm2Vygo4sUfcdOmeKfUfMqzgyMqlMXbD1p-JgFF2SGP382TF4uyCt4cTDNq-C62EwlfkFY_y6EPs5y9v4Wjz6gtrG53FS20SZP67LFg3r9AvZ8kiIzpkFu9llt3EFB-UGcsWBnBh39BPlD8AD9nQhUHJiXRojjRAl8YmOKKIA2h3-hHAdwpXpbQAA4aTxqHyH1Zkxd9YvEesEQF53BVvWAxe4fQIV4TNYoAo65bRZy3l-Jg'
  }
];

// Flash Sale items for Promotions Page
export const FLASH_SALE_ITEMS: Product[] = [
  {
    id: 'fs1',
    name: 'Hộp bút gel Thiên Long chính hãng (20 cây nét 0.5mm)',
    brand: 'Thiên Long',
    category: 'but-viet',
    price: 48000,
    originalPrice: 80000,
    discountPercent: 40,
    rating: 4.5,
    reviewCount: 248,
    soldPercent: 85,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBqy9yT_ZgRDlXJ2NlKi5oBr9K5qR5ad07pF0TSdzvC3Cm0O3CR6EYnfPbrdeR7nuiG820UbWcwoTIz0bhWF84x7_aLHhXEdkASkYinBvUD1-GTkCMW4ttFxGqp1BgQoz0vmFh8P8aF3b_wPdHKex3GV2FB9ODJCkSHYoedxa3yPgBK85m6eNj5WcdgzVpzW0mfRnA-zR_Iqnx4sk7rAAre278KJymQqWgP09MC0_lU4KPFisWHqn3zWg'
  },
  {
    id: 'fs2',
    name: 'Combo 5 cuốn vở Klong Caro A5 120 trang giấy chống lóa',
    brand: 'Klong Journal',
    category: 'so-tay',
    price: 65000,
    originalPrice: 100000,
    discountPercent: 35,
    rating: 5,
    reviewCount: 412,
    soldPercent: 92,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCtl-Ci5it273t0Nmi2H32q505Yykzp-nJbNUopU7DbZOYg8jmyzit3PaP1F_SXdlzAhsB1sU_uV_VffJaG1fCpsEOQNRis-ACY4wWW3WcrSuW7-XiHAtn6HaefCwFAnV1eyilnW33Wn4WB6XyMXzsigBuqPtDmFbatnF8bxFKtJOayMdjy3e5d3Ymm5F_lMMpONuWZA1Fq-CXTjfrywKqzVIuGJ9t-FDmS2m-Rtekc9GIHfT6C4lzMfw'
  },
  {
    id: 'fs3',
    name: 'Hộp bút vải đa năng Kuromi sức chứa khủng chống nước',
    brand: 'Stationery Bags',
    category: 'balo-hop-but',
    price: 39000,
    originalPrice: 78000,
    discountPercent: 50,
    rating: 5,
    reviewCount: 189,
    soldPercent: 78,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDXTznHVjZJ_qHTD_0tBFWMRtNqdq909T6V8XtKknfQ-tzwSWAhADcLJ5VvG2BD29_NHFQF-cOPXI6ho-evd0c4Cz-GXDGnbykkrejPZih7QAwJY9ai2KzYZ54zjicofxP-4BVthMJ97fbSHxnXUaYkb0ZlHmao2SfhAvr3pWGeTG8TmLTb7YznmnTSNk1pw3vwlGv9cXaGYqNJnzHdNzFjLXljeRly-Dzh1btTkDZTpaug3WjWXcVUqA'
  },
  {
    id: 'fs4',
    name: 'Máy tính khoa học Casio FX-580VN X (Bảo hành 7 năm)',
    brand: 'Casio',
    category: 'may-tinh',
    price: 570000,
    originalPrice: 695000,
    discountPercent: 18,
    rating: 5,
    reviewCount: 530,
    soldPercent: 60,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCU8OO4wtVwyf0goXhObG9M-yiurK3FTR2T69O5l47_7hZCthQrGjlmeJCI5XmVobJGfLmMkqkfZan0_WBIjEYjUoGHyB_fnLZ_iewEcZ-7GbFlYo9nSXLRTRpAFconRGPvjTbb6ByVwOz7VGo1xqcGWCfT82oVEX1PYgdWHnLF34vIvUnfYaQYC0tSuzsyF7ZGg56-6rIZfCWae5y_OTIu7S0e_g8Fdw0CpJetzt6k6y956Ebo0Bm3sw'
  }
];

// Vouchers for Promotion Page
export const VOUCHERS: Voucher[] = [
  {
    code: 'VPP15K',
    title: '15.000đ',
    condition: 'ĐƠN 149K',
    description: 'Giảm 15.000đ cho đơn hàng văn phòng phẩm từ 149K',
    discount: 15000
  },
  {
    code: 'VPP30K',
    title: '30.000đ',
    condition: 'ĐƠN 299K',
    description: 'Giảm ngay 30.000đ khi sắm balo, sổ tay từ 299K',
    discount: 30000
  },
  {
    code: 'FREESHIP',
    title: 'FREESHIP',
    condition: 'TOÀN QUỐC',
    description: 'Miễn phí giao hàng tiêu chuẩn cho đơn từ 199.000đ',
    discount: 25000,
    isFreeship: true
  },
  {
    code: 'HSSV50K',
    title: '50.000đ',
    condition: 'HSSV VIP',
    description: 'Ưu đãi học sinh sinh viên giảm 50K cho đơn từ 450K',
    discount: 50000,
    isVip: true
  }
];

// Blog Posts
export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'b-featured',
    title: 'Cách lập kế hoạch học tập hiệu quả với phương pháp Time Blocking và Sổ Planner',
    category: 'Lập kế hoạch',
    categorySlug: 'bujo',
    categoryLabel: 'Lập kế hoạch',
    author: 'Minh Thư',
    date: '12/10/2024',
    readTime: '5 phút đọc',
    views: '5.6k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAJYEhZ_9ZA6Hwm4J48hkYfvPunIHCmsMIO_c0jIfIe4L4RuwWZwXFvIysRTZuEjDlhAQsvsNjCNcUWdMmoDUBJeholO-6jbMDB1fcDoDZdXY-I_sPySLO1xz-Sr1q4YnU7hVpaSNKQg6nWjGcmrOdjs4ChGU99ELboP8xc3vxMUW7rjQxIVZKEMKXsB1wj_c87WGoKunLVENkXOYv9sqIcmPf4tYYelxnYEmnZH3wNDxwQquEw6hEsng',
    excerpt: 'Bí quyết phân chia khung giờ vàng giúp bạn tập trung 100%, ghi nhớ bài học lâu hơn mà không bị áp lực thi cử. Kết hợp sổ planner và hệ thống nhãn dán màu sắc chuẩn phong cách học bá.',
    tags: ['#TimeBlocking', '#StudyGram', '#Planner2025'],
    isFeatured: true
  },
  {
    id: 'b1',
    title: 'Top 5 dòng bút gel viết êm, nhanh khô không nhòe dành cho sĩ tử ôn thi',
    category: 'Văn phòng phẩm',
    categorySlug: 'reviews',
    categoryLabel: 'Review sản phẩm',
    author: 'Hoàng Nam',
    date: '10/10/2024',
    readTime: '4 phút',
    views: '1.8k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAA-uw0EqrD-1AkdEJ0QDdUbsINXZNvV731PDK69C1romr2NezddkQaAXiTDSavPpPc3ZkgFxT9iMUJNNQiBoAe0rIyZugB3DzuFH1NQQEb2CJ6Bxa-jPUZxEFTF0Ew4il7cAxtyojZniyol4k8yITIDQjMz_ViEJ2ljBWhiUJQzLYUG3zQA-tUz-v_g0XENMsjEoaxqe6y2BgjAG1X7X1Ha4eJUR1HUJXMmI0aQ2vVnDVa6LlrtbJsHA',
    excerpt: 'Tổng hợp những cây bút mực gel thần thánh giúp ghi chép tốc độ cao, không sợ lem bẩn khi làm bài thi trắc nghiệm lẫn tự luận.',
    tags: ['#GelPen', '#OnThi']
  },
  {
    id: 'b2',
    title: 'Hướng dẫn bắt đầu Bullet Journal cho người mới: Tối giản nhưng cực kỳ cuốn hút',
    category: 'Sổ tay sáng tạo',
    categorySlug: 'bujo',
    categoryLabel: 'Lập kế hoạch',
    author: 'Thu Hà',
    date: '08/10/2024',
    readTime: '6 phút',
    views: '2.4k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAR_fKvSwzwSjBjswiyiqRNGBt5wZhfNmTmEz6fdpjnAKJjWr5UFUfJBoEGwgTSRnBiA4PNyJ724ZAxmYun1ZkjG11uJoPVRKuqTWFM9eHe-iCpQHBjLaQvlgYaaEXCE8sqdeE50LT8_73fv50ykoSVBxOuUYfM86z0Noy9IHBDZjQTtZRvUurmEbzcoItzAQLyGXVOp2m6f8WomGUDlu4HaFd3G8cttp9j5rDt0seSIwrTKLzCh37pwA',
    excerpt: 'Không cần vẽ đẹp vẫn có thể sở hữu cuốn sổ quản lý công việc và mục tiêu cá nhân khoa học, thẩm mỹ chuẩn aesthetic.',
    tags: ['#BulletJournal', '#Minimalist']
  },
  {
    id: 'b3',
    title: 'Cách chọn máy tính Casio chính hãng cho kỳ thi THPT Quốc gia không lo hàng nhái',
    category: 'Kinh nghiệm thi cử',
    categorySlug: 'study-tips',
    categoryLabel: 'Mẹo học tập',
    author: 'Thầy Quốc',
    date: '05/10/2024',
    readTime: '7 phút',
    views: '3.1k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAtpgQn2WPrJTR7DCuHsKxS-gddD0TwY1zxH28bLSf1dl4snnUTw0JIf7j93v6pgupRO5I7_0VjTgHpwn6fGZVly2vCXxdhubS-_iMuttej6vKM0ouMZtMNG1NcBCV2Mggta6HbQqsLs3nlWp9U-rp7cROhWRiyHP4oM8842sIDKZc3_sBdOi4jL28-Avh_GXwjNJOZcIt7r2mEqNLq1F7agGX7hWOWnbne-n0Ow53f3Qzm95c91zuqng',
    excerpt: 'Các đặc điểm nhận diện tem bảo hành chính hãng, kiểm tra số series và danh mục máy tính bỏ túi được phép mang vào phòng thi.',
    tags: ['#Casio', '#THPTQG']
  },
  {
    id: 'b4',
    title: 'Gợi ý 7 mẫu setup góc học tập phong cách Hàn Quốc giúp tăng 200% cảm hứng',
    category: 'Góc học tập',
    categorySlug: 'desk-space',
    categoryLabel: 'Không gian học tập',
    author: 'Phương Linh',
    date: '03/10/2024',
    readTime: '5 phút',
    views: '1.5k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCVhuwppfYcT38DE7z7GbFRMiQTI57QjpeT6QPJA-pWgWt8o75DHnvYw8JBY_OQMuiIN9NGo6fjJsookyGmvPhrjqsu8DJZE8f0qUQIw1ceFXgETlo36pPGL6Ud6RIkOR0-hE7sfRK9QaKmhmhzlh_qqXK56k5CPvipfcuraxf0YhrQXHc0wdzi4sDwZuOyGqXNp-TgcjZOFvEDYGA5Wz4Hz2XFYpn4mtUj2DTD8xbxVyvfiF4o0zNKuQ',
    excerpt: 'Tối ưu diện tích bàn học nhỏ bằng khay kệ đa năng, bảng ghim pegboard và phối màu pastel mang lại không gian chill mỗi khi ngồi học.',
    tags: ['#DeskSetup', '#Aesthetic']
  },
  {
    id: 'b5',
    title: 'Nghệ thuật Calligraphy cơ bản: Luyện nét thanh nét đậm với bút cọ mềm',
    category: 'Viết chữ đẹp',
    categorySlug: 'calligraphy',
    categoryLabel: 'Calligraphy',
    author: 'Lan Anh',
    date: '29/09/2024',
    readTime: '8 phút',
    views: '4.2k lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBbpc7sDOVpvAHNgC0fAjLOqZR7PH6CvpYJnIx76NcsVR_ct4Lpra0GxnZD_amAfdNC9qS-2K4B3_dV5Y6q5mBzclZjdLG2jwNPtw_jtCTXuqpy5NzVglzqtnOgnuK_fDtcgj8sq0A1lw8aS1ebmTpU0PLgrl-s_cc3aQqPXPGCDSCo4G_9qKnMOiIjHqHd4mvjHjnq2U36hCxxLUANlhbWYMbroWP30mmSGqRIA3uoqY7cWJ8a3KhWlQ',
    excerpt: 'Từng bước làm quen với bút brush pen, kỹ thuật cầm bút, lực tay và các mẫu chữ tiêu đề bài học ấn tượng khiến ai cũng trầm trồ.',
    tags: ['#Calligraphy', '#BrushPen']
  },
  {
    id: 'b6',
    title: '5 món văn phòng phẩm nhỏ nhưng giải cứu bạn khỏi bàn làm việc bừa bộn',
    category: 'Tiện ích văn phòng',
    categorySlug: 'reviews',
    categoryLabel: 'Mẹo văn phòng',
    author: 'Quốc Bảo',
    date: '25/09/2024',
    readTime: '3 phút',
    views: '950 lượt xem',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA2KPItOg7IWTqXQ1YrTccYqtDNdymUMU1NGem-OTl1Duy08bDCchymwGZXT84NQN-5RizjKUm4Mo3LKeS7ebdYZv5o9I98e4AHAGjn5TAWrXrO0ShXLTNNV1R3xtuEO_3tXPVOS2cvMvQ8md3upw9hasO8H6PZ_R5wrU2iT7McabWmnNXkhl8PXGhLH-IuVCPPo4LReLhfRBjujoDVP97_WM6qQzuhOwIpvMBK2jluzUtBU7lHTTryGQ',
    excerpt: 'Kẹp giấy phân loại tài liệu, khay đựng bút chia ngăn và giấy note đánh dấu chỉ số giúp tiết kiệm 30 phút dọn bàn mỗi ngày.',
    tags: ['#OfficeOrganization', '#LifeHacks']
  }
];

// Store locations for Contact Page
export const STORE_LOCATIONS: StoreLocation[] = [
  {
    name: '1. Showroom Quận 5 (Flagship)',
    tag: 'TP.HCM',
    address: '123 Nguyễn Văn Cừ, Phường 2, Quận 5, TP. Hồ Chí Minh',
    hours: '8:00 - 21:30',
    phone: '(028) 3835 1234',
    isFlagship: true
  },
  {
    name: '2. Chi nhánh Quận 1',
    tag: 'TP.HCM',
    address: '45 Đinh Tiên Hoàng, Phường Đa Kao, Quận 1, TP. Hồ Chí Minh',
    hours: '8:30 - 21:00',
    phone: '(028) 3910 5678'
  },
  {
    name: '3. Chi nhánh Cầu Giấy',
    tag: 'Hà Nội',
    address: '88 Xuân Thủy, Phường Dịch Vọng Hậu, Quận Cầu Giấy, Hà Nội',
    hours: '8:00 - 21:30',
    phone: '(024) 3754 9999'
  }
];
