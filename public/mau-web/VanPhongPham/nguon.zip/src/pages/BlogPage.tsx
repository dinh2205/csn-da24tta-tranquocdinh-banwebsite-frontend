import React, { useState } from 'react';
import { PageRoute, BlogPost } from '../types';
import { BLOG_POSTS } from '../data/mockData';

interface BlogPageProps {
  onNavigate: (page: PageRoute) => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const BlogPage: React.FC<BlogPageProps> = ({ onNavigate, onShowToast }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [savedPosts, setSavedPosts] = useState<string[]>([]);
  const [subName, setSubName] = useState('');
  const [subEmail, setSubEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const categories = [
    { id: 'all', label: 'Tất cả', icon: 'grid_view' },
    { id: 'study-tips', label: 'Phương pháp học tập', icon: 'school' },
    { id: 'bujo', label: 'Bullet Journal & Lập kế hoạch', icon: 'menu_book' },
    { id: 'reviews', label: 'Review văn phòng phẩm', icon: 'rate_review' },
    { id: 'calligraphy', label: 'Nghệ thuật Calligraphy', icon: 'draw' },
    { id: 'desk-space', label: 'Không gian bàn học', icon: 'desk' },
  ];

  const filteredPosts = activeCategory === 'all'
    ? BLOG_POSTS.filter((p) => !p.isFeatured)
    : BLOG_POSTS.filter((p) => !p.isFeatured && p.categorySlug === activeCategory);

  const featuredPost = BLOG_POSTS.find((p) => p.isFeatured) || BLOG_POSTS[0];

  const handleToggleBookmark = (id: string, title: string) => {
    if (savedPosts.includes(id)) {
      setSavedPosts(savedPosts.filter((x) => x !== id));
      onShowToast(`Đã gỡ bài "${title}" khỏi danh sách lưu!`, 'bookmark_remove');
    } else {
      setSavedPosts([...savedPosts, id]);
      onShowToast(`Đã lưu bài viết "${title}"!`, 'bookmark_added');
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (subEmail) {
      setIsSubscribed(true);
      onShowToast(`Chào mừng ${subName || subEmail} gia nhập cộng đồng!`, 'mark_email_read');
    }
  };

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      <div className="w-full max-w-[1320px] mx-auto px-4 sm:px-8">
        
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-space-xs py-space-md text-body-sm font-body-sm text-outline">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-primary transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="material-symbols-outlined text-[14px] text-outline-variant">chevron_right</span>
          <span className="text-on-surface font-label-md font-semibold">Blog &amp; Mẹo học tập</span>
        </nav>

        {/* Page Header Section */}
        <section className="relative overflow-hidden rounded-xl bg-gradient-to-r from-surface-container via-surface-container-low to-surface-container-high p-space-xl md:p-space-2xl my-space-md shadow-sm">
          <div className="relative z-10 max-w-2xl flex flex-col gap-space-sm">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary-container text-on-secondary-container font-label-sm text-label-sm w-fit shadow-sm font-bold">
              <span className="material-symbols-outlined text-[15px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                auto_awesome
              </span>
              <span>GÓC CẢM HỨNG STUDYGRAM</span>
            </div>
            <h1 className="font-headline-lg text-headline-lg text-on-surface tracking-tight font-bold">
              Góc Cảm Hứng &amp; Sáng Tạo
            </h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant leading-relaxed">
              Mẹo học tập hiệu quả, nghệ thuật ghi chép và thế giới văn phòng phẩm đầy sắc màu dành riêng cho học sinh, sinh viên và người đi làm.
            </p>
          </div>

          <div className="absolute -right-6 -bottom-8 w-44 h-44 rounded-full bg-primary-fixed opacity-40 blur-2xl pointer-events-none" />
          <div className="absolute right-32 top-4 w-32 h-32 rounded-xl bg-secondary-fixed opacity-50 rotate-12 blur-lg pointer-events-none" />
          <div className="absolute right-12 top-8 hidden lg:block opacity-20 pointer-events-none">
            <span className="material-symbols-outlined text-[130px] text-primary">edit_note</span>
          </div>
        </section>

        {/* Category Filter Tabs */}
        <section className="py-space-md overflow-x-auto scrollbar-none" id="categories-bar">
          <div className="flex items-center gap-space-sm min-w-max pb-1">
            {categories.map((c) => {
              const isActive = activeCategory === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setActiveCategory(c.id)}
                  className={`px-4 py-2 rounded-full font-label-md text-label-md shadow-sm transition-all flex items-center gap-1.5 cursor-pointer font-bold ${
                    isActive
                      ? 'bg-primary text-on-primary'
                      : 'bg-surface-container-lowest text-on-surface-variant hover:text-primary hover:bg-surface-container'
                  }`}
                >
                  <span className="material-symbols-outlined text-[16px]">{c.icon}</span>
                  <span>{c.label}</span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Featured Hero Article */}
        <article className="relative bg-surface-container-lowest rounded-xl overflow-hidden shadow-md my-space-lg group transition-transform duration-300 hover:-translate-y-1 border border-surface-container/60">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 items-stretch">
            <div className="lg:col-span-7 relative min-h-[300px] lg:min-h-[420px] overflow-hidden">
              <img
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                alt={featuredPost.title}
                src={featuredPost.image}
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="px-3 py-1 rounded-full bg-tertiary-container text-on-tertiary-container font-label-sm text-label-sm uppercase tracking-wider font-bold shadow-sm">
                  Tiêu Điểm Tuần
                </span>
                <span className="px-3 py-1 rounded-full bg-surface-container-lowest/90 backdrop-blur-sm text-primary font-label-sm text-label-sm font-bold shadow-sm">
                  Lập kế hoạch
                </span>
              </div>
            </div>
            <div className="lg:col-span-5 p-space-xl flex flex-col justify-between bg-surface-container-lowest">
              <div className="flex flex-col gap-space-md">
                <div className="flex items-center gap-space-sm text-body-sm font-body-sm text-outline">
                  <span className="flex items-center gap-1 text-primary font-label-md text-label-md font-semibold">
                    <span className="material-symbols-outlined text-[16px]">verified_user</span>
                    {featuredPost.author}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <span className="material-symbols-outlined text-[15px]">schedule</span>
                    {featuredPost.readTime}
                  </span>
                  <span>•</span>
                  <span>{featuredPost.date}</span>
                </div>
                <h2 className="font-headline-md text-headline-md text-on-surface hover:text-primary transition-colors leading-snug font-bold">
                  {featuredPost.title}
                </h2>
                <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                  {featuredPost.excerpt}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  {featuredPost.tags.map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 rounded-lg bg-surface-container text-on-surface-variant font-label-sm text-label-sm"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
              <div className="pt-space-lg flex items-center justify-between border-t border-surface-container/60 mt-4">
                <button
                  onClick={() => onShowToast(`Đang mở: "${featuredPost.title}"`, 'article')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shadow-sm cursor-pointer font-bold"
                >
                  <span>Đọc bài viết</span>
                  <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                </button>
                <button
                  onClick={() => handleToggleBookmark(featuredPost.id, featuredPost.title)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                    savedPosts.includes(featuredPost.id)
                      ? 'bg-primary text-on-primary'
                      : 'bg-surface-container-low text-on-surface-variant hover:text-tertiary-container hover:bg-surface-container'
                  }`}
                  title="Lưu bài viết"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {savedPosts.includes(featuredPost.id) ? 'bookmark_added' : 'bookmark'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </article>

        {/* Section Heading: Latest Articles */}
        <div className="flex items-center justify-between pt-space-xl pb-space-md">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-6 rounded-full bg-primary" />
            <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold">
              Bài Viết Mới Nhất
            </h2>
          </div>
          <button
            onClick={() => setActiveCategory('all')}
            className="flex items-center gap-1 text-primary font-label-md text-label-md hover:underline cursor-pointer font-semibold"
          >
            <span>Xem tất cả bài viết</span>
            <span className="material-symbols-outlined text-[16px]">chevron_right</span>
          </button>
        </div>

        {/* Articles Grid: 3 columns x 2 rows */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-space-lg mb-space-2xl">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              className="group bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col border border-surface-container/60"
            >
              <div className="relative h-48 overflow-hidden bg-surface-container-low">
                <img
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  alt={post.title}
                  src={post.image}
                />
                <span
                  className={`absolute top-3 left-3 px-2.5 py-1 rounded-full font-label-sm text-label-sm shadow-sm font-bold ${
                    post.categorySlug === 'bujo'
                      ? 'bg-secondary-container text-on-secondary-container'
                      : post.categorySlug === 'calligraphy'
                      ? 'bg-secondary-fixed text-on-secondary-fixed-variant'
                      : post.categorySlug === 'desk-space'
                      ? 'bg-surface-container-high text-primary'
                      : post.categorySlug === 'study-tips'
                      ? 'bg-primary-fixed text-on-primary-fixed'
                      : 'bg-primary text-on-primary'
                  }`}
                >
                  {post.categoryLabel}
                </span>
                <span className="absolute bottom-3 right-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur-sm text-on-surface-variant font-label-sm text-[11px] flex items-center gap-1 shadow-sm font-medium">
                  <span className="material-symbols-outlined text-[13px]">schedule</span>{' '}
                  {post.readTime}
                </span>
              </div>
              <div className="p-space-lg flex-1 flex flex-col justify-between">
                <div className="flex flex-col gap-2">
                  <span className="text-body-sm font-body-sm text-outline">
                    {post.date} • {post.category}
                  </span>
                  <h3 className="font-headline-sm text-[16px] text-on-surface group-hover:text-primary transition-colors leading-snug line-clamp-2 font-bold">
                    {post.title}
                  </h3>
                  <p className="font-body-sm text-body-sm text-on-surface-variant line-clamp-2">
                    {post.excerpt}
                  </p>
                </div>
                <div className="pt-space-md flex items-center justify-between text-body-sm font-body-sm border-t border-surface-container/40 mt-3">
                  <span className="text-outline flex items-center gap-1 text-xs">
                    <span className="material-symbols-outlined text-[16px]">visibility</span>{' '}
                    {post.views}
                  </span>
                  <button
                    onClick={() => onShowToast(`Đang mở: "${post.title}"`, 'article')}
                    className="font-label-md text-label-md text-primary group-hover:translate-x-1 transition-transform inline-flex items-center gap-0.5 cursor-pointer font-semibold"
                  >
                    <span>Chi tiết</span>
                    <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                  </button>
                </div>
              </div>
            </article>
          ))}
        </section>

        {/* Interactive Weekly Newsletter Box */}
        <section className="relative rounded-2xl bg-surface-container-low p-space-xl md:p-space-2xl overflow-hidden shadow-sm mb-space-2xl border border-surface-container/80">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-space-xl items-center">
            <div className="lg:col-span-7 flex flex-col gap-space-sm">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm w-fit font-bold">
                <span className="material-symbols-outlined text-[16px]">local_cafe</span>
                <span>BẢN TIN MỖI SÁNG THỨ HAI</span>
              </div>
              <h2 className="font-headline-md text-headline-md text-on-surface font-bold">
                Nhận mẹo học tập &amp; template ghi chép miễn phí
              </h2>
              <p className="font-body-md text-body-md text-on-surface-variant max-w-xl leading-relaxed">
                Tham gia cộng đồng hơn 15.000+ bạn trẻ đam mê học tập. Chúng mình gửi tặng file PDF thời khóa biểu, habit tracker và mã voucher mua văn phòng phẩm 15% vào hòm thư bạn mỗi tuần.
              </p>
              <div className="flex flex-wrap items-center gap-space-lg pt-1 text-body-sm font-body-sm text-on-surface-variant">
                <span className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-primary text-[18px]">check_circle</span>
                  <span>Không spam quảng cáo</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-primary text-[18px]">check_circle</span>
                  <span>Tặng kèm quà số (Digital freebie)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-primary text-[18px]">check_circle</span>
                  <span>Hủy đăng ký bất kỳ lúc nào</span>
                </span>
              </div>
            </div>

            <div className="lg:col-span-5 bg-surface-container-lowest rounded-xl p-space-lg shadow-sm border border-surface-container/60">
              {isSubscribed ? (
                <div className="flex flex-col items-center justify-center py-6 text-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-primary-fixed flex items-center justify-center text-primary">
                    <span className="material-symbols-outlined text-[28px]">mark_email_read</span>
                  </div>
                  <h4 className="font-headline-sm text-headline-sm text-primary font-bold">
                    Đăng ký thành công!
                  </h4>
                  <p className="font-body-sm text-body-sm text-on-surface-variant max-w-xs">
                    Check hộp thư <strong>{subEmail}</strong> để tải ngay bộ Template Planner 2025 độc quyền nhé!
                  </p>
                  <button
                    onClick={() => {
                      setIsSubscribed(false);
                      setSubName('');
                      setSubEmail('');
                    }}
                    className="mt-2 text-xs text-primary underline"
                  >
                    Đăng ký email khác
                  </button>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="sub-name">
                      Tên bạn hoặc nickname
                    </label>
                    <input
                      className="w-full h-11 px-4 rounded-xl bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      id="sub-name"
                      placeholder="VD: Minh Thư, Hoàng..."
                      required
                      type="text"
                      value={subName}
                      onChange={(e) => setSubName(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="sub-email">
                      Email nhận bản tin
                    </label>
                    <input
                      className="w-full h-11 px-4 rounded-xl bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:outline-none focus:ring-2 focus:ring-primary transition-all"
                      id="sub-email"
                      placeholder="emailcuaban@gmail.com"
                      required
                      type="email"
                      value={subEmail}
                      onChange={(e) => setSubEmail(e.target.value)}
                    />
                  </div>
                  <button
                    className="w-full h-11 mt-1 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-lg text-label-lg transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer font-bold"
                    type="submit"
                  >
                    <span className="material-symbols-outlined text-[20px]">mark_email_read</span>
                    <span>Đăng ký nhận mẹo hay</span>
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="absolute -left-12 -top-12 w-64 h-64 rounded-full bg-primary-container opacity-10 blur-3xl pointer-events-none" />
          <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-secondary-container opacity-20 blur-3xl pointer-events-none" />
        </section>

        {/* Value Assurance Grid */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-md py-space-lg mb-space-xl">
          <div className="flex items-center gap-space-md p-space-md rounded-xl bg-surface-container-lowest shadow-sm border border-surface-container/60">
            <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary shrink-0">
              <span className="material-symbols-outlined text-[24px]">local_shipping</span>
            </div>
            <div>
              <h4 className="font-label-md text-label-md text-on-surface font-bold">Giao hàng nhanh</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Toàn quốc, 1 - 3 ngày</p>
            </div>
          </div>

          <div className="flex items-center gap-space-md p-space-md rounded-xl bg-surface-container-lowest shadow-sm border border-surface-container/60">
            <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary shrink-0">
              <span className="material-symbols-outlined text-[24px]">verified</span>
            </div>
            <div>
              <h4 className="font-label-md text-label-md text-on-surface font-bold">Chính hãng 100%</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Cam kết nguồn gốc rõ ràng</p>
            </div>
          </div>

          <div className="flex items-center gap-space-md p-space-md rounded-xl bg-surface-container-lowest shadow-sm border border-surface-container/60">
            <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary shrink-0">
              <span className="material-symbols-outlined text-[24px]">sell</span>
            </div>
            <div>
              <h4 className="font-label-md text-label-md text-on-surface font-bold">Giá tốt mỗi ngày</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Ưu đãi học sinh, sinh viên</p>
            </div>
          </div>

          <div className="flex items-center gap-space-md p-space-md rounded-xl bg-surface-container-lowest shadow-sm border border-surface-container/60">
            <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary shrink-0">
              <span className="material-symbols-outlined text-[24px]">headset_mic</span>
            </div>
            <div>
              <h4 className="font-label-md text-label-md text-on-surface font-bold">Hỗ trợ tận tâm</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Tư vấn chọn bút và sổ phù hợp</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
