import React from 'react';
import { PageRoute, Product } from '../types';

interface CategoriesPageProps {
  onNavigate: (page: PageRoute) => void;
  onAddToCart: (product: Product) => void;
  onShowToast: (msg: string, icon?: string) => void;
  onSelectCategory?: (slug: string) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({
  onNavigate,
  onAddToCart,
  onShowToast,
  onSelectCategory,
}) => {
  const handleCategoryNav = (slug: string) => {
    if (onSelectCategory) {
      onSelectCategory(slug);
    }
    onNavigate('san-pham');
  };

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      <div className="max-w-[1320px] mx-auto w-full px-4 sm:px-8 pb-space-2xl">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 py-space-md text-on-surface-variant font-body-sm text-body-sm">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-primary transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="material-symbols-outlined text-[14px] text-outline">chevron_right</span>
          <span className="text-on-surface font-label-md text-label-md font-semibold">Danh mục sản phẩm</span>
        </nav>

        {/* Page Banner */}
        <section className="mb-space-xl relative overflow-hidden rounded-xl bg-surface-container-low p-space-xl">
          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-space-lg">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container-high text-primary font-label-sm text-label-sm mb-3">
                <span className="material-symbols-outlined text-[16px]">category</span>
                <span className="font-bold">HỆ THỐNG PHÂN LOẠI CHÍNH HÃNG</span>
              </div>
              <h1 className="font-headline-lg text-headline-lg text-on-surface tracking-tight mb-2 font-bold">
                Danh mục sản phẩm
              </h1>
              <p className="font-body-lg text-body-lg text-on-surface-variant">
                Khám phá thế giới văn phòng phẩm phong phú, truyền cảm hứng học tập và sáng tạo cho mỗi ngày tràn đầy năng lượng.
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0 flex-wrap">
              <div className="flex items-center gap-2 bg-surface-container-lowest px-4 py-2.5 rounded-full shadow-sm text-on-surface font-medium">
                <span className="material-symbols-outlined text-primary text-[20px]">local_shipping</span>
                <span className="font-label-md text-label-md">Freeship từ 199K</span>
              </div>
              <div className="flex items-center gap-2 bg-surface-container-lowest px-4 py-2.5 rounded-full shadow-sm text-on-surface font-medium">
                <span className="material-symbols-outlined text-secondary-container text-secondary text-[20px]">award_star</span>
                <span className="font-label-md text-label-md">100% Chính Hãng</span>
              </div>
            </div>
          </div>
          <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-surface-variant/40 rounded-full blur-3xl pointer-events-none" />
        </section>

        {/* 6 Category Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-space-xl">
          
          {/* CATEGORY 1: Bút & Dụng cụ viết */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">edit_note</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 01</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Bút &amp; Dụng cụ viết</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Bút bi, gel mượt mà, highlight tươi sáng</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('but-viet')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 240+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Bút bi', 'Bút gel nước', 'Bút dạ quang', 'Bút viết Calligraphy', 'Ruột & ngòi thay thế'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('but-viet')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat1-1',
                        name: 'Bút gel Thiên Long TL-08',
                        brand: 'Thiên Long',
                        category: 'but-viet',
                        price: 16000,
                        rating: 5,
                        reviewCount: 120,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCg4k0UzzxKLteXRsRVdc1-HmSEzhs32zLrc5RydMi9VmGFYlI2urrpg29-7-vRnLV1d4zCP3tEHuWmpaF4EpzqAN5gQDmN09uClpMIQ4D4hRgyjoJphDUhi7QguBPu5MmP66nl6YYNfxIN_TLgvuIITGwFwaT53G8CYhti3oy-sdVV7z6oiJpmc1uS4tsS3-yJWHZNUCZpu2EyDtlNwbxXFiuDbsFn9DFpvmbr9jNMEtWS4aHBSGIBdA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Bút gel Thiên Long" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCg4k0UzzxKLteXRsRVdc1-HmSEzhs32zLrc5RydMi9VmGFYlI2urrpg29-7-vRnLV1d4zCP3tEHuWmpaF4EpzqAN5gQDmN09uClpMIQ4D4hRgyjoJphDUhi7QguBPu5MmP66nl6YYNfxIN_TLgvuIITGwFwaT53G8CYhti3oy-sdVV7z6oiJpmc1uS4tsS3-yJWHZNUCZpu2EyDtlNwbxXFiuDbsFn9DFpvmbr9jNMEtWS4aHBSGIBdA" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-20%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Bút gel Thiên Long TL-08</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">16.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat1-2',
                        name: 'Bộ Highlight Pastel 6 màu',
                        brand: 'Deli',
                        category: 'but-viet',
                        price: 42000,
                        rating: 5,
                        reviewCount: 95,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBaSmzPD8GHQGMiDVO6vAaDCLligUO0Z1hPUax76mpaono3W5YcBT0FQlOyQQbEpyTuipRRzBJv_cQSiolqpvTXvDl7h5XJG9MwW3GBmZDF42Hbggq1KUcJdx1yrOSopkkD9V-JzA-NjwN5eYX348SZg60VodVexrok2BNivijbmGWTtNjdaECQ1UzCgy6knu_RzdNT1XLAsm3ckNlfmiJpQ5twh3p7zNdUsshVwYxwbFUVENDsyfPTAA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Bộ Highlight Pastel" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBaSmzPD8GHQGMiDVO6vAaDCLligUO0Z1hPUax76mpaono3W5YcBT0FQlOyQQbEpyTuipRRzBJv_cQSiolqpvTXvDl7h5XJG9MwW3GBmZDF42Hbggq1KUcJdx1yrOSopkkD9V-JzA-NjwN5eYX348SZg60VodVexrok2BNivijbmGWTtNjdaECQ1UzCgy6knu_RzdNT1XLAsm3ckNlfmiJpQ5twh3p7zNdUsshVwYxwbFUVENDsyfPTAA" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Bộ Highlight Pastel 6 màu</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">42.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat1-3',
                        name: 'Bút chì kim ngòi 0.5mm',
                        brand: 'Pentel',
                        category: 'but-viet',
                        price: 25000,
                        rating: 5,
                        reviewCount: 42,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJBFeSF_fn7SUJAVgZbJOYfE2-90IMvBsPI5XcviZ8CAtPbfORAbShKrvEDbDffu1VXHO0gnAGByyXAMMmd4yyOI0Uv4NnU9YUnm09WOtwAPr4aN2CMrsScwrDhRG5CnJuWN9csPUmgF812hP8DDNi-h5GTl4GjJrCWRgBlnl5Va9QQKFpYyv8pJbYHw1I90-kEskY5jeHSC2OluXizljlpowEWES2QdljuvjYkRDjegRYml635OZqWw'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Bút chì kim" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBJBFeSF_fn7SUJAVgZbJOYfE2-90IMvBsPI5XcviZ8CAtPbfORAbShKrvEDbDffu1VXHO0gnAGByyXAMMmd4yyOI0Uv4NnU9YUnm09WOtwAPr4aN2CMrsScwrDhRG5CnJuWN9csPUmgF812hP8DDNi-h5GTl4GjJrCWRgBlnl5Va9QQKFpYyv8pJbYHw1I90-kEskY5jeHSC2OluXizljlpowEWES2QdljuvjYkRDjegRYml635OZqWw" />
                      <span className="absolute top-1 left-1 bg-primary text-on-primary text-[9px] font-bold px-1 rounded">Mới</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Bút chì kim ngòi 0.5mm</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">25.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* CATEGORY 2: Sổ tay, Vở & Giấy viết */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">menu_book</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 02</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Sổ tay, Vở &amp; Giấy viết</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Giấy chống thấm, chống lóa mắt cao cấp</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('so-tay')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 180+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Sổ lò xo B5', 'Sổ còng Bìa da', 'Vở kẻ ngang / Caro', 'Giấy kiểm tra 4 ô ly', 'Sketchbook vẽ phác thảo'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('so-tay')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat2-1',
                        name: 'Sổ lò xo B5 Campus 200 trang',
                        brand: 'Campus',
                        category: 'so-tay',
                        price: 35000,
                        rating: 5,
                        reviewCount: 88,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA4v9bL0hPC3Cxtxm36REm-1-gYFE2hzl9-FzDUqZjTUz1-nXkPtmifqG08kNWVyi6PRA3VgISWbAzzjVZhGsiQLXJ7YEy8wrHIrV4-UfKNGVODkpa72uv2_C3Ey81p2_DdZsdzHKlUMnEXfgwmAfWADij8VUYRdYs4ycPbloFg1yy-9iU6JVJA19HmD788EiHMhB575qYfefUYujf2kXoKINZwri2nyS3o8QnJbLJ7KgGg__xTVXm8qA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Sổ lò xo B5 Campus" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA4v9bL0hPC3Cxtxm36REm-1-gYFE2hzl9-FzDUqZjTUz1-nXkPtmifqG08kNWVyi6PRA3VgISWbAzzjVZhGsiQLXJ7YEy8wrHIrV4-UfKNGVODkpa72uv2_C3Ey81p2_DdZsdzHKlUMnEXfgwmAfWADij8VUYRdYs4ycPbloFg1yy-9iU6JVJA19HmD788EiHMhB575qYfefUYujf2kXoKINZwri2nyS3o8QnJbLJ7KgGg__xTVXm8qA" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Sổ lò xo B5 Campus 200 trang</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">35.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat2-2',
                        name: 'Sổ còng Klong Caro A5',
                        brand: 'Klong Journal',
                        category: 'so-tay',
                        price: 58000,
                        rating: 5,
                        reviewCount: 92,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDHmvYy0hufdIaE7ezulYPrjAM0wzLWjI-VZ1CcqoWQnS4vKk3B8GICbNTC8pJ7nANII2qeYiUwZF133NFw3XVq81OySzGE6fbeSrLIr_QOsvy5LZUgIme62Q4h70rUEUCuoH_hzJIHZA-E-vmV1uQsqByYpKn3HQioY3Um59eUaKU4PxCMRdjGiCdFDpuwxagjhXemy9JlInlhPzN-dGl7fb334ZS20dHCB1RFKN_6vDPOx-Pdns-fQg'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Sổ còng Klong Caro A5" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDHmvYy0hufdIaE7ezulYPrjAM0wzLWjI-VZ1CcqoWQnS4vKk3B8GICbNTC8pJ7nANII2qeYiUwZF133NFw3XVq81OySzGE6fbeSrLIr_QOsvy5LZUgIme62Q4h70rUEUCuoH_hzJIHZA-E-vmV1uQsqByYpKn3HQioY3Um59eUaKU4PxCMRdjGiCdFDpuwxagjhXemy9JlInlhPzN-dGl7fb334ZS20dHCB1RFKN_6vDPOx-Pdns-fQg" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-15%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Sổ còng Klong Caro A5</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">58.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat2-3',
                        name: 'Sổ vẽ Sketchbook 160gsm',
                        brand: 'Klong Journal',
                        category: 'so-tay',
                        price: 65000,
                        rating: 5,
                        reviewCount: 50,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDDKGLsH9ZPKE1XGNoNCsCWRrAwpNJt0wJTfJlLbmjLHaoS48IzCroDEFsnBnae_GoY03QtPZ__Q24zxtt0AE5gACVd1MzlFY6FyCwriycwuzjhbPFOSiMr-_TCXj0Ci4ox5E-GMZrMptMj7txOG494qrr378CnGcUKWxrj_n6xozwcvBUqkuVlEtl_AKsjUQC4cXlQuJgiGTGHYIAfokuN1e1xR1VawhkMG8yz5oQGV6IGh3BpnkcXYg'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Sổ vẽ Sketchbook" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDDKGLsH9ZPKE1XGNoNCsCWRrAwpNJt0wJTfJlLbmjLHaoS48IzCroDEFsnBnae_GoY03QtPZ__Q24zxtt0AE5gACVd1MzlFY6FyCwriycwuzjhbPFOSiMr-_TCXj0Ci4ox5E-GMZrMptMj7txOG494qrr378CnGcUKWxrj_n6xozwcvBUqkuVlEtl_AKsjUQC4cXlQuJgiGTGHYIAfokuN1e1xR1VawhkMG8yz5oQGV6IGh3BpnkcXYg" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Sổ vẽ Sketchbook 160gsm</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">65.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* CATEGORY 3: Giấy ghi chú & Băng keo dán */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">sticky_note_2</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 03</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Giấy note &amp; Băng keo dán</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Trang trí bullet journal, ghi nhớ hiệu quả</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('giay-note')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 120+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Giấy note màu Pastel', 'Giấy note có dòng kẻ', 'Băng keo Washi Tape', 'Băng dính 2 mặt trong suốt', 'Phân trang chỉ mục Neon'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('giay-note')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat3-1',
                        name: 'Giấy note nhiều màu 400 tờ',
                        brand: 'Post-it Pro',
                        category: 'giay-note',
                        price: 12000,
                        rating: 5,
                        reviewCount: 76,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCfPtZ7oRQ3CdsAXPLMdU_Yyjdb7_U0HYvapqlGXMPKYo2eWJY5hJKJQrZ-S722LkqOgplLyBBlZdXC1J4id2IvrfZqYQ4ZCZ9jO8FnicTmi8rQnItgMx1A66HnlOwfrvbrFoahrPZ2VFRNobskqjxoXQqQOv9mj8Xba9rRzZj7ler-sKp_eRcZdFj1iQzT-wCXZXmgHz-luHjbnaVtAje3Wi-zM2PKLXqmICy07V-2RaEj_i2_bs0SCA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Giấy note nhiều màu" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCfPtZ7oRQ3CdsAXPLMdU_Yyjdb7_U0HYvapqlGXMPKYo2eWJY5hJKJQrZ-S722LkqOgplLyBBlZdXC1J4id2IvrfZqYQ4ZCZ9jO8FnicTmi8rQnItgMx1A66HnlOwfrvbrFoahrPZ2VFRNobskqjxoXQqQOv9mj8Xba9rRzZj7ler-sKp_eRcZdFj1iQzT-wCXZXmgHz-luHjbnaVtAje3Wi-zM2PKLXqmICy07V-2RaEj_i2_bs0SCA" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-15%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Giấy note nhiều màu 400 tờ</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">12.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat3-2',
                        name: 'Set 5 cuộn Washi Tape họa tiết',
                        brand: 'Deco Art',
                        category: 'giay-note',
                        price: 28000,
                        rating: 5,
                        reviewCount: 60,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBlKt6WmlkbLqE-B5LdSRX9MPce08fb1kzO_rnZQ3Tt6IrAmCdV6-QgGNhCbRK1UMJSXWVjS4ODk6IH1YNfON6M72lyonhNmuS2HN4M3nQ-2UsRbznMuJHPv6B0JBJ6vCL6yuGEWOwluVvPkKRnyVQrfTS6sCYWHp6W90qufimxkIcCgYffSi9-cha0CTM__WY3ZSRAp8GLdE24_dOjssG3D1ImgxtfHdruxxuzu6vRbVrJNBLuhGdPlA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Set 5 cuộn Washi Tape" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBlKt6WmlkbLqE-B5LdSRX9MPce08fb1kzO_rnZQ3Tt6IrAmCdV6-QgGNhCbRK1UMJSXWVjS4ODk6IH1YNfON6M72lyonhNmuS2HN4M3nQ-2UsRbznMuJHPv6B0JBJ6vCL6yuGEWOwluVvPkKRnyVQrfTS6sCYWHp6W90qufimxkIcCgYffSi9-cha0CTM__WY3ZSRAp8GLdE24_dOjssG3D1ImgxtfHdruxxuzu6vRbVrJNBLuhGdPlA" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Set 5 cuộn Washi Tape</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">28.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat3-3',
                        name: 'Phân trang nhựa mờ PET',
                        brand: 'Deco Art',
                        category: 'giay-note',
                        price: 18000,
                        rating: 5,
                        reviewCount: 38,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBp2GN4beV2ufhst3jiIefY4B0XJQAdMHKZQNQjdA7krHKuPDGqLnaM65YYxYVFn7_WJJe_ZsHAMwqW_zJM_J8nSREKS2_14sflFShWiRNsEs8mKyeogIH9gaa8_9lhLV3YTvhmeHpsUkY-XshK8sJ7xPkiHmox2jIXwIZo49c63YT23y3y7uO2qOkPYavVAsgAcTSuTN6IWGz4MEx-DHggDoJCcACYUKNGsKb5vmpjtLeI_LaK_mKO8w'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Phân trang nhựa mờ PET" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBp2GN4beV2ufhst3jiIefY4B0XJQAdMHKZQNQjdA7krHKuPDGqLnaM65YYxYVFn7_WJJe_ZsHAMwqW_zJM_J8nSREKS2_14sflFShWiRNsEs8mKyeogIH9gaa8_9lhLV3YTvhmeHpsUkY-XshK8sJ7xPkiHmox2jIXwIZo49c63YT23y3y7uO2qOkPYavVAsgAcTSuTN6IWGz4MEx-DHggDoJCcACYUKNGsKb5vmpjtLeI_LaK_mKO8w" />
                      <span className="absolute top-1 left-1 bg-primary text-on-primary text-[9px] font-bold px-1 rounded">Mới</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Phân trang nhựa mờ PET</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">18.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* CATEGORY 4: Dụng cụ học tập & Thủ công */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">architecture</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 04</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Dụng cụ học tập &amp; Thủ công</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Thước, kéo, gôm tẩy chuẩn chỉnh từng góc</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('dung-cu-hoc-tap')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 210+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Bộ Thước kẻ & Eke', 'Kéo thủ công mini', 'Băng xóa kéo tiện lợi', 'Gôm tẩy 4B không bụi', 'Keo khô dán giấy & Dập ghim'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('dung-cu-hoc-tap')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat4-1',
                        name: 'Bộ Eke & Thước nhôm 20cm',
                        brand: 'Thiên Long',
                        category: 'dung-cu-hoc-tap',
                        price: 22000,
                        rating: 5,
                        reviewCount: 45,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB_tkk2spGpECJf-yBM_kkQWpyfhZOOVVa5k3svbETPDRDnuZjBHUvYZAyq6DqabcLsCTBtDlH9UO7bhylo2r_5Dp1cnvSz343vcec3SnwldMSvBI_NNgt-zuPUEvrc62nS2j3SOeMOEFSYPfP3C8SLAPAQ-ZIM-iNIiS59sAA3HVTPNg5Lr4LUB43ID-IwDmA5YvaDv2x--yYtJDIcEm3DDI92Ai62ewjGRxRZSz5wj6MW9xnwC_x7Jg'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Bộ Eke & Thước nhôm" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB_tkk2spGpECJf-yBM_kkQWpyfhZOOVVa5k3svbETPDRDnuZjBHUvYZAyq6DqabcLsCTBtDlH9UO7bhylo2r_5Dp1cnvSz343vcec3SnwldMSvBI_NNgt-zuPUEvrc62nS2j3SOeMOEFSYPfP3C8SLAPAQ-ZIM-iNIiS59sAA3HVTPNg5Lr4LUB43ID-IwDmA5YvaDv2x--yYtJDIcEm3DDI92Ai62ewjGRxRZSz5wj6MW9xnwC_x7Jg" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Bộ Eke &amp; Thước nhôm 20cm</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">22.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat4-2',
                        name: 'Băng xóa kéo Plus 12m',
                        brand: 'Plus',
                        category: 'dung-cu-hoc-tap',
                        price: 29000,
                        rating: 5,
                        reviewCount: 67,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAuoUZy9wOVd7_0o8uQGpNgV8LzVOYg210V2rL50xjqJmDqPk0JTCYVkG5X-riahxyslFfQAYQNkVg9oPXEE9NYdPkbK0n4MnqR7oR-i27xof-ZjccrEYZ-2TCwlxsm7LiwvLCoOaIMjcf9U9vx_AXaxQ1K4eOUi8yuZ4AMWpR8fwRwspfalw6ylEvRuU5_mXr8iGWhQShURwP6txcgCZG0mNJpPa75PO4_ZWDE_DsCxjl3wvkqeIf0Bw'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Băng xóa kéo Plus" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAuoUZy9wOVd7_0o8uQGpNgV8LzVOYg210V2rL50xjqJmDqPk0JTCYVkG5X-riahxyslFfQAYQNkVg9oPXEE9NYdPkbK0n4MnqR7oR-i27xof-ZjccrEYZ-2TCwlxsm7LiwvLCoOaIMjcf9U9vx_AXaxQ1K4eOUi8yuZ4AMWpR8fwRwspfalw6ylEvRuU5_mXr8iGWhQShURwP6txcgCZG0mNJpPa75PO4_ZWDE_DsCxjl3wvkqeIf0Bw" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Băng xóa kéo Plus 12m</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">29.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat4-3',
                        name: 'Gôm tẩy Pentel siêu sạch',
                        brand: 'Pentel',
                        category: 'dung-cu-hoc-tap',
                        price: 9000,
                        rating: 5,
                        reviewCount: 99,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDR0qVp1JVV-CZsfCTCNwAEC8C3y7-Wg7zMEBTpFLp669ZQ2Rnry5qYFe4AKKn09ahT8F8fVAG1U3jiZ7FB0sarigY84ICfhbqwBlL2hYXPh0bOHHbMlgn0eM0iRqhP8_awlDOybihgRiVqNNI24re0GgXdkZXEOey4RFZfjSLvcqnKuh8obZzDYZDbUqhBUtzQYZtEGL4JaGKnNMjBn0yiGo-QMFpNzjgc2LeLPGxj2vNHw-ng3hzGGA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Gôm tẩy Pentel" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDR0qVp1JVV-CZsfCTCNwAEC8C3y7-Wg7zMEBTpFLp669ZQ2Rnry5qYFe4AKKn09ahT8F8fVAG1U3jiZ7FB0sarigY84ICfhbqwBlL2hYXPh0bOHHbMlgn0eM0iRqhP8_awlDOybihgRiVqNNI24re0GgXdkZXEOey4RFZfjSLvcqnKuh8obZzDYZDbUqhBUtzQYZtEGL4JaGKnNMjBn0yiGo-QMFpNzjgc2LeLPGxj2vNHw-ng3hzGGA" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-10%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Gôm tẩy Pentel siêu sạch</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">9.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* CATEGORY 5: Balo, Cặp & Hộp bút */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">backpack</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 05</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Balo, Cặp &amp; Hộp bút</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Thời trang, chống thấm, nhiều ngăn tiện lợi</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('balo-hop-but')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 145+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Hộp bút nhiều ngăn', 'Túi vải Canvas tiện lợi', 'Balo học sinh - sinh viên', 'Balo chống gù tiểu học', 'Túi đựng tài liệu A4'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('balo-hop-but')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat5-1',
                        name: 'Hộp bút cute nhiều ngăn',
                        brand: 'Stationery Bags',
                        category: 'balo-hop-but',
                        price: 45000,
                        rating: 5,
                        reviewCount: 64,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBjLhSmY_6uKRq9GunLP9cBVfEimPFVi3jZfadpKHJGyvjj7Wdz_vzU9CPxwwd79lrKCQqMGJU0JT4wF0j7GJypUnuDEUZcrwQF8CukRFAp3UD2PjBpxuJu2l3FJ7Wd3hT5WzKf4Ai3vGQ-sLm0sn4g2r8-D7336QaY6iUb31TNgIawXpz3nQx_8C4yWUyFTlZQo5G-KRdkxvY2xxsxeIe6jikq5K6p96uGSYt4lv5Z24LUPH_iByLuWw'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Hộp bút cute" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBjLhSmY_6uKRq9GunLP9cBVfEimPFVi3jZfadpKHJGyvjj7Wdz_vzU9CPxwwd79lrKCQqMGJU0JT4wF0j7GJypUnuDEUZcrwQF8CukRFAp3UD2PjBpxuJu2l3FJ7Wd3hT5WzKf4Ai3vGQ-sLm0sn4g2r8-D7336QaY6iUb31TNgIawXpz3nQx_8C4yWUyFTlZQo5G-KRdkxvY2xxsxeIe6jikq5K6p96uGSYt4lv5Z24LUPH_iByLuWw" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Hộp bút cute nhiều ngăn</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">45.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat5-2',
                        name: 'Balo học sinh thời trang',
                        brand: 'Stationery Bags',
                        category: 'balo-hop-but',
                        price: 320000,
                        rating: 5,
                        reviewCount: 89,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD1PiIUiYq1qpyMm6053ZFBdrcHulLKTiQWGjoW6ka6MZIlaVw_gdf5G9oGNBSudmtlQSV0-oBeNIwmO9Fe-_MIEAjOxXaHeHezJHcGwbIKshusDpGxxzqKyV8EgUL2Ah6V4IpMzqBYwp-O-OGbECCV0VZvz-b4RCZKA3YERqJwiBURIXo9uTZLnA_zwKTn0N9xU-gZ8CVIkWckh6pb-8oej-HthEgI_eZAsOZS78ovkp--djazFxsuyA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Balo học sinh thời trang" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1PiIUiYq1qpyMm6053ZFBdrcHulLKTiQWGjoW6ka6MZIlaVw_gdf5G9oGNBSudmtlQSV0-oBeNIwmO9Fe-_MIEAjOxXaHeHezJHcGwbIKshusDpGxxzqKyV8EgUL2Ah6V4IpMzqBYwp-O-OGbECCV0VZvz-b4RCZKA3YERqJwiBURIXo9uTZLnA_zwKTn0N9xU-gZ8CVIkWckh6pb-8oej-HthEgI_eZAsOZS78ovkp--djazFxsuyA" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-25%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Balo học sinh thời trang</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">320.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat5-3',
                        name: 'Túi Canvas quai đeo A4',
                        brand: 'Stationery Bags',
                        category: 'balo-hop-but',
                        price: 79000,
                        rating: 5,
                        reviewCount: 30,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuClX_dFZDI78ka5LtV2oainCqQdXA7eeRJ4tMrhcoDYBw1hgYekAfMR3Yt79BhT7ZWLXS2PafjTp4z2XUaLsBZwrJ8s8s-M2jjfB68StXwYnr16c_awBDMnuS7mCLl0COIlsCRy0F9iR6gJikfKw7nbHh-KCb13ykgehhJYs9bDsmvYuSNoGxzF8k7pledqRyMqup5v84Z8KtuVIbcnXktAVPEt97ZPANRhHNXa1cTb0VMB6xfYGWLgOQ'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Túi Canvas quai đeo A4" src="https://lh3.googleusercontent.com/aida-public/AB6AXuClX_dFZDI78ka5LtV2oainCqQdXA7eeRJ4tMrhcoDYBw1hgYekAfMR3Yt79BhT7ZWLXS2PafjTp4z2XUaLsBZwrJ8s8s-M2jjfB68StXwYnr16c_awBDMnuS7mCLl0COIlsCRy0F9iR6gJikfKw7nbHh-KCb13ykgehhJYs9bDsmvYuSNoGxzF8k7pledqRyMqup5v84Z8KtuVIbcnXktAVPEt97ZPANRhHNXa1cTb0VMB6xfYGWLgOQ" />
                      <span className="absolute top-1 left-1 bg-primary text-on-primary text-[9px] font-bold px-1 rounded">Mới</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Túi Canvas quai đeo A4</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">79.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>

          {/* CATEGORY 6: Máy tính & Thiết bị văn phòng */}
          <article className="flex flex-col rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden">
            <div className="p-space-lg bg-surface-container-low flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-space-md w-full sm:w-auto">
                <div className="w-16 h-16 rounded-xl bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined text-[32px]">calculate</span>
                </div>
                <div>
                  <span className="font-label-sm text-label-sm text-primary uppercase tracking-wider font-bold">Ngành hàng 06</span>
                  <h2 className="font-headline-md text-headline-md text-on-surface font-bold">Máy tính &amp; Thiết bị VP</h2>
                  <p className="font-body-sm text-body-sm text-on-surface-variant">Bảo hành chính hãng 7 năm, độ bền cao</p>
                </div>
              </div>
              <button
                onClick={() => handleCategoryNav('may-tinh')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md transition-all shrink-0 w-full sm:w-auto justify-center cursor-pointer font-bold"
              >
                <span>Xem 90+ sản phẩm</span>
                <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
              </button>
            </div>
            <div className="p-space-lg flex-1 flex flex-col justify-between">
              <div>
                <span className="text-on-surface-variant font-label-sm text-label-sm uppercase tracking-wider block mb-2.5">Nhóm phân loại con</span>
                <div className="flex flex-wrap gap-2 mb-space-lg">
                  {['Máy tính THCS & THPT', 'Máy tính tài chính kế toán', 'Khay kệ đựng hồ sơ', 'Máy in nhãn nhiệt mini', 'Máy dập ghim trợ lực'].map((sub) => (
                    <button
                      key={sub}
                      onClick={() => handleCategoryNav('may-tinh')}
                      className="px-3 py-1.5 rounded-lg bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-sm text-body-sm transition-colors cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-label-md text-label-md text-on-surface flex items-center gap-1 font-bold">
                    <span className="material-symbols-outlined text-tertiary-container text-[18px]">local_fire_department</span>
                    Bán chạy nhất tuần
                  </span>
                  <span className="font-body-sm text-body-sm text-outline">Top 3 gợi ý</span>
                </div>
                <div className="grid grid-cols-3 gap-space-sm">
                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat6-1',
                        name: 'Máy tính Casio FX-580VN X',
                        brand: 'Casio',
                        category: 'may-tinh',
                        price: 570000,
                        rating: 5,
                        reviewCount: 520,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCeL5r-9gF1E77Zim73svZRsg5Isa2lJmjVh0Z-hfH09EAPgM0ubf_6dABOV9-L5hx6uUUS1oD_AkvIlUhvh82QRcA7Q6EEtyyeHcumNRzW6049x_Bd0UjWvnaSsyu71SZXpdMTxruCT5hVjUKh73ITw32JCiFsdtcZry-sf7hb27u11ENqmYdJhlizJ-6dFiK55sTt8eBxN3pFoGMFIIaatzHOqbZ8lvNazx-dfp78YTnleb5Njp0uMw'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Máy tính Casio FX-580VN X" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCeL5r-9gF1E77Zim73svZRsg5Isa2lJmjVh0Z-hfH09EAPgM0ubf_6dABOV9-L5hx6uUUS1oD_AkvIlUhvh82QRcA7Q6EEtyyeHcumNRzW6049x_Bd0UjWvnaSsyu71SZXpdMTxruCT5hVjUKh73ITw32JCiFsdtcZry-sf7hb27u11ENqmYdJhlizJ-6dFiK55sTt8eBxN3pFoGMFIIaatzHOqbZ8lvNazx-dfp78YTnleb5Njp0uMw" />
                      <span className="absolute top-1 left-1 bg-primary text-on-primary text-[9px] font-bold px-1 rounded">Mới</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Máy tính Casio FX-580VN X</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">570.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat6-2',
                        name: 'Máy in tem mini Bluetooth',
                        brand: 'Deli',
                        category: 'may-tinh',
                        price: 389000,
                        rating: 5,
                        reviewCount: 42,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBEZg-wQPpfiAPMcTNF1iZc3BeHYUbOJs7iEAE7T2qRKjF653GQ2NDmDioSi0B8JwmPGeyL-qzURrEYrNiBgnvxcOzQdFa-1wSUe2SCYlpQ742K-HzkViZYGcP3M3P_H4EtrXzvVWow2Xs0GARahj5sxSTq5J5J1traRDkhpDAGmj-guwjR1-uQDKXKzmkHWS8pRMPoLYhc1a0WN3rte5KTBW4bMGBWC0py23ubSEq_waux9WGxaXOq5A'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Máy in tem mini" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBEZg-wQPpfiAPMcTNF1iZc3BeHYUbOJs7iEAE7T2qRKjF653GQ2NDmDioSi0B8JwmPGeyL-qzURrEYrNiBgnvxcOzQdFa-1wSUe2SCYlpQ742K-HzkViZYGcP3M3P_H4EtrXzvVWow2Xs0GARahj5sxSTq5J5J1traRDkhpDAGmj-guwjR1-uQDKXKzmkHWS8pRMPoLYhc1a0WN3rte5KTBW4bMGBWC0py23ubSEq_waux9WGxaXOq5A" />
                      <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary-container text-[9px] font-bold px-1 rounded">-18%</span>
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Máy in tem mini Bluetooth</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">389.000đ</span>
                  </div>

                  <div
                    onClick={() => {
                      onAddToCart({
                        id: 'cat6-3',
                        name: 'Khay tài liệu 3 tầng Deli',
                        brand: 'Deli',
                        category: 'may-tinh',
                        price: 85000,
                        rating: 5,
                        reviewCount: 30,
                        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAbGrLBF8eJTiICM42YDwPkZ7F1y9gDeY5N3S9o1_aV7DeB70P9S4bM7x9iDR1b399Qovs8ugT6yHT8rRLQaJG5nRkoidYj6aGT131UQbXKgP8BBxs2C8qykYvGW_UaxIIOghn49jDHzmRJB6_SmIegtwqSamgJXn_pbxJ75WdNYcx4bld9B85RCoKOSSOsrdBWRBKlxzzMLZfUEz3zHO0l8GCvp4BziBX08w9wrx1DSvEDPtq0t3YSNA'
                      });
                    }}
                    className="flex flex-col bg-surface-container-low p-2 rounded-lg group cursor-pointer hover:shadow-xs transition-all"
                  >
                    <div className="w-full aspect-square rounded bg-surface-container-lowest overflow-hidden mb-2 relative">
                      <img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt="Khay tài liệu 3 tầng" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAbGrLBF8eJTiICM42YDwPkZ7F1y9gDeY5N3S9o1_aV7DeB70P9S4bM7x9iDR1b399Qovs8ugT6yHT8rRLQaJG5nRkoidYj6aGT131UQbXKgP8BBxs2C8qykYvGW_UaxIIOghn49jDHzmRJB6_SmIegtwqSamgJXn_pbxJ75WdNYcx4bld9B85RCoKOSSOsrdBWRBKlxzzMLZfUEz3zHO0l8GCvp4BziBX08w9wrx1DSvEDPtq0t3YSNA" />
                    </div>
                    <h3 className="font-label-sm text-label-sm text-on-surface truncate">Khay tài liệu 3 tầng Deli</h3>
                    <span className="font-price-lg text-price-lg text-primary mt-0.5 font-bold">85.000đ</span>
                  </div>
                </div>
              </div>
            </div>
          </article>
        </div>

        {/* B2B & Wholesale Callout Banner */}
        <div className="mt-space-2xl rounded-xl bg-gradient-to-r from-primary to-primary-container p-space-xl text-on-primary flex flex-col md:flex-row items-center justify-between gap-space-lg shadow-md">
          <div className="flex items-center gap-space-lg">
            <div className="w-16 h-16 rounded-full bg-surface-container-lowest/20 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[36px] text-on-primary">apartment</span>
            </div>
            <div className="flex flex-col">
              <div className="inline-flex items-center gap-1.5 text-secondary-fixed font-label-sm text-label-sm uppercase tracking-wider mb-1 font-bold">
                <span className="material-symbols-outlined text-[16px]">verified</span>
                <span>Dịch vụ B2B &amp; Khách hàng doanh nghiệp</span>
              </div>
              <h2 className="font-headline-md text-headline-md leading-snug font-bold">
                Cần mua sắm cho trường học hoặc doanh nghiệp?
              </h2>
              <p className="font-body-md text-body-md text-on-primary-container opacity-90 mt-1 max-w-xl">
                Nhận báo giá sỉ với mức chiết khấu lên đến 35%, hóa đơn VAT đầy đủ và chính sách công nợ linh hoạt.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0 w-full md:w-auto justify-end">
            <button
              onClick={() => onShowToast('Đã gửi yêu cầu báo giá sỉ, nhân viên B2B sẽ gọi lại bạn!', 'mark_email_read')}
              className="w-full md:w-auto px-6 py-3 rounded-full bg-secondary-container hover:bg-secondary-fixed text-on-secondary-container font-label-lg text-label-lg transition-all shadow-sm font-bold cursor-pointer"
              type="button"
            >
              Nhận báo giá sỉ ngay
            </button>
            <a
              href="tel:19001234"
              className="hidden sm:inline-flex items-center gap-1.5 px-5 py-3 rounded-full bg-surface-container-lowest/15 hover:bg-surface-container-lowest/25 text-on-primary font-label-lg text-label-lg transition-all font-semibold"
            >
              <span className="material-symbols-outlined text-[20px]">phone_in_talk</span>
              <span>1900 1234</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
