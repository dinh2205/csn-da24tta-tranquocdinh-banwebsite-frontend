import React, { useState } from 'react';
import { PageRoute } from '../types';
import { MAP_IMAGE, STORE_LOCATIONS } from '../data/mockData';

interface ContactPageProps {
  onNavigate: (page: PageRoute) => void;
  onShowToast: (msg: string, icon?: string) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ onNavigate, onShowToast }) => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    topic: '',
    message: '',
  });

  const [openFaqs, setOpenFaqs] = useState<number[]>([0, 1, 2]); // default expanded like in HTML

  const toggleFaq = (index: number) => {
    setOpenFaqs((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    onShowToast('Gửi tin nhắn phản hồi thành công!', 'mark_email_read');
  };

  const faqs = [
    {
      q: 'Tôi có được kiểm tra hàng trước khi thanh toán không?',
      icon: 'fact_check',
      a: (
        <p>
          <strong>Hoàn toàn ĐƯỢC!</strong> Stationery Shop áp dụng chính sách đồng kiểm khi nhận hàng. Quý khách được quyền kiểm tra số lượng, ngoại quan bao bì và đúng mẫu mã trước khi thanh toán cho nhân viên giao vận. Nếu có sự cố móp méo hoặc sai hàng, bạn có thể từ chối nhận ngay mà không phát sinh bất kỳ khoản phí nào.
        </p>
      ),
    },
    {
      q: 'Phí vận chuyển và thời gian giao hàng như thế nào?',
      icon: 'local_shipping',
      a: (
        <ul className="list-disc list-inside space-y-1">
          <li><strong>Nội thành TP.HCM &amp; Hà Nội:</strong> Nhận hàng trong vòng 24 giờ làm việc. Cửa hàng hỗ trợ giao Hỏa tốc 2 giờ theo nhu cầu.</li>
          <li><strong>Các tỉnh thành khác:</strong> Thời gian giao dao động từ 2 - 3 ngày làm việc.</li>
          <li><strong>Chính sách Miễn phí vận chuyển:</strong> Áp dụng tự động cho toàn bộ đơn hàng có giá trị từ <strong>199.000đ</strong> trở lên trên toàn quốc.</li>
        </ul>
      ),
    },
    {
      q: 'Cửa hàng có xuất hóa đơn VAT cho công ty / trường học không?',
      icon: 'receipt_long',
      a: (
        <p>
          Có. Chúng tôi cung cấp hóa đơn điện tử VAT đầy đủ và hợp lệ theo quy định nhà nước cho mọi cơ quan, trường học, doanh nghiệp. Bạn chỉ cần tick chọn <em>"Yêu cầu xuất hóa đơn công ty"</em> tại bước Đặt hàng hoặc cung cấp mã số thuế cho nhân viên hỗ trợ khi chọn hình thức mua sỉ.
        </p>
      ),
    },
  ];

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      <div className="max-w-[1320px] mx-auto w-full px-4 sm:px-8 py-space-xl">
        
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="flex items-center gap-2 font-body-sm text-body-sm text-on-surface-variant mb-space-lg">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="material-symbols-outlined text-[14px] text-outline">chevron_right</span>
          <span className="text-primary font-medium">Liên hệ</span>
        </nav>

        {/* Page Header Banner */}
        <section className="relative overflow-hidden rounded-xl bg-gradient-to-r from-primary via-primary-container to-surface-tint p-space-xl text-on-primary shadow-md mb-space-2xl">
          <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-surface-container-lowest/10 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute right-1/4 -top-8 w-40 h-40 bg-secondary-container/20 rounded-full blur-xl pointer-events-none" />
          <div className="relative z-10 max-w-3xl flex flex-col gap-space-xs">
            <div className="inline-flex items-center gap-2 bg-surface-container-lowest/15 backdrop-blur-md px-3 py-1 rounded-full w-fit">
              <span className="material-symbols-outlined text-[16px] text-secondary-container">support_agent</span>
              <span className="font-label-sm text-label-sm text-surface-bright tracking-wider uppercase font-bold">
                Tận tâm phục vụ bạn
              </span>
            </div>
            <h1 className="font-headline-lg text-headline-lg text-on-primary font-bold">
              Liên hệ với Stationery Shop
            </h1>
            <p className="font-body-lg text-body-lg text-surface-variant max-w-2xl mt-1">
              Chúng tôi luôn sẵn sàng lắng nghe, tư vấn và hỗ trợ bạn mọi lúc để mang đến trải nghiệm học tập và làm việc trọn vẹn nhất!
            </p>
          </div>
        </section>

        {/* 3 Quick Contact Cards */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-gutter mb-space-2xl">
          {/* Card 1: Hotline */}
          <div className="group bg-surface-container-lowest rounded-xl p-space-lg shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between border border-surface-container/60">
            <div className="flex items-start gap-space-md">
              <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors shrink-0">
                <span className="material-symbols-outlined text-[24px]">call</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider font-bold">
                  Tư vấn &amp; Chăm sóc
                </span>
                <span className="font-headline-sm text-headline-sm text-primary mt-0.5 font-bold">
                  1900 1234
                </span>
                <div className="mt-2 space-y-1 font-body-sm text-body-sm text-on-surface-variant">
                  <p className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-secondary-container" />
                    <span><strong>Nhánh 1:</strong> Mua lẻ &amp; Đơn online</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                    <span><strong>Nhánh 2:</strong> Đơn sỉ &amp; Dự án trường học</span>
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-space-md pt-space-sm bg-surface-container-low/60 -mx-space-lg -mb-space-lg px-space-lg py-2.5 rounded-b-xl flex items-center justify-between text-body-sm font-body-sm text-on-surface-variant border-t border-surface-container/40">
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-[15px] text-outline">schedule</span>
                <span>Giờ làm việc:</span>
              </span>
              <span className="font-medium text-on-surface">8:00 - 22:00 (Hàng ngày)</span>
            </div>
          </div>

          {/* Card 2: Email */}
          <div className="group bg-surface-container-lowest rounded-xl p-space-lg shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between border border-surface-container/60">
            <div className="flex items-start gap-space-md">
              <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors shrink-0">
                <span className="material-symbols-outlined text-[24px]">mail</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider font-bold">
                  Hòm thư điện tử
                </span>
                <a
                  className="font-headline-sm text-headline-sm text-primary hover:text-primary-container truncate mt-0.5 transition-colors font-bold"
                  href="mailto:cskh@stationeryshop.vn"
                >
                  cskh@stationeryshop.vn
                </a>
                <p className="mt-2 font-body-sm text-body-sm text-on-surface-variant">
                  Giải đáp nhanh yêu cầu bảo hành, đối soát hóa đơn hoặc khiếu nại chất lượng dịch vụ.
                </p>
              </div>
            </div>
            <div className="mt-space-md pt-space-sm bg-surface-container-low/60 -mx-space-lg -mb-space-lg px-space-lg py-2.5 rounded-b-xl flex items-center justify-between text-body-sm font-body-sm text-on-surface-variant border-t border-surface-container/40">
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-[15px] text-tertiary">bolt</span>
                <span>Tốc độ phản hồi:</span>
              </span>
              <span className="font-medium text-on-surface">Trong vòng 2 giờ</span>
            </div>
          </div>

          {/* Card 3: Headquarter Showroom */}
          <div className="group bg-surface-container-lowest rounded-xl p-space-lg shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between border border-surface-container/60">
            <div className="flex items-start gap-space-md">
              <div className="w-12 h-12 rounded-full bg-surface-container flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors shrink-0">
                <span className="material-symbols-outlined text-[24px]">storefront</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-label-sm text-label-sm text-outline uppercase tracking-wider font-bold">
                  Showroom trung tâm
                </span>
                <span className="font-label-lg text-label-lg text-on-surface mt-0.5 font-bold">
                  Quận 5, TP. Hồ Chí Minh
                </span>
                <p className="mt-1 font-body-sm text-body-sm text-on-surface-variant line-clamp-2">
                  123 Nguyễn Văn Cừ, Phường 2, Quận 5, TP. Hồ Chí Minh (Gần ĐH Khoa học Tự nhiên)
                </p>
              </div>
            </div>
            <div className="mt-space-md pt-space-sm bg-surface-container-low/60 -mx-space-lg -mb-space-lg px-space-lg py-2.5 rounded-b-xl flex items-center justify-between text-body-sm font-body-sm text-on-surface-variant border-t border-surface-container/40">
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-[15px] text-primary">local_parking</span>
                <span>Bãi giữ xe:</span>
              </span>
              <span className="font-medium text-primary font-bold">Miễn phí cho khách hàng</span>
            </div>
          </div>
        </section>

        {/* Main Content Section: Two Columns (Form + Showroom Map) */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-gutter mb-space-2xl items-start">
          {/* Left Column: Feedback & Inquiry Form (7 cols) */}
          <div className="lg:col-span-7 bg-surface-container-lowest rounded-xl p-space-xl shadow-sm flex flex-col border border-surface-container/60">
            <div className="flex items-center justify-between pb-space-md">
              <div>
                <span className="font-label-sm text-label-sm uppercase tracking-wider text-primary font-bold">
                  Biểu mẫu trực tuyến
                </span>
                <h2 className="font-headline-md text-headline-md text-on-surface mt-0.5 font-bold">
                  Gửi phản hồi / Yêu cầu tư vấn
                </h2>
              </div>
              <span className="material-symbols-outlined text-outline-variant text-[32px]">edit_note</span>
            </div>
            <p className="font-body-md text-body-md text-on-surface-variant mb-space-lg">
              Hãy điền thông tin bên dưới, chuyên viên hỗ trợ của Stationery Shop sẽ liên hệ phản hồi bạn trong thời gian sớm nhất.
            </p>

            <form onSubmit={handleSubmit} className="flex flex-col gap-space-md">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
                {/* Full Name */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="fullName">
                    Họ và tên <span className="text-tertiary">*</span>
                  </label>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined text-[18px] text-outline absolute left-3 pointer-events-none">
                      person
                    </span>
                    <input
                      className="w-full h-11 pl-10 pr-3 rounded-lg bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary focus:outline-none transition-all"
                      id="fullName"
                      placeholder="Ví dụ: Nguyễn Văn An"
                      required
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    />
                  </div>
                </div>

                {/* Phone Number */}
                <div className="flex flex-col gap-1.5">
                  <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="phone">
                    Số điện thoại <span className="text-tertiary">*</span>
                  </label>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined text-[18px] text-outline absolute left-3 pointer-events-none">
                      phone
                    </span>
                    <input
                      className="w-full h-11 pl-10 pr-3 rounded-lg bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary focus:outline-none transition-all"
                      id="phone"
                      placeholder="0901 234 567"
                      required
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              {/* Email Address */}
              <div className="flex flex-col gap-1.5">
                <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="email">
                  Địa chỉ Email <span className="text-tertiary">*</span>
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[18px] text-outline absolute left-3 pointer-events-none">
                    alternate_email
                  </span>
                  <input
                    className="w-full h-11 pl-10 pr-3 rounded-lg bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary focus:outline-none transition-all"
                    id="email"
                    placeholder="tenban@email.com"
                    required
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
              </div>

              {/* Topic Dropdown */}
              <div className="flex flex-col gap-1.5">
                <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="topic">
                  Bạn cần hỗ trợ về vấn đề gì? <span className="text-tertiary">*</span>
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[18px] text-outline absolute left-3 pointer-events-none">
                    help_center
                  </span>
                  <select
                    className="w-full h-11 pl-10 pr-10 rounded-lg bg-surface-container-low text-on-surface text-body-md font-body-md focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary focus:outline-none transition-all appearance-none cursor-pointer"
                    id="topic"
                    required
                    value={formData.topic}
                    onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                  >
                    <option disabled value="">-- Vui lòng chọn danh mục cần giải đáp --</option>
                    <option value="tu-van">Tư vấn lựa chọn sản phẩm học tập &amp; văn phòng</option>
                    <option value="tra-cuu">Tra cứu tiến độ giao nhận đơn hàng</option>
                    <option value="bao-hanh">Yêu cầu đổi trả sản phẩm &amp; chính sách bảo hành</option>
                    <option value="bao-gia-si">Đặt mua số lượng lớn / Báo giá sỉ cho trường học &amp; doanh nghiệp</option>
                    <option value="khac">Các phản ánh và góp ý dịch vụ khác</option>
                  </select>
                  <span className="material-symbols-outlined text-[20px] text-outline absolute right-3 pointer-events-none">
                    arrow_drop_down
                  </span>
                </div>
              </div>

              {/* Message Area */}
              <div className="flex flex-col gap-1.5">
                <label className="font-label-md text-label-md text-on-surface font-semibold" htmlFor="message">
                  Nội dung tin nhắn <span className="text-tertiary">*</span>
                </label>
                <textarea
                  className="w-full p-3 rounded-lg bg-surface-container-low text-on-surface placeholder:text-outline text-body-md font-body-md focus:bg-surface-container-lowest focus:ring-2 focus:ring-primary focus:outline-none transition-all resize-none"
                  id="message"
                  placeholder="Ghi chú chi tiết mã đơn hàng, sản phẩm hoặc thông tin bạn cần chúng tôi trợ giúp..."
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                />
              </div>

              {/* Quick Security Note */}
              <div className="flex items-center justify-between bg-surface-container-low p-3 rounded-lg text-body-sm font-body-sm text-on-surface-variant">
                <span className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[18px] text-primary">security</span>
                  <span>Thông tin cá nhân được bảo mật tuyệt đối theo chính sách cửa hàng.</span>
                </span>
                <span className="text-[11px] text-outline hidden sm:inline font-mono">ENCRYPTED</span>
              </div>

              {/* Success Alert */}
              {formSubmitted && (
                <div className="p-3 rounded-lg bg-surface-container-high text-on-surface flex items-start gap-2 border border-primary/20">
                  <span className="material-symbols-outlined text-primary text-[20px] shrink-0 mt-0.5">
                    check_circle
                  </span>
                  <div>
                    <p className="font-label-md text-label-md text-primary font-bold">
                      Gửi yêu cầu thành công!
                    </p>
                    <p className="font-body-sm text-body-sm text-on-surface-variant">
                      Đội ngũ CSKH Stationery Shop đã tiếp nhận và sẽ liên hệ lại với bạn qua điện thoại/email trong ít phút.
                    </p>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <div className="mt-2 flex items-center gap-4 flex-wrap">
                <button
                  className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-lg text-label-lg shadow-md hover:shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer font-bold"
                  type="submit"
                >
                  <span>Gửi tin nhắn ngay</span>
                  <span className="material-symbols-outlined text-[18px]">send</span>
                </button>
                <span className="font-body-sm text-body-sm text-outline">
                  Phản hồi tức thì trong giờ hành chính
                </span>
              </div>
            </form>
          </div>

          {/* Right Column: Showroom Map & Multi-Branch Network (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-space-lg">
            {/* Interactive Map Visual Container */}
            <div className="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm flex flex-col border border-surface-container/60">
              <div className="p-space-md flex items-center justify-between bg-surface-container-low">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[22px]">pin_drop</span>
                  <div>
                    <h3 className="font-label-lg text-label-lg text-on-surface font-bold">
                      Vị trí Showroom Quận 5
                    </h3>
                    <span className="text-[11px] text-on-surface-variant block">
                      Trải nghiệm mua sắm trực tiếp &amp; nhận hàng tại chỗ
                    </span>
                  </div>
                </div>
                <a
                  className="inline-flex items-center gap-1 text-primary hover:underline font-label-sm text-label-sm font-bold"
                  href="https://maps.google.com"
                  rel="noopener noreferrer"
                  target="_blank"
                >
                  <span>Chỉ đường</span>
                  <span className="material-symbols-outlined text-[14px]">open_in_new</span>
                </a>
              </div>

              {/* Map visual */}
              <div className="relative w-full h-[220px]">
                <div
                  className="w-full h-full bg-cover bg-center"
                  style={{ backgroundImage: `url('${MAP_IMAGE}')` }}
                />
                <div className="absolute bottom-3 left-3 bg-surface-container-lowest/90 backdrop-blur-md px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-tertiary-container animate-pulse" />
                  <span className="font-label-sm text-label-sm text-on-surface font-semibold">
                    Đang mở cửa đón khách
                  </span>
                </div>
              </div>
            </div>

            {/* Store List Card */}
            <div className="bg-surface-container-lowest rounded-xl p-space-lg shadow-sm flex flex-col gap-space-md border border-surface-container/60">
              <div className="flex items-center justify-between pb-2 border-b border-surface-container">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[20px]">store</span>
                  <h3 className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    Hệ thống 3 cửa hàng
                  </h3>
                </div>
                <span className="bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm px-2.5 py-0.5 rounded-full font-bold">
                  Toàn quốc
                </span>
              </div>

              <div className="space-y-space-md">
                {STORE_LOCATIONS.map((loc) => (
                  <div
                    key={loc.name}
                    onClick={() => onShowToast(`Đã chọn xem chi nhánh: ${loc.name}`, 'location_on')}
                    className="p-space-md rounded-lg bg-surface-container-low hover:bg-surface-container transition-colors flex flex-col gap-1.5 cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-label-lg text-label-lg text-primary font-bold">
                        {loc.name}
                      </span>
                      <span
                        className={`font-label-sm text-label-sm px-2 py-0.5 rounded font-bold shadow-xs ${
                          loc.isFlagship
                            ? 'bg-surface-container-lowest text-primary'
                            : 'bg-surface-container-lowest text-on-surface-variant'
                        }`}
                      >
                        {loc.tag}
                      </span>
                    </div>
                    <p className="font-body-sm text-body-sm text-on-surface flex items-start gap-1.5">
                      <span className="material-symbols-outlined text-[16px] text-outline shrink-0 mt-0.5">
                        location_on
                      </span>
                      <span>{loc.address}</span>
                    </p>
                    <div className="flex items-center gap-4 text-body-sm font-body-sm text-on-surface-variant mt-1">
                      <span className="flex items-center gap-1">
                        <span className="material-symbols-outlined text-[14px] text-outline">
                          schedule
                        </span>
                        <span>{loc.hours}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="material-symbols-outlined text-[14px] text-outline">
                          phone
                        </span>
                        <span>{loc.phone}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Accordion Section */}
        <section className="bg-surface-container-lowest rounded-xl p-space-xl shadow-sm mb-space-2xl border border-surface-container/60">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-space-lg gap-2">
            <div>
              <span className="font-label-sm text-label-sm uppercase tracking-wider text-primary font-bold">
                Giải đáp thắc mắc
              </span>
              <h2 className="font-headline-md text-headline-md text-on-surface mt-0.5 font-bold">
                Câu hỏi thường gặp (FAQ)
              </h2>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Bạn cần tìm câu trả lời nhanh? Dưới đây là các câu hỏi phổ biến nhất.
            </p>
          </div>

          <div className="space-y-space-md">
            {faqs.map((faq, idx) => {
              const isOpen = openFaqs.includes(idx);
              return (
                <div key={idx} className="bg-surface-container-low rounded-lg overflow-hidden transition-colors">
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-space-md flex items-center justify-between text-left hover:bg-surface-container transition-colors cursor-pointer"
                    type="button"
                  >
                    <span className="font-label-lg text-label-lg text-on-surface flex items-center gap-2.5 font-semibold">
                      <span className="material-symbols-outlined text-primary text-[20px]">
                        {faq.icon}
                      </span>
                      <span>{faq.q}</span>
                    </span>
                    <span
                      className={`material-symbols-outlined text-outline transition-transform duration-200 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    >
                      expand_more
                    </span>
                  </button>
                  {isOpen && (
                    <div className="p-space-md pt-0 text-on-surface-variant font-body-md text-body-md leading-relaxed animate-in fade-in duration-200">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Value Proposition Banner Strip */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-md bg-surface-container-low p-space-lg rounded-xl">
          <div className="flex items-center gap-space-md bg-surface-container-lowest p-space-md rounded-lg shadow-xs">
            <span className="material-symbols-outlined text-primary text-[32px]">local_shipping</span>
            <div>
              <h4 className="font-label-lg text-label-lg text-on-surface font-bold">Giao hàng nhanh</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Toàn quốc, chỉ 1 - 3 ngày</p>
            </div>
          </div>
          <div className="flex items-center gap-space-md bg-surface-container-lowest p-space-md rounded-lg shadow-xs">
            <span className="material-symbols-outlined text-primary text-[32px]">verified_user</span>
            <div>
              <h4 className="font-label-lg text-label-lg text-on-surface font-bold">Sản phẩm chính hãng</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Cam kết 100% nguồn gốc rõ ràng</p>
            </div>
          </div>
          <div className="flex items-center gap-space-md bg-surface-container-lowest p-space-md rounded-lg shadow-xs">
            <span className="material-symbols-outlined text-primary text-[32px]">sell</span>
            <div>
              <h4 className="font-label-lg text-label-lg text-on-surface font-bold">Giá tốt mỗi ngày</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Nhiều ưu đãi học sinh - sinh viên</p>
            </div>
          </div>
          <div className="flex items-center gap-space-md bg-surface-container-lowest p-space-md rounded-lg shadow-xs">
            <span className="material-symbols-outlined text-primary text-[32px]">headset_mic</span>
            <div>
              <h4 className="font-label-lg text-label-lg text-on-surface font-bold">Hỗ trợ tận tâm</h4>
              <p className="font-body-sm text-body-sm text-on-surface-variant">Tư vấn nhanh chóng 8:00 - 22:00</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
