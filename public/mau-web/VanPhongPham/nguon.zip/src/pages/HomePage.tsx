import React, { useState } from 'react';
import { PageRoute, Product } from '../types';

interface HomePageProps {
  onNavigate: (page: PageRoute) => void;
  onAddToCart: (product: Product) => void;
  onShowToast: (msg: string, icon?: string) => void;
  onFilterCategory?: (cat: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onAddToCart,
  onShowToast,
  onFilterCategory,
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const featuredProducts: Product[] = [
    {
      id: 'hp1',
      name: 'Bút gel Thiên Long TL-08',
      brand: 'Thiên Long',
      category: 'but-viet',
      price: 16000,
      originalPrice: 20000,
      discountPercent: 20,
      rating: 4.5,
      reviewCount: 125,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBWvO5uD-tOMN49O5rNAUswmf4ZRCyN__GnHjmcJcyDneQ3tdwkHKGk38crZIn4ZX8g5x54-XBth5mxPx_d1gsbomC4rYyALcXOzocjsUP6c65kzBiri3xH0evEF_MWVpdMwtu1nYbF8HUP7JnafCNficpT17R08gCoi_V2VeTJ_Ui3z_aQRWcxBTqv7rM1X_1kH3PlG-CAIapVeVBCcCC3BqiQ4K4VOhaV7_qkgBZhsiOQ2gbF8CrJ6Q'
    },
    {
      id: 'hp2',
      name: 'Sổ tay lò xo B5 Campus',
      brand: 'Campus',
      category: 'so-tay',
      price: 35000,
      isNew: true,
      rating: 4.5,
      reviewCount: 98,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBIk3J_Nnjaiu3nwU8r6R_E5t-UhkLKUDX06bUX9qNLiKZ7XrsDZLyweqq8Md59--RONYODN9P9PjddxZpEvBzG24xZzx_yqTkExjbfvGI6xct8aZKsP4sNbjv_Kb_bvSyJsIdu9pZSwf8nKTgEkgv4p3HBamn27C_6WhrA9_PGOlIopas3iN-qXG3HnG76YXSrly2wlvvS5SgUtyDmDHymLBMQjtfpS_ALnc6kcbDgjOmXFUwIc1TBtA'
    },
    {
      id: 'hp3',
      name: 'Giấy note nhiều màu',
      brand: 'Post-it Pro',
      category: 'giay-note',
      price: 12000,
      originalPrice: 14000,
      discountPercent: 15,
      rating: 4.5,
      reviewCount: 76,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBnzcPrz19rvZzvQ_A1AFgauBhRAipCTNi5aDMT1eFcGHvKk6ov6g9GAEl2VC1gpBgBp7LXvtRYDLDPTTATaUrziDo6964XKn50Hr7pT_IX_JhS22uhtbZ2CYf1DErZA-UZqiRPijkYgLhC8k6tjDJQVOlJelqV69OJp2SFzJUlw0vaQmse_nWB114NQJZ6HVrGQzrvrMGHJWQC02FmvQ8Jbgapa13dufrKYxeP2jWtuBcj_62d50-p1g'
    },
    {
      id: 'hp4',
      name: 'Hộp bút cute nhiều ngăn',
      brand: 'Stationery Bags',
      category: 'balo-hop-but',
      price: 45000,
      rating: 4.5,
      reviewCount: 64,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCXt91ZdP_8dN2Ou8i-bCHMPWIObbR9LRD3mY9ZRTIDeQtW07mp-VIhJEBnpexsBktPsnVcnU-5h8sYEkol8lkOxrxveg4zKdmt4n4hBjFGoazheyGAmIKrhUeJnG44DhoS8QGFyOaSlNyE9usKbZAzISuWL-Vnjc2lxQCIwuFput2FlmKS70q-NN5BUy5337qkmX9J94pLNSkIO1UVr4mg_eFVx-3zFByT00wKVFW5xaRIIFViVL-SQw'
    },
    {
      id: 'hp5',
      name: 'Máy tính Casio FX-580VN X',
      brand: 'Casio',
      category: 'may-tinh',
      price: 570000,
      isNew: true,
      rating: 4.5,
      reviewCount: 120,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAcqo-CMKKdxKN7iH_xVrqBuawxYPpmG7M7SIKwHMyoPW7okDw5-2kFZCiVizMdhy1BvIk2lEvd8QzOd9r8mRGSiOisn2FTaJXBGlUhFKTifcygdOcTqQmEUOplTgWaeBE9bWLtVfCDa21zIymWA_0DkEBRDCjhIGKZmH8-OvSTzdECY0sObrJgNDcUXJF6g97T_JqpCZMMbRNuhWA4FGLOm64yN-YzSbt7YIcOy0KUQUsWebK0i9gsjA'
    },
    {
      id: 'hp6',
      name: 'Balo học sinh thời trang',
      brand: 'Stationery Bags',
      category: 'balo-hop-but',
      price: 320000,
      originalPrice: 420000,
      discountPercent: 25,
      rating: 4.5,
      reviewCount: 89,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuChs1a8lzTa5iy3oztYM6xBAMqhF7i0VC-Wh8btyg7XtWfn0X385sqRe9uo5CuLR5vbL5O-ZN1HxdcZvGoSLaf9hUDaNsvM_-sOAktGWMviiIhpSPGHyJthdoiRpuiicWR7_UFpW9lNAtVr6vK6GXoCTIah2kq02pRgZ8VpxPI9nSoVJ_3KZbNQAkR4mpeUHw2kHPUUGfFG3PFXTA1x-FSC5oyQtUpFZk_DF4gMk4x4EEc2apXietJsFg'
    }
  ];

  const handleCategoryClick = (catSlug: string) => {
    if (onFilterCategory) {
      onFilterCategory(catSlug);
    }
    onNavigate('san-pham');
  };

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      <div className="max-w-[1320px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex flex-col gap-7">
        
        {/* HERO SECTION */}
        <section className="relative w-full rounded-2xl overflow-hidden bg-gradient-to-r from-[#d7efff] via-[#e8f4fc] to-[#f9fbff] shadow-sm">
          {/* Decorative Doodles Background Layers */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
            <svg
              className="absolute top-6 left-8 w-16 h-16 text-primary/40 -rotate-12"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              viewBox="0 0 24 24"
            >
              <path d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <svg
              className="absolute top-12 left-1/3 w-6 h-6 text-secondary-container"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
            <div className="absolute bottom-6 left-[28%] text-primary/40 text-2xl font-bold select-none">
              <span className="material-symbols-outlined text-[34px]">sentiment_satisfied</span>
            </div>
          </div>

          {/* Hero Slide Inner */}
          <div className="relative grid grid-cols-1 lg:grid-cols-12 min-h-[360px] items-center p-6 sm:p-10 lg:p-12 gap-8 z-10">
            {/* Left Text Content */}
            <div className="lg:col-span-6 flex flex-col items-start gap-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container-lowest/80 text-primary font-label-md text-label-md shadow-sm">
                <span className="material-symbols-outlined text-[18px] text-secondary">auto_awesome</span>
                <span>Tiếp thêm cảm hứng mỗi ngày!</span>
              </div>
              <h1 className="font-display-hero text-[34px] sm:text-[42px] lg:text-[46px] leading-[1.15] text-[#0f3f7c] font-extrabold tracking-tight">
                Văn phòng phẩm<br />cho học tập và làm việc
              </h1>
              <p className="font-body-lg text-body-lg text-on-surface-variant font-medium">
                Đa dạng sản phẩm <span className="text-primary font-bold">•</span> Chất lượng chính hãng <span className="text-primary font-bold">•</span> Giá tốt mỗi ngày
              </p>
              <div className="pt-2 flex items-center gap-4">
                <button
                  onClick={() => onNavigate('san-pham')}
                  className="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-secondary-container hover:bg-secondary-fixed-dim text-on-secondary-fixed font-label-lg text-label-lg font-bold shadow-md hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5 cursor-pointer"
                >
                  <span>Mua ngay</span>
                  <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
                </button>
              </div>
            </div>

            {/* Right Hero Visual Collage */}
            <div className="lg:col-span-6 relative flex items-center justify-center lg:justify-end">
              <div className="relative w-full max-w-[540px] h-[280px] sm:h-[320px] rounded-2xl overflow-hidden shadow-lg bg-surface-container-lowest">
                <img
                  className="w-full h-full object-cover"
                  alt="Không gian học tập Stationery Shop"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD7JhGRWUK2Wsf3px-mSi4iFzpysAVK-q4pIraAteebS-H3HR1daLjmPTWsWCMfZ6bjsJxifT_o5k-apqMHmoPSbeCrbPPMPLhSdYEmDCVR3uHQPdosZqarJ1CaPXXfEwBJAvDlus1qaD4eVwRR2yhWYA3lb-vgD6hlhUsKmUlUAjmyOQcREg6MQDOMuWyat1rqg-QhdIBGxSRamrPnJEzdtXRVoDp4VgFzcOhDxDtGZIGsyP5OvGDeNQ"
                />
                {/* Overlay note badge */}
                <div className="absolute top-4 right-4 bg-[#fff9c4] text-[#423100] px-4 py-3 rounded-xl shadow-md rotate-2 max-w-[180px] border-l-4 border-[#fdd02c]">
                  <p className="text-xs font-bold leading-snug">Học tốt • Làm việc hiệu quả cùng Stationery Shop</p>
                  <div className="flex justify-end mt-1 text-tertiary">
                    <span className="material-symbols-outlined text-[16px]">favorite</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Slider Arrows */}
          <button
            onClick={() => setCurrentSlide((prev) => (prev === 0 ? 2 : prev - 1))}
            aria-label="Slide trước"
            className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-surface-container-lowest/90 hover:bg-surface-container-lowest text-on-surface flex items-center justify-center shadow-md transition-transform hover:scale-105 z-20 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">chevron_left</span>
          </button>
          <button
            onClick={() => setCurrentSlide((prev) => (prev === 2 ? 0 : prev + 1))}
            aria-label="Slide tiếp theo"
            className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-surface-container-lowest/90 hover:bg-surface-container-lowest text-on-surface flex items-center justify-center shadow-md transition-transform hover:scale-105 z-20 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[20px]">chevron_right</span>
          </button>

          {/* Slider Pagination Dots */}
          <div className="absolute bottom-3.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
            <span
              onClick={() => setCurrentSlide(0)}
              className={`h-2 rounded-full cursor-pointer transition-all ${
                currentSlide === 0 ? 'w-6 bg-primary' : 'w-2 bg-outline-variant hover:bg-primary/50'
              }`}
            />
            <span
              onClick={() => setCurrentSlide(1)}
              className={`h-2 rounded-full cursor-pointer transition-all ${
                currentSlide === 1 ? 'w-6 bg-primary' : 'w-2 bg-outline-variant hover:bg-primary/50'
              }`}
            />
            <span
              onClick={() => setCurrentSlide(2)}
              className={`h-2 rounded-full cursor-pointer transition-all ${
                currentSlide === 2 ? 'w-6 bg-primary' : 'w-2 bg-outline-variant hover:bg-primary/50'
              }`}
            />
          </div>
        </section>

        {/* QUICK CATEGORY TILES (6 items) */}
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {/* 1: Bút viết */}
          <div
            onClick={() => handleCategoryClick('but-viet')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-surface-container-low flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Bút viết"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDJIcOwJSbd-LBdmotIcFte3r7EEDtBBNMBcVLdaSMK6f8nwSnMT9aXzKU9FnETo_yuvJWliccvjTONXgStCy1xhcC1hI0o_T_pCfwakjkELOqSeW4P0ojLehDjNUJZ6itxJVGXO3CKpPFy_EXHTMaaKeGNzL-hgyNdU0ZBo_F_iXjgb6qPzhWNnsym63N2iXpgN_-DrsiIZY-5h8TyChUqydAJN6qLbLrFdp2nEujw6K87gJhre2K8SA"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Bút viết
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Bút bi, gel, chì...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>

          {/* 2: Sổ tay */}
          <div
            onClick={() => handleCategoryClick('so-tay')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-[#f0e7ff] flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Sổ tay"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuB1FyywWgJNce5P2L_NvCfQy1G9HEv4v2_Iw6dUUnxdk2jO05Pb_aezRtBI3pStEv8pfmRR68nzZCnx0E2V8eIimYR1QTzlUIYkuAqT2Qt4he0rFAf-CkeQsx7fq4rxBIrZP5Pqcl_3AZsyqFdJhC8ZbvRchVEVZqTmf-koUIAIr8U8lYYbB_dW8vbut4ZroMNmebdpp6wJT7jH-yNUY4_PEjq7EBeHG_fvn-TVjpVqNx20fmNsY_yZ_w"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Sổ tay
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Sổ lò xo, sổ plan...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>

          {/* 3: Giấy note */}
          <div
            onClick={() => handleCategoryClick('giay-note')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-[#fff4de] flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Giấy note"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCo0oIGqvRcUXdgapk8GXmU-WMnkq6Nm412QrxAkPFHewTOTM9WSwfIdGoRjre63SDqenyq7ZOYKPPvQ4jgV1sx2SvLivMHvH-Uu6lxsdbSsXX3fa0i6rTM0fSkeZ3XPT9saRm9sfk6knufEp1TQKDTsEvBVNQE2IdmDRPaCnf2okiDOI88PP5WfbqCZ5iZeWerOPvlTvIBQn_bHSZT_O2HNcu_aB198ddSAmL20Yo1QbUJ_hGjblrqOA"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Giấy note
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Giấy ghi chú, dán...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>

          {/* 4: Dụng cụ học tập */}
          <div
            onClick={() => handleCategoryClick('dung-cu-hoc-tap')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-[#e3f9ed] flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Dụng cụ học tập"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAtF-1GUFF6QQPqfFtVFTK856MOgKxl2P_W0t2K93rBoi-FlC0HORVzrcDaoNJlRrT9yc2Ixa_624C5SAbaJBvUtgSMb1HtgHTTCW_VI_CF3RS-hzELFnS_1v8EIaqxZJ3k-bjerBp9WLmKrsiQOWJgac-sq7LXYBXAMuix1Gbn_9G2QAmhSAhdGkSgVzD-GqWvT7Sg7DobOzIUDJ9PjJwiFC8ONNM4hTrPL9vFi53wHtIz_aqBs7iuyw"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Dụng cụ học tập
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Thước, kéo, keo...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>

          {/* 5: Balo / Hộp bút */}
          <div
            onClick={() => handleCategoryClick('balo-hop-but')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-[#e1f0ff] flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Balo và hộp bút"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCli0sVTzKK-SFlVCQeEnb2W7tBdVDYaDoGKnRwg8YuWU2-NbQ0QnXwJBwpTQZH8Mbca7fNPCMYSGZHFaNaGHpP8LhgoBJGRVBFie7d3Q5Wa-v4X_2lOTzerqXtGEVuR-ZLKhH3RsROd6rQFiw79hQI9JEV2YX6VwICi-cWUAVw2BbxRZdLyoOz3Q92dpEobKwfiVTwP4G4rddcfIFm53ezpABVTzDe0GeNluJHujDRT58fN8dknqPWtg"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Balo / Hộp bút
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Balo, túi xách xinh...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>

          {/* 6: Máy tính cầm tay */}
          <div
            onClick={() => handleCategoryClick('may-tinh')}
            className="group flex items-center p-3 rounded-xl bg-surface-container-lowest shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5 gap-3 min-w-0 cursor-pointer"
          >
            <div className="w-11 h-11 rounded-lg bg-[#edf2f7] flex items-center justify-center shrink-0 overflow-hidden">
              <img
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                alt="Máy tính cầm tay"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDv0gIrVw-7WtzV7cH6-yEKu4AnCf8htrEy8qEgdpuyX8vMJgHzPCdqzSOujVOtheJ3I91KE-N7a1_JNJqndyUBcJfBZskx_vK57TwGRAvZmpy6hOZGWKXK7Gy1N8UIPGejfTXXnvmw3GfoOReF5TocbnBL1f_09hENLGei4XIvvprdoaYYH9amrPH2BejG3GHfE5bJYwwCaaicKmtL-TMh4A3h0n3Lk8MWgTlYLzMjwHLF1h3Zn24L_g"
              />
            </div>
            <div className="flex flex-col min-w-0 flex-1">
              <span className="font-label-lg text-label-lg text-on-surface font-bold truncate group-hover:text-primary transition-colors">
                Máy tính
              </span>
              <span className="font-body-sm text-body-sm text-outline truncate text-[11px]">
                Casio, Thiên Long...
              </span>
            </div>
            <span className="material-symbols-outlined text-outline group-hover:text-primary text-[18px] shrink-0 transition-colors">
              chevron_right
            </span>
          </div>
        </section>

        {/* MAIN BODY: 3:1 SPLIT */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* LEFT: HOT PRODUCTS (Col 1-9) */}
          <section className="lg:col-span-9 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-tertiary-container text-2xl">🔥</span>
                <h2 className="font-headline-md text-headline-md text-on-surface font-bold tracking-tight">
                  Sản phẩm nổi bật
                </h2>
              </div>
              <button
                onClick={() => onNavigate('san-pham')}
                className="inline-flex items-center gap-1 font-label-md text-label-md text-primary hover:text-primary-container font-semibold group transition-colors cursor-pointer"
              >
                <span>Xem tất cả</span>
                <span className="material-symbols-outlined text-[16px] group-hover:translate-x-1 transition-transform">
                  arrow_forward
                </span>
              </button>
            </div>

            {/* 6-Product Grid (3 columns on desktop) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {featuredProducts.map((p) => (
                <div
                  key={p.id}
                  className="group relative flex flex-col bg-surface-container-lowest rounded-2xl p-3 shadow-sm hover:shadow-md transition-all duration-200 transform hover:-translate-y-1"
                >
                  <div className="relative w-full aspect-square rounded-xl bg-surface-container-low overflow-hidden mb-3">
                    {p.discountPercent && (
                      <span className="absolute top-2.5 left-2.5 z-10 px-2 py-0.5 rounded bg-tertiary-container text-on-tertiary font-label-sm text-label-sm font-bold shadow-sm">
                        -{p.discountPercent}%
                      </span>
                    )}
                    {p.isNew && (
                      <span className="absolute top-2.5 left-2.5 z-10 px-2 py-0.5 rounded bg-primary text-on-primary font-label-sm text-label-sm font-bold shadow-sm">
                        Mới
                      </span>
                    )}
                    <img
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      alt={p.name}
                      src={p.image}
                    />
                  </div>
                  <div className="flex flex-col flex-1">
                    <h3 className="font-label-lg text-label-lg text-on-surface font-bold line-clamp-1 group-hover:text-primary transition-colors">
                      {p.name}
                    </h3>
                    <div className="flex items-center gap-1 mt-1">
                      <div className="flex items-center text-secondary-container">
                        {[...Array(4)].map((_, i) => (
                          <span
                            key={i}
                            className="material-symbols-outlined text-[15px]"
                            style={{ fontVariationSettings: "'FILL' 1" }}
                          >
                            star
                          </span>
                        ))}
                        <span
                          className="material-symbols-outlined text-[15px]"
                          style={{ fontVariationSettings: "'FILL' 1" }}
                        >
                          star_half
                        </span>
                      </div>
                      <span className="font-body-sm text-body-sm text-outline text-[11px]">
                        ({p.reviewCount})
                      </span>
                    </div>
                    <div className="flex items-baseline gap-2 mt-2 mb-3">
                      <span className="font-price-lg text-price-lg text-primary font-extrabold">
                        {p.price.toLocaleString('vi-VN')}đ
                      </span>
                      {p.originalPrice && (
                        <span className="font-price-original text-price-original text-outline line-through">
                          {p.originalPrice.toLocaleString('vi-VN')}đ
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => onAddToCart(p)}
                      className="mt-auto w-full py-2 px-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer active:scale-95"
                    >
                      <span className="material-symbols-outlined text-[17px]">shopping_cart</span>
                      <span>Thêm vào giỏ</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* RIGHT: PROMO AD BANNERS (Col 10-12) */}
          <aside className="lg:col-span-3 flex flex-col gap-4">
            {/* Banner 1: Combo học tập tiết kiệm (Yellow theme) */}
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#fff7d1] via-[#ffec99] to-[#fedb6b] p-5 shadow-sm flex flex-col justify-between min-h-[260px] group">
              <div className="absolute top-3 right-3 w-13 h-13 rounded-full bg-tertiary text-on-tertiary flex flex-col items-center justify-center p-2 shadow-md leading-tight text-center z-10">
                <span className="text-[9px] font-bold uppercase leading-none">Giảm đến</span>
                <span className="text-sm font-extrabold leading-none mt-0.5">30%</span>
              </div>
              <div className="flex flex-col gap-1 pr-12 z-10">
                <span className="font-headline-sm text-[17px] text-[#00458d] font-extrabold tracking-tight uppercase leading-snug">
                  Combo học tập tiết kiệm
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant font-medium">
                  Đầy đủ đồ dùng – Giá siêu tốt
                </p>
              </div>

              {/* Illustrated Imagery Center */}
              <div className="my-3 relative w-full h-24 rounded-xl overflow-hidden bg-surface-container-lowest/70 backdrop-blur-sm shadow-inner">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  alt="Combo học tập tiết kiệm"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCxuniOC8NZ1E29PPCKPPT9AqHutHjECcLylO4RRmTK8cFE_YyFVoioIsX7aVtFog4uX8gEXQCvUAKpVEzpAQX9utoEThdOGxC6KOTuV7irVeexQrO0fLj1p5j01hHVjIVszEHV6r0IzL4lbxBAedcw5xb17OTZKkXoHYNEtr5REIAeluAcODcO-XqaLeLtHA9-WzOt2UZKysQ95G77PFuT0xnKvCxqN2NAXWu6qnQLCl2Bf1h6yoqLuw"
                />
              </div>

              <button
                onClick={() => onNavigate('khuyen-mai')}
                className="inline-flex items-center justify-center gap-1.5 w-full py-2.5 px-4 rounded-full bg-tertiary-container hover:bg-tertiary text-on-tertiary font-label-md text-label-md font-bold shadow-md hover:shadow-lg transition-all z-10 cursor-pointer"
              >
                <span>Mua ngay</span>
                <span className="material-symbols-outlined text-[17px]">arrow_forward</span>
              </button>
            </div>

            {/* Banner 2: Sổ tay & Planner (Pastel Blue theme) */}
            <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#dff0ff] via-[#d0e7fc] to-[#bfe0fa] p-5 shadow-sm flex flex-col justify-between min-h-[260px] group">
              <div className="flex flex-col gap-1 z-10">
                <span className="font-headline-sm text-[17px] text-[#0f3f7c] font-extrabold tracking-tight uppercase leading-snug">
                  Sổ tay &amp; Planner
                </span>
                <p className="font-body-sm text-body-sm text-on-surface-variant leading-snug">
                  Lên kế hoạch hôm nay<br />Cho một phiên bản tốt hơn!
                </p>
              </div>

              <div className="my-3 relative w-full h-24 rounded-xl overflow-hidden bg-surface-container-lowest/70 backdrop-blur-sm shadow-inner">
                <img
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  alt="Sổ tay & Planner"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuC0hEXcVQKvxNYr2gp24cKfDt4-aHtnsCRCxOHBXJPEdNvfh4Ca5Zh2GCXC-j3uYcxr5qPpgpJMhGHi4vqK2kj3wdBJJKg9wqyJsrcBgyntNC1KuoGgXS4QaawkxFm1HwwAZY_R1_imD5VeRuz5AlPc3JGf3Ly0QdLhtxrovDiqM4FIHgWiN1oBdGt0uB-dVwy4w8Z5934hqmhgrlQ2Wz1DHHvPu8qSoL8DBsPKbXyDpQ3RwN9vrZqPyw"
                />
              </div>

              <button
                onClick={() => {
                  handleCategoryClick('so-tay');
                }}
                className="inline-flex items-center justify-center gap-1.5 w-full py-2.5 px-4 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md font-bold shadow-md hover:shadow-lg transition-all z-10 cursor-pointer"
              >
                <span>Xem ngay</span>
                <span className="material-symbols-outlined text-[17px]">arrow_forward</span>
              </button>
            </div>
          </aside>
        </div>

        {/* VALUE PROPOSITION BAR (4 Pillars) */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 sm:p-5 rounded-2xl bg-[#f0f7fd] shadow-sm">
          <div className="flex items-center gap-3.5 p-2 rounded-xl">
            <div className="w-11 h-11 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm shrink-0">
              <span className="material-symbols-outlined text-[24px]">local_shipping</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-lg text-label-lg text-on-surface font-bold">Giao hàng nhanh</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Toàn quốc, nhận hàng từ 1 - 3 ngày</span>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-2 rounded-xl">
            <div className="w-11 h-11 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm shrink-0">
              <span className="material-symbols-outlined text-[24px]">verified</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-lg text-label-lg text-on-surface font-bold">Sản phẩm chính hãng</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Cam kết chất lượng, nguồn gốc rõ ràng</span>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-2 rounded-xl">
            <div className="w-11 h-11 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm shrink-0">
              <span className="material-symbols-outlined text-[24px]">local_offer</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-lg text-label-lg text-on-surface font-bold">Giá tốt mỗi ngày</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Nhiều ưu đãi hấp dẫn</span>
            </div>
          </div>

          <div className="flex items-center gap-3.5 p-2 rounded-xl">
            <div className="w-11 h-11 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary shadow-sm shrink-0">
              <span className="material-symbols-outlined text-[24px]">support_agent</span>
            </div>
            <div className="flex flex-col">
              <span className="font-label-lg text-label-lg text-on-surface font-bold">Hỗ trợ tận tâm</span>
              <span className="font-body-sm text-body-sm text-on-surface-variant">Tư vấn nhanh chóng, 8:00 - 22:00</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
