import React, { useState, useMemo } from 'react';
import { PageRoute, Product } from '../types';
import { ALL_PRODUCTS } from '../data/mockData';

interface ProductsPageProps {
  onNavigate: (page: PageRoute) => void;
  onAddToCart: (product: Product) => void;
  onShowToast: (msg: string, icon?: string) => void;
  searchQuery: string;
  selectedCategorySlug?: string;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({
  onNavigate,
  onAddToCart,
  onShowToast,
  searchQuery,
  selectedCategorySlug,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(selectedCategorySlug || 'all');
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<string>('popular');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPageNum, setCurrentPageNum] = useState<number>(1);

  const categories = [
    { label: 'Tất cả sản phẩm', slug: 'all', count: 128 },
    { label: 'Bút viết & Mực', slug: 'but-viet', count: 42 },
    { label: 'Sổ tay & Vở ghi chép', slug: 'so-tay', count: 29 },
    { label: 'Giấy & Note dán', slug: 'giay-note', count: 18 },
    { label: 'Dụng cụ vẽ & Thủ công', slug: 'dung-cu-ve', count: 15 },
    { label: 'Balo & Hộp bút', slug: 'balo-hop-but', count: 16 },
    { label: 'Máy tính khoa học', slug: 'may-tinh', count: 8 },
  ];

  const brands = ['Thiên Long', 'Campus', 'Casio', 'Deli', 'Plus', 'Pentel', 'Klong Journal'];

  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
  };

  const resetFilters = () => {
    setSelectedCategory('all');
    setSelectedBrands([]);
    setPriceRange([]);
    setMinRating(null);
    onShowToast('Đã đặt lại bộ lọc', 'restart_alt');
  };

  const filteredProducts = useMemo(() => {
    return ALL_PRODUCTS.filter((product) => {
      // Search query
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (
          !product.name.toLowerCase().includes(q) &&
          !product.brand.toLowerCase().includes(q)
        ) {
          return false;
        }
      }

      // Category
      if (selectedCategory !== 'all' && product.category !== selectedCategory) {
        return false;
      }

      // Brand
      if (selectedBrands.length > 0 && !selectedBrands.includes(product.brand)) {
        return false;
      }

      // Price range
      if (priceRange.length > 0) {
        const matchesPrice = priceRange.some((range) => {
          if (range === 'under50') return product.price < 50000;
          if (range === '50to150') return product.price >= 50000 && product.price <= 150000;
          if (range === '150to300') return product.price > 150000 && product.price <= 300000;
          if (range === 'above300') return product.price > 300000;
          return false;
        });
        if (!matchesPrice) return false;
      }

      // Rating
      if (minRating && product.rating < minRating) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'bestseller') return (b.reviewCount || 0) - (a.reviewCount || 0);
      return 0; // default popular
    });
  }, [searchQuery, selectedCategory, selectedBrands, priceRange, minRating, sortBy]);

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      {/* Breadcrumb & Top Bar */}
      <div className="w-full bg-surface-container-low/70 py-space-sm border-b border-surface-container">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-8 flex items-center justify-between">
          <nav className="flex items-center gap-2 font-body-sm text-body-sm text-on-surface-variant">
            <button
              onClick={() => onNavigate('trang-chu')}
              className="hover:text-primary transition-colors flex items-center gap-1 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px]">home</span>
              <span>Trang chủ</span>
            </button>
            <span className="material-symbols-outlined text-[14px] text-outline">chevron_right</span>
            <span className="text-primary font-medium">Tất cả sản phẩm</span>
          </nav>
          <span className="hidden sm:inline-block font-label-sm text-label-sm text-outline-variant bg-surface-container-lowest px-2.5 py-1 rounded-full text-on-surface-variant shadow-sm">
            ✨ Hơn 1.200 món đồ dùng học tập &amp; văn phòng chính hãng
          </span>
        </div>
      </div>

      {/* Page Header Banner */}
      <div className="w-full bg-gradient-to-r from-surface-container-high via-surface-container to-surface-container-low py-space-xl">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-8 flex flex-col md:flex-row md:items-center justify-between gap-space-lg relative overflow-hidden">
          <div className="max-w-2xl relative z-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-secondary-container/30 text-on-secondary-container font-label-sm text-label-sm mb-2">
              <span className="material-symbols-outlined text-[15px] text-secondary">verified_user</span>
              <span>100% Chính hãng • Bảo hành đổi mới</span>
            </div>
            <h1 className="font-headline-lg text-headline-lg text-on-surface tracking-tight mb-2">
              Tất cả sản phẩm văn phòng phẩm &amp; đồ dùng học tập
            </h1>
            <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              Cung cấp trọn vẹn bút viết sắc nét, sổ tay chất lượng cao, máy tính khoa học và phụ kiện bàn học tiện dụng giúp bạn tăng nguồn cảm hứng học tập mỗi ngày.
            </p>
          </div>

          {/* Quick Feature Pill Badges */}
          <div className="flex items-center gap-3 shrink-0 relative z-10">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 px-3 py-2 bg-surface-container-lowest rounded-xl shadow-sm">
                <span className="material-symbols-outlined text-primary text-[20px]">local_shipping</span>
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm text-on-surface font-semibold">Freeship từ 199k</span>
                  <span className="font-body-sm text-[10px] text-outline">Giao toàn quốc 1-3 ngày</span>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-surface-container-lowest rounded-xl shadow-sm">
                <span className="material-symbols-outlined text-tertiary text-[20px]">percent</span>
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm text-on-surface font-semibold">Voucher HSSV</span>
                  <span className="font-body-sm text-[10px] text-outline">Giảm thêm tới 15%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="absolute -right-8 -bottom-10 pointer-events-none opacity-20">
            <span className="material-symbols-outlined text-[180px] text-primary">draw</span>
          </div>
        </div>
      </div>

      {/* Main Catalog Area */}
      <div className="max-w-[1320px] mx-auto px-4 sm:px-8 w-full py-space-xl">
        <div className="flex flex-col lg:flex-row gap-space-xl items-start">
          
          {/* ================= SIDEBAR FILTER (260px desktop) ================= */}
          <aside className="w-full lg:w-[260px] shrink-0 flex flex-col gap-space-md">
            <div className="bg-surface-container-lowest rounded-xl p-4 shadow-sm flex flex-col gap-space-lg">
              {/* Filter Header */}
              <div className="flex items-center justify-between pb-2 bg-surface-container-low/40 -mx-4 -mt-4 p-3 rounded-t-xl">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[20px]">tune</span>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    Bộ lọc tìm kiếm
                  </h2>
                </div>
                <button
                  onClick={resetFilters}
                  className="text-primary hover:text-primary-container font-label-sm text-label-sm transition-colors cursor-pointer"
                  type="button"
                >
                  Xóa tất cả
                </button>
              </div>

              {/* Section 1: Categories */}
              <div className="flex flex-col gap-2">
                <span className="font-label-md text-label-md text-on-surface font-bold uppercase tracking-wider">
                  Danh mục
                </span>
                <div className="flex flex-col gap-1.5 mt-1 font-body-sm text-body-sm">
                  {categories.map((c) => (
                    <label
                      key={c.slug}
                      className="flex items-center justify-between cursor-pointer group py-1 px-1.5 rounded-lg hover:bg-surface-container-low transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          checked={selectedCategory === c.slug}
                          onChange={() => setSelectedCategory(c.slug)}
                          className="accent-primary w-4 h-4 cursor-pointer"
                          name="category"
                          type="radio"
                        />
                        <span
                          className={`font-medium ${
                            selectedCategory === c.slug
                              ? 'text-primary'
                              : 'text-on-surface-variant group-hover:text-on-surface'
                          }`}
                        >
                          {c.label}
                        </span>
                      </div>
                      <span className="font-label-sm text-[11px] text-outline bg-surface-container px-1.5 py-0.5 rounded">
                        {c.count}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Section 2: Brands */}
              <div className="flex flex-col gap-2 pt-2 border-t border-surface-container">
                <span className="font-label-md text-label-md text-on-surface font-bold uppercase tracking-wider">
                  Thương hiệu
                </span>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {brands.map((b) => (
                    <label
                      key={b}
                      className="flex items-center gap-2 p-1.5 rounded-lg bg-surface-container-low/50 hover:bg-surface-container-low cursor-pointer transition-colors text-on-surface-variant font-body-sm text-body-sm"
                    >
                      <input
                        checked={selectedBrands.includes(b)}
                        onChange={() => toggleBrand(b)}
                        className="accent-primary rounded cursor-pointer"
                        type="checkbox"
                      />
                      <span className="font-medium text-xs truncate">{b}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Section 3: Price Range */}
              <div className="flex flex-col gap-2 pt-2 border-t border-surface-container">
                <span className="font-label-md text-label-md text-on-surface font-bold uppercase tracking-wider">
                  Khoảng giá
                </span>
                <div className="flex flex-col gap-1.5 mt-1 font-body-sm text-body-sm">
                  {[
                    { id: 'under50', label: 'Dưới 50.000đ' },
                    { id: '50to150', label: '50.000đ - 150.000đ' },
                    { id: '150to300', label: '150.000đ - 300.000đ' },
                    { id: 'above300', label: 'Trên 300.000đ' },
                  ].map((p) => (
                    <label
                      key={p.id}
                      className="flex items-center gap-2 cursor-pointer text-on-surface-variant hover:text-on-surface"
                    >
                      <input
                        checked={priceRange.includes(p.id)}
                        onChange={(e) => {
                          if (e.target.checked) setPriceRange([...priceRange, p.id]);
                          else setPriceRange(priceRange.filter((x) => x !== p.id));
                        }}
                        className="accent-primary rounded cursor-pointer"
                        type="checkbox"
                      />
                      <span>{p.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Section 4: Rating */}
              <div className="flex flex-col gap-2 pt-2 border-t border-surface-container">
                <span className="font-label-md text-label-md text-on-surface font-bold uppercase tracking-wider">
                  Đánh giá
                </span>
                <div className="flex flex-col gap-1.5 font-body-sm text-body-sm">
                  <label className="flex items-center gap-2 cursor-pointer text-on-surface-variant hover:text-on-surface">
                    <input
                      checked={minRating === 5}
                      onChange={() => setMinRating(minRating === 5 ? null : 5)}
                      className="accent-primary rounded cursor-pointer"
                      type="checkbox"
                    />
                    <div className="flex items-center gap-0.5 text-secondary-container">
                      {[...Array(5)].map((_, i) => (
                        <span
                          key={i}
                          className="material-symbols-outlined text-[16px]"
                          style={{ fontVariationSettings: "'FILL' 1" }}
                        >
                          star
                        </span>
                      ))}
                    </div>
                    <span className="font-label-sm text-label-sm text-on-surface">5 sao chuẩn</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-on-surface-variant hover:text-on-surface">
                    <input
                      checked={minRating === 4}
                      onChange={() => setMinRating(minRating === 4 ? null : 4)}
                      className="accent-primary rounded cursor-pointer"
                      type="checkbox"
                    />
                    <div className="flex items-center gap-0.5 text-secondary-container">
                      {[...Array(4)].map((_, i) => (
                        <span
                          key={i}
                          className="material-symbols-outlined text-[16px]"
                          style={{ fontVariationSettings: "'FILL' 1" }}
                        >
                          star
                        </span>
                      ))}
                      <span className="material-symbols-outlined text-[16px] text-outline-variant">
                        star
                      </span>
                    </div>
                    <span className="font-label-sm text-label-sm text-on-surface">Từ 4 sao</span>
                  </label>
                </div>
              </div>

              {/* Buttons Action */}
              <div className="flex flex-col gap-2 pt-2 border-t border-surface-container">
                <button
                  onClick={() => onShowToast(`Đã lọc ra ${filteredProducts.length} sản phẩm phù hợp!`, 'filter_alt')}
                  className="w-full py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md flex items-center justify-center gap-1.5 shadow-sm transition-all hover:shadow-md cursor-pointer font-bold"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[18px]">filter_alt</span>
                  <span>Áp dụng bộ lọc ({filteredProducts.length})</span>
                </button>
              </div>
            </div>

            {/* Promo Banner Widget in Sidebar */}
            <div className="bg-gradient-to-br from-secondary-container/20 to-primary/10 rounded-xl p-4 flex flex-col gap-2 shadow-sm relative overflow-hidden border border-secondary-container/30">
              <span className="font-label-sm text-label-sm text-tertiary uppercase font-bold tracking-wider">
                Ưu đãi sinh viên
              </span>
              <p className="font-headline-sm text-headline-sm text-on-surface leading-snug font-bold">
                Giảm thêm 10% đơn đầu tiên
              </p>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Nhập mã <strong className="text-primary font-bold">HOCVUIVE</strong> khi thanh toán.
              </p>
              <div className="mt-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('HOCVUIVE');
                    onShowToast('Đã sao chép mã HOCVUIVE!', 'content_copy');
                  }}
                  className="px-3.5 py-1.5 rounded-full bg-surface-container-lowest text-primary font-label-sm text-label-sm shadow-sm hover:bg-primary hover:text-on-primary transition-all font-bold cursor-pointer"
                  type="button"
                >
                  Sao chép mã
                </button>
              </div>
            </div>
          </aside>

          {/* ================= PRODUCTS AREA (Right) ================= */}
          <section className="flex-1 w-full flex flex-col gap-space-lg">
            {/* Controls Bar (Sort & View Layout) */}
            <div className="bg-surface-container-lowest rounded-xl p-3 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-space-md">
              <div className="flex items-center gap-2">
                <span className="font-label-md text-label-md text-on-surface">Tìm thấy:</span>
                <span className="font-headline-sm text-headline-sm text-primary font-extrabold">
                  {filteredProducts.length}
                </span>
                <span className="font-body-sm text-body-sm text-on-surface-variant">
                  sản phẩm phù hợp
                </span>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                {/* Sort dropdown */}
                <div className="flex items-center gap-2 font-body-sm text-body-sm text-on-surface-variant">
                  <span className="hidden md:inline shrink-0">Sắp xếp theo:</span>
                  <div className="relative">
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="appearance-none bg-surface-container-low text-on-surface font-label-md text-label-md pl-3 pr-8 py-1.5 rounded-lg focus:outline-none cursor-pointer hover:bg-surface-container transition-colors"
                    >
                      <option value="popular">Phổ biến nhất</option>
                      <option value="bestseller">Bán chạy hàng đầu</option>
                      <option value="price-asc">Giá tăng dần</option>
                      <option value="price-desc">Giá giảm dần</option>
                    </select>
                    <span className="material-symbols-outlined text-[16px] text-outline absolute right-2 top-2 pointer-events-none">
                      expand_more
                    </span>
                  </div>
                </div>

                {/* View Toggles */}
                <div className="flex items-center bg-surface-container-low p-1 rounded-lg">
                  <button
                    onClick={() => setViewMode('grid')}
                    aria-label="Xem lưới"
                    className={`w-7 h-7 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                      viewMode === 'grid'
                        ? 'bg-surface-container-lowest text-primary shadow-xs'
                        : 'text-on-surface-variant hover:text-primary'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">grid_view</span>
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    aria-label="Xem danh sách"
                    className={`w-7 h-7 rounded-md flex items-center justify-center transition-all cursor-pointer ${
                      viewMode === 'list'
                        ? 'bg-surface-container-lowest text-primary shadow-xs'
                        : 'text-on-surface-variant hover:text-primary'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">view_list</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Product Cards Grid or List */}
            {filteredProducts.length === 0 ? (
              <div className="bg-surface-container-lowest rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-3">
                <span className="material-symbols-outlined text-[56px] text-outline-variant">
                  search_off
                </span>
                <h3 className="font-headline-sm text-on-surface font-bold">
                  Không tìm thấy sản phẩm nào
                </h3>
                <p className="font-body-sm text-on-surface-variant max-w-sm">
                  Thử tìm kiếm với từ khóa khác hoặc xóa bớt tiêu chí lọc để xem thêm nhiều sản phẩm hơn.
                </p>
                <button
                  onClick={resetFilters}
                  className="mt-2 px-5 py-2 rounded-full bg-primary text-on-primary font-label-md hover:bg-primary-container"
                >
                  Xóa bộ lọc
                </button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-space-md">
                {filteredProducts.map((p) => (
                  <div
                    key={p.id}
                    className="group bg-surface-container-lowest rounded-xl p-space-md shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-200 flex flex-col justify-between relative overflow-hidden"
                  >
                    <div className="relative">
                      {p.discountPercent && (
                        <span className="absolute top-0 left-0 bg-tertiary-container text-on-tertiary font-label-sm text-label-sm px-2 py-0.5 rounded-full font-bold shadow-xs z-10">
                          -{p.discountPercent}%
                        </span>
                      )}
                      {p.isNew && (
                        <span className="absolute top-0 left-0 bg-primary text-on-primary font-label-sm text-label-sm px-2 py-0.5 rounded-full font-bold shadow-xs z-10">
                          Mới
                        </span>
                      )}
                      {p.isHot && (
                        <span className="absolute top-0 left-0 bg-primary text-on-primary font-label-sm text-label-sm px-2 py-0.5 rounded-full font-bold shadow-xs z-10">
                          HOT
                        </span>
                      )}
                      <div className="w-full aspect-square rounded-lg bg-surface-container-low overflow-hidden mb-3 relative flex items-center justify-center">
                        <img
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          alt={p.name}
                          src={p.image}
                        />
                      </div>
                      <span className="font-body-sm text-[11px] text-outline uppercase font-semibold">
                        {p.brand}
                      </span>
                      <h3 className="font-label-lg text-label-lg text-on-surface group-hover:text-primary transition-colors line-clamp-2 mt-0.5 h-10 font-bold">
                        {p.name}
                      </h3>
                      {/* Rating */}
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <div className="flex text-secondary-container">
                          {[...Array(Math.floor(p.rating))].map((_, i) => (
                            <span
                              key={i}
                              className="material-symbols-outlined text-[14px]"
                              style={{ fontVariationSettings: "'FILL' 1" }}
                            >
                              star
                            </span>
                          ))}
                          {p.rating % 1 !== 0 && (
                            <span
                              className="material-symbols-outlined text-[14px]"
                              style={{ fontVariationSettings: "'FILL' 1" }}
                            >
                              star_half
                            </span>
                          )}
                        </div>
                        <span className="font-body-sm text-[11px] text-outline">
                          ({p.reviewCount})
                        </span>
                      </div>
                    </div>
                    {/* Pricing & Action */}
                    <div className="mt-3 pt-2">
                      <div className="flex items-baseline gap-2 mb-2.5">
                        <span className="font-price-lg text-price-lg text-primary font-extrabold">
                          {p.price.toLocaleString('vi-VN')}đ
                        </span>
                        {p.originalPrice && (
                          <span className="font-price-original text-price-original text-outline line-through">
                            {p.originalPrice.toLocaleString('vi-VN')}đ
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => onAddToCart(p)}
                        className="w-full py-2 px-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md flex items-center justify-center gap-1.5 transition-colors shadow-xs cursor-pointer font-semibold active:scale-95"
                        type="button"
                      >
                        <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
                        <span>Thêm vào giỏ</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* List Mode */
              <div className="flex flex-col gap-3">
                {filteredProducts.map((p) => (
                  <div
                    key={p.id}
                    className="bg-surface-container-lowest rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row items-center gap-4"
                  >
                    <div className="w-28 h-28 rounded-lg overflow-hidden bg-surface-container-low shrink-0 relative">
                      {p.discountPercent && (
                        <span className="absolute top-1 left-1 bg-tertiary-container text-on-tertiary text-[10px] font-bold px-1.5 py-0.5 rounded">
                          -{p.discountPercent}%
                        </span>
                      )}
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-xs uppercase text-outline font-semibold">{p.brand}</span>
                      <h3 className="font-headline-sm text-on-surface font-bold text-base hover:text-primary transition-colors">
                        {p.name}
                      </h3>
                      <div className="flex items-center gap-1 text-secondary-container mt-1">
                        {[...Array(5)].map((_, i) => (
                          <span
                            key={i}
                            className="material-symbols-outlined text-[14px]"
                            style={{ fontVariationSettings: "'FILL' 1" }}
                          >
                            star
                          </span>
                        ))}
                        <span className="text-outline text-xs ml-1">({p.reviewCount} đánh giá)</span>
                      </div>
                      <div className="flex items-baseline gap-2 mt-2">
                        <span className="text-primary font-bold text-lg">
                          {p.price.toLocaleString('vi-VN')}đ
                        </span>
                        {p.originalPrice && (
                          <span className="text-outline text-xs line-through">
                            {p.originalPrice.toLocaleString('vi-VN')}đ
                          </span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => onAddToCart(p)}
                      className="px-5 py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-semibold text-sm flex items-center gap-2 shrink-0 cursor-pointer shadow-sm active:scale-95"
                    >
                      <span className="material-symbols-outlined text-[18px]">shopping_bag</span>
                      <span>Thêm vào giỏ</span>
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Pagination */}
            <div className="w-full bg-surface-container-lowest rounded-xl p-space-md shadow-sm flex flex-col sm:flex-row items-center justify-between gap-space-md mt-space-md">
              <span className="font-body-sm text-body-sm text-on-surface-variant">
                Hiển thị <strong>1 - {filteredProducts.length}</strong> trong số{' '}
                <strong>128</strong> sản phẩm
              </span>
              <nav className="flex items-center gap-1 sm:gap-2">
                <button
                  disabled={currentPageNum === 1}
                  onClick={() => setCurrentPageNum(Math.max(1, currentPageNum - 1))}
                  className="w-9 h-9 rounded-lg bg-surface-container-low text-outline flex items-center justify-center disabled:opacity-40 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">chevron_left</span>
                </button>
                {[1, 2, 3, 4].map((page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPageNum(page)}
                    className={`w-9 h-9 rounded-lg font-label-md text-label-md font-bold transition-all cursor-pointer ${
                      currentPageNum === page
                        ? 'bg-primary text-on-primary shadow-xs'
                        : 'bg-surface-container-low text-on-surface hover:bg-surface-container'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <span className="px-1 text-outline">...</span>
                <button
                  onClick={() => setCurrentPageNum(11)}
                  className={`w-9 h-9 rounded-lg font-label-md text-label-md transition-all cursor-pointer ${
                    currentPageNum === 11
                      ? 'bg-primary text-on-primary font-bold'
                      : 'bg-surface-container-low text-on-surface hover:bg-surface-container'
                  }`}
                >
                  11
                </button>
                <button
                  onClick={() => setCurrentPageNum((prev) => Math.min(11, prev + 1))}
                  className="h-9 px-3 rounded-lg bg-surface-container-low hover:bg-primary hover:text-on-primary text-on-surface flex items-center gap-1 font-label-md text-label-md transition-colors cursor-pointer"
                >
                  <span>Trang sau</span>
                  <span className="material-symbols-outlined text-[16px]">chevron_right</span>
                </button>
              </nav>
            </div>
          </section>
        </div>
      </div>

      {/* Shopping Guarantees Bottom Banner */}
      <div className="w-full bg-surface-container-low/60 mt-space-xl py-space-lg border-t border-surface-container">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-space-lg">
            <div className="flex items-center gap-3 bg-surface-container-lowest p-4 rounded-xl shadow-xs">
              <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[24px]">local_shipping</span>
              </div>
              <div className="flex flex-col">
                <span className="font-headline-sm text-[16px] text-on-surface font-bold">
                  Giao hàng thần tốc
                </span>
                <span className="font-body-sm text-body-sm text-outline">
                  Nội thành 2h, toàn quốc 24-48h
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 bg-surface-container-lowest p-4 rounded-xl shadow-xs">
              <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[24px]">verified</span>
              </div>
              <div className="flex flex-col">
                <span className="font-headline-sm text-[16px] text-on-surface font-bold">
                  Chính hãng 100%
                </span>
                <span className="font-body-sm text-body-sm text-outline">
                  Cam kết hoàn tiền gấp 3 nếu giả
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 bg-surface-container-lowest p-4 rounded-xl shadow-xs">
              <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[24px]">published_with_changes</span>
              </div>
              <div className="flex flex-col">
                <span className="font-headline-sm text-[16px] text-on-surface font-bold">
                  Đổi trả trong 7 ngày
                </span>
                <span className="font-body-sm text-body-sm text-outline">
                  Thủ tục nhanh gọn, miễn phí gửi lại
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 bg-surface-container-lowest p-4 rounded-xl shadow-xs">
              <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[24px]">support_agent</span>
              </div>
              <div className="flex flex-col">
                <span className="font-headline-sm text-[16px] text-on-surface font-bold">
                  Tư vấn tận tình
                </span>
                <span className="font-body-sm text-body-sm text-outline">
                  Hotline &amp; Chat hỗ trợ 8h - 22h
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
