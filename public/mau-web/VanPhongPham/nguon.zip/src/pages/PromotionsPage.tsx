import React, { useState, useEffect } from 'react';
import { PageRoute, Product } from '../types';
import { FLASH_SALE_ITEMS, VOUCHERS } from '../data/mockData';

interface PromotionsPageProps {
  onNavigate: (page: PageRoute) => void;
  onAddToCart: (product: Product) => void;
  onShowToast: (msg: string, icon?: string) => void;
  onApplyCoupon: (code: string) => void;
  appliedCoupon: string | null;
}

export const PromotionsPage: React.FC<PromotionsPageProps> = ({
  onNavigate,
  onAddToCart,
  onShowToast,
  onApplyCoupon,
  appliedCoupon,
}) => {
  const [savedVouchers, setSavedVouchers] = useState<string[]>(
    appliedCoupon ? [appliedCoupon] : []
  );

  // Live countdown timer state (initially 2 days, 14 hours, 35 minutes, 12 seconds)
  const [timeLeft, setTimeLeft] = useState({
    days: 2,
    hours: 14,
    minutes: 35,
    seconds: 12,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleSaveVoucher = (code: string) => {
    if (savedVouchers.includes(code)) return;
    setSavedVouchers([...savedVouchers, code]);
    onApplyCoupon(code);
    onShowToast(`Đã lưu mã ${code} vào ví ưu đãi của bạn!`, 'check_circle');
  };

  const handleBuyCombo = (comboName: string, price: number, img: string) => {
    onAddToCart({
      id: `combo-${Date.now()}`,
      name: comboName,
      brand: 'Stationery Combo',
      category: 'combo',
      price: price,
      rating: 5,
      reviewCount: 320,
      image: img,
    });
    onShowToast(`Đã thêm "${comboName}" vào giỏ hàng!`, 'shopping_bag');
  };

  return (
    <div className="flex flex-col w-full font-body-md text-on-surface">
      {/* Sub-header / Breadcrumb Context */}
      <div className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 py-3">
        <nav className="flex items-center gap-2 text-on-surface-variant font-label-md text-label-md">
          <button
            onClick={() => onNavigate('trang-chu')}
            className="hover:text-primary transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>Trang chủ</span>
          </button>
          <span className="material-symbols-outlined text-[14px] text-outline">chevron_right</span>
          <span className="text-tertiary font-bold flex items-center gap-1">
            <span
              className="material-symbols-outlined text-[16px] text-tertiary"
              style={{ fontVariationSettings: "'FILL' 1" }}
            >
              local_fire_department
            </span>
            <span>Khuyến mãi HOT</span>
          </span>
        </nav>
      </div>

      {/* Hero Promo Super Banner */}
      <section className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 mb-8">
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-tertiary-container via-[#f84f38] to-secondary-container p-6 sm:p-10 shadow-lg text-on-tertiary">
          <div className="absolute -right-10 -bottom-10 w-96 h-96 rounded-full bg-secondary-fixed/20 blur-3xl pointer-events-none" />
          <div className="absolute top-2 right-1/4 w-40 h-40 rounded-full bg-surface-container-lowest/15 blur-2xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="flex flex-col items-start gap-4 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container-lowest/25 backdrop-blur-sm text-surface-container-lowest font-label-sm text-label-sm uppercase tracking-wider font-bold">
                <span
                  className="material-symbols-outlined text-[16px] text-secondary-container"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  campaign
                </span>
                <span>Đại tiệc siêu sale mùa tựu trường</span>
              </div>
              <h1 className="font-display-hero text-display-hero-mobile sm:text-display-hero text-surface-container-lowest leading-tight tracking-tight drop-shadow-sm font-extrabold">
                SĂN DEAL HỌC TẬP <br className="hidden sm:inline" />
                <span className="text-secondary-fixed drop-shadow-md">GIẢM ĐẾN 50%</span>
              </h1>
              <p className="font-body-lg text-body-lg text-surface-container-lowest/90 leading-relaxed">
                Hàng ngàn văn phòng phẩm, vở kẻ ngang, bút viết chất lượng Nhật Bản và dụng cụ học tập chính hãng với mức trợ giá siêu hấp dẫn!
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href="#flash-sale"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-secondary-container hover:bg-secondary-fixed text-on-secondary-container font-label-lg text-label-lg shadow-md hover:shadow-xl hover:-translate-y-0.5 transition-all font-bold"
                >
                  <span>Săn Deal Ngay</span>
                  <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                </a>
                <a
                  href="#voucher-hub"
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-surface-container-lowest/20 hover:bg-surface-container-lowest/30 text-surface-container-lowest font-label-lg text-label-lg backdrop-blur-sm transition-all font-bold"
                >
                  <span className="material-symbols-outlined text-[18px]">confirmation_number</span>
                  <span>Lưu Kho Voucher</span>
                </a>
              </div>
            </div>

            {/* Flash Sale Countdown Widget */}
            <div className="w-full lg:w-auto shrink-0 bg-surface-container-lowest/15 backdrop-blur-md p-6 rounded-xl flex flex-col items-center shadow-md">
              <div className="flex items-center gap-2 mb-3 text-surface-container-lowest font-headline-sm text-headline-sm font-bold">
                <span
                  className="material-symbols-outlined text-secondary-container text-[24px]"
                  style={{ fontVariationSettings: "'FILL' 1" }}
                >
                  bolt
                </span>
                <span>KẾT THÚC SAU</span>
              </div>
              <div className="flex items-center gap-2 sm:gap-3 text-center">
                <div className="flex flex-col items-center">
                  <div className="w-14 sm:w-16 h-14 sm:h-16 rounded-lg bg-surface-container-lowest text-tertiary font-display-hero text-headline-lg flex items-center justify-center shadow-md leading-none font-bold">
                    {String(timeLeft.days).padStart(2, '0')}
                  </div>
                  <span className="font-label-sm text-label-sm text-surface-container-lowest/90 mt-1 uppercase font-semibold">
                    Ngày
                  </span>
                </div>
                <span className="font-headline-lg text-headline-lg text-surface-container-lowest pb-4 font-bold">:</span>
                <div className="flex flex-col items-center">
                  <div className="w-14 sm:w-16 h-14 sm:h-16 rounded-lg bg-surface-container-lowest text-tertiary font-display-hero text-headline-lg flex items-center justify-center shadow-md leading-none font-bold">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </div>
                  <span className="font-label-sm text-label-sm text-surface-container-lowest/90 mt-1 uppercase font-semibold">
                    Giờ
                  </span>
                </div>
                <span className="font-headline-lg text-headline-lg text-surface-container-lowest pb-4 font-bold">:</span>
                <div className="flex flex-col items-center">
                  <div className="w-14 sm:w-16 h-14 sm:h-16 rounded-lg bg-surface-container-lowest text-tertiary font-display-hero text-headline-lg flex items-center justify-center shadow-md leading-none font-bold">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </div>
                  <span className="font-label-sm text-label-sm text-surface-container-lowest/90 mt-1 uppercase font-semibold">
                    Phút
                  </span>
                </div>
                <span className="font-headline-lg text-headline-lg text-surface-container-lowest pb-4 font-bold">:</span>
                <div className="flex flex-col items-center">
                  <div className="w-14 sm:w-16 h-14 sm:h-16 rounded-lg bg-surface-container-lowest text-tertiary font-display-hero text-headline-lg flex items-center justify-center shadow-md leading-none font-bold">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </div>
                  <span className="font-label-sm text-label-sm text-surface-container-lowest/90 mt-1 uppercase font-semibold">
                    Giây
                  </span>
                </div>
              </div>
              <div className="w-full mt-4 pt-3 flex items-center justify-between text-surface-container-lowest text-body-sm font-body-sm bg-surface-container-lowest/10 px-3 py-1.5 rounded-lg">
                <span className="flex items-center gap-1 font-medium">
                  <span className="material-symbols-outlined text-[16px] text-secondary-fixed">inventory_2</span>
                  <span>Số lượng có hạn</span>
                </span>
                <span className="font-bold text-secondary-fixed">Freeship từ 199K</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Voucher Hub Section */}
      <section className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 mb-12" id="voucher-hub">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-primary font-label-md text-label-md uppercase tracking-wider mb-1 font-bold">
              <span className="material-symbols-outlined text-[18px]">loyalty</span>
              <span>Mã Giảm Giá Độc Quyền</span>
            </div>
            <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold">
              Kho Voucher Siêu Ưu Đãi
            </h2>
          </div>
          <p className="font-body-sm text-body-sm text-on-surface-variant">
            Lưu voucher trước - Áp dụng tự động tại giỏ hàng của bạn
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-space-lg">
          {VOUCHERS.map((v) => {
            const isSaved = savedVouchers.includes(v.code);
            return (
              <div
                key={v.code}
                className="relative bg-surface-container-lowest rounded-xl p-4 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group border border-surface-container/60"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${
                      v.isVip
                        ? 'bg-tertiary-fixed text-tertiary'
                        : v.isFreeship
                        ? 'bg-surface-container-high text-primary-container'
                        : v.code === 'VPP30K'
                        ? 'bg-secondary-fixed/30 text-secondary'
                        : 'bg-surface-container text-primary'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[26px]">
                      {v.isVip ? 'school' : v.isFreeship ? 'local_shipping' : 'local_activity'}
                    </span>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-headline-sm text-headline-sm font-bold ${
                          v.isVip ? 'text-tertiary' : v.isFreeship ? 'text-primary-container' : 'text-primary'
                        }`}
                      >
                        {v.title}
                      </span>
                      <span className="px-1.5 py-0.5 rounded bg-surface-container text-primary font-label-sm text-[10px] font-bold">
                        {v.condition}
                      </span>
                    </div>
                    <p className="font-body-sm text-body-sm text-on-surface-variant mt-0.5">
                      {v.description}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 flex items-center justify-between border-t border-surface-container/40">
                  <div className="flex flex-col">
                    <span className="font-label-sm text-[10px] text-outline uppercase tracking-wider font-semibold">
                      Mã coupon
                    </span>
                    <span className="font-label-md text-label-md text-on-surface font-mono font-bold">
                      {v.code}
                    </span>
                  </div>
                  <button
                    onClick={() => handleSaveVoucher(v.code)}
                    disabled={isSaved}
                    className={`px-4 py-1.5 rounded-full font-label-md text-label-md transition-all shadow-sm cursor-pointer font-bold ${
                      isSaved
                        ? 'bg-outline-variant text-on-surface-variant cursor-default'
                        : v.isVip
                        ? 'bg-tertiary-container hover:bg-tertiary text-on-tertiary active:scale-95'
                        : 'bg-primary hover:bg-primary-container text-on-primary active:scale-95'
                    }`}
                  >
                    {isSaved ? 'Đã lưu' : 'Lưu mã'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Flash Sale Grid with visual stock trackers */}
      <section className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 mb-12" id="flash-sale">
        <div className="bg-surface-container-lowest rounded-2xl p-6 sm:p-8 shadow-sm border border-surface-container/60">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-surface-container">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-tertiary-container text-on-tertiary flex items-center justify-center shadow-md animate-pulse">
                <span className="material-symbols-outlined text-[24px]">bolt</span>
              </div>
              <div>
                <h2 className="font-headline-lg text-headline-lg text-on-surface flex items-center gap-2 font-bold">
                  Flash Sale Hôm Nay
                  <span className="text-tertiary text-label-sm font-label-sm bg-tertiary-fixed px-2 py-0.5 rounded uppercase font-bold">
                    Số lượng có hạn
                  </span>
                </h2>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Giá ưu đãi chớp nhoáng, tự động về giá gốc khi thanh tiến độ đạt 100%
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-body-sm font-body-sm text-on-surface-variant hidden sm:inline">
                Khung giờ vàng:
              </span>
              <span className="px-3 py-1 rounded-full bg-tertiary-container text-on-tertiary font-label-sm text-label-sm font-bold">
                09:00 - 21:00
              </span>
            </div>
          </div>

          {/* Flash sale product cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-lg pt-6">
            {FLASH_SALE_ITEMS.map((item) => (
              <div
                key={item.id}
                className="group bg-surface-container-low rounded-xl p-3 flex flex-col justify-between hover:shadow-lg hover:-translate-y-1 transition-all"
              >
                <div className="relative w-full aspect-square bg-surface-container-lowest rounded-lg overflow-hidden mb-3">
                  <div className="absolute top-2 left-2 z-10 bg-tertiary-container text-on-tertiary px-2 py-0.5 rounded font-label-sm text-label-sm font-bold shadow-sm">
                    -{item.discountPercent}%
                  </div>
                  {item.id === 'fs4' && (
                    <div className="absolute top-2 right-2 z-10 bg-primary text-on-primary px-2 py-0.5 rounded font-label-sm text-[10px] font-bold shadow-sm">
                      CHÍNH HÃNG
                    </div>
                  )}
                  <img
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    alt={item.name}
                    src={item.image}
                  />
                </div>
                <div className="flex flex-col flex-1">
                  <div className="flex items-center gap-1 text-[#ffb400] text-[14px] mb-1">
                    {[...Array(4)].map((_, i) => (
                      <span
                        key={i}
                        className="material-symbols-outlined text-[16px]"
                        style={{ fontVariationSettings: "'FILL' 1" }}
                      >
                        star
                      </span>
                    ))}
                    <span
                      className="material-symbols-outlined text-[16px]"
                      style={{ fontVariationSettings: "'FILL' 1" }}
                    >
                      {item.id === 'fs1' ? 'star_half' : 'star'}
                    </span>
                    <span className="text-on-surface-variant font-body-sm text-body-sm ml-1">
                      ({item.reviewCount})
                    </span>
                  </div>
                  <h3 className="font-headline-sm text-[15px] text-on-surface line-clamp-2 mb-2 group-hover:text-primary transition-colors font-bold">
                    {item.name}
                  </h3>
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="font-price-lg text-price-lg text-tertiary font-bold">
                      {item.price.toLocaleString('vi-VN')}đ
                    </span>
                    <span className="font-price-original text-price-original text-outline line-through">
                      {item.originalPrice?.toLocaleString('vi-VN')}đ
                    </span>
                  </div>
                  {/* Progress tracker */}
                  <div className="w-full bg-surface-container-highest rounded-full h-3.5 relative overflow-hidden mb-3">
                    <div
                      className="bg-gradient-to-r from-tertiary-container to-secondary-container h-full rounded-full transition-all duration-500"
                      style={{ width: `${item.soldPercent}%` }}
                    />
                    <span className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-on-primary uppercase tracking-tight drop-shadow-sm">
                      {item.soldPercent && item.soldPercent > 90
                        ? `Sắp cháy hàng ${item.soldPercent}%`
                        : `Đã bán ${item.soldPercent}%`}
                    </span>
                  </div>
                  <button
                    onClick={() => onAddToCart(item)}
                    className="w-full py-2.5 px-3 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95 cursor-pointer font-bold"
                  >
                    <span className="material-symbols-outlined text-[18px]">add_shopping_cart</span>
                    <span>Thêm vào giỏ</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Value Combos Section */}
      <section className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 mb-12">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2 text-primary font-label-md text-label-md uppercase tracking-wider mb-1 font-bold">
              <span className="material-symbols-outlined text-[18px]">auto_awesome</span>
              <span>Giải Pháp Trọn Gói Giá Hời</span>
            </div>
            <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold">
              Combo Tiết Kiệm Dành Riêng Cho Bạn
            </h2>
          </div>
          <button
            onClick={() => onNavigate('san-pham')}
            className="font-label-md text-label-md text-primary hover:text-primary-container font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            <span>Xem tất cả combo</span>
            <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-space-lg">
          {/* Combo 1 */}
          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between border border-surface-container/60">
            <div>
              <div className="relative w-full h-48 rounded-xl overflow-hidden bg-surface-container-low mb-4">
                <span className="absolute top-2 left-2 z-10 bg-tertiary-container text-on-tertiary font-label-sm text-label-sm px-2.5 py-1 rounded-full font-bold shadow-sm">
                  Tiết kiệm 161.000đ
                </span>
                <img
                  className="w-full h-full object-cover"
                  alt="Combo Nhập Học Đầy Đủ"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCdrONTQwaJL7GScE2rIHtwPZ8iv9I6S_7pLp-9QxD3yIY-DIqGVIlR2CArcSqNib5hbehF6cIzohMcuCzO-dT5CYbKA-oNykhbb92pcC-JTkxe62w62EaDpFoe3GbE5Fp6rmjyog_rSTJNSaLEzttmTQ3xwYrgh6G-L4Apm_Zu7nRZrzzyAVCpuflbpF2w2nIllQmVMYGb7TbyJmrq9ekTjm8_IqcTmI8tR2MGC1qCxsYPP1jy95Yyrg"
                />
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2 py-0.5 rounded bg-surface-container text-primary font-label-sm text-[10px] font-bold">
                  HỌC SINH - SINH VIÊN
                </span>
                <span className="text-outline text-body-sm font-body-sm">• Trọn bộ 5 món</span>
              </div>
              <h3 className="font-headline-md text-headline-md text-on-surface mb-2 font-bold">
                Combo Nhập Học Đầy Đủ
              </h3>
              <ul className="flex flex-col gap-1.5 font-body-sm text-body-sm text-on-surface-variant mb-4">
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>1 Balo đi học chống thấm cao cấp</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>1 Hộp bút nhiều ngăn thời trang</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>10 Cuốn vở Campus 96 trang &amp; Bộ thước kẻ + bút</span>
                </li>
              </ul>
            </div>
            <div className="pt-4 flex items-center justify-between border-t border-surface-container/60">
              <div className="flex flex-col">
                <span className="font-price-lg text-price-lg text-primary font-bold">389.000đ</span>
                <span className="font-price-original text-price-original text-outline line-through">
                  550.000đ
                </span>
              </div>
              <button
                onClick={() =>
                  handleBuyCombo(
                    'Combo Nhập Học Đầy Đủ',
                    389000,
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuCdrONTQwaJL7GScE2rIHtwPZ8iv9I6S_7pLp-9QxD3yIY-DIqGVIlR2CArcSqNib5hbehF6cIzohMcuCzO-dT5CYbKA-oNykhbb92pcC-JTkxe62w62EaDpFoe3GbE5Fp6rmjyog_rSTJNSaLEzttmTQ3xwYrgh6G-L4Apm_Zu7nRZrzzyAVCpuflbpF2w2nIllQmVMYGb7TbyJmrq9ekTjm8_IqcTmI8tR2MGC1qCxsYPP1jy95Yyrg'
                  )
                }
                className="px-5 py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer font-bold"
              >
                <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                <span>Mua combo</span>
              </button>
            </div>
          </div>

          {/* Combo 2 */}
          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between border border-surface-container/60">
            <div>
              <div className="relative w-full h-48 rounded-xl overflow-hidden bg-surface-container-low mb-4">
                <span className="absolute top-2 left-2 z-10 bg-secondary text-on-secondary font-label-sm text-label-sm px-2.5 py-1 rounded-full font-bold shadow-sm">
                  Tiết kiệm 61.000đ
                </span>
                <img
                  className="w-full h-full object-cover"
                  alt="Combo Bullet Journal Khởi Đầu"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0CmjTXZCYaGI70a55NUidFu8sgA1FoUdFqag1vN7rISqjTBrxYZEWToODnslSVkKdaGw9iptPrx5cTFRI9wrYoS_w8lbem81mq6--2XDLZHBMgAvp0dPGXIGFkC-EfZZVv6ojeUReuZtmAp-dpFUBM23tQRZVI6jNq5XgIVOvxp2loZAQsXNuZ8ShEgvmLJdpMD4iR1eradobhjrnVMdqqQrTGf_MuvEuyJIAXbOlyD8W7pDR8UpB9g"
                />
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2 py-0.5 rounded bg-secondary-fixed/40 text-on-secondary-fixed-variant font-label-sm text-[10px] font-bold">
                  CREATIVE &amp; JOURNAL
                </span>
                <span className="text-outline text-body-sm font-body-sm">• Trọn bộ 3 món</span>
              </div>
              <h3 className="font-headline-md text-headline-md text-on-surface mb-2 font-bold">
                Combo Bullet Journal Khởi Đầu
              </h3>
              <ul className="flex flex-col gap-1.5 font-body-sm text-body-sm text-on-surface-variant mb-4">
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-secondary">check_circle</span>
                  <span>1 Sổ Dot Grid 160 trang giấy 100gsm</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-secondary">check_circle</span>
                  <span>12 Bút dạ highlight 2 đầu màu pastel vintage</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-secondary">check_circle</span>
                  <span>5 Cuộn băng dính washi tape họa tiết hoa cỏ</span>
                </li>
              </ul>
            </div>
            <div className="pt-4 flex items-center justify-between border-t border-surface-container/60">
              <div className="flex flex-col">
                <span className="font-price-lg text-price-lg text-secondary font-bold">149.000đ</span>
                <span className="font-price-original text-price-original text-outline line-through">
                  210.000đ
                </span>
              </div>
              <button
                onClick={() =>
                  handleBuyCombo(
                    'Combo Bullet Journal Khởi Đầu',
                    149000,
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuD0CmjTXZCYaGI70a55NUidFu8sgA1FoUdFqag1vN7rISqjTBrxYZEWToODnslSVkKdaGw9iptPrx5cTFRI9wrYoS_w8lbem81mq6--2XDLZHBMgAvp0dPGXIGFkC-EfZZVv6ojeUReuZtmAp-dpFUBM23tQRZVI6jNq5XgIVOvxp2loZAQsXNuZ8ShEgvmLJdpMD4iR1eradobhjrnVMdqqQrTGf_MuvEuyJIAXbOlyD8W7pDR8UpB9g'
                  )
                }
                className="px-5 py-2.5 rounded-full bg-secondary-container hover:bg-secondary-fixed text-on-secondary-container font-label-md text-label-md flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer font-bold"
              >
                <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                <span>Mua combo</span>
              </button>
            </div>
          </div>

          {/* Combo 3 */}
          <div className="bg-surface-container-lowest rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between border border-surface-container/60">
            <div>
              <div className="relative w-full h-48 rounded-xl overflow-hidden bg-surface-container-low mb-4">
                <span className="absolute top-2 left-2 z-10 bg-primary-container text-on-primary-container font-label-sm text-label-sm px-2.5 py-1 rounded-full font-bold shadow-sm">
                  Tiết kiệm 75.000đ
                </span>
                <img
                  className="w-full h-full object-cover"
                  alt="Combo Văn Phòng Tiện Lợi"
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDAQG7o7ooxsAqx4q_IYfpuk-qQqr-LGJl9H7fjF1lZuP6uPbGgEkAktiZL-zQPwsHw2d0pWE0jlSabnOlgNIEsdpmRxdcbBMzdH8dJn5T7HoYYVtqlBV8WRDch3GEeuzjyoStjsxkUThzgtvPcJp_0JgHGtouurSzx5A9tQr9UUfLfU-_g8kvgrk27ub1tGNi5NFSNJoKTlpSF5J6J99BiBeVQYVujBc8U4C5Pf35jGWLB8PdU-dRIRw"
                />
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2 py-0.5 rounded bg-surface-container-high text-on-primary-fixed-variant font-label-sm text-[10px] font-bold">
                  VĂN PHÒNG CHUYÊN NGHIỆP
                </span>
                <span className="text-outline text-body-sm font-body-sm">• Trọn bộ 4 món</span>
              </div>
              <h3 className="font-headline-md text-headline-md text-on-surface mb-2 font-bold">
                Combo Văn Phòng Tiện Lợi
              </h3>
              <ul className="flex flex-col gap-1.5 font-body-sm text-body-sm text-on-surface-variant mb-4">
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>1 Khay tài liệu sắt sơn tĩnh điện 3 tầng</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>1 Bút ký kim loại cao cấp kèm ngòi thay thế</span>
                </li>
                <li className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-[16px] text-primary">check_circle</span>
                  <span>2 Tệp giấy note vàng 3x3 &amp; 1 Hộp kẹp bướm</span>
                </li>
              </ul>
            </div>
            <div className="pt-4 flex items-center justify-between border-t border-surface-container/60">
              <div className="flex flex-col">
                <span className="font-price-lg text-price-lg text-primary font-bold">185.000đ</span>
                <span className="font-price-original text-price-original text-outline line-through">
                  260.000đ
                </span>
              </div>
              <button
                onClick={() =>
                  handleBuyCombo(
                    'Combo Văn Phòng Tiện Lợi',
                    185000,
                    'https://lh3.googleusercontent.com/aida-public/AB6AXuDAQG7o7ooxsAqx4q_IYfpuk-qQqr-LGJl9H7fjF1lZuP6uPbGgEkAktiZL-zQPwsHw2d0pWE0jlSabnOlgNIEsdpmRxdcbBMzdH8dJn5T7HoYYVtqlBV8WRDch3GEeuzjyoStjsxkUThzgtvPcJp_0JgHGtouurSzx5A9tQr9UUfLfU-_g8kvgrk27ub1tGNi5NFSNJoKTlpSF5J6J99BiBeVQYVujBc8U4C5Pf35jGWLB8PdU-dRIRw'
                  )
                }
                className="px-5 py-2.5 rounded-full bg-primary hover:bg-primary-container text-on-primary font-label-md text-label-md flex items-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer font-bold"
              >
                <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                <span>Mua combo</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Tiered Gift Policy Section */}
      <section className="max-w-[1320px] w-full mx-auto px-4 sm:px-8 mb-8">
        <div className="bg-gradient-to-br from-surface-container-low via-surface-container-lowest to-surface-container-high rounded-2xl p-6 sm:p-8 shadow-sm border border-surface-container/60">
          <div className="max-w-3xl mb-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container text-primary font-label-sm text-label-sm uppercase tracking-wider mb-2 font-bold">
              <span className="material-symbols-outlined text-[16px]">featured_seasonal_and_gifts</span>
              <span>Quà tặng đơn hàng</span>
            </div>
            <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold">
              Càng Mua Nhiều, Quà Càng Khủng!
            </h2>
            <p className="font-body-md text-body-md text-on-surface-variant">
              Tự động thêm phần quà tương ứng vào kiện hàng khi thanh toán thỏa điều kiện.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Gift Tier 1 */}
            <div className="bg-surface-container-lowest rounded-xl p-5 shadow-sm flex items-center gap-4 border border-surface-container/60">
              <div className="w-20 h-20 rounded-xl bg-secondary-fixed/30 flex items-center justify-center shrink-0 text-secondary">
                <span className="material-symbols-outlined text-[40px]">sentiment_very_satisfied</span>
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-secondary-fixed/50 text-on-secondary-fixed-variant font-label-sm text-label-sm font-bold">
                    ĐƠN TỪ 99K
                  </span>
                  <span className="text-tertiary font-bold text-label-sm text-label-sm">
                    Miễn phí 100%
                  </span>
                </div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface mt-1 font-bold">
                  Tặng 01 Set Sticker Dễ Thương
                </h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                  Bộ hình dán decal chống thấm nước, trang trí mũ bảo hiểm, laptop, sổ tay cá nhân cực xinh.
                </p>
              </div>
            </div>

            {/* Gift Tier 2 */}
            <div className="bg-surface-container-lowest rounded-xl p-5 shadow-sm flex items-center gap-4 border border-surface-container/60">
              <div className="w-20 h-20 rounded-xl bg-surface-container flex items-center justify-center shrink-0 text-primary">
                <span className="material-symbols-outlined text-[40px]">shopping_bag</span>
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-surface-container text-primary font-label-sm text-label-sm font-bold">
                    ĐƠN TỪ 299K
                  </span>
                  <span className="text-tertiary font-bold text-label-sm text-label-sm">
                    Trị giá 65.000đ
                  </span>
                </div>
                <h3 className="font-headline-sm text-headline-sm text-on-surface mt-1 font-bold">
                  Tặng 01 Túi Canvas Vintage
                </h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">
                  Túi vải bố thân thiện môi trường, in slogan học tập độc quyền từ Stationery Shop.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
