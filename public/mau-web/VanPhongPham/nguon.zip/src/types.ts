export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  isNew?: boolean;
  isHot?: boolean;
  rating: number;
  reviewCount: number;
  soldPercent?: number;
  image: string;
  description?: string;
  tags?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Voucher {
  code: string;
  title: string;
  condition: string;
  description: string;
  discount: number;
  isVip?: boolean;
  isFreeship?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  categorySlug: 'study-tips' | 'bujo' | 'reviews' | 'calligraphy' | 'desk-space';
  categoryLabel: string;
  author: string;
  date: string;
  readTime: string;
  views: string;
  image: string;
  excerpt: string;
  tags: string[];
  isFeatured?: boolean;
}

export interface StoreLocation {
  name: string;
  tag: string;
  address: string;
  hours: string;
  phone: string;
  isFlagship?: boolean;
}

export type PageRoute = 'trang-chu' | 'san-pham' | 'danh-muc' | 'khuyen-mai' | 'blog' | 'lien-he';
