/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

// Pages
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import HeritageListPage from './pages/HeritageListPage';
import HeritageDetailPage from './pages/HeritageDetailPage';
import ArtisanListPage from './pages/ArtisanListPage';
import ArtisanDetailPage from './pages/ArtisanDetailPage';
import EventListPage from './pages/EventListPage';
import EventDetailPage from './pages/EventDetailPage';
import NewsListPage from './pages/NewsListPage';
import NewsDetailPage from './pages/NewsDetailPage';
import CraftMapPage from './pages/CraftMapPage';
import ContactPage from './pages/ContactPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App() {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen bg-[#FFFCF5] text-[#161616]">
        <ScrollToTop />
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/gioi-thieu" element={<AboutPage />} />
            <Route path="/di-san" element={<HeritageListPage />} />
            <Route path="/di-san/:slug" element={<HeritageDetailPage />} />
            <Route path="/nghe-nhan" element={<ArtisanListPage />} />
            <Route path="/nghe-nhan/:slug" element={<ArtisanDetailPage />} />
            <Route path="/su-kien" element={<EventListPage />} />
            <Route path="/su-kien/:slug" element={<EventDetailPage />} />
            <Route path="/tin-tuc" element={<NewsListPage />} />
            <Route path="/tin-tuc/:slug" element={<NewsDetailPage />} />
            <Route path="/ban-do-lang-nghe" element={<CraftMapPage />} />
            <Route path="/lien-he" element={<ContactPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
}
