import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, Award } from 'lucide-react';

export interface ArtisanItem {
  id: string;
  slug: string;
  name: string;
  craft: string;
  province: string;
  region: string;
  experience?: string;
  portrait: string;
  color?: string;
  shortBio: string;
  biography: string;
  story: string;
  gallery: string[];
  heritageIds: string[];
  awards?: string[];
}

interface ArtisanCardProps {
  artisan: ArtisanItem;
  variant?: 'compact' | 'detailed';
}

export default function ArtisanCard({ artisan, variant = 'compact' }: ArtisanCardProps) {
  const accentColor = artisan.color || '#C91F37';

  if (variant === 'compact') {
    return (
      <Link
        to={`/nghe-nhan/${artisan.slug}`}
        className="group bg-white rounded-lg overflow-hidden border border-[#E4E1D9] hover:border-gray-400 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col block"
      >
        {/* Photo Container */}
        <div className="relative aspect-[4/3.5] overflow-hidden bg-gray-100">
          <img
            src={artisan.portrait}
            alt={artisan.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {artisan.experience && (
            <div className="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-xs text-white text-[11px] px-2 py-0.5 rounded font-medium">
              {artisan.experience}
            </div>
          )}
        </div>

        {/* Content Box */}
        <div className="p-4 flex items-center justify-between border-t border-gray-100">
          <div>
            <span className="text-[11px] font-semibold tracking-wider text-gray-500 uppercase block">
              Nghệ nhân
            </span>
            <h4 className="font-heading font-bold text-base text-[#082951] group-hover:text-[#C91F37] transition-colors leading-tight">
              {artisan.name}
            </h4>
            <p className="text-xs text-gray-600 mt-0.5">{artisan.craft}</p>
          </div>

          <div
            className="w-8 h-8 rounded-full flex items-center justify-center transition-transform group-hover:translate-x-1 shrink-0"
            style={{ backgroundColor: `${accentColor}15`, color: accentColor }}
          >
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </Link>
    );
  }

  // Detailed Card for ArtisanListPage
  return (
    <div className="bg-white rounded-xl overflow-hidden border border-[#E4E1D9] hover:border-[#C91F37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group">
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
        <img
          src={artisan.portrait}
          alt={artisan.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div
          className="absolute top-3 right-3 text-xs font-bold px-2.5 py-1 rounded text-white shadow-xs"
          style={{ backgroundColor: accentColor }}
        >
          {artisan.province}
        </div>
        {artisan.experience && (
          <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-xs text-white text-xs px-2.5 py-1 rounded font-medium">
            {artisan.experience}
          </div>
        )}
      </div>

      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#C91F37]" />
            <span>{artisan.region} • {artisan.province}</span>
          </div>

          <Link to={`/nghe-nhan/${artisan.slug}`}>
            <h3 className="font-heading font-bold text-lg text-[#082951] group-hover:text-[#C91F37] transition-colors">
              {artisan.name}
            </h3>
          </Link>

          <span className="inline-block text-xs font-semibold text-gray-700 bg-[#F7F4EA] px-2 py-0.5 rounded mt-1 mb-2">
            {artisan.craft}
          </span>

          <p className="text-xs sm:text-sm text-gray-600 line-clamp-3 leading-relaxed">
            {artisan.shortBio}
          </p>
        </div>

        <div className="pt-4 mt-4 border-t border-gray-100 flex items-center justify-between">
          <span className="text-xs text-gray-400 font-medium">
            {artisan.awards ? `${artisan.awards.length} danh hiệu` : 'Nghệ nhân tiêu biểu'}
          </span>
          <Link
            to={`/nghe-nhan/${artisan.slug}`}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] group-hover:translate-x-0.5 transition-all uppercase tracking-wider"
          >
            <span>Xem hồ sơ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
