import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, ArrowRight, Calendar } from 'lucide-react';

export interface EventItem {
  id: string;
  slug: string;
  title: string;
  eventType: string;
  day: string;
  month: string;
  startDate: string;
  endDate: string;
  location: string;
  venue?: string;
  coverImage: string;
  description: string;
  schedule?: { time: string; activity: string }[];
  gallery?: string[];
  registrationEnabled?: boolean;
  fee?: string;
  speaker?: string;
  seatsAvailable?: number;
}

interface EventCardProps {
  event: EventItem;
  variant?: 'banner' | 'catalog';
}

export default function EventCard({ event, variant = 'banner' }: EventCardProps) {
  if (variant === 'banner') {
    return (
      <Link
        to={`/su-kien/${event.slug}`}
        className="group bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col block text-left"
      >
        {/* Cover Photo */}
        <div className="relative h-44 overflow-hidden bg-gray-100">
          <img
            src={event.coverImage}
            alt={event.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded shadow-md text-center border border-gray-100">
            <span className="block font-heading font-black text-xl text-[#C91F37] leading-none">
              {event.day}
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500">
              THÁNG {event.month}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 flex-1 flex flex-col justify-between bg-white">
          <div>
            <h4 className="font-heading font-bold text-base text-[#082951] group-hover:text-[#C91F37] transition-colors leading-snug line-clamp-2">
              {event.title}
            </h4>
          </div>

          <div className="pt-3 mt-3 border-t border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-gray-600">
              <MapPin className="w-3.5 h-3.5 text-[#C91F37] shrink-0" />
              <span className="font-medium">{event.location}</span>
            </div>

            <div className="w-7 h-7 rounded-full bg-gray-100 group-hover:bg-[#C91F37] text-gray-500 group-hover:text-white flex items-center justify-center transition-colors">
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </Link>
    );
  }

  // Catalog variant for EventListPage
  return (
    <div className="bg-white rounded-xl overflow-hidden border border-[#E4E1D9] hover:border-[#C91F37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group">
      <div className="relative h-52 overflow-hidden bg-gray-100">
        <img
          src={event.coverImage}
          alt={event.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 bg-[#082951] text-white text-xs font-bold px-2.5 py-1 rounded">
          {event.eventType}
        </div>
        <div className="absolute top-3 right-3 bg-white/95 text-center px-3 py-1 rounded shadow-md border border-gray-200">
          <div className="font-heading font-black text-lg text-[#C91F37] leading-tight">
            {event.day}
          </div>
          <div className="text-[10px] uppercase font-bold text-gray-600">
            Tháng {event.month}
          </div>
        </div>
      </div>

      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-2">
            <MapPin className="w-3.5 h-3.5 text-[#C91F37]" />
            <span>{event.location}</span>
          </div>

          <Link to={`/su-kien/${event.slug}`}>
            <h3 className="font-heading font-bold text-lg text-[#082951] group-hover:text-[#C91F37] transition-colors line-clamp-2">
              {event.title}
            </h3>
          </Link>

          <p className="text-xs sm:text-sm text-gray-600 mt-2 line-clamp-2 leading-relaxed">
            {event.description}
          </p>
        </div>

        <div className="pt-4 mt-4 border-t border-gray-100 flex items-center justify-between">
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
            {event.fee || 'Mở cửa tự do'}
          </span>
          <Link
            to={`/su-kien/${event.slug}`}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] group-hover:translate-x-0.5 transition-all uppercase tracking-wider"
          >
            <span>Chi tiết & Đăng ký</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
