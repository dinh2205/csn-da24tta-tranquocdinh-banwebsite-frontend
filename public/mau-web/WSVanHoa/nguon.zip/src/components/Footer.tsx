import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Mail, Phone, Heart, Facebook, Youtube, Instagram, X } from 'lucide-react';

export default function Footer() {
  const [modalContent, setModalContent] = useState<{ title: string; text: string } | null>(null);

  const openSupportModal = (type: 'faq' | 'terms' | 'privacy') => {
    if (type === 'faq') {
      setModalContent({
        title: 'Câu hỏi thường gặp (FAQ)',
        text: '1. Làm thế nào để đăng ký gian hàng hoặc giới thiệu nghệ nhân? Bạn có thể gửi thông tin qua biểu mẫu tại trang Liên hệ.\n\n2. Dữ liệu trên website có nguồn gốc từ đâu? Các thông tin về kỹ thuật, lịch sử làng nghề được tham khảo từ tư liệu nghiên cứu văn hóa dân gian Việt Nam và lời chia sẻ của các nghệ nhân.\n\n3. Tham gia các sự kiện văn hóa có mất phí không? Phần lớn các triển lãm mở cửa tự do; một số workshop chuyên sâu sẽ có phụ phí nguyên vật liệu được ghi rõ tại trang chi tiết sự kiện.'
      });
    } else if (type === 'terms') {
      setModalContent({
        title: 'Điều khoản sử dụng',
        text: 'Website Tinh Hoa Nghệ Nhân Việt phục vụ mục đích phi lợi nhuận, quảng bá và bảo tồn giá trị văn hóa truyền thống Việt Nam. Nghiêm cấm sao chép, sử dụng hình ảnh nghệ nhân cho các mục đích thương mại vi phạm quyền tác giả hoặc xuyên tạc giá trị di sản.'
      });
    } else if (type === 'privacy') {
      setModalContent({
        title: 'Chính sách bảo mật',
        text: 'Chúng tôi tôn trọng quyền riêng tư của quý khách. Mọi thông tin đăng ký tham gia sự kiện và tin nhắn liên hệ được lưu trữ an toàn trong trình duyệt (LocalStorage demo) và không chia sẻ cho bất kỳ bên thứ ba nào khi chưa có sự đồng thuận.'
      });
    }
  };

  return (
    <footer className="bg-[#061B37] text-white border-t border-white/10 relative overflow-hidden">
      {/* Decorative Traditional Pagoda / Temple Watermark Silhouette */}
      <div className="absolute right-0 bottom-0 pointer-events-none opacity-10 hidden md:block">
        <svg width="420" height="320" viewBox="0 0 400 300" fill="none" stroke="currentColor" strokeWidth="1.5">
          {/* Traditional Pagoda Roof Lines (Khuê Văn Các / Chùa Một Cột) */}
          <path d="M200 40 L200 70 M160 70 L240 70 M130 90 L270 90 M100 110 C150 100, 250 100, 300 110 M80 120 C140 105, 260 105, 320 120" />
          <path d="M120 120 L120 180 M280 120 L280 180 M150 120 L150 180 M250 120 L250 180" />
          <path d="M60 180 C130 160, 270 160, 340 180 M40 195 C120 170, 280 170, 360 195" />
          <path d="M100 195 L100 280 M300 195 L300 280 M170 195 L170 280 M230 195 L230 280" />
          <path d="M20 280 L380 280" />
          <circle cx="200" cy="150" r="16" />
        </svg>
      </div>

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 mb-12">
          {/* Brand Column (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-[#F3B33F]">
                <svg viewBox="0 0 48 48" fill="none" className="w-9 h-9 stroke-current" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M24 6 C24 16, 14 26, 8 26 C16 26, 24 38, 24 42 C24 38, 32 26, 40 26 C34 26, 24 16, 24 6 Z" fill="rgba(243, 179, 63, 0.2)" />
                  <path d="M24 14 C24 22, 17 28, 12 28 C18 28, 24 36, 24 40 C24 36, 30 28, 36 28 C31 28, 24 22, 24 14 Z" fill="#F3B33F" />
                  <circle cx="24" cy="28" r="3" fill="#C91F37" />
                </svg>
              </div>
              <div className="flex flex-col">
                <span className="font-heading font-black text-base tracking-wider uppercase text-white leading-tight">
                  Tinh Hoa Nghệ Nhân Việt
                </span>
                <span className="text-xs text-yellow-500 font-medium tracking-wide">
                  Di sản thủ công truyền thống
                </span>
              </div>
            </Link>

            <p className="text-sm text-gray-300 leading-relaxed max-w-sm">
              Nền tảng kết nối, quảng bá và đồng hành cùng nghệ nhân, làng nghề Việt Nam. Gìn giữ bản sắc - Lan tỏa giá trị văn hóa dân tộc ra thế giới.
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#C91F37] flex items-center justify-center text-gray-300 hover:text-white transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#C91F37] flex items-center justify-center text-gray-300 hover:text-white transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#C91F37] flex items-center justify-center text-gray-300 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <div className="w-9 h-9 rounded-full bg-white/10 hover:bg-[#C91F37] flex items-center justify-center text-gray-300 hover:text-white transition-colors font-bold text-xs cursor-pointer">
                TT
              </div>
            </div>
          </div>

          {/* Quick Links (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-heading font-bold text-sm tracking-wider uppercase text-white border-b border-white/10 pb-2">
              Liên kết nhanh
            </h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <Link to="/" className="hover:text-yellow-400 transition-colors">
                  Trang chủ
                </Link>
              </li>
              <li>
                <Link to="/gioi-thieu" className="hover:text-yellow-400 transition-colors">
                  Về chúng tôi
                </Link>
              </li>
              <li>
                <Link to="/nghe-nhan" className="hover:text-yellow-400 transition-colors">
                  Nghệ nhân
                </Link>
              </li>
              <li>
                <Link to="/di-san" className="hover:text-yellow-400 transition-colors">
                  Di sản
                </Link>
              </li>
              <li>
                <Link to="/su-kien" className="hover:text-yellow-400 transition-colors">
                  Sự kiện
                </Link>
              </li>
              <li>
                <Link to="/tin-tuc" className="hover:text-yellow-400 transition-colors">
                  Tin tức
                </Link>
              </li>
              <li>
                <Link to="/ban-do-lang-nghe" className="hover:text-yellow-400 transition-colors">
                  Bản đồ làng nghề
                </Link>
              </li>
              <li>
                <Link to="/lien-he" className="hover:text-yellow-400 transition-colors">
                  Liên hệ
                </Link>
              </li>
            </ul>
          </div>

          {/* Support Links (2 cols) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-heading font-bold text-sm tracking-wider uppercase text-white border-b border-white/10 pb-2">
              Hỗ trợ
            </h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <button
                  onClick={() => openSupportModal('faq')}
                  className="hover:text-yellow-400 text-left transition-colors"
                >
                  Câu hỏi thường gặp
                </button>
              </li>
              <li>
                <button
                  onClick={() => openSupportModal('terms')}
                  className="hover:text-yellow-400 text-left transition-colors"
                >
                  Điều khoản sử dụng
                </button>
              </li>
              <li>
                <button
                  onClick={() => openSupportModal('privacy')}
                  className="hover:text-yellow-400 text-left transition-colors"
                >
                  Chính sách bảo mật
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-heading font-bold text-sm tracking-wider uppercase text-white border-b border-white/10 pb-2">
              Liên hệ
            </h4>
            <ul className="space-y-3 text-sm text-gray-300">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#C91F37] shrink-0 mt-1" />
                <span>123 Đường Văn Hóa, Quận 1, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#C91F37] shrink-0" />
                <a href="mailto:contact@nghenhanviet.vn" className="hover:text-white transition-colors">
                  contact@nghenhanviet.vn
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#C91F37] shrink-0" />
                <a href="tel:02812345678" className="hover:text-white transition-colors">
                  (028) 1234 5678
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 gap-3">
          <p>© 2026 Tinh Hoa Nghệ Nhân Việt. Tất cả quyền được bảo lưu.</p>
          <p className="flex items-center gap-1.5 text-gray-300">
            <span>Gìn giữ bản sắc Việt - Kết nối cộng đồng</span>
            <Heart className="w-3.5 h-3.5 text-[#C91F37] fill-[#C91F37]" />
          </p>
        </div>
      </div>

      {/* Support Info Modal */}
      {modalContent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#082951] text-white p-6 rounded-xl border border-white/20 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/15 pb-3">
              <h3 className="font-heading font-bold text-lg text-yellow-400">
                {modalContent.title}
              </h3>
              <button
                onClick={() => setModalContent(null)}
                className="p-1 text-gray-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-sm text-gray-200 leading-relaxed whitespace-pre-line">
              {modalContent.text}
            </div>
            <div className="pt-2 text-right">
              <button
                onClick={() => setModalContent(null)}
                className="px-4 py-1.5 bg-[#C91F37] hover:bg-[#A71B32] text-white rounded text-xs font-semibold"
              >
                Đã hiểu
              </button>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}
