import React, { useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { Search, Globe, Menu, X, ArrowRight, ChevronDown } from 'lucide-react';
import SearchModal from './SearchModal';

export default function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [lang, setLang] = useState<'vi' | 'en'>('vi');
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const navLinks = [
    { label: 'Trang chủ', path: '/' },
    { label: 'Về chúng tôi', path: '/gioi-thieu' },
    { label: 'Nghệ nhân', path: '/nghe-nhan' },
    { label: 'Di sản', path: '/di-san' },
    { label: 'Sự kiện', path: '/su-kien' },
    { label: 'Tin tức', path: '/tin-tuc' },
    { label: 'Bản đồ làng nghề', path: '/ban-do-lang-nghe' },
    { label: 'Liên hệ', path: '/lien-he' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#082951] text-white shadow-md border-b border-[#164B7B]/50 transition-all">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 h-[76px] flex items-center justify-between gap-4">
          {/* Logo & Brand Identity */}
          <Link to="/" className="flex items-center gap-3 shrink-0 group">
            {/* Stylized Lotus Brand Icon */}
            <div className="w-10 h-10 rounded-lg flex items-center justify-center text-[#F3B33F] transition-transform group-hover:scale-105">
              <svg viewBox="0 0 48 48" fill="none" className="w-9 h-9 stroke-current" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                {/* Cultural Lotus Flower Pattern */}
                <path d="M24 6 C24 16, 14 26, 8 26 C16 26, 24 38, 24 42 C24 38, 32 26, 40 26 C34 26, 24 16, 24 6 Z" fill="rgba(243, 179, 63, 0.2)" />
                <path d="M24 14 C24 22, 17 28, 12 28 C18 28, 24 36, 24 40 C24 36, 30 28, 36 28 C31 28, 24 22, 24 14 Z" fill="#F3B33F" />
                <circle cx="24" cy="28" r="3" fill="#C91F37" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="font-heading font-black text-sm sm:text-base tracking-wider uppercase text-white leading-tight">
                Tinh Hoa
              </span>
              <span className="font-heading font-semibold text-xs tracking-wider uppercase text-gray-300 leading-tight">
                Nghệ Nhân Việt
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-3 text-sm font-medium">
            {navLinks.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `px-3 py-2 rounded-sm transition-colors relative whitespace-nowrap ${
                    isActive
                      ? 'text-white font-semibold'
                      : 'text-gray-200 hover:text-white hover:bg-white/5'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <span>{item.label}</span>
                    {isActive && (
                      <span className="absolute bottom-0 left-3 right-3 h-[2.5px] bg-[#C91F37] rounded-full" />
                    )}
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Action Elements: Search, Lang, CTA */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Search Trigger */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-2 text-gray-200 hover:text-white hover:bg-white/10 rounded-full transition-colors"
              title="Tìm kiếm"
              aria-label="Tìm kiếm nội dung"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold uppercase tracking-wider text-gray-200 hover:text-white hover:bg-white/10 rounded transition-colors"
              >
                <span>{lang.toUpperCase()}</span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>

              {isLangDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-36 bg-[#061B37] text-white rounded-lg shadow-xl border border-white/10 py-1 z-50 text-xs"
                  onClick={() => setIsLangDropdownOpen(false)}
                >
                  <button
                    onClick={() => setLang('vi')}
                    className={`w-full text-left px-3 py-2 hover:bg-white/10 flex items-center justify-between ${
                      lang === 'vi' ? 'text-yellow-400 font-bold' : 'text-gray-300'
                    }`}
                  >
                    <span>Tiếng Việt</span>
                    {lang === 'vi' && <span>✓</span>}
                  </button>
                  <button
                    onClick={() => {
                      setLang('en');
                      alert('Phiên bản tiếng Anh đang trong lộ trình số hóa dữ liệu song ngữ.');
                    }}
                    className={`w-full text-left px-3 py-2 hover:bg-white/10 flex items-center justify-between ${
                      lang === 'en' ? 'text-yellow-400 font-bold' : 'text-gray-300'
                    }`}
                  >
                    <span>English</span>
                    {lang === 'en' && <span>✓</span>}
                  </button>
                </div>
              )}
            </div>

            {/* Primary Action Button */}
            <Link
              to="/di-san"
              className="hidden sm:inline-flex items-center gap-2 bg-[#C91F37] hover:bg-[#A71B32] text-white px-4 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg active:scale-95"
            >
              <span>Khám phá ngay</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-200 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-[#061B37] border-t border-white/10 px-4 pt-3 pb-6 space-y-2 animate-fadeIn">
            {navLinks.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={({ isActive }) =>
                  `block px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#C91F37] text-white font-bold'
                      : 'text-gray-200 hover:bg-white/5 hover:text-white'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}

            <div className="pt-3 border-t border-white/10">
              <Link
                to="/di-san"
                onClick={() => setIsMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 bg-[#C91F37] hover:bg-[#A71B32] text-white py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all"
              >
                <span>Khám phá ngay di sản</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Global Search Modal */}
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
}
