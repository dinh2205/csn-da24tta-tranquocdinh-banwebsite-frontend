import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MapPin } from 'lucide-react';

export interface HeritageItem {
  id: string;
  slug: string;
  name: string;
  craftType: string;
  region: string;
  province: string;
  village: string;
  color?: string;
  number?: string;
  coverImage: string;
  gallery: string[];
  description: string;
  history: string;
  techniques: string[];
  artisanIds: string[];
}

interface HeritageCardProps {
  heritage: HeritageItem;
  variant?: 'grid-editorial' | 'catalog';
}

export default function HeritageCard({ heritage, variant = 'catalog' }: HeritageCardProps) {
  if (variant === 'grid-editorial') {
    return (
      <Link
        to={`/di-san/${heritage.slug}`}
        className="group relative h-[320px] sm:h-[350px] overflow-hidden flex flex-col justify-between p-6 transition-transform duration-300 hover:-translate-y-1 block shadow-md"
        style={{ backgroundColor: heritage.color || '#082951' }}
      >
        {/* Background Image with Soft Cultural Color Accent & Legibility Gradient */}
        <div className="absolute inset-0 z-0">
          <img
            src={heritage.coverImage}
            alt={heritage.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-85"
          />
          {/* Subtle color wash matching brand hue */}
          <div
            className="absolute inset-0 opacity-40 mix-blend-multiply transition-opacity duration-300 group-hover:opacity-30"
            style={{ backgroundColor: heritage.color || '#082951' }}
          />
          {/* Dark gradient towards bottom for text legibility */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        </div>

        {/* Top: Large Decorative Number */}
        <div className="relative z-10 flex items-start justify-between">
          <span className="font-heading font-black text-4xl sm:text-5xl text-white/90 tracking-tighter">
            {heritage.number || '01'}
          </span>
          <span className="text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-black/30 text-white backdrop-blur-xs">
            {heritage.region}
          </span>
        </div>

        {/* Bottom Content */}
        <div className="relative z-10">
          <p className="text-xs font-semibold uppercase tracking-wider text-white/80 mb-1">
            {heritage.craftType}
          </p>
          <h3 className="font-heading font-bold text-lg sm:text-xl text-white uppercase leading-snug group-hover:text-yellow-300 transition-colors">
            {heritage.name}
          </h3>
          <div className="flex items-center gap-2 mt-4 text-white text-xs font-bold uppercase tracking-wider group-hover:translate-x-1 transition-transform">
            <span>Chi tiết</span>
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </Link>
    );
  }

  // Catalog variant for HeritageListPage
  return (
    <div className="bg-white rounded-lg overflow-hidden border border-[#E4E1D9] hover:border-[#C91F37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group">
      <Link to={`/di-san/${heritage.slug}`} className="relative h-56 overflow-hidden block">
        <img
          src={heritage.coverImage}
          alt={heritage.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 bg-[#082951]/90 backdrop-blur-xs text-white text-xs font-bold px-2.5 py-1 rounded">
          {heritage.craftType}
        </div>
        <div className="absolute top-3 right-3 text-xs font-bold px-2.5 py-1 rounded text-white" style={{ backgroundColor: heritage.color || '#C91F37' }}>
          {heritage.region}
        </div>
      </Link>

      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-2">
            <MapPin className="w-3.5 h-3.5 text-[#C91F37]" />
            <span>{heritage.province}</span>
          </div>

          <Link to={`/di-san/${heritage.slug}`}>
            <h3 className="font-heading font-bold text-lg text-[#082951] group-hover:text-[#C91F37] transition-colors line-clamp-1">
              {heritage.name}
            </h3>
          </Link>

          <p className="text-xs sm:text-sm text-gray-600 mt-2 line-clamp-2 leading-relaxed">
            {heritage.description}
          </p>
        </div>

        <div className="pt-4 mt-4 border-t border-gray-100 flex items-center justify-between">
          <span className="text-xs text-gray-400 font-medium">
            {heritage.village.split(',')[0]}
          </span>
          <Link
            to={`/di-san/${heritage.slug}`}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] group-hover:translate-x-0.5 transition-all uppercase tracking-wider"
          >
            <span>Xem chi tiết</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
