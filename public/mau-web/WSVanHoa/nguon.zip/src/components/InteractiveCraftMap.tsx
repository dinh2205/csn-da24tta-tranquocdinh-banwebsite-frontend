import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, ArrowRight, Sparkles, Compass } from 'lucide-react';
import villagesData from '../data/craftVillages.json';

interface InteractiveCraftMapProps {
  selectedRegion?: string;
  onSelectRegion?: (region: string) => void;
  compact?: boolean;
}

export default function InteractiveCraftMap({
  selectedRegion = 'Tất cả',
  onSelectRegion,
  compact = false,
}: InteractiveCraftMapProps) {
  const [activeVillageId, setActiveVillageId] = useState<string>('bat-trang');
  const [internalRegion, setInternalRegion] = useState<string>(selectedRegion);

  const currentRegion = onSelectRegion ? selectedRegion : internalRegion;

  const handleRegionChange = (reg: string) => {
    if (onSelectRegion) {
      onSelectRegion(reg);
    } else {
      setInternalRegion(reg);
    }
  };

  const filteredVillages = villagesData.filter(
    (v) => currentRegion === 'Tất cả' || v.region === currentRegion
  );

  const activeVillage = villagesData.find((v) => v.id === activeVillageId) || villagesData[0];

  const regions = [
    { name: 'Tất cả', color: '#082951' },
    { name: 'Miền Bắc', color: '#C91F37' },
    { name: 'Miền Trung', color: '#D36E24' },
    { name: 'Tây Nguyên', color: '#582080' },
    { name: 'Miền Nam', color: '#007F80' },
  ];

  return (
    <div className={`grid grid-cols-1 ${compact ? 'lg:grid-cols-12' : 'lg:grid-cols-12'} gap-8 items-center`}>
      {/* SVG Map Canvas (5 or 6 cols) */}
      <div className={`${compact ? 'lg:col-span-5' : 'lg:col-span-6'} flex flex-col items-center justify-center relative bg-white/70 p-4 sm:p-6 rounded-2xl border border-[#E4E1D9] shadow-sm`}>
        {/* Compass / Watermark */}
        <div className="absolute top-4 left-4 flex items-center gap-1.5 text-xs font-semibold text-gray-500">
          <Compass className="w-4 h-4 text-[#C91F37]" />
          <span>Bản đồ làng nghề thủ công</span>
        </div>

        {/* Vietnam S-Shape SVG Map */}
        <div className="relative w-full max-w-[340px] aspect-[1/2] my-4 select-none">
          <svg
            viewBox="0 0 100 200"
            className="w-full h-full filter drop-shadow-md"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Stylized Vietnam S-Shape Mainland Path */}
            <path
              d="M 68.1 35.4 L 66.4 35.5 L 64.5 36.9 L 62.1 37.8 L 61.6 40.3 L 59.6 41.5 L 58.6 41.0 L 56.6 41.5 L 54.5 40.9 L 55.2 43.9 L 53.1 46.2 L 53.3 47.6 L 52.7 48.8 L 49.0 52.0 L 47.9 52.1 L 47.1 52.6 L 45.3 56.5 L 45.0 59.7 L 44.2 61.5 L 43.4 62.3 L 43.2 63.3 L 46.1 68.4 L 47.9 70.5 L 49.8 71.5 L 52.5 74.5 L 52.1 75.3 L 52.3 77.0 L 51.2 76.7 L 52.7 77.7 L 55.0 80.9 L 59.1 84.3 L 59.7 86.1 L 63.6 88.9 L 63.5 89.3 L 66.3 91.5 L 66.6 92.4 L 68.7 92.3 L 70.6 94.9 L 71.2 95.0 L 71.4 96.1 L 74.5 100.5 L 77.1 102.8 L 78.3 106.9 L 79.9 110.1 L 79.9 111.9 L 82.2 119.5 L 82.0 120.5 L 81.6 119.5 L 81.8 125.9 L 83.4 129.4 L 83.7 133.4 L 82.5 131.7 L 81.3 132.8 L 82.2 135.6 L 81.1 135.4 L 81.2 139.1 L 81.7 140.5 L 81.6 141.0 L 81.1 140.0 L 80.6 141.7 L 81.1 143.0 L 80.4 144.3 L 79.4 144.4 L 78.8 147.2 L 77.1 147.5 L 75.8 148.8 L 74.2 149.2 L 71.3 151.7 L 69.4 152.1 L 68.4 154.0 L 66.7 154.2 L 60.6 157.6 L 59.9 156.8 L 58.7 156.5 L 57.9 154.7 L 57.3 157.5 L 56.8 157.7 L 55.8 157.2 L 54.9 156.1 L 53.6 156.8 L 55.1 157.1 L 55.5 157.8 L 55.2 158.7 L 52.1 158.7 L 54.9 159.8 L 55.5 160.7 L 54.2 162.0 L 54.2 163.0 L 53.5 163.5 L 52.0 162.6 L 48.7 159.5 L 52.6 163.9 L 53.3 165.9 L 52.4 166.8 L 51.2 166.8 L 49.4 165.5 L 46.5 162.4 L 45.5 161.9 L 48.9 166.4 L 49.4 167.4 L 49.0 168.6 L 42.0 171.9 L 40.1 175.1 L 37.9 177.0 L 35.5 177.5 L 34.2 177.4 L 35.6 175.7 L 34.7 175.1 L 35.0 166.3 L 35.6 164.0 L 37.6 163.0 L 37.7 162.6 L 37.0 161.2 L 35.3 160.7 L 34.6 159.7 L 33.1 160.1 L 30.6 157.4 L 32.1 156.3 L 35.1 156.1 L 37.2 154.2 L 37.1 151.9 L 40.0 152.7 L 41.0 151.5 L 44.6 151.1 L 45.7 152.5 L 46.6 152.2 L 49.0 153.2 L 48.6 151.8 L 48.9 150.5 L 45.7 147.7 L 45.7 144.0 L 46.5 143.8 L 47.3 142.6 L 51.5 143.4 L 51.6 140.5 L 54.6 140.2 L 55.3 139.4 L 57.1 139.1 L 60.1 136.6 L 61.3 136.4 L 62.0 137.1 L 63.2 135.9 L 63.7 134.0 L 62.8 128.6 L 64.2 124.1 L 61.3 116.6 L 61.7 113.9 L 62.6 113.0 L 63.5 110.8 L 63.4 108.4 L 62.9 107.2 L 64.7 104.1 L 63.8 102.6 L 60.8 100.1 L 59.6 98.1 L 62.0 96.5 L 62.0 95.5 L 57.1 92.1 L 56.2 90.3 L 55.1 91.0 L 54.2 90.5 L 53.0 88.8 L 52.5 85.5 L 51.7 84.9 L 50.1 82.6 L 47.3 80.4 L 44.0 76.8 L 42.9 74.1 L 41.5 72.3 L 40.2 71.9 L 37.9 69.5 L 37.6 68.5 L 38.2 66.8 L 33.7 65.1 L 24.9 59.6 L 26.8 57.6 L 26.4 55.5 L 28.8 55.4 L 32.3 56.1 L 33.9 54.6 L 34.7 53.0 L 35.9 51.8 L 35.9 51.0 L 35.1 49.7 L 33.5 49.7 L 32.6 47.8 L 30.0 47.1 L 31.7 45.8 L 32.3 44.8 L 29.8 42.9 L 27.2 41.5 L 24.8 42.5 L 23.1 44.1 L 22.2 44.3 L 16.6 42.1 L 13.9 38.0 L 15.0 34.7 L 15.0 33.5 L 13.9 32.9 L 13.6 32.1 L 12.8 33.5 L 11.9 33.5 L 11.1 31.0 L 10.1 30.4 L 6.3 25.8 L 9.9 21.7 L 13.7 23.5 L 15.3 25.0 L 17.0 24.0 L 17.0 23.4 L 19.0 21.5 L 20.7 23.5 L 22.1 21.3 L 25.5 24.0 L 26.7 21.7 L 27.6 21.1 L 28.3 21.0 L 29.2 22.1 L 30.0 22.2 L 31.7 21.1 L 33.4 20.9 L 34.5 19.9 L 34.8 17.8 L 35.2 17.4 L 39.6 15.2 L 41.3 16.4 L 42.5 18.2 L 44.0 18.6 L 45.6 19.8 L 46.8 19.6 L 47.2 19.2 L 48.8 19.3 L 50.2 20.5 L 53.0 20.0 L 55.5 21.4 L 54.7 22.9 L 53.4 23.6 L 53.1 24.4 L 53.1 26.2 L 54.2 27.3 L 54.3 30.2 L 55.0 29.9 L 57.5 30.8 L 58.5 32.2 L 59.7 33.1 L 60.7 33.1 L 61.5 34.3 L 62.4 33.9 L 62.8 34.4 L 64.6 34.2 L 65.8 33.7 Z M 26.8 157.7 L 26.9 159.5 L 26.3 161.6 L 25.6 159.3 L 24.5 157.9 L 25.9 157.3 Z M 58.1 43.7 L 57.7 43.8 L 56.9 42.9 L 57.3 42.4 L 58.5 43.0 Z M 59.6 157.6 L 58.7 158.2 L 58.6 157.7 L 59.7 157.0 Z M 64.2 38.6 L 62.7 39.9 L 62.1 39.9 L 62.8 38.0 Z M 53.8 176.4 L 53.2 176.2 L 54.2 175.5 Z M 56.4 43.0 L 55.4 42.4 L 55.6 41.7 Z M 63.3 41.8 L 62.0 42.0 L 63.6 40.6 Z"
              fill="#F7F4EA"
              stroke="#D1CEBF"
              strokeWidth="1.5"
            />

            {/* Hoang Sa & Truong Sa Archipelago badges */}
            <g className="text-[4px] fill-gray-500">
              {/* Hoang Sa */}
              <circle cx="88" cy="88" r="1.5" fill="#C91F37" />
              <circle cx="91" cy="92" r="1.2" fill="#C91F37" />
              <text x="99" y="83" textAnchor="end" fontSize="3.5" fontWeight="bold" fill="#082951">
                Q.Đ Hoàng Sa
              </text>
              {/* Truong Sa */}
              <circle cx="89" cy="152" r="1.5" fill="#007F80" />
              <circle cx="92" cy="156" r="1.2" fill="#007F80" />
              <circle cx="87" cy="158" r="1.2" fill="#007F80" />
              <text x="99" y="166" textAnchor="end" fontSize="3.5" fontWeight="bold" fill="#082951">
                Q.Đ Trường Sa
              </text>
            </g>

            {/* Village Pins */}
            {villagesData.map((v) => {
              const isSelected = v.id === activeVillageId;
              const isVisible = currentRegion === 'Tất cả' || v.region === currentRegion;
              if (!isVisible) return null;

              return (
                <g
                  key={v.id}
                  onClick={() => setActiveVillageId(v.id)}
                  className="cursor-pointer transition-all duration-300"
                >
                  {/* Pin Pulse when selected */}
                  {isSelected && (
                    <circle
                      cx={v.x}
                      cy={v.y}
                      r="6"
                      fill={v.color}
                      className="animate-ping opacity-40"
                    />
                  )}
                  {/* Pin Base */}
                  <circle
                    cx={v.x}
                    cy={v.y}
                    r={isSelected ? 4.5 : 3}
                    fill={isSelected ? '#FFFFFF' : v.color}
                    stroke={v.color}
                    strokeWidth={isSelected ? 2.5 : 1}
                  />
                  {/* Inner Dot */}
                  <circle
                    cx={v.x}
                    cy={v.y}
                    r={isSelected ? 2 : 1.2}
                    fill={isSelected ? v.color : '#FFFFFF'}
                  />
                </g>
              );
            })}
          </svg>
        </div>

        <p className="text-xs text-gray-400 text-center">
          * Nhấn vào điểm đánh dấu trên bản đồ để xem làng nghề tương ứng
        </p>
      </div>

      {/* Village Details & Region Selector (7 or 6 cols) */}
      <div className={`${compact ? 'lg:col-span-7' : 'lg:col-span-6'} space-y-6`}>
        {/* Region Filter Buttons */}
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-gray-500 block mb-2">
            Chọn vùng miền:
          </span>
          <div className="flex flex-wrap gap-2">
            {regions.map((reg) => (
              <button
                key={reg.name}
                onClick={() => handleRegionChange(reg.name)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                  currentRegion === reg.name
                    ? 'bg-[#082951] text-white shadow-md'
                    : 'bg-white border border-[#E4E1D9] text-gray-700 hover:border-[#C91F37] hover:text-[#C91F37]'
                }`}
              >
                {reg.name}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Village Showcase Card */}
        {activeVillage && (
          <div className="bg-white rounded-xl border border-[#E4E1D9] p-6 shadow-md overflow-hidden relative group">
            <div className="flex flex-col sm:flex-row gap-5 items-start">
              <img
                src={activeVillage.image}
                alt={activeVillage.name}
                className="w-full sm:w-36 h-36 object-cover rounded-lg shadow-xs shrink-0"
              />

              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <span
                    className="text-[11px] font-bold uppercase px-2 py-0.5 rounded text-white"
                    style={{ backgroundColor: activeVillage.color }}
                  >
                    {activeVillage.region}
                  </span>
                  <span className="text-xs text-gray-500 font-medium">
                    {activeVillage.founded}
                  </span>
                </div>

                <h3 className="font-heading font-black text-xl text-[#082951]">
                  {activeVillage.name}
                </h3>

                <p className="text-xs font-semibold text-[#C91F37]">
                  {activeVillage.craft} • {activeVillage.province}
                </p>

                <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                  {activeVillage.description}
                </p>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-xs text-gray-400 font-medium">
                    {activeVillage.artisanCount}
                  </span>
                  <Link
                    to={`/di-san/${activeVillage.heritageSlug}`}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider transition-transform group-hover:translate-x-1"
                  >
                    <span>Khám phá di sản</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* List of Villages in Current Region */}
        <div className="bg-[#F7F4EA] rounded-xl p-4 border border-[#E4E1D9]">
          <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-[#082951] mb-2.5">
            Danh sách làng nghề ({filteredVillages.length}):
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {filteredVillages.map((v) => (
              <button
                key={v.id}
                onClick={() => setActiveVillageId(v.id)}
                className={`text-left p-2 rounded-lg text-xs font-medium transition-all ${
                  v.id === activeVillageId
                    ? 'bg-white shadow-xs border border-[#C91F37] text-[#C91F37] font-bold'
                    : 'bg-white/60 hover:bg-white text-gray-700'
                }`}
              >
                <div className="truncate">{v.name}</div>
                <div className="text-[10px] text-gray-400 truncate">{v.province}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
