import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, Tag } from 'lucide-react';

export interface ArticleItem {
  id: string;
  slug: string;
  title: string;
  category: string;
  author?: string;
  publishedAt: string;
  displayDate: string;
  coverImage: string;
  summary: string;
  content?: { type: string; text?: string; author?: string; url?: string; caption?: string }[];
}

interface NewsCardProps {
  article: ArticleItem;
  variant?: 'compact' | 'featured' | 'standard';
}

export default function NewsCard({ article, variant = 'standard' }: NewsCardProps) {
  if (variant === 'featured') {
    return (
      <div className="bg-white rounded-xl overflow-hidden border border-[#E4E1D9] hover:border-[#C91F37] shadow-md hover:shadow-xl transition-all duration-300 grid grid-cols-1 md:grid-cols-12 group">
        <div className="md:col-span-7 relative h-64 md:h-full overflow-hidden">
          <img
            src={article.coverImage}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute top-4 left-4 bg-[#C91F37] text-white text-xs font-bold px-3 py-1 rounded">
            Tiêu điểm
          </div>
        </div>

        <div className="md:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
              <span className="font-semibold text-[#007F80] bg-teal-50 px-2 py-0.5 rounded">
                {article.category}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {article.displayDate}
              </span>
            </div>

            <Link to={`/tin-tuc/${article.slug}`}>
              <h3 className="font-heading font-black text-xl sm:text-2xl text-[#082951] group-hover:text-[#C91F37] transition-colors leading-tight">
                {article.title}
              </h3>
            </Link>

            <p className="text-sm text-gray-600 mt-3 line-clamp-3 leading-relaxed">
              {article.summary}
            </p>
          </div>

          <div className="pt-6 mt-6 border-t border-gray-100 flex items-center justify-between">
            <span className="text-xs text-gray-500 font-medium">
              Bởi {article.author || 'Tinh Hoa Việt'}
            </span>
            <Link
              to={`/tin-tuc/${article.slug}`}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] group-hover:translate-x-1 transition-transform uppercase tracking-wider"
            >
              <span>Đọc tiếp</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Standard news card (like on HomePage & NewsListPage grid)
  return (
    <div className="bg-white rounded-lg overflow-hidden border border-[#E4E1D9] hover:border-[#C91F37] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group">
      <Link to={`/tin-tuc/${article.slug}`} className="relative h-48 overflow-hidden block">
        <img
          src={article.coverImage}
          alt={article.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 bg-[#082951]/90 backdrop-blur-xs text-white text-[11px] font-semibold px-2 py-0.5 rounded">
          {article.category}
        </div>
      </Link>

      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[11px] font-medium text-gray-400 block mb-1.5">
            {article.displayDate}
          </span>

          <Link to={`/tin-tuc/${article.slug}`}>
            <h4 className="font-heading font-bold text-base text-[#082951] group-hover:text-[#C91F37] transition-colors leading-snug line-clamp-2">
              {article.title}
            </h4>
          </Link>

          {article.summary && (
            <p className="text-xs text-gray-600 mt-2 line-clamp-2 leading-relaxed">
              {article.summary}
            </p>
          )}
        </div>

        <div className="pt-3 mt-3 border-t border-gray-100 flex items-center justify-between">
          <span className="text-[11px] text-gray-400">
            {article.author || 'Ban biên tập'}
          </span>
          <Link
            to={`/tin-tuc/${article.slug}`}
            className="inline-flex items-center gap-1 text-xs font-bold text-[#C91F37] group-hover:translate-x-1 transition-transform uppercase tracking-wider"
          >
            <span>Chi tiết</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
