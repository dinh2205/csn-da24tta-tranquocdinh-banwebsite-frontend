import React from 'react';
import Breadcrumb, { BreadcrumbItem } from './Breadcrumb';

interface PageBannerProps {
  title: string;
  subtitle?: string;
  breadcrumbs: BreadcrumbItem[];
  badge?: string;
  badgeColor?: string;
}

export default function PageBanner({
  title,
  subtitle,
  breadcrumbs,
  badge,
  badgeColor = '#C91F37',
}: PageBannerProps) {
  return (
    <div className="relative bg-[#082951] text-white pt-8 pb-12 sm:pt-10 sm:pb-16 overflow-hidden border-b border-[#164B7B]">
      {/* Geometric Decorative Triangles & Accent Background */}
      <div className="absolute top-0 right-0 w-96 h-full pointer-events-none opacity-20">
        <svg viewBox="0 0 400 300" fill="none" className="w-full h-full">
          <polygon points="150,0 400,0 400,250" fill="#582080" />
          <polygon points="250,50 400,0 400,300" fill="#C91F37" />
          <polygon points="320,100 400,200 300,300" fill="#F3B33F" />
        </svg>
      </div>

      {/* Cultural lattice pattern overlay */}
      <div className="absolute inset-0 bg-cultural-pattern opacity-10 pointer-events-none" />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="mb-4">
          <Breadcrumb items={breadcrumbs} />
        </div>

        <div className="max-w-3xl">
          {badge && (
            <span
              className="inline-block px-3 py-1 rounded text-xs font-bold uppercase tracking-wider text-white mb-3"
              style={{ backgroundColor: badgeColor }}
            >
              {badge}
            </span>
          )}

          <h1 className="font-heading font-black text-2xl sm:text-4xl lg:text-5xl uppercase tracking-tight text-white leading-tight">
            {title}
          </h1>

          {subtitle && (
            <p className="mt-3 text-sm sm:text-base text-gray-300 leading-relaxed max-w-2xl">
              {subtitle}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
