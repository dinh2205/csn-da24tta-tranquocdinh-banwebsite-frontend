import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export default function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-center gap-2 mt-10">
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="w-10 h-10 rounded-lg border border-[#E4E1D9] bg-white flex items-center justify-center text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:border-[#C91F37] hover:text-[#C91F37] transition-colors"
        aria-label="Trang trước"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
        <button
          key={pageNum}
          onClick={() => onPageChange(pageNum)}
          className={`w-10 h-10 rounded-lg font-heading font-bold text-sm transition-colors ${
            pageNum === currentPage
              ? 'bg-[#082951] text-white shadow-md'
              : 'bg-white border border-[#E4E1D9] text-gray-700 hover:border-[#C91F37] hover:text-[#C91F37]'
          }`}
        >
          {pageNum}
        </button>
      ))}

      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="w-10 h-10 rounded-lg border border-[#E4E1D9] bg-white flex items-center justify-center text-gray-700 disabled:opacity-40 disabled:cursor-not-allowed hover:border-[#C91F37] hover:text-[#C91F37] transition-colors"
        aria-label="Trang tiếp"
      >
        <ChevronRight className="w-5 h-5" />
      </button>
    </div>
  );
}
