import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, ChevronRight, User, Landmark, Calendar, Newspaper } from 'lucide-react';
import heritageData from '../data/heritage.json';
import artisanData from '../data/artisans.json';
import eventData from '../data/events.json';
import articleData from '../data/articles.json';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Function to normalize Vietnamese characters for easy search
function normalizeVN(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'd');
}

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  const results = useMemo(() => {
    const query = normalizeVN(searchTerm.trim());
    if (!query) return null;

    const matchedHeritage = heritageData.filter(
      (item) =>
        normalizeVN(item.name).includes(query) ||
        normalizeVN(item.craftType).includes(query) ||
        normalizeVN(item.province).includes(query) ||
        normalizeVN(item.description).includes(query)
    );

    const matchedArtisans = artisanData.filter(
      (item) =>
        normalizeVN(item.name).includes(query) ||
        normalizeVN(item.craft).includes(query) ||
        normalizeVN(item.province).includes(query) ||
        normalizeVN(item.shortBio).includes(query)
    );

    const matchedEvents = eventData.filter(
      (item) =>
        normalizeVN(item.title).includes(query) ||
        normalizeVN(item.location).includes(query) ||
        normalizeVN(item.eventType).includes(query)
    );

    const matchedArticles = articleData.filter(
      (item) =>
        normalizeVN(item.title).includes(query) ||
        normalizeVN(item.category).includes(query) ||
        normalizeVN(item.summary).includes(query)
    );

    return {
      heritage: matchedHeritage,
      artisans: matchedArtisans,
      events: matchedEvents,
      articles: matchedArticles,
      total:
        matchedHeritage.length +
        matchedArtisans.length +
        matchedEvents.length +
        matchedArticles.length,
    };
  }, [searchTerm]);

  if (!isOpen) return null;

  const handleSelect = (url: string) => {
    onClose();
    setSearchTerm('');
    navigate(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-2xl bg-[#FFFCF5] rounded-xl shadow-2xl border border-[#E4E1D9] overflow-hidden flex flex-col max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-[#E4E1D9] bg-white gap-3">
          <Search className="w-5 h-5 text-[#C91F37] shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm kiếm nghệ nhân, di sản, sự kiện, bài viết..."
            autoFocus
            className="flex-1 bg-transparent text-base text-[#161616] placeholder:text-gray-400 focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-xs text-gray-500 hover:text-black px-1.5 py-0.5 rounded bg-gray-100"
            >
              Xóa
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results / Suggestion Body */}
        <div className="p-4 overflow-y-auto space-y-5 flex-1">
          {!searchTerm && (
            <div className="py-6 text-center text-gray-500">
              <p className="text-sm font-medium text-gray-700 mb-2">Gợi ý tìm kiếm phổ biến:</p>
              <div className="flex flex-wrap justify-center gap-2 mt-3">
                {['Gốm Bát Tràng', 'Nón lá Huế', 'Lụa Vạn Phúc', 'Đồng Kỵ', 'Nghệ nhân Nguyễn Văn Hòa', 'Triển lãm'].map(
                  (tag) => (
                    <button
                      key={tag}
                      onClick={() => setSearchTerm(tag)}
                      className="px-3 py-1 bg-white border border-[#E4E1D9] hover:border-[#C91F37] hover:text-[#C91F37] rounded-full text-xs font-medium text-gray-700 transition-colors"
                    >
                      {tag}
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {searchTerm && results && results.total === 0 && (
            <div className="py-10 text-center text-gray-500">
              <p className="text-base font-semibold text-gray-800">Không tìm thấy kết quả phù hợp</p>
              <p className="text-xs text-gray-500 mt-1">
                Thử tìm với từ khóa khác như: gốm, nón, lụa, tranh, mộc...
              </p>
            </div>
          )}

          {results && results.total > 0 && (
            <>
              {/* Heritage Results */}
              {results.heritage.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#BA2636] mb-2 px-1">
                    <Landmark className="w-3.5 h-3.5" />
                    <span>Di sản ({results.heritage.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {results.heritage.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleSelect(`/di-san/${item.slug}`)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-[#F7F4EA] flex items-center justify-between group transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={item.coverImage}
                            alt={item.name}
                            className="w-10 h-10 object-cover rounded shadow-xs"
                          />
                          <div>
                            <div className="font-semibold text-sm text-[#082951] group-hover:text-[#BA2636]">
                              {item.name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {item.craftType} • {item.province}
                            </div>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#BA2636] group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Artisan Results */}
              {results.artisans.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#582080] mb-2 px-1">
                    <User className="w-3.5 h-3.5" />
                    <span>Nghệ nhân ({results.artisans.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {results.artisans.map((artisan) => (
                      <button
                        key={artisan.id}
                        onClick={() => handleSelect(`/nghe-nhan/${artisan.slug}`)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-[#F7F4EA] flex items-center justify-between group transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={artisan.portrait}
                            alt={artisan.name}
                            className="w-10 h-10 object-cover rounded-full shadow-xs"
                          />
                          <div>
                            <div className="font-semibold text-sm text-[#082951] group-hover:text-[#582080]">
                              {artisan.name}
                            </div>
                            <div className="text-xs text-gray-500">
                              {artisan.craft} • {artisan.province}
                            </div>
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#582080] group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Event Results */}
              {results.events.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#C91F37] mb-2 px-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Sự kiện ({results.events.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {results.events.map((event) => (
                      <button
                        key={event.id}
                        onClick={() => handleSelect(`/su-kien/${event.slug}`)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-[#F7F4EA] flex items-center justify-between group transition-colors"
                      >
                        <div>
                          <div className="font-semibold text-sm text-[#082951] group-hover:text-[#C91F37]">
                            {event.title}
                          </div>
                          <div className="text-xs text-gray-500">
                            {event.day}/{event.month} • {event.location}
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#C91F37] group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* News Results */}
              {results.articles.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#007F80] mb-2 px-1">
                    <Newspaper className="w-3.5 h-3.5" />
                    <span>Tin tức ({results.articles.length})</span>
                  </div>
                  <div className="space-y-1.5">
                    {results.articles.map((article) => (
                      <button
                        key={article.id}
                        onClick={() => handleSelect(`/tin-tuc/${article.slug}`)}
                        className="w-full text-left p-2.5 rounded-lg hover:bg-[#F7F4EA] flex items-center justify-between group transition-colors"
                      >
                        <div>
                          <div className="font-semibold text-sm text-[#082951] group-hover:text-[#007F80]">
                            {article.title}
                          </div>
                          <div className="text-xs text-gray-500">
                            {article.category} • {article.displayDate}
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-[#007F80] group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-[#E4E1D9] text-[11px] text-gray-500 flex items-center justify-between">
          <span>Nhấn <kbd className="px-1.5 py-0.5 bg-white border border-gray-300 rounded text-gray-700">ESC</kbd> để đóng</span>
          <span>Hỗ trợ gõ tiếng Việt có hoặc không dấu</span>
        </div>
      </div>
    </div>
  );
}
