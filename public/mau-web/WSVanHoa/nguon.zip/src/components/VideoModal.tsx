import React, { useState } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Sparkles, Award } from 'lucide-react';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export default function VideoModal({ isOpen, onClose, title = "Câu chuyện từ bàn tay nghệ nhân" }: VideoModalProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-4xl bg-[#061B37] text-white rounded-2xl overflow-hidden shadow-2xl border border-white/10 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#082951]">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C91F37] animate-ping" />
            <h3 className="font-heading font-bold text-base sm:text-lg text-white">
              {title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Area */}
        <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden group">
          <img
            src="./assets/images/hero-artisan-weaving.jpg"
            alt="Artisan Story Video Documentary"
            className="w-full h-full object-cover opacity-85"
          />

          {/* Vignette Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/40" />

          {/* Subtitles / Story narrative overlay */}
          <div className="absolute bottom-16 left-6 right-6 text-center">
            <span className="inline-block px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-xs sm:text-sm text-yellow-300 font-medium shadow-lg">
              “Nước men lam Bát Tràng và từng mũi kim thêu nón xứ Huế - linh hồn của trăm năm văn hiến.”
            </span>
          </div>

          {/* Play / Pause Center Overlay Button */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="absolute z-10 w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#C91F37] hover:bg-[#D72E43] text-white flex items-center justify-center shadow-2xl transition-transform hover:scale-110"
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 fill-current" />
            ) : (
              <Play className="w-8 h-8 fill-current ml-1" />
            )}
          </button>

          {/* Video Controls Bar */}
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 to-transparent p-4 flex items-center justify-between text-xs text-gray-300">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="hover:text-white"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <span>02:45 / 06:12</span>
            </div>

            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className="hover:text-white"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <span className="bg-white/20 px-2 py-0.5 rounded text-[10px] uppercase font-bold text-white tracking-widest">
                4K HDR
              </span>
            </div>
          </div>
        </div>

        {/* Video Description footer */}
        <div className="p-6 bg-[#061B37] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-yellow-400 font-semibold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Phim tài liệu di sản văn hóa • Tinh Hoa Nghệ Nhân Việt</span>
            </div>
            <p className="text-sm text-gray-300">
              Ghi lại những khoảnh khắc chân thực, mộc mạc và đầy tự hào tại các xưởng thủ công truyền thống Bắc - Trung - Nam.
            </p>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#C91F37] hover:bg-[#A71B32] text-white text-xs font-semibold uppercase tracking-wider transition-colors shrink-0"
          >
            Đóng xem video
          </button>
        </div>
      </div>
    </div>
  );
}
