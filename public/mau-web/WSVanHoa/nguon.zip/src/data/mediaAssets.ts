import heroArtisanWeaving from '../assets/images/hero_artisan_weaving_1792136561057.jpg';
import batTrangPottery from '../assets/images/bat_trang_pottery_1792136582626.jpg';
import hueConicalHat from '../assets/images/hue_conical_hat_1792136598277.jpg';
import haDongSilk from '../assets/images/ha_dong_silk_1792136615910.jpg';
import dongKyCarving from '../assets/images/dong_ky_carving_1792136631923.jpg';
import dongHoPainting from '../assets/images/dong_ho_painting_1792136649725.jpg';
import phuVinhBamboo from '../assets/images/phu_vinh_bamboo_1792136667832.jpg';
import potteryPaintingStory from '../assets/images/pottery_painting_story_1792136684433.jpg';
import artisanPotterPortrait from '../assets/images/artisan_potter_portrait_1792136703041.jpg';
import artisanNonlaPortrait from '../assets/images/artisan_nonla_portrait_1792136719416.jpg';
import artisanWoodcarverPortrait from '../assets/images/artisan_woodcarver_portrait_1792136736699.jpg';
import artisanWeaverPortrait from '../assets/images/artisan_weaver_portrait_1792136756074.jpg';
import vietnamAncientTemple from '../assets/images/vietnam_ancient_temple_1792136776225.jpg';
import eventExhibitionHall from '../assets/images/event_exhibition_hall_1792136842170.jpg';
import eventLanternFestival from '../assets/images/event_lantern_festival_1792136794827.jpg';
import communityArtisans from '../assets/images/community_artisans_1792136815379.jpg';
import wovenBambooBasket from '../assets/images/woven_bamboo_basket_1792136862332.jpg';

export const MEDIA = {
  hero: {
    artisanWeaving: heroArtisanWeaving,
    templeAccent: vietnamAncientTemple,
    potteryAccent: potteryPaintingStory,
    wovenBasketAccent: wovenBambooBasket,
  },
  crafts: {
    batTrang: batTrangPottery,
    hueConicalHat: hueConicalHat,
    haDongSilk: haDongSilk,
    dongKyCarving: dongKyCarving,
    dongHoPainting: dongHoPainting,
    phuVinhBamboo: phuVinhBamboo,
  },
  story: {
    potteryPainting: potteryPaintingStory,
  },
  artisans: {
    nguyenVanHoa: artisanPotterPortrait,
    tranThiLan: artisanNonlaPortrait,
    leVanTai: artisanWoodcarverPortrait,
    phamThiHuong: artisanWeaverPortrait,
    nguyenDangChe: dongHoPainting,
    nguyenVanTrung: heroArtisanWeaving,
  },
  events: {
    exhibition: eventExhibitionHall,
    workshop: hueConicalHat,
    festival: eventLanternFestival,
    talk: haDongSilk,
  },
  news: {
    traditionalVillage: vietnamAncientTemple,
    lanternFestival: eventLanternFestival,
    bambooCraft: phuVinhBamboo,
    silkWeaving: haDongSilk,
  },
  community: communityArtisans,
  temple: vietnamAncientTemple,
};
