import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Sparkles, HeartHandshake, Globe, Compass, ArrowRight, Award, Users } from 'lucide-react';
import PageBanner from '../components/PageBanner';

export default function AboutPage() {
  const values = [
    {
      icon: <Shield className="w-8 h-8 text-[#C91F37]" />,
      title: "Gìn giữ bản sắc",
      desc: "Lưu trữ và tái hiện nguyên bản tri thức dân gian, kỹ thuật thủ công gia truyền và nguồn gốc văn hóa của các làng nghề truyền thống Việt Nam."
    },
    {
      icon: <Sparkles className="w-8 h-8 text-[#F3B33F]" />,
      title: "Tôn vinh nghệ nhân",
      desc: "Kể câu chuyện về những bàn tay tài hoa, người giữ lửa cho di sản, tri ân những cống hiến bền bỉ của các thế hệ nghệ nhân gạo cội."
    },
    {
      icon: <HeartHandshake className="w-8 h-8 text-[#582080]" />,
      title: "Kết nối thế hệ",
      desc: "Tạo nhịp cầu để người trẻ tiếp cận, học hỏi và chung tay cùng các nghệ nhân phát triển sản phẩm thủ công mang hơi thở thời đại."
    },
    {
      icon: <Globe className="w-8 h-8 text-[#007F80]" />,
      title: "Vươn ra thế giới",
      desc: "Quảng bá hình ảnh mỹ nghệ Việt Nam đến bạn bè quốc tế thông qua các nền tảng số hóa, triển lãm văn hóa và giao lưu văn hóa quốc tế."
    }
  ];

  return (
    <div className="bg-[#FFFCF5] text-[#161616]">
      <PageBanner
        title="Về Tinh Hoa Nghệ Nhân Việt"
        subtitle="Dự án số hóa và bảo tồn di sản thủ công truyền thống, kết nối công chúng với những bậc thầy gìn giữ hồn thiêng dân tộc."
        breadcrumbs={[{ label: 'Về chúng tôi' }]}
        badge="Giới thiệu dự án"
        badgeColor="#C91F37"
      />

      {/* Overview Section */}
      <section className="py-16 sm:py-20 border-b border-[#E4E1D9]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                Sứ mệnh của chúng tôi
              </span>
              <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#082951] leading-tight">
                LƯU TRỮ VÀ LAN TỎA TRI THỨC THỦ CÔNG VIỆT NAM
              </h2>
              <p className="text-base text-gray-700 leading-relaxed">
                Việt Nam tự hào có hơn 5.400 làng nghề và làng có nghề trải dài từ địa đầu Móng Cái đến mũi Cà Mau. Tuy nhiên, trước làn sóng công nghiệp hóa và cơ chế thị trường, nhiều bí quyết nghề cổ truyền đang đứng trước nguy cơ mai một khi các nghệ nhân lớn tuổi qua đời mà không kịp truyền dạy.
              </p>
              <p className="text-base text-gray-700 leading-relaxed">
                <strong>Tinh Hoa Nghệ Nhân Việt</strong> ra đời như một không gian triển lãm số, nơi mọi công dân, du khách và nhà nghiên cứu có thể tra cứu thông tin chính xác về làng nghề, lắng nghe câu chuyện tâm tình của từng nghệ nhân và tìm kiếm cơ hội trải nghiệm thực tế.
              </p>
              <div className="pt-2 flex items-center gap-4">
                <Link
                  to="/di-san"
                  className="bg-[#C91F37] hover:bg-[#A71B32] text-white px-6 py-3 rounded-md text-xs font-bold uppercase tracking-wider transition-colors inline-flex items-center gap-2"
                >
                  <span>Khám phá các di sản</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/lien-he"
                  className="border border-[#082951] text-[#082951] hover:bg-[#082951] hover:text-white px-5 py-3 rounded-md text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Đồng hành cùng dự án
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6 relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
                <img
                  src="./assets/images/event-exhibition-hall.jpg"
                  alt="Không gian triển lãm nghề thủ công truyền thống Hà Nội"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-4 sm:-bottom-8 sm:right-6 bg-[#082951] text-white p-6 rounded-xl shadow-xl max-w-xs border border-white/10">
                <div className="font-heading font-black text-3xl text-yellow-400">100%</div>
                <div className="text-xs text-gray-200 mt-1">
                  Tận tâm vì mục tiêu lưu giữ văn hóa truyền thống phi lợi nhuận.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="py-16 sm:py-20 bg-[#F7F4EA] border-b border-[#E4E1D9]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
              Giá trị cốt lõi
            </span>
            <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#082951] uppercase mt-2">
              4 TRỤ CỘT BẢO TỒN DI SẢN
            </h2>
            <p className="text-sm text-gray-600 mt-3">
              Những định hướng chiến lược giúp dự án duy trì tính khách quan, chân thực và bền vững.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((val, idx) => (
              <div
                key={idx}
                className="bg-white p-8 rounded-xl border border-[#E4E1D9] shadow-sm hover:shadow-lg transition-all"
              >
                <div className="mb-4">{val.icon}</div>
                <h3 className="font-heading font-bold text-lg text-[#082951] mb-2">
                  {val.title}
                </h3>
                <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                  {val.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Banner */}
      <section className="bg-[#BA2636] text-white py-16">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <h2 className="font-heading font-black text-2xl sm:text-4xl uppercase tracking-tight">
            BẠN LÀ NGHỆ NHÂN HOẶC CÓ THÔNG TIN LÀNG NGHỀ CẦN QUẢNG BÁ?
          </h2>
          <p className="text-sm sm:text-base text-white/90 max-w-2xl mx-auto">
            Hãy liên hệ với chúng tôi để cùng đưa hình ảnh làng nghề quê hương bạn đến với cộng đồng người yêu văn hóa khắp trong và ngoài nước.
          </p>
          <div className="pt-4">
            <Link
              to="/lien-he"
              className="inline-flex items-center gap-2 bg-[#F3B33F] hover:bg-yellow-400 text-[#082951] font-heading font-black text-xs uppercase tracking-wider py-3.5 px-8 rounded shadow-lg transition-transform hover:scale-105"
            >
              <span>Gửi thông tin đề xuất</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
