import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  MapPin,
  Award,
  Clock,
  Sparkles,
  ArrowRight,
  ZoomIn,
  BookOpen,
  Landmark,
  Share2,
  CheckCircle2,
} from 'lucide-react';
import artisanData from '../data/artisans.json';
import heritageData from '../data/heritage.json';
import PageBanner from '../components/PageBanner';
import HeritageCard from '../components/HeritageCard';
import ArtisanCard from '../components/ArtisanCard';
import ImageLightbox from '../components/ImageLightbox';

export default function ArtisanDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const artisan = artisanData.find((a) => a.slug === slug);

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [copiedShare, setCopiedShare] = useState(false);

  if (!artisan) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <h2 className="font-heading font-black text-3xl text-[#082951] mb-2">
          Không tìm thấy hồ sơ nghệ nhân
        </h2>
        <p className="text-gray-600 mb-6">
          Hồ sơ nghệ nhân bạn đang tìm kiếm không tồn tại hoặc đã được chuyển vị trí.
        </p>
        <Link
          to="/nghe-nhan"
          className="bg-[#C91F37] text-white px-6 py-2.5 rounded-md font-bold text-xs uppercase tracking-wider"
        >
          Quay lại danh sách nghệ nhân
        </Link>
      </div>
    );
  }

  // Linked heritage
  const relatedHeritages = heritageData.filter((h) =>
    artisan.heritageIds.includes(h.id) || artisan.heritageIds.includes(h.slug)
  );

  // Other artisans
  const otherArtisans = artisanData
    .filter((a) => a.id !== artisan.id)
    .slice(0, 3);

  const allPhotos = [artisan.portrait, ...(artisan.gallery || [])];

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616]">
      <PageBanner
        title={`Nghệ nhân ${artisan.name}`}
        subtitle={`${artisan.craft} • ${artisan.province}`}
        breadcrumbs={[
          { label: 'Nghệ nhân', path: '/nghe-nhan' },
          { label: artisan.name },
        ]}
        badge={artisan.region}
        badgeColor={artisan.color || '#582080'}
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          {/* Main Story (8 cols) */}
          <div className="lg:col-span-8 space-y-10">
            {/* Portrait & Core Bio Highlight */}
            <div className="bg-white rounded-2xl overflow-hidden border border-[#E4E1D9] shadow-md flex flex-col md:flex-row">
              <div className="md:w-1/2 relative aspect-[4/4.5] bg-gray-100">
                <img
                  src={artisan.portrait}
                  alt={artisan.name}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => {
                    setLightboxIndex(0);
                    setLightboxOpen(true);
                  }}
                  className="absolute bottom-3 right-3 bg-black/70 hover:bg-black/90 text-white p-2 rounded-lg text-xs flex items-center gap-1.5 backdrop-blur-xs"
                >
                  <ZoomIn className="w-4 h-4" />
                  <span>Xem chân dung</span>
                </button>
              </div>

              <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37] block mb-2">
                    Hồ sơ nghệ nhân
                  </span>
                  <h2 className="font-heading font-black text-2xl sm:text-3xl text-[#082951] leading-tight">
                    {artisan.name}
                  </h2>
                  <p className="text-sm font-semibold text-[#582080] mt-1">
                    {artisan.craft}
                  </p>

                  <div className="flex items-center gap-2 text-xs text-gray-500 mt-3">
                    <Clock className="w-4 h-4 text-[#C91F37]" />
                    <span>{artisan.experience || 'Nhiều năm cống hiến'}</span>
                  </div>

                  <p className="text-sm text-gray-700 leading-relaxed mt-4 italic border-l-2 border-[#C91F37] pl-3">
                    “{artisan.shortBio}”
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-gray-100 flex items-center justify-between">
                  <div className="text-xs text-gray-500">
                    <span className="font-semibold text-gray-700">Địa phương:</span> {artisan.province}
                  </div>
                  <button
                    onClick={handleShare}
                    className="text-xs font-bold text-[#082951] hover:text-[#C91F37] flex items-center gap-1"
                  >
                    {copiedShare ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Đã lưu link</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Chia sẻ</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Biography & Family Roots */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-4">
              <div className="flex items-center gap-2.5 text-[#082951]">
                <BookOpen className="w-6 h-6 text-[#C91F37]" />
                <h3 className="font-heading font-black text-xl sm:text-2xl uppercase">
                  Tiểu sử và Cơ duyên với nghề
                </h3>
              </div>
              <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                {artisan.biography}
              </p>
            </div>

            {/* Craft Journey & Philosophy Story */}
            <div className="bg-[#F7F4EA] p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] space-y-4">
              <div className="flex items-center gap-2.5 text-[#082951]">
                <Sparkles className="w-6 h-6 text-[#F3B33F]" />
                <h3 className="font-heading font-black text-xl sm:text-2xl uppercase">
                  Hành trình gìn giữ và triết lý làm nghề
                </h3>
              </div>
              <p className="text-sm sm:text-base text-gray-800 leading-relaxed font-serif italic text-lg leading-relaxed">
                {artisan.story}
              </p>
            </div>

            {/* Gallery of Artisan's Works */}
            {artisan.gallery && artisan.gallery.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading font-black text-xl sm:text-2xl text-[#082951] uppercase">
                    Khoảnh khắc chế tác & Tác phẩm
                  </h3>
                  <span className="text-xs text-gray-500">
                    {allPhotos.length} ảnh tư liệu
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {allPhotos.map((img, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setLightboxIndex(idx);
                        setLightboxOpen(true);
                      }}
                      className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer shadow-sm border border-[#E4E1D9]"
                    >
                      <img
                        src={img}
                        alt={`${artisan.name} gallery ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                        <ZoomIn className="w-6 h-6" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar (4 cols) */}
          <div className="lg:col-span-4 space-y-8">
            {/* Honors and Awards Card */}
            {artisan.awards && artisan.awards.length > 0 && (
              <div className="bg-white rounded-2xl border border-[#E4E1D9] p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 text-[#082951] border-b border-gray-100 pb-3">
                  <Award className="w-5 h-5 text-[#F3B33F]" />
                  <h4 className="font-heading font-bold text-base uppercase">
                    Danh hiệu & Khen thưởng
                  </h4>
                </div>

                <ul className="space-y-3">
                  {artisan.awards.map((award, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-gray-700">
                      <span className="w-2 h-2 rounded-full bg-[#C91F37] mt-1.5 shrink-0" />
                      <span>{award}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Related Heritage Link Card */}
            {relatedHeritages.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Landmark className="w-5 h-5 text-[#C91F37]" />
                  <h4 className="font-heading font-bold text-base uppercase text-[#082951]">
                    Di sản gắn liền
                  </h4>
                </div>

                <div className="space-y-4">
                  {relatedHeritages.map((heritage) => (
                    <HeritageCard key={heritage.id} heritage={heritage} variant="catalog" />
                  ))}
                </div>
              </div>
            )}

            {/* Contact / Workshop Visit CTA */}
            <div className="bg-[#082951] text-white p-6 rounded-2xl shadow-md text-center space-y-3">
              <h4 className="font-heading font-bold text-base uppercase">
                Giao lưu & Học hỏi kinh nghiệm
              </h4>
              <p className="text-xs text-gray-300 leading-relaxed">
                Quý khán giả có nhu cầu kết nối, đặt tác phẩm độc bản hoặc thăm xưởng nghề của nghệ nhân {artisan.name}?
              </p>
              <Link
                to="/lien-he"
                className="inline-block bg-[#C91F37] hover:bg-[#A71B32] text-white px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
              >
                Gửi yêu cầu liên hệ
              </Link>
            </div>
          </div>
        </div>

        {/* Other Artisans */}
        {otherArtisans.length > 0 && (
          <div className="mt-16 pt-12 border-t border-[#E4E1D9] space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                  Những người giữ lửa khác
                </span>
                <h3 className="font-heading font-black text-2xl text-[#082951] uppercase">
                  Gương mặt nghệ nhân tiêu biểu
                </h3>
              </div>
              <Link
                to="/nghe-nhan"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider"
              >
                <span>Xem tất cả</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {otherArtisans.map((a) => (
                <ArtisanCard key={a.id} artisan={a} variant="detailed" />
              ))}
            </div>
          </div>
        )}
      </div>

      <ImageLightbox
        images={allPhotos}
        currentIndex={lightboxIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onSelectIndex={(idx) => setLightboxIndex(idx)}
      />
    </div>
  );
}
