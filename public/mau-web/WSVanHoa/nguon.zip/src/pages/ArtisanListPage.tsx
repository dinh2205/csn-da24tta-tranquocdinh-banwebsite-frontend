import React, { useState, useMemo } from 'react';
import { Search, UserCheck, RefreshCw } from 'lucide-react';
import artisanData from '../data/artisans.json';
import PageBanner from '../components/PageBanner';
import ArtisanCard from '../components/ArtisanCard';
import Pagination from '../components/Pagination';

export default function ArtisanListPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('Tất cả');
  const [sortBy, setSortBy] = useState<'name-asc' | 'name-desc'>('name-asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const regions = ['Tất cả', 'Miền Bắc', 'Miền Trung', 'Tây Nguyên', 'Miền Nam'];

  const filteredArtisans = useMemo(() => {
    return artisanData
      .filter((artisan) => {
        const matchesSearch =
          artisan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          artisan.craft.toLowerCase().includes(searchTerm.toLowerCase()) ||
          artisan.province.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRegion = selectedRegion === 'Tất cả' || artisan.region === selectedRegion;
        return matchesSearch && matchesRegion;
      })
      .sort((a, b) => {
        if (sortBy === 'name-asc') return a.name.localeCompare(b.name, 'vi');
        if (sortBy === 'name-desc') return b.name.localeCompare(a.name, 'vi');
        return 0;
      });
  }, [searchTerm, selectedRegion, sortBy]);

  const totalPages = Math.ceil(filteredArtisans.length / itemsPerPage);
  const currentArtisans = filteredArtisans.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedRegion('Tất cả');
    setSortBy('name-asc');
    setCurrentPage(1);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Gương mặt nghệ nhân Việt"
        subtitle="Hồ sơ những bậc thầy thủ công, bàn tay vàng gìn giữ linh hồn và câu chuyện nghề truyền thống Việt Nam qua bao biến thiên lịch sử."
        breadcrumbs={[{ label: 'Nghệ nhân' }]}
        badge="Nghệ nhân tiêu biểu"
        badgeColor="#582080"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        {/* Search & Filter Header */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-[#E4E1D9] shadow-sm mb-10 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-6 relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Tìm tên nghệ nhân, nghề thủ công, tỉnh thành..."
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:bg-white focus:outline-none focus:border-[#C91F37] transition-colors"
              />
            </div>

            <div className="md:col-span-3">
              <select
                value={selectedRegion}
                onChange={(e) => {
                  setSelectedRegion(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:outline-none focus:border-[#C91F37] transition-colors"
              >
                {regions.map((reg) => (
                  <option key={reg} value={reg}>
                    Vùng: {reg}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-3">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:outline-none focus:border-[#C91F37] transition-colors"
              >
                <option value="name-asc">Tên nghệ nhân: A - Z</option>
                <option value="name-desc">Tên nghệ nhân: Z - A</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-gray-100 text-xs">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#C91F37]" />
              <span className="text-gray-600 font-semibold">
                Hiển thị {filteredArtisans.length} nghệ nhân
              </span>
            </div>

            {(searchTerm || selectedRegion !== 'Tất cả') && (
              <button
                onClick={resetFilters}
                className="flex items-center gap-1 text-[#C91F37] hover:underline font-semibold"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Đặt lại bộ lọc</span>
              </button>
            )}
          </div>
        </div>

        {/* Artisans Grid */}
        {currentArtisans.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {currentArtisans.map((artisan) => (
              <ArtisanCard key={artisan.id} artisan={artisan} variant="detailed" />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-white rounded-xl border border-[#E4E1D9] p-8">
            <p className="font-heading font-bold text-lg text-gray-700">
              Không tìm thấy nghệ nhân phù hợp
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Vui lòng thử tìm kiếm bằng từ khóa khác hoặc xóa bộ lọc.
            </p>
            <button
              onClick={resetFilters}
              className="mt-4 px-5 py-2 bg-[#082951] text-white text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-[#164B7B]"
            >
              Xem tất cả nghệ nhân
            </button>
          </div>
        )}

        {/* Pagination */}
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setCurrentPage(page)}
        />
      </div>
    </div>
  );
}
