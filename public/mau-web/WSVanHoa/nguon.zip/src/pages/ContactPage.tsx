import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Mail,
  Phone,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Building,
} from 'lucide-react';
import PageBanner from '../components/PageBanner';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    subject: 'Đề xuất nghệ nhân',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [savedMessages, setSavedMessages] = useState<any[]>([]);

  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem('tinhhoa_contact_messages') || '[]');
      setSavedMessages(stored);
    } catch (e) {
      console.error(e);
    }
  }, [success]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const messageRecord = {
      id: Date.now().toString(),
      createdAt: new Date().toLocaleString('vi-VN'),
      ...formData,
    };

    try {
      const existing = JSON.parse(localStorage.getItem('tinhhoa_contact_messages') || '[]');
      existing.unshift(messageRecord);
      localStorage.setItem('tinhhoa_contact_messages', JSON.stringify(existing));
    } catch (err) {
      console.error(err);
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess(true);
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        subject: 'Đề xuất nghệ nhân',
        message: '',
      });
    }, 500);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Liên hệ với chúng tôi"
        subtitle="Chúng tôi luôn lắng nghe những ý kiến đóng góp, đề xuất nghệ nhân và cơ hội hợp tác quảng bá di sản Việt."
        breadcrumbs={[{ label: 'Liên hệ' }]}
        badge="Kết nối cộng đồng"
        badgeColor="#C91F37"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          {/* Contact Information & Office Details (5 cols) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                Thông tin kết nối
              </span>
              <h2 className="font-heading font-black text-2xl text-[#082951]">
                TRUNG TÂM TINH HOA NGHỆ NHÂN VIỆT
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed">
                Quý cơ quan, nghệ nhân, du khách và đơn vị báo chí có thể liên hệ trực tiếp qua các kênh thông tin dưới đây.
              </p>

              <div className="space-y-4 pt-2 text-sm text-gray-700">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-gray-900 block">Địa chỉ văn phòng:</span>
                    <span>123 Đường Văn Hóa, Phường Bến Nghé, Quận 1, TP. Hồ Chí Minh</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0 mt-0.5">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-gray-900 block">Email tiếp nhận:</span>
                    <a href="mailto:contact@nghenhanviet.vn" className="text-[#082951] hover:underline">
                      contact@nghenhanviet.vn
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0 mt-0.5">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-gray-900 block">Đường dây nóng:</span>
                    <a href="tel:02812345678" className="text-[#082951] hover:underline">
                      (028) 1234 5678
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-gray-900 block">Giờ làm việc:</span>
                    <span>Thứ Hai - Thứ Bảy: 08:00 - 17:30 (Trừ ngày lễ Tết)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Demo Note */}
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-800 space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span>Chế độ mô phỏng (LocalStorage Demo)</span>
              </div>
              <p>
                Tin nhắn gửi từ biểu mẫu sẽ được lưu trực tiếp vào bộ nhớ cục bộ trình duyệt của bạn nhằm kiểm tra luồng tương tác thực tế mà không gửi thư rác.
              </p>
            </div>
          </div>

          {/* Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-white p-6 sm:p-10 rounded-2xl border border-[#E4E1D9] shadow-md space-y-6">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#007F80]">
                  Gửi thư điện tử
                </span>
                <h3 className="font-heading font-black text-2xl text-[#082951] mt-1">
                  ĐÓNG GÓP Ý KIẾN HOẶC ĐỀ XUẤT NGHỆ NHÂN
                </h3>
              </div>

              {success && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3 text-emerald-900">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="text-xs sm:text-sm">
                    <p className="font-bold">Tin nhắn của bạn đã được lưu thành công!</p>
                    <p className="mt-0.5 text-emerald-800">
                      Cảm ơn bạn đã đồng hành cùng cộng đồng Tinh Hoa Nghệ Nhân Việt.
                    </p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Họ và tên *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="Nguyễn Văn A"
                      className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@example.com"
                      className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Số điện thoại
                    </label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="0912 345 678"
                      className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                      Chủ đề liên hệ
                    </label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    >
                      <option value="Đề xuất nghệ nhân">Đề xuất nghệ nhân tiêu biểu</option>
                      <option value="Hợp tác">Hợp tác tổ chức sự kiện / Triển lãm</option>
                      <option value="Góp ý">Góp ý nội dung tư liệu di sản</option>
                      <option value="Câu hỏi khác">Câu hỏi khác</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                    Nội dung thông điệp *
                  </label>
                  <textarea
                    required
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Mô tả chi tiết câu chuyện nghệ nhân hoặc nội dung bạn mong muốn gửi gắm..."
                    className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-3 bg-[#C91F37] hover:bg-[#A71B32] disabled:opacity-50 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{isSubmitting ? 'Đang gửi thông tin...' : 'Gửi tin nhắn'}</span>
                </button>
              </form>

              {/* Sent Messages History in Demo Mode */}
              {savedMessages.length > 0 && (
                <div className="pt-6 border-t border-gray-100">
                  <h4 className="font-heading font-bold text-xs uppercase text-gray-500 mb-3 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Lịch sử gửi tin trên thiết bị này ({savedMessages.length}):</span>
                  </h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {savedMessages.slice(0, 3).map((item) => (
                      <div key={item.id} className="p-2.5 rounded bg-gray-50 text-xs border border-gray-200">
                        <div className="flex items-center justify-between text-gray-500">
                          <span className="font-semibold text-gray-800">{item.fullName}</span>
                          <span>{item.createdAt}</span>
                        </div>
                        <div className="text-[#C91F37] font-medium mt-0.5">{item.subject}</div>
                        <p className="text-gray-600 truncate mt-1">{item.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
