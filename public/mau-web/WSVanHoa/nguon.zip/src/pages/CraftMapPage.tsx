import React, { useState } from 'react';
import { Compass, MapPin, Sparkles, ArrowRight, Layers } from 'lucide-react';
import PageBanner from '../components/PageBanner';
import InteractiveCraftMap from '../components/InteractiveCraftMap';

export default function CraftMapPage() {
  const [selectedRegion, setSelectedRegion] = useState('Tất cả');

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Bản đồ làng nghề Việt Nam"
        subtitle="Hành trình khám phá địa lý di sản trải dài khắp dải đất hình chữ S, nơi lưu giữ tinh hoa bàn tay khéo léo của người Việt."
        breadcrumbs={[{ label: 'Bản đồ làng nghề' }]}
        badge="Địa lý văn hóa"
        badgeColor="#C91F37"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
        {/* Intro Highlight Box */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
              Không gian số hóa di sản
            </span>
            <h2 className="font-heading font-black text-xl sm:text-2xl text-[#082951]">
              TRA CỨU VỊ TRÍ & ĐẶC TRƯNG LÀNG NGHỀ THEO VÙNG MIỀN
            </h2>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
              Nhấp chọn các điểm ghim trên bản đồ tương tác để xem chi tiết lịch sử, sản phẩm tiêu biểu và thông tin nghệ nhân đại diện cho từng làng nghề truyền thống.
            </p>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F7F4EA] border border-[#E4E1D9] text-xs font-semibold text-[#082951] shrink-0">
            <Sparkles className="w-4 h-4 text-[#F3B33F]" />
            <span>Dữ liệu số hóa 4 vùng miền</span>
          </div>
        </div>

        {/* Interactive Map Component */}
        <InteractiveCraftMap
          selectedRegion={selectedRegion}
          onSelectRegion={(reg) => setSelectedRegion(reg)}
          compact={false}
        />

        {/* Regional Characteristics Guide Cards */}
        <div className="pt-8 border-t border-[#E4E1D9]">
          <h3 className="font-heading font-black text-2xl text-[#082951] uppercase mb-6 text-center sm:text-left">
            Đặc trưng thủ công theo từng vùng miền
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* North */}
            <div className="bg-white p-6 rounded-xl border-t-4 border-[#C91F37] shadow-sm space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#C91F37]">
                Miền Bắc
              </span>
              <h4 className="font-heading font-bold text-lg text-[#082951]">
                Cái nôi ngàn năm văn hiến
              </h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Đậm tính bác học và tinh tế với các nghề gốm sứ men rạn, tranh khắc gỗ mộc bản, dệt lụa tơ tằm, mộc mỹ nghệ Kinh Bắc và mây tre đan tinh xảo.
              </p>
            </div>

            {/* Central */}
            <div className="bg-white p-6 rounded-xl border-t-4 border-[#D36E24] shadow-sm space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#D36E24]">
                Miền Trung
              </span>
              <h4 className="font-heading font-bold text-lg text-[#082951]">
                Nét quý phái cung đình & duyên hải
              </h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Gắn bó với lịch sử vương triều và đời sống miền biển: Nón bài thơ xứ Huế, mộc chạm khắc Kim Bồng, gốm đất nung Thanh Hà và nghề đan lưới biển.
              </p>
            </div>

            {/* Highlands */}
            <div className="bg-white p-6 rounded-xl border-t-4 border-[#582080] shadow-sm space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#582080]">
                Tây Nguyên
              </span>
              <h4 className="font-heading font-bold text-lg text-[#082951]">
                Hơi thở sử thi & đại ngàn
              </h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Nguyên sơ và phóng khoáng: Dệt thổ cẩm Ê Đê hoa văn kỷ hà, điêu khắc tượng nhà mồ Ba Na, chế tác nhạc cụ cồng chiêng và đàn T’rưng tre nứa.
              </p>
            </div>

            {/* South */}
            <div className="bg-white p-6 rounded-xl border-t-4 border-[#007F80] shadow-sm space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#007F80]">
                Miền Nam
              </span>
              <h4 className="font-heading font-bold text-lg text-[#082951]">
                Hào sảng châu thổ Cửu Long
              </h4>
              <p className="text-xs text-gray-600 leading-relaxed">
                Thích ứng với hệ sinh thái sông nước: Dệt chiếu cói Định Yên, gốm men màu Lái Thiêu - Bình Dương, đan đát lục bình và thủ công từ dừa Bến Tre.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
