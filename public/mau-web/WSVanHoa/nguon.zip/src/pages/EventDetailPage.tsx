import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Calendar,
  MapPin,
  Clock,
  Ticket,
  Users,
  CheckCircle,
  Share2,
  AlertCircle,
  ArrowRight,
  ZoomIn,
} from 'lucide-react';
import eventData from '../data/events.json';
import PageBanner from '../components/PageBanner';
import EventCard from '../components/EventCard';
import ImageLightbox from '../components/ImageLightbox';

export default function EventDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const event = eventData.find((e) => e.slug === slug);

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    participants: 1,
    note: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [ticketCode, setTicketCode] = useState('');

  // Lightbox
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  if (!event) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <h2 className="font-heading font-black text-3xl text-[#082951] mb-2">
          Không tìm thấy sự kiện
        </h2>
        <p className="text-gray-600 mb-6">
          Sự kiện bạn đang tìm không tồn tại hoặc đã kết thúc.
        </p>
        <Link
          to="/su-kien"
          className="bg-[#C91F37] text-white px-6 py-2.5 rounded-md font-bold text-xs uppercase tracking-wider"
        >
          Quay lại danh sách sự kiện
        </Link>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const generatedTicket = `THV-${event.day}${event.month}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRegistration = {
      id: Date.now().toString(),
      eventId: event.id,
      eventTitle: event.title,
      ticketCode: generatedTicket,
      createdAt: new Date().toISOString(),
      ...formData,
    };

    // Store in LocalStorage
    try {
      const existing = JSON.parse(localStorage.getItem('tinhhoa_event_registrations') || '[]');
      existing.push(newRegistration);
      localStorage.setItem('tinhhoa_event_registrations', JSON.stringify(existing));
    } catch (err) {
      console.error(err);
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setTicketCode(generatedTicket);
      setRegistrationSuccess(true);
    }, 600);
  };

  const relatedEvents = eventData
    .filter((e) => e.id !== event.id)
    .slice(0, 3);

  const photos = [event.coverImage, ...(event.gallery || [])];

  return (
    <div className="bg-[#FFFCF5] text-[#161616]">
      <PageBanner
        title={event.title}
        subtitle={`${event.eventType} • ${event.location}`}
        breadcrumbs={[
          { label: 'Sự kiện', path: '/su-kien' },
          { label: event.title },
        ]}
        badge={event.eventType}
        badgeColor="#C91F37"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          {/* Main Content (8 cols) */}
          <div className="lg:col-span-8 space-y-10">
            {/* Cover Image Showcase */}
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-[#E4E1D9] group">
              <img
                src={event.coverImage}
                alt={event.title}
                className="w-full h-[320px] sm:h-[420px] object-cover"
              />
              <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-xs px-3.5 py-2 rounded-xl shadow-lg border border-gray-100 text-center">
                <span className="block font-heading font-black text-2xl text-[#C91F37] leading-none">
                  {event.day}
                </span>
                <span className="text-xs font-bold uppercase tracking-wider text-gray-500">
                  THÁNG {event.month}
                </span>
              </div>
            </div>

            {/* Event Description */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                Thông tin chi tiết
              </span>
              <h2 className="font-heading font-black text-2xl sm:text-3xl text-[#082951]">
                GIỚI THIỆU SỰ KIỆN
              </h2>
              <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                {event.description}
              </p>
            </div>

            {/* Event Agenda / Schedule */}
            {event.schedule && event.schedule.length > 0 && (
              <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-6">
                <div className="flex items-center gap-2.5 text-[#082951]">
                  <Clock className="w-6 h-6 text-[#C91F37]" />
                  <h3 className="font-heading font-black text-xl sm:text-2xl uppercase">
                    Chương trình & Lịch trình chi tiết
                  </h3>
                </div>

                <div className="space-y-4">
                  {event.schedule.map((slot, idx) => (
                    <div
                      key={idx}
                      className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-6 p-4 rounded-xl bg-[#F7F4EA] border border-[#E4E1D9]/70"
                    >
                      <span className="inline-block px-3 py-1 rounded bg-[#082951] text-white text-xs font-bold shrink-0">
                        {slot.time}
                      </span>
                      <p className="text-sm text-gray-800 font-medium">
                        {slot.activity}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Event Gallery */}
            {photos.length > 1 && (
              <div className="space-y-4">
                <h3 className="font-heading font-black text-xl sm:text-2xl text-[#082951] uppercase">
                  Hình ảnh không gian tổ chức
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {photos.map((img, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setLightboxIndex(idx);
                        setLightboxOpen(true);
                      }}
                      className="group relative aspect-video rounded-xl overflow-hidden cursor-pointer shadow-sm border border-[#E4E1D9]"
                    >
                      <img
                        src={img}
                        alt={`Sự kiện ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                        <ZoomIn className="w-6 h-6" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar / Registration Panel (4 cols) */}
          <div className="lg:col-span-4 space-y-8">
            {/* Quick Metadata Box */}
            <div className="bg-white rounded-2xl border border-[#E4E1D9] p-6 shadow-sm space-y-4">
              <h4 className="font-heading font-bold text-base uppercase text-[#082951] border-b border-gray-100 pb-3">
                Tổng quan đăng ký
              </h4>

              <div className="space-y-3.5 text-xs sm:text-sm">
                <div>
                  <span className="text-gray-400 block text-xs">Thời gian:</span>
                  <div className="flex items-center gap-2 text-gray-800 font-semibold mt-0.5">
                    <Calendar className="w-4 h-4 text-[#C91F37]" />
                    <span>Ngày {event.day} tháng {event.month}, 2026</span>
                  </div>
                </div>

                <div>
                  <span className="text-gray-400 block text-xs">Địa điểm:</span>
                  <div className="flex items-start gap-2 text-gray-800 font-medium mt-0.5">
                    <MapPin className="w-4 h-4 text-[#C91F37] shrink-0 mt-0.5" />
                    <span>{event.venue || event.location}</span>
                  </div>
                </div>

                <div>
                  <span className="text-gray-400 block text-xs">Phí tham dự:</span>
                  <span className="inline-block mt-0.5 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
                    {event.fee || 'Miễn phí vé vào cửa'}
                  </span>
                </div>

                {event.speaker && (
                  <div>
                    <span className="text-gray-400 block text-xs">Khách mời / Nghệ nhân:</span>
                    <span className="font-semibold text-gray-800">{event.speaker}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Registration Form Box */}
            <div className="bg-white rounded-2xl border border-[#E4E1D9] p-6 shadow-md">
              <div className="flex items-center gap-2 mb-4 text-[#082951]">
                <Ticket className="w-5 h-5 text-[#C91F37]" />
                <h4 className="font-heading font-bold text-base uppercase">
                  Đăng ký tham dự
                </h4>
              </div>

              {registrationSuccess ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-3 text-center">
                  <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
                  <h5 className="font-heading font-bold text-base text-emerald-900">
                    Đăng ký thành công!
                  </h5>
                  <p className="text-xs text-emerald-800">
                    Mã vé điện tử của bạn là:
                  </p>
                  <div className="font-mono font-black text-lg bg-white px-3 py-1.5 rounded border border-emerald-300 text-emerald-900 tracking-wider">
                    {ticketCode}
                  </div>
                  <p className="text-[11px] text-gray-500 italic">
                    * Thông tin đã được lưu trong bộ nhớ máy (LocalStorage demo).
                  </p>
                  <button
                    onClick={() => {
                      setRegistrationSuccess(false);
                      setFormData({ fullName: '', email: '', phone: '', participants: 1, note: '' });
                    }}
                    className="mt-2 text-xs text-[#082951] font-semibold underline"
                  >
                    Đăng ký thêm người khác
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Họ và tên *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="Nguyễn Văn A"
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@example.com"
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Số điện thoại *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="0912 345 678"
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Số lượng người tham dự
                    </label>
                    <select
                      value={formData.participants}
                      onChange={(e) => setFormData({ ...formData, participants: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 focus:bg-white focus:outline-none"
                    >
                      {[1, 2, 3, 4, 5].map((n) => (
                        <option key={n} value={n}>
                          {n} người
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Demo Disclaimer notice as per JSON specs */}
                  <div className="flex items-start gap-2 p-2.5 rounded bg-amber-50 border border-amber-200 text-[11px] text-amber-800">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>Lịch và biểu mẫu mang tính minh họa trình diễn (LocalStorage demo).</span>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 bg-[#C91F37] hover:bg-[#A71B32] disabled:opacity-50 text-white rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
                  >
                    {isSubmitting ? 'Đang xác nhận...' : 'Xác nhận đăng ký tham dự'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Related Events */}
        {relatedEvents.length > 0 && (
          <div className="mt-16 pt-12 border-t border-[#E4E1D9] space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                  Lịch hoạt động khác
                </span>
                <h3 className="font-heading font-black text-2xl text-[#082951] uppercase">
                  Sự kiện sắp diễn ra
                </h3>
              </div>
              <Link
                to="/su-kien"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider"
              >
                <span>Xem tất cả</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {relatedEvents.map((evt) => (
                <EventCard key={evt.id} event={evt} variant="catalog" />
              ))}
            </div>
          </div>
        )}
      </div>

      <ImageLightbox
        images={photos}
        currentIndex={lightboxIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onSelectIndex={(idx) => setLightboxIndex(idx)}
      />
    </div>
  );
}
