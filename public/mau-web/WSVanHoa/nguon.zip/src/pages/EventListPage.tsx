import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, ArrowRight, Filter, RefreshCw } from 'lucide-react';
import eventData from '../data/events.json';
import PageBanner from '../components/PageBanner';
import EventCard from '../components/EventCard';
import Pagination from '../components/Pagination';

export default function EventListPage() {
  const [selectedType, setSelectedType] = useState('Tất cả');
  const [selectedLocation, setSelectedLocation] = useState('Tất cả');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const eventTypes = ['Tất cả', 'Triển lãm', 'Workshop', 'Lễ hội', 'Giao lưu nghệ nhân'];
  const locations = ['Tất cả', 'Hà Nội', 'Huế', 'TP. Hồ Chí Minh'];

  const filteredEvents = useMemo(() => {
    return eventData.filter((evt) => {
      const matchesType = selectedType === 'Tất cả' || evt.eventType === selectedType;
      const matchesLocation = selectedLocation === 'Tất cả' || evt.location === selectedLocation;
      return matchesType && matchesLocation;
    });
  }, [selectedType, selectedLocation]);

  const totalPages = Math.ceil(filteredEvents.length / itemsPerPage);
  const currentEvents = filteredEvents.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const featuredEvent = eventData[0];

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Sự kiện văn hóa"
        subtitle="Chuỗi các triển lãm, workshop trải nghiệm, lễ hội truyền thống và tọa đàm văn hóa nhằm tôn vinh giá trị bàn tay Việt."
        breadcrumbs={[{ label: 'Sự kiện' }]}
        badge="Lịch hoạt động"
        badgeColor="#C91F37"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        {/* Featured Event Spotlight */}
        {featuredEvent && (
          <div className="bg-[#082951] text-white rounded-2xl overflow-hidden shadow-xl mb-12 border border-[#164B7B]">
            <div className="grid grid-cols-1 lg:grid-cols-12">
              <div className="lg:col-span-7 relative h-72 lg:h-auto overflow-hidden">
                <img
                  src={featuredEvent.coverImage}
                  alt={featuredEvent.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-[#C91F37] text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">
                  Sự kiện tâm điểm
                </div>
              </div>

              <div className="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-xs font-semibold text-yellow-400">
                    <Calendar className="w-4 h-4" />
                    <span>Khởi tranh ngày {featuredEvent.day}/{featuredEvent.month}/2026</span>
                  </div>

                  <h2 className="font-heading font-black text-2xl sm:text-3xl uppercase leading-tight text-white">
                    {featuredEvent.title}
                  </h2>

                  <div className="flex items-center gap-2 text-xs text-gray-300">
                    <MapPin className="w-4 h-4 text-[#C91F37]" />
                    <span>{featuredEvent.venue || featuredEvent.location}</span>
                  </div>

                  <p className="text-sm text-gray-200 leading-relaxed line-clamp-3">
                    {featuredEvent.description}
                  </p>
                </div>

                <div className="pt-2">
                  <Link
                    to={`/su-kien/${featuredEvent.slug}`}
                    className="inline-flex items-center gap-2 bg-[#C91F37] hover:bg-[#A71B32] text-white px-6 py-3 rounded-md text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
                  >
                    <span>Xem lịch trình & Đăng ký</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-[#E4E1D9] shadow-sm mb-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Phân loại:
            </span>
            {eventTypes.map((t) => (
              <button
                key={t}
                onClick={() => {
                  setSelectedType(t);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedType === t
                    ? 'bg-[#082951] text-white font-bold'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-500">
              Địa điểm:
            </span>
            <select
              value={selectedLocation}
              onChange={(e) => {
                setSelectedLocation(e.target.value);
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs font-semibold text-[#082951] focus:outline-none"
            >
              {locations.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Events Grid */}
        {currentEvents.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {currentEvents.map((evt) => (
              <EventCard key={evt.id} event={evt} variant="catalog" />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-white rounded-xl border border-[#E4E1D9] p-8">
            <p className="font-heading font-bold text-lg text-gray-700">
              Không có sự kiện nào phù hợp với bộ lọc
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Hãy thử chọn loại hình hoặc địa điểm tổ chức khác.
            </p>
          </div>
        )}

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setCurrentPage(page)}
        />
      </div>
    </div>
  );
}
