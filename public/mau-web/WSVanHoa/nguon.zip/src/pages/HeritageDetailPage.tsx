import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  MapPin,
  Calendar,
  Layers,
  ArrowRight,
  ZoomIn,
  Users,
  Share2,
  CheckCircle2,
  History,
  Wrench,
  Sparkles,
} from 'lucide-react';
import heritageData from '../data/heritage.json';
import artisanData from '../data/artisans.json';
import PageBanner from '../components/PageBanner';
import ArtisanCard from '../components/ArtisanCard';
import HeritageCard from '../components/HeritageCard';
import ImageLightbox from '../components/ImageLightbox';

export default function HeritageDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const heritage = heritageData.find((h) => h.slug === slug);

  // Lightbox state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [copiedShare, setCopiedShare] = useState(false);

  if (!heritage) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <h2 className="font-heading font-black text-3xl text-[#082951] mb-2">
          Không tìm thấy di sản
        </h2>
        <p className="text-gray-600 mb-6">
          Di sản bạn đang tìm kiếm không tồn tại hoặc đường dẫn đã thay đổi.
        </p>
        <Link
          to="/di-san"
          className="bg-[#C91F37] text-white px-6 py-2.5 rounded-md font-bold text-xs uppercase tracking-wider"
        >
          Quay lại danh mục di sản
        </Link>
      </div>
    );
  }

  // Linked artisans
  const relatedArtisans = artisanData.filter((artisan) =>
    heritage.artisanIds.includes(artisan.id) || artisan.heritageIds.includes(heritage.id)
  );

  // Related heritages
  const relatedHeritages = heritageData.filter(
    (item) => item.id !== heritage.id && (heritage.relatedIds?.includes(item.id) || item.region === heritage.region)
  ).slice(0, 3);

  const allPhotos = [heritage.coverImage, ...(heritage.gallery || [])];

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616]">
      {/* Banner */}
      <PageBanner
        title={heritage.name}
        subtitle={`${heritage.craftType} • ${heritage.province}`}
        breadcrumbs={[
          { label: 'Di sản', path: '/di-san' },
          { label: heritage.name },
        ]}
        badge={heritage.region}
        badgeColor={heritage.color || '#BA2636'}
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          {/* Main Content (8 cols) */}
          <div className="lg:col-span-8 space-y-12">
            {/* Hero Image Showcase */}
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-[#E4E1D9] group">
              <img
                src={heritage.coverImage}
                alt={heritage.name}
                className="w-full h-[360px] sm:h-[460px] object-cover"
              />
              <button
                onClick={() => {
                  setLightboxIndex(0);
                  setLightboxOpen(true);
                }}
                className="absolute bottom-4 right-4 bg-black/70 hover:bg-black/90 text-white px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 backdrop-blur-xs transition-colors"
              >
                <ZoomIn className="w-4 h-4" />
                <span>Xem ảnh lớn</span>
              </button>
            </div>

            {/* Overview / Introduction */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                Tổng quan di sản
              </span>
              <h2 className="font-heading font-black text-2xl sm:text-3xl text-[#082951]">
                GIÁ TRỊ TINH HOA VĂN HÓA
              </h2>
              <p className="text-base sm:text-lg text-gray-700 leading-relaxed font-serif italic text-gray-800 border-l-4 border-[#C91F37] pl-4 py-1">
                “{heritage.description}”
              </p>
            </div>

            {/* Origin & History Narrative */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-4">
              <div className="flex items-center gap-2.5 text-[#082951]">
                <History className="w-6 h-6 text-[#C91F37]" />
                <h3 className="font-heading font-black text-xl sm:text-2xl uppercase">
                  Nguồn gốc và Lịch sử hình thành
                </h3>
              </div>
              <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                {heritage.history}
              </p>
            </div>

            {/* Traditional Step-by-Step Techniques */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E4E1D9] shadow-sm space-y-6">
              <div className="flex items-center gap-2.5 text-[#082951]">
                <Wrench className="w-6 h-6 text-[#C91F37]" />
                <h3 className="font-heading font-black text-xl sm:text-2xl uppercase">
                  Quy trình kỹ thuật thủ công đặc sắc
                </h3>
              </div>

              <div className="space-y-4">
                {heritage.techniques.map((step, idx) => (
                  <div key={idx} className="flex items-start gap-4 p-4 rounded-xl bg-[#F7F4EA] border border-[#E4E1D9]/70">
                    <span className="w-8 h-8 rounded-full bg-[#082951] text-white font-heading font-black text-sm flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <p className="text-sm text-gray-800 leading-relaxed pt-1">
                      {step}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Product Photo Gallery */}
            {heritage.gallery && heritage.gallery.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-heading font-black text-xl sm:text-2xl text-[#082951] uppercase">
                    Thư viện hình ảnh di sản
                  </h3>
                  <span className="text-xs text-gray-500">
                    {allPhotos.length} hình ảnh tư liệu
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {allPhotos.map((photo, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setLightboxIndex(idx);
                        setLightboxOpen(true);
                      }}
                      className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer shadow-sm border border-[#E4E1D9]"
                    >
                      <img
                        src={photo}
                        alt={`${heritage.name} ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                        <ZoomIn className="w-6 h-6" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar (4 cols) */}
          <div className="lg:col-span-4 space-y-8">
            {/* Quick Fact Card */}
            <div className="bg-white rounded-2xl border border-[#E4E1D9] p-6 shadow-sm space-y-5">
              <h4 className="font-heading font-bold text-base uppercase text-[#082951] border-b border-gray-100 pb-3">
                Thông tin làng nghề
              </h4>

              <div className="space-y-4 text-sm">
                <div>
                  <span className="text-xs text-gray-400 block">Địa chỉ làng nghề:</span>
                  <div className="flex items-start gap-2 text-gray-800 font-medium mt-1">
                    <MapPin className="w-4 h-4 text-[#C91F37] shrink-0 mt-0.5" />
                    <span>{heritage.village}</span>
                  </div>
                </div>

                <div>
                  <span className="text-xs text-gray-400 block">Loại hình thủ công:</span>
                  <span className="text-gray-800 font-semibold">{heritage.craftType}</span>
                </div>

                <div>
                  <span className="text-xs text-gray-400 block">Khu vực địa lý:</span>
                  <span className="text-gray-800 font-semibold">{heritage.region}</span>
                </div>

                <div>
                  <span className="text-xs text-gray-400 block">Tỉnh / Thành phố:</span>
                  <span className="text-gray-800 font-semibold">{heritage.province}</span>
                </div>
              </div>

              {/* Share Button */}
              <div className="pt-4 border-t border-gray-100">
                <button
                  onClick={handleShare}
                  className="w-full py-2.5 px-4 rounded-lg border border-[#082951] hover:bg-[#082951] text-[#082951] hover:text-white transition-colors text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2"
                >
                  {copiedShare ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      <span>Đã sao chép liên kết!</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4" />
                      <span>Chia sẻ di sản này</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Related Artisans */}
            {relatedArtisans.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#C91F37]" />
                  <h4 className="font-heading font-bold text-base uppercase text-[#082951]">
                    Nghệ nhân tiêu biểu
                  </h4>
                </div>

                <div className="space-y-4">
                  {relatedArtisans.map((artisan) => (
                    <ArtisanCard key={artisan.id} artisan={artisan} variant="compact" />
                  ))}
                </div>
              </div>
            )}

            {/* Explore interactive map CTA */}
            <div className="bg-[#082951] text-white p-6 rounded-2xl shadow-md text-center space-y-3">
              <Sparkles className="w-6 h-6 text-yellow-400 mx-auto" />
              <h4 className="font-heading font-bold text-base uppercase">
                Khám phá vị trí trên bản đồ
              </h4>
              <p className="text-xs text-gray-300">
                Tìm hiểu thêm các làng nghề lân cận tại tỉnh {heritage.province} và vùng {heritage.region}.
              </p>
              <Link
                to="/ban-do-lang-nghe"
                className="inline-block bg-[#C91F37] hover:bg-[#A71B32] text-white px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
              >
                Mở Bản đồ làng nghề
              </Link>
            </div>
          </div>
        </div>

        {/* Related Heritage Bottom Carousel */}
        {relatedHeritages.length > 0 && (
          <div className="mt-16 pt-12 border-t border-[#E4E1D9] space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                  Cùng khám phá
                </span>
                <h3 className="font-heading font-black text-2xl text-[#082951] uppercase">
                  Di sản cùng khu vực & thể loại
                </h3>
              </div>
              <Link
                to="/di-san"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider"
              >
                <span>Xem tất cả</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {relatedHeritages.map((item) => (
                <HeritageCard key={item.id} heritage={item} variant="catalog" />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Lightbox */}
      <ImageLightbox
        images={allPhotos}
        currentIndex={lightboxIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onSelectIndex={(idx) => setLightboxIndex(idx)}
      />
    </div>
  );
}
