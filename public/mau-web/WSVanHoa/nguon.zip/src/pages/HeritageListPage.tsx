import React, { useState, useMemo } from 'react';
import { Search, Filter, SlidersHorizontal, RefreshCw } from 'lucide-react';
import heritageData from '../data/heritage.json';
import PageBanner from '../components/PageBanner';
import HeritageCard from '../components/HeritageCard';
import Pagination from '../components/Pagination';

export default function HeritageListPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('Tất cả');
  const [selectedType, setSelectedType] = useState('Tất cả');
  const [sortBy, setSortBy] = useState<'name-asc' | 'name-desc'>('name-asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const regions = ['Tất cả', 'Miền Bắc', 'Miền Trung', 'Tây Nguyên', 'Miền Nam'];
  const craftTypes = ['Tất cả', 'Gốm sứ', 'Thủ công mây lá', 'Dệt may', 'Điêu khắc', 'Tranh dân gian', 'Mây tre đan'];

  const filteredHeritages = useMemo(() => {
    return heritageData
      .filter((item) => {
        const matchesSearch =
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.province.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesRegion = selectedRegion === 'Tất cả' || item.region === selectedRegion;
        const matchesType = selectedType === 'Tất cả' || item.craftType === selectedType;
        return matchesSearch && matchesRegion && matchesType;
      })
      .sort((a, b) => {
        if (sortBy === 'name-asc') return a.name.localeCompare(b.name, 'vi');
        if (sortBy === 'name-desc') return b.name.localeCompare(a.name, 'vi');
        return 0;
      });
  }, [searchTerm, selectedRegion, selectedType, sortBy]);

  const totalPages = Math.ceil(filteredHeritages.length / itemsPerPage);
  const currentHeritages = filteredHeritages.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedRegion('Tất cả');
    setSelectedType('Tất cả');
    setSortBy('name-asc');
    setCurrentPage(1);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Khám phá di sản văn hóa Việt"
        subtitle="Hệ thống tư liệu về các làng nghề thủ công trứ danh, kỹ thuật gia truyền và sản phẩm kết tinh từ tinh hoa đất nước."
        breadcrumbs={[{ label: 'Di sản' }]}
        badge="Danh mục di sản"
        badgeColor="#007F80"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
        {/* Filter and Search Bar Section */}
        <div className="bg-white p-5 sm:p-6 rounded-xl border border-[#E4E1D9] shadow-sm mb-10 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Search Input (5 cols) */}
            <div className="md:col-span-5 relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Tìm tên di sản, làng nghề, tỉnh thành..."
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:bg-white focus:outline-none focus:border-[#C91F37] transition-colors"
              />
            </div>

            {/* Region Selector (3 cols) */}
            <div className="md:col-span-3">
              <select
                value={selectedRegion}
                onChange={(e) => {
                  setSelectedRegion(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:outline-none focus:border-[#C91F37] transition-colors"
              >
                {regions.map((reg) => (
                  <option key={reg} value={reg}>
                    Vùng: {reg}
                  </option>
                ))}
              </select>
            </div>

            {/* Craft Type Selector (2 cols) */}
            <div className="md:col-span-2">
              <select
                value={selectedType}
                onChange={(e) => {
                  setSelectedType(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:outline-none focus:border-[#C91F37] transition-colors"
              >
                {craftTypes.map((type) => (
                  <option key={type} value={type}>
                    Loại: {type}
                  </option>
                ))}
              </select>
            </div>

            {/* Sorting (2 cols) */}
            <div className="md:col-span-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3.5 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm text-[#082951] focus:outline-none focus:border-[#C91F37] transition-colors"
              >
                <option value="name-asc">Tên: A - Z</option>
                <option value="name-desc">Tên: Z - A</option>
              </select>
            </div>
          </div>

          {/* Quick Filter Tags & Results Counter */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-gray-100 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-gray-500 font-medium">Vùng miền:</span>
              {regions.map((r) => (
                <button
                  key={r}
                  onClick={() => {
                    setSelectedRegion(r);
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-full text-xs transition-colors ${
                    selectedRegion === r
                      ? 'bg-[#082951] text-white font-bold'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-gray-600 font-semibold">
                Hiển thị {filteredHeritages.length} di sản
              </span>
              {(searchTerm || selectedRegion !== 'Tất cả' || selectedType !== 'Tất cả') && (
                <button
                  onClick={resetFilters}
                  className="flex items-center gap-1 text-[#C91F37] hover:underline font-semibold"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Đặt lại</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Heritage Grid */}
        {currentHeritages.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {currentHeritages.map((item) => (
              <HeritageCard key={item.id} heritage={item} variant="catalog" />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-white rounded-xl border border-[#E4E1D9] p-8">
            <p className="font-heading font-bold text-lg text-gray-700">
              Không tìm thấy di sản nào phù hợp với bộ lọc
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Hãy thử thay đổi từ khóa hoặc đặt lại bộ lọc tìm kiếm.
            </p>
            <button
              onClick={resetFilters}
              className="mt-4 px-5 py-2 bg-[#082951] text-white text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-[#164B7B] transition-colors"
            >
              Xem tất cả di sản
            </button>
          </div>
        )}

        {/* Pagination */}
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setCurrentPage(page)}
        />
      </div>
    </div>
  );
}
