import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Play,
  Users,
  Landmark,
  Palette,
  Award,
  MapPin,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import heritageData from '../data/heritage.json';
import artisanData from '../data/artisans.json';
import eventData from '../data/events.json';
import articleData from '../data/articles.json';
import HeritageCard from '../components/HeritageCard';
import ArtisanCard from '../components/ArtisanCard';
import EventCard from '../components/EventCard';
import NewsCard from '../components/NewsCard';
import VideoModal from '../components/VideoModal';

export default function HomePage() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [videoModalTitle, setVideoModalTitle] = useState('Câu chuyện từ bàn tay nghệ nhân');
  const [activeSlide, setActiveSlide] = useState(1);

  const openVideo = (title?: string) => {
    if (title) setVideoModalTitle(title);
    setIsVideoModalOpen(true);
  };

  // Top 6 heritage items for the colorful grid
  const categoryHeritages = heritageData.slice(0, 6);

  // Top 4 featured artisans matching reference
  const featuredArtisans = artisanData.slice(0, 4);

  // 3 featured events
  const featuredEvents = eventData.slice(0, 3);

  // 3 articles
  const featuredNews = articleData.slice(0, 3);

  return (
    <div className="bg-[#FFFCF5] text-[#161616] overflow-x-hidden">
      {/* ========================================================
          1. EDITORIAL HERO SECTION
          Matching download.png: Elderly bamboo weaver, layered geometry, typography
      ======================================================== */}
      <section className="relative bg-[#082951] text-white overflow-hidden min-h-[580px] lg:min-h-[640px] flex items-center">
        {/* Cultural Background Texture & Subtle Gradient */}
        <div
          className="absolute inset-0 z-0 opacity-15 bg-cultural-pattern pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 40%, rgba(255,255,255,0.15) 1px, transparent 1px), radial-gradient(circle at 80% 70%, rgba(255,255,255,0.15) 1px, transparent 1px)',
            backgroundSize: '28px 28px',
          }}
        />

        {/* Diagonal Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#061B37] via-[#0D3664] to-[#061B37]/80 z-0" />

        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Content (cols 6 or 7) */}
            <div className="lg:col-span-6 xl:col-span-7 space-y-6">
              {/* Eyebrow */}
              <div className="flex items-center gap-2">
                <span className="w-8 h-[2px] bg-[#F3B33F]" />
                <span className="font-heading font-extrabold text-xs sm:text-sm tracking-widest uppercase text-[#F3B33F]">
                  TINH HOA NGHỆ NHÂN VIỆT
                </span>
              </div>

              {/* Massive Title */}
              <div className="space-y-1">
                <h1 className="font-heading font-black text-4xl sm:text-6xl xl:text-7xl uppercase tracking-tight leading-[1.05]">
                  <span className="block text-white">GÌN GIỮ</span>
                  <span className="block text-white">BẢN SẮC</span>
                  <span className="block text-[#F3B33F]">VƯƠN RA THẾ GIỚI</span>
                </h1>
              </div>

              {/* Subtitle / Description */}
              <p className="text-sm sm:text-base text-gray-200 max-w-xl leading-relaxed">
                Nơi hội tụ những câu chuyện, sản phẩm và giá trị văn hóa được gìn giữ bởi bàn tay tài hoa của các nghệ nhân Việt Nam.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link
                  to="/nghe-nhan"
                  className="inline-flex items-center gap-2 bg-[#C91F37] hover:bg-[#A71B32] text-white px-6 py-3 rounded-md text-xs sm:text-sm font-bold uppercase tracking-wider transition-all shadow-lg hover:shadow-xl hover:translate-x-0.5"
                >
                  <span>Khám phá nghệ nhân</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <button
                  onClick={() => openVideo('Di sản ngàn năm - Tiếng vọng ngàn đời')}
                  className="inline-flex items-center gap-2 bg-transparent hover:bg-white/10 border border-white/40 hover:border-white text-white px-5 py-3 rounded-md text-xs sm:text-sm font-semibold tracking-wider transition-colors"
                >
                  <span>Xem video</span>
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
              </div>
            </div>

            {/* Right Visual (cols 6 or 5) - Editorial Collage Composition */}
            <div className="lg:col-span-6 xl:col-span-5 relative flex items-center justify-center min-h-[380px] sm:min-h-[460px]">
              {/* Top Right Museum Category Badge */}
              <div className="absolute top-0 right-2 z-20 text-right hidden sm:block">
                <div className="text-[10px] font-extrabold uppercase tracking-widest text-gray-300 leading-tight border-r-2 border-[#F3B33F] pr-2">
                  <div>CRAFT</div>
                  <div>PEOPLE</div>
                  <div>CULTURE</div>
                  <div className="text-[#F3B33F]">VIETNAM</div>
                </div>
              </div>

              {/* Red Circular Backdrop Layer */}
              <div className="absolute right-4 sm:right-10 top-12 w-64 h-64 sm:w-80 sm:h-80 rounded-full bg-[#BA2636] opacity-80 blur-xs" />

              {/* Yellow Decorative Circle */}
              <div className="absolute right-0 top-24 w-36 h-36 rounded-full bg-[#F3B33F] opacity-70" />

              {/* Inset Photo 1: Ancient Pagoda Architecture */}
              <div className="absolute top-2 right-12 z-10 w-28 h-20 sm:w-36 sm:h-24 rounded-lg overflow-hidden border-2 border-white/60 shadow-xl rotate-3">
                <img
                  src="./assets/images/vietnam-ancient-temple.jpg"
                  alt="Dinh lang Viet Nam Architecture"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Inset Photo 2: Hands painting ceramic pottery */}
              <div className="absolute top-16 left-2 sm:left-6 z-10 w-24 h-24 sm:w-32 sm:h-32 rounded-full overflow-hidden border-2 border-[#F3B33F] shadow-xl -rotate-6">
                <img
                  src="./assets/images/pottery-painting-story.jpg"
                  alt="Crafting pottery by hand"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Main Subject Photo: Elderly Vietnamese Artisan Weaving Bamboo */}
              <div className="relative z-10 w-full max-w-[420px] aspect-[4/4.5] flex items-end justify-center">
                <img
                  src="./assets/images/hero-artisan-weaving.jpg"
                  alt="Nghe nhan Viet Nam dan may tre"
                  className="w-full h-full object-cover rounded-2xl shadow-2xl border-2 border-white/20 filter contrast-105"
                />

                {/* Overlaid Woven Basket Feature */}
                <div className="absolute -bottom-6 -left-6 z-20 w-44 h-32 sm:w-56 sm:h-40 rounded-xl overflow-hidden border-3 border-white shadow-2xl">
                  <img
                    src="./assets/images/woven-bamboo-basket.jpg"
                    alt="Traditional Handwoven Bamboo Basket"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 inset-x-0 bg-black/60 backdrop-blur-xs p-1.5 text-center text-[10px] font-bold text-yellow-300 uppercase tracking-wider">
                    Mây tre đan Phú Vinh
                  </div>
                </div>
              </div>

              {/* Slide Indicators: 01 02 03 */}
              <div className="absolute bottom-2 right-4 z-20 flex items-center gap-2 text-xs font-mono text-gray-300">
                <button
                  onClick={() => setActiveSlide(1)}
                  className={`transition-colors ${
                    activeSlide === 1 ? 'text-white font-bold border-b-2 border-[#F3B33F]' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  01
                </button>
                <button
                  onClick={() => setActiveSlide(2)}
                  className={`transition-colors ${
                    activeSlide === 2 ? 'text-white font-bold border-b-2 border-[#F3B33F]' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  02
                </button>
                <button
                  onClick={() => setActiveSlide(3)}
                  className={`transition-colors ${
                    activeSlide === 3 ? 'text-white font-bold border-b-2 border-[#F3B33F]' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  03
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          2. HORIZONTAL STATISTICS STRIP
          100+ Nghệ nhân | 50+ Làng nghề | 200+ Sản phẩm | 10+ Sự kiện
      ======================================================== */}
      <section className="bg-white border-b border-[#E4E1D9] py-8 sm:py-10">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8 divide-y sm:divide-y-0 sm:divide-x divide-gray-200">
            {/* Stat 1 */}
            <div className="flex items-center gap-4 px-2 sm:px-4">
              <div className="w-12 h-12 rounded-full bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#082951] leading-none">
                  100+
                </div>
                <div className="text-xs sm:text-sm text-gray-600 font-medium mt-1">
                  Nghệ nhân tiêu biểu
                </div>
              </div>
            </div>

            {/* Stat 2 */}
            <div className="flex items-center gap-4 px-2 sm:px-4 pt-4 sm:pt-0">
              <div className="w-12 h-12 rounded-full bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0">
                <Landmark className="w-6 h-6" />
              </div>
              <div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#082951] leading-none">
                  50+
                </div>
                <div className="text-xs sm:text-sm text-gray-600 font-medium mt-1">
                  Làng nghề truyền thống
                </div>
              </div>
            </div>

            {/* Stat 3 */}
            <div className="flex items-center gap-4 px-2 sm:px-4 pt-4 sm:pt-0">
              <div className="w-12 h-12 rounded-full bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0">
                <Palette className="w-6 h-6" />
              </div>
              <div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#082951] leading-none">
                  200+
                </div>
                <div className="text-xs sm:text-sm text-gray-600 font-medium mt-1">
                  Sản phẩm đặc sắc
                </div>
              </div>
            </div>

            {/* Stat 4 */}
            <div className="flex items-center gap-4 px-2 sm:px-4 pt-4 sm:pt-0">
              <div className="w-12 h-12 rounded-full bg-red-50 text-[#C91F37] flex items-center justify-center shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <div className="font-heading font-black text-2xl sm:text-3xl text-[#082951] leading-none">
                  10+
                </div>
                <div className="text-xs sm:text-sm text-gray-600 font-medium mt-1">
                  Sự kiện văn hóa mỗi năm
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          3. EDITORIAL SPLIT BANNER: KHÁM PHÁ DI SẢN VĂN HÓA VIỆT
          Left cream, right purple temple with diagonal triangles
      ======================================================== */}
      <section className="border-b border-[#E4E1D9]">
        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[300px]">
          {/* Left Panel (6 cols) */}
          <div className="md:col-span-6 bg-[#F7F4EA] p-8 sm:p-12 lg:p-16 flex flex-col justify-center">
            <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#082951] uppercase leading-tight tracking-tight">
              KHÁM PHÁ DI SẢN VĂN HÓA VIỆT
            </h2>
            <p className="mt-4 text-sm sm:text-base text-gray-600 leading-relaxed max-w-md">
              Hành trình qua những làng nghề, câu chuyện của nghệ nhân và những giá trị văn hóa đang được bảo tồn và lan tỏa.
            </p>
            <div className="mt-6">
              <Link
                to="/di-san"
                className="inline-flex items-center gap-2 text-sm font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider group"
              >
                <span>Xem tất cả</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </div>

          {/* Right Visual Panel (6 cols) */}
          <div className="md:col-span-6 relative overflow-hidden min-h-[260px] bg-[#582080]">
            <img
              src="./assets/images/vietnam-ancient-temple.jpg"
              alt="Vietnamese Historic Temple Motif"
              className="w-full h-full object-cover mix-blend-multiply opacity-80"
            />
            {/* Geometric White & Purple Triangles Overlay matching reference */}
            <div className="absolute top-0 right-0 w-36 h-36 pointer-events-none">
              <svg viewBox="0 0 100 100" className="w-full h-full fill-white/90">
                <polygon points="100,0 40,0 100,60" />
              </svg>
            </div>
            <div className="absolute top-12 right-12 w-28 h-28 pointer-events-none">
              <svg viewBox="0 0 100 100" className="w-full h-full fill-purple-950/70">
                <polygon points="100,0 20,0 100,80" />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          4. COLORFUL EDITORIAL CATEGORY GRID (6 COLUMNS)
          01 Gốm Bát Tràng (#BA2636) | 02 Nón Huế (#582080) | 03 Lụa Hà Đông (#007F80)
          04 Gỗ Đồng Kỵ (#C69228) | 05 Tranh Đông Hồ (#BE263C) | 06 Mây Tre Phú Vinh (#174B7B)
      ======================================================== */}
      <section className="w-full">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
          {categoryHeritages.map((item) => (
            <HeritageCard key={item.id} heritage={item} variant="grid-editorial" />
          ))}
        </div>
      </section>

      {/* ========================================================
          5. VIDEO STORY SPLIT: CÂU CHUYỆN TỪ BÀN TAY NGHỆ NHÂN
          Left: Ceramic painting hands with big circular red Play button
          Right: Dark navy block with quote and button
      ======================================================== */}
      <section className="border-t border-b border-[#E4E1D9]">
        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[380px]">
          {/* Left Visual with Play Button (6 cols) */}
          <div
            className="md:col-span-6 relative min-h-[300px] overflow-hidden group cursor-pointer"
            onClick={() => openVideo('Câu chuyện từ bàn tay nghệ nhân gốm')}
          >
            <img
              src="./assets/images/pottery-painting-story.jpg"
              alt="Artisan hands painting ceramic bowl"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />

            {/* Glowing Red Circular Play Button */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#C91F37] text-white flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110">
                <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-current ml-1" />
              </div>
            </div>
          </div>

          {/* Right Navy Block (6 cols) */}
          <div className="md:col-span-6 bg-[#082951] text-white p-8 sm:p-12 lg:p-16 flex flex-col justify-center relative overflow-hidden">
            {/* Traditional Geometric Motif in Top Right Corner */}
            <div className="absolute top-0 right-0 w-28 h-28 pointer-events-none opacity-40">
              <svg viewBox="0 0 100 100" fill="none" className="w-full h-full">
                <polygon points="100,0 20,0 100,80" fill="#C91F37" />
                <polygon points="100,20 50,0 100,50" fill="#F3B33F" />
              </svg>
            </div>

            <div className="relative z-10 space-y-4">
              <h2 className="font-heading font-black text-2xl sm:text-4xl uppercase leading-tight tracking-tight text-white">
                CÂU CHUYỆN TỪ BÀN TAY NGHỆ NHÂN
              </h2>

              <p className="text-base sm:text-xl font-light italic text-yellow-300 leading-relaxed">
                “Mỗi sản phẩm là một câu chuyện, mỗi đường nét là một phần hồn Việt.”
              </p>

              <div className="pt-4">
                <button
                  onClick={() => openVideo('Câu chuyện từ bàn tay nghệ nhân gốm')}
                  className="inline-flex items-center gap-2 text-sm font-bold text-white hover:text-yellow-300 uppercase tracking-wider transition-colors group"
                >
                  <span>Xem video câu chuyện</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          6. FEATURED ARTISANS: GƯƠNG MẶT NGHỆ NHÂN
          4 portrait cards with colored arrows & details
      ======================================================== */}
      <section className="bg-[#F7F4EA] py-16 sm:py-20 border-b border-[#E4E1D9]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#082951] uppercase tracking-tight">
                GƯƠNG MẶT NGHỆ NHÂN
              </h2>
              <p className="text-sm sm:text-base text-gray-600 mt-2">
                Những con người thầm lặng gìn giữ và thổi hồn vào di sản Việt.
              </p>
            </div>

            <Link
              to="/nghe-nhan"
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider group shrink-0"
            >
              <span>Xem tất cả nghệ nhân</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>

          {/* 4 Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredArtisans.map((artisan) => (
              <ArtisanCard key={artisan.id} artisan={artisan} variant="compact" />
            ))}
          </div>
        </div>
      </section>

      {/* ========================================================
          7. FEATURED EVENTS: SỰ KIỆN VĂN HÓA NỔI BẬT
          Bold Red Banner #C91F37 with 3 event cards
      ======================================================== */}
      <section className="bg-[#C91F37] text-white py-16 sm:py-20">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Panel (4 cols) */}
            <div className="lg:col-span-4 space-y-4">
              <h2 className="font-heading font-black text-3xl sm:text-4xl uppercase leading-tight tracking-tight text-white">
                SỰ KIỆN VĂN HÓA NỔI BẬT
              </h2>

              <p className="text-sm text-white/90 leading-relaxed">
                Tham gia các lễ hội, triển lãm, workshop để trải nghiệm trực tiếp và lan tỏa giá trị văn hóa Việt.
              </p>

              <div className="pt-2">
                <Link
                  to="/su-kien"
                  className="inline-flex items-center gap-2 bg-white hover:bg-gray-100 text-[#C91F37] px-5 py-2.5 rounded text-xs font-bold uppercase tracking-wider transition-all shadow-md group"
                >
                  <span>Xem tất cả sự kiện</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>

            {/* Right Event Cards Grid (8 cols) */}
            <div className="lg:col-span-8">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                {featuredEvents.map((evt) => (
                  <EventCard key={evt.id} event={evt} variant="banner" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          8. CRAFT MAP PROMO: BẢN ĐỒ LÀNG NGHỀ VIỆT NAM
          Left text, center map preview, right region pills
      ======================================================== */}
      <section className="bg-[#F7F4EA] py-16 sm:py-20 border-b border-[#E4E1D9]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Info (4 cols) */}
            <div className="lg:col-span-4 space-y-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C91F37]">
                Địa lý di sản
              </span>
              <h2 className="font-heading font-black text-3xl sm:text-4xl text-[#082951] uppercase leading-tight tracking-tight">
                BẢN ĐỒ LÀNG NGHỀ VIỆT NAM
              </h2>
              <p className="text-sm text-gray-600 leading-relaxed">
                Khám phá các làng nghề truyền thống trên khắp mọi miền đất nước, từ gốm sứ châu thổ Bắc Bộ đến thổ cẩm Tây Nguyên và mây tre Nam Bộ.
              </p>
              <div className="pt-2">
                <Link
                  to="/ban-do-lang-nghe"
                  className="inline-flex items-center gap-2 bg-[#C91F37] hover:bg-[#A71B32] text-white px-6 py-3 rounded text-xs font-bold uppercase tracking-wider transition-all shadow-md hover:shadow-lg group"
                >
                  <span>Xem bản đồ tương tác</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>

            {/* Center Map Graphic Preview (4 cols) */}
            <div className="lg:col-span-4 flex justify-center">
              <div className="relative w-64 h-96 bg-white p-4 rounded-2xl border border-[#E4E1D9] shadow-md flex items-center justify-center">
                <svg viewBox="0 0 100 200" className="w-full h-full filter drop-shadow-sm">
                  <path
                    d="M 68.1 35.4 L 66.4 35.5 L 64.5 36.9 L 62.1 37.8 L 61.6 40.3 L 59.6 41.5 L 58.6 41.0 L 56.6 41.5 L 54.5 40.9 L 55.2 43.9 L 53.1 46.2 L 53.3 47.6 L 52.7 48.8 L 49.0 52.0 L 47.9 52.1 L 47.1 52.6 L 45.3 56.5 L 45.0 59.7 L 44.2 61.5 L 43.4 62.3 L 43.2 63.3 L 46.1 68.4 L 47.9 70.5 L 49.8 71.5 L 52.5 74.5 L 52.1 75.3 L 52.3 77.0 L 51.2 76.7 L 52.7 77.7 L 55.0 80.9 L 59.1 84.3 L 59.7 86.1 L 63.6 88.9 L 63.5 89.3 L 66.3 91.5 L 66.6 92.4 L 68.7 92.3 L 70.6 94.9 L 71.2 95.0 L 71.4 96.1 L 74.5 100.5 L 77.1 102.8 L 78.3 106.9 L 79.9 110.1 L 79.9 111.9 L 82.2 119.5 L 82.0 120.5 L 81.6 119.5 L 81.8 125.9 L 83.4 129.4 L 83.7 133.4 L 82.5 131.7 L 81.3 132.8 L 82.2 135.6 L 81.1 135.4 L 81.2 139.1 L 81.7 140.5 L 81.6 141.0 L 81.1 140.0 L 80.6 141.7 L 81.1 143.0 L 80.4 144.3 L 79.4 144.4 L 78.8 147.2 L 77.1 147.5 L 75.8 148.8 L 74.2 149.2 L 71.3 151.7 L 69.4 152.1 L 68.4 154.0 L 66.7 154.2 L 60.6 157.6 L 59.9 156.8 L 58.7 156.5 L 57.9 154.7 L 57.3 157.5 L 56.8 157.7 L 55.8 157.2 L 54.9 156.1 L 53.6 156.8 L 55.1 157.1 L 55.5 157.8 L 55.2 158.7 L 52.1 158.7 L 54.9 159.8 L 55.5 160.7 L 54.2 162.0 L 54.2 163.0 L 53.5 163.5 L 52.0 162.6 L 48.7 159.5 L 52.6 163.9 L 53.3 165.9 L 52.4 166.8 L 51.2 166.8 L 49.4 165.5 L 46.5 162.4 L 45.5 161.9 L 48.9 166.4 L 49.4 167.4 L 49.0 168.6 L 42.0 171.9 L 40.1 175.1 L 37.9 177.0 L 35.5 177.5 L 34.2 177.4 L 35.6 175.7 L 34.7 175.1 L 35.0 166.3 L 35.6 164.0 L 37.6 163.0 L 37.7 162.6 L 37.0 161.2 L 35.3 160.7 L 34.6 159.7 L 33.1 160.1 L 30.6 157.4 L 32.1 156.3 L 35.1 156.1 L 37.2 154.2 L 37.1 151.9 L 40.0 152.7 L 41.0 151.5 L 44.6 151.1 L 45.7 152.5 L 46.6 152.2 L 49.0 153.2 L 48.6 151.8 L 48.9 150.5 L 45.7 147.7 L 45.7 144.0 L 46.5 143.8 L 47.3 142.6 L 51.5 143.4 L 51.6 140.5 L 54.6 140.2 L 55.3 139.4 L 57.1 139.1 L 60.1 136.6 L 61.3 136.4 L 62.0 137.1 L 63.2 135.9 L 63.7 134.0 L 62.8 128.6 L 64.2 124.1 L 61.3 116.6 L 61.7 113.9 L 62.6 113.0 L 63.5 110.8 L 63.4 108.4 L 62.9 107.2 L 64.7 104.1 L 63.8 102.6 L 60.8 100.1 L 59.6 98.1 L 62.0 96.5 L 62.0 95.5 L 57.1 92.1 L 56.2 90.3 L 55.1 91.0 L 54.2 90.5 L 53.0 88.8 L 52.5 85.5 L 51.7 84.9 L 50.1 82.6 L 47.3 80.4 L 44.0 76.8 L 42.9 74.1 L 41.5 72.3 L 40.2 71.9 L 37.9 69.5 L 37.6 68.5 L 38.2 66.8 L 33.7 65.1 L 24.9 59.6 L 26.8 57.6 L 26.4 55.5 L 28.8 55.4 L 32.3 56.1 L 33.9 54.6 L 34.7 53.0 L 35.9 51.8 L 35.9 51.0 L 35.1 49.7 L 33.5 49.7 L 32.6 47.8 L 30.0 47.1 L 31.7 45.8 L 32.3 44.8 L 29.8 42.9 L 27.2 41.5 L 24.8 42.5 L 23.1 44.1 L 22.2 44.3 L 16.6 42.1 L 13.9 38.0 L 15.0 34.7 L 15.0 33.5 L 13.9 32.9 L 13.6 32.1 L 12.8 33.5 L 11.9 33.5 L 11.1 31.0 L 10.1 30.4 L 6.3 25.8 L 9.9 21.7 L 13.7 23.5 L 15.3 25.0 L 17.0 24.0 L 17.0 23.4 L 19.0 21.5 L 20.7 23.5 L 22.1 21.3 L 25.5 24.0 L 26.7 21.7 L 27.6 21.1 L 28.3 21.0 L 29.2 22.1 L 30.0 22.2 L 31.7 21.1 L 33.4 20.9 L 34.5 19.9 L 34.8 17.8 L 35.2 17.4 L 39.6 15.2 L 41.3 16.4 L 42.5 18.2 L 44.0 18.6 L 45.6 19.8 L 46.8 19.6 L 47.2 19.2 L 48.8 19.3 L 50.2 20.5 L 53.0 20.0 L 55.5 21.4 L 54.7 22.9 L 53.4 23.6 L 53.1 24.4 L 53.1 26.2 L 54.2 27.3 L 54.3 30.2 L 55.0 29.9 L 57.5 30.8 L 58.5 32.2 L 59.7 33.1 L 60.7 33.1 L 61.5 34.3 L 62.4 33.9 L 62.8 34.4 L 64.6 34.2 L 65.8 33.7 Z M 26.8 157.7 L 26.9 159.5 L 26.3 161.6 L 25.6 159.3 L 24.5 157.9 L 25.9 157.3 Z M 58.1 43.7 L 57.7 43.8 L 56.9 42.9 L 57.3 42.4 L 58.5 43.0 Z M 59.6 157.6 L 58.7 158.2 L 58.6 157.7 L 59.7 157.0 Z M 64.2 38.6 L 62.7 39.9 L 62.1 39.9 L 62.8 38.0 Z M 53.8 176.4 L 53.2 176.2 L 54.2 175.5 Z M 56.4 43.0 L 55.4 42.4 L 55.6 41.7 Z M 63.3 41.8 L 62.0 42.0 L 63.6 40.6 Z"
                    fill="#F7F4EA"
                    stroke="#C91F37"
                    strokeWidth="1.5"
                  />
                  {/* North marker */}
                  <circle cx="46" cy="41" r="4" fill="#C91F37" />
                  {/* Central marker */}
                  <circle cx="68" cy="96" r="4" fill="#D36E24" />
                  {/* Highlands marker */}
                  <circle cx="69" cy="133" r="4" fill="#582080" />
                  {/* South marker */}
                  <circle cx="55" cy="153" r="4" fill="#007F80" />
                  {/* Hoàng Sa & Trường Sa */}
                  <circle cx="88" cy="88" r="1.6" fill="#C91F37" />
                  <circle cx="91" cy="92" r="1.3" fill="#C91F37" />
                  <text x="99" y="83" textAnchor="end" fontSize="6" fontWeight="bold" fill="#082951">Hoàng Sa</text>
                  <circle cx="89" cy="152" r="1.6" fill="#007F80" />
                  <circle cx="92" cy="156" r="1.3" fill="#007F80" />
                  <circle cx="87" cy="158" r="1.3" fill="#007F80" />
                  <text x="99" y="168" textAnchor="end" fontSize="6" fontWeight="bold" fill="#082951">Trường Sa</text>
                </svg>
                <div className="absolute bottom-3 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                  63 Tỉnh Thành • Trăm Làng Nghề
                </div>
              </div>
            </div>

            {/* Right Region Samples (4 cols) */}
            <div className="lg:col-span-4 space-y-3">
              {/* Region 1: Miền Bắc */}
              <div className="bg-white p-4 rounded-xl border border-[#E4E1D9] shadow-xs flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-red-100 text-[#C91F37] font-bold text-xs flex items-center justify-center shrink-0">
                  MB
                </span>
                <div>
                  <h4 className="font-heading font-bold text-sm text-[#082951]">Miền Bắc</h4>
                  <p className="text-xs text-gray-500">Gốm sứ, lụa, tranh dân gian...</p>
                </div>
              </div>

              {/* Region 2: Miền Trung */}
              <div className="bg-white p-4 rounded-xl border border-[#E4E1D9] shadow-xs flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-orange-100 text-[#D36E24] font-bold text-xs flex items-center justify-center shrink-0">
                  MT
                </span>
                <div>
                  <h4 className="font-heading font-bold text-sm text-[#082951]">Miền Trung</h4>
                  <p className="text-xs text-gray-500">Nón lá, mộc, gốm cổ...</p>
                </div>
              </div>

              {/* Region 3: Tây Nguyên */}
              <div className="bg-white p-4 rounded-xl border border-[#E4E1D9] shadow-xs flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-purple-100 text-[#582080] font-bold text-xs flex items-center justify-center shrink-0">
                  TN
                </span>
                <div>
                  <h4 className="font-heading font-bold text-sm text-[#082951]">Tây Nguyên</h4>
                  <p className="text-xs text-gray-500">Dệt thổ cẩm, điêu khắc...</p>
                </div>
              </div>

              {/* Region 4: Miền Nam */}
              <div className="bg-white p-4 rounded-xl border border-[#E4E1D9] shadow-xs flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-teal-100 text-[#007F80] font-bold text-xs flex items-center justify-center shrink-0">
                  MN
                </span>
                <div>
                  <h4 className="font-heading font-bold text-sm text-[#082951]">Miền Nam</h4>
                  <p className="text-xs text-gray-500">Mây tre đan, gốm, thủ công mỹ nghệ...</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================
          9. NEWS & ARTICLES: TIN TỨC & BÀI VIẾT + COMMUNITY CTA
          3 news items + 1 Red Community Join card with yellow button
      ======================================================== */}
      <section className="bg-white py-16 sm:py-20 border-b border-[#E4E1D9]">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <h2 className="font-heading font-black text-2xl sm:text-4xl text-[#082951] uppercase tracking-tight">
                TIN TỨC & BÀI VIẾT
              </h2>
              <p className="text-sm sm:text-base text-gray-600 mt-2">
                Cập nhật những câu chuyện, kiến thức và hoạt động mới nhất.
              </p>
            </div>

            <Link
              to="/tin-tuc"
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider group shrink-0"
            >
              <span>Xem tất cả</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* 3 News Articles */}
            {featuredNews.map((article) => (
              <NewsCard key={article.id} article={article} variant="standard" />
            ))}

            {/* 4th Card: Community CTA Card matching reference image */}
            <div className="bg-[#BA2636] text-white rounded-lg p-6 flex flex-col justify-between shadow-md relative overflow-hidden group">
              {/* Background photography overlay */}
              <div className="absolute inset-0 z-0">
                <img
                  src="./assets/images/community-artisans.jpg"
                  alt="Community Artisans"
                  className="w-full h-full object-cover opacity-25 mix-blend-multiply"
                />
              </div>

              <div className="relative z-10">
                <span className="text-[11px] font-bold uppercase tracking-widest text-yellow-300 block mb-1">
                  ĐỒNG HÀNH
                </span>
                <h3 className="font-heading font-black text-xl uppercase leading-tight text-white">
                  ĐĂNG KÝ THAM GIA CỘNG ĐỒNG
                </h3>
                <p className="text-xs text-white/90 mt-2 leading-relaxed">
                  Cùng kết nối, chia sẻ câu chuyện và lan tỏa giá trị văn hóa Việt.
                </p>
              </div>

              <div className="relative z-10 pt-6">
                <Link
                  to="/lien-he"
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#F3B33F] hover:bg-yellow-400 text-[#082951] font-heading font-black text-xs uppercase tracking-wider py-3 px-4 rounded shadow-md transition-all hover:shadow-lg"
                >
                  <span>Tham gia ngay</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Global Video Modal */}
      <VideoModal
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
        title={videoModalTitle}
      />
    </div>
  );
}
