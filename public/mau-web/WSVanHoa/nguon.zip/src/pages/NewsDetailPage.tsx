import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Calendar,
  User,
  Share2,
  CheckCircle2,
  ArrowRight,
  BookOpen,
} from 'lucide-react';
import articleData from '../data/articles.json';
import PageBanner from '../components/PageBanner';
import NewsCard from '../components/NewsCard';

export default function NewsDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const article = articleData.find((a) => a.slug === slug);
  const [copiedShare, setCopiedShare] = useState(false);

  if (!article) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center">
        <h2 className="font-heading font-black text-3xl text-[#082951] mb-2">
          Không tìm thấy bài viết
        </h2>
        <p className="text-gray-600 mb-6">
          Bài viết bạn đang tìm không tồn tại hoặc đã bị gỡ bỏ.
        </p>
        <Link
          to="/tin-tuc"
          className="bg-[#C91F37] text-white px-6 py-2.5 rounded-md font-bold text-xs uppercase tracking-wider"
        >
          Quay lại danh mục tin tức
        </Link>
      </div>
    );
  }

  const relatedArticles = articleData
    .filter((a) => a.id !== article.id)
    .slice(0, 3);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div className="bg-[#FFFCF5] text-[#161616]">
      <PageBanner
        title={article.title}
        subtitle={`${article.category} • ${article.displayDate}`}
        breadcrumbs={[
          { label: 'Tin tức', path: '/tin-tuc' },
          { label: article.title },
        ]}
        badge={article.category}
        badgeColor="#007F80"
      />

      <div className="max-w-[1000px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        <article className="space-y-8">
          {/* Article Meta Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-[#E4E1D9] text-xs text-gray-500">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 font-medium text-gray-700">
                <User className="w-4 h-4 text-[#C91F37]" />
                <span>{article.author || 'Tinh Hoa Việt'}</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span>{article.displayDate}</span>
              </span>
            </div>

            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 text-[#082951] hover:text-[#C91F37] font-semibold transition-colors"
            >
              {copiedShare ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Đã sao chép liên kết</span>
                </>
              ) : (
                <>
                  <Share2 className="w-4 h-4" />
                  <span>Chia sẻ bài viết</span>
                </>
              )}
            </button>
          </div>

          {/* Lead Summary */}
          {article.summary && (
            <p className="text-lg sm:text-xl font-serif text-gray-800 italic leading-relaxed bg-[#F7F4EA] p-6 rounded-2xl border-l-4 border-[#C91F37]">
              “{article.summary}”
            </p>
          )}

          {/* Cover Photo */}
          <div className="rounded-2xl overflow-hidden shadow-md">
            <img
              src={article.coverImage}
              alt={article.title}
              className="w-full h-auto max-h-[500px] object-cover"
            />
          </div>

          {/* Article Body Content Blocks */}
          <div className="space-y-6 text-base sm:text-lg text-gray-800 leading-relaxed font-sans">
            {article.content?.map((block, idx) => {
              if (block.type === 'paragraph') {
                return <p key={idx}>{block.text}</p>;
              }
              if (block.type === 'quote') {
                return (
                  <blockquote
                    key={idx}
                    className="my-8 p-6 sm:p-8 bg-white rounded-xl border-l-4 border-[#F3B33F] shadow-sm space-y-2"
                  >
                    <p className="font-heading font-semibold text-lg sm:text-xl text-[#082951] italic leading-snug">
                      {block.text}
                    </p>
                    {block.author && (
                      <cite className="block text-xs uppercase tracking-wider text-gray-500 font-sans font-bold not-italic">
                        — {block.author}
                      </cite>
                    )}
                  </blockquote>
                );
              }
              if (block.type === 'image') {
                return (
                  <figure key={idx} className="my-8 space-y-2">
                    <img
                      src={block.url}
                      alt={block.caption || 'Hình ảnh minh họa'}
                      className="w-full rounded-xl overflow-hidden shadow-sm"
                    />
                    {block.caption && (
                      <figcaption className="text-xs text-center text-gray-500 italic">
                        {block.caption}
                      </figcaption>
                    )}
                  </figure>
                );
              }
              return null;
            })}
          </div>
        </article>

        {/* Related Articles */}
        {relatedArticles.length > 0 && (
          <div className="mt-16 pt-12 border-t border-[#E4E1D9] space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-black text-2xl text-[#082951] uppercase">
                Bài viết cùng chủ đề
              </h3>
              <Link
                to="/tin-tuc"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#C91F37] hover:text-[#A71B32] uppercase tracking-wider"
              >
                <span>Xem tất cả</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {relatedArticles.map((art) => (
                <NewsCard key={art.id} article={art} variant="standard" />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
