import React, { useState, useMemo } from 'react';
import { Search, Tag, RefreshCw } from 'lucide-react';
import articleData from '../data/articles.json';
import PageBanner from '../components/PageBanner';
import NewsCard from '../components/NewsCard';
import Pagination from '../components/Pagination';

export default function NewsListPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const categories = ['Tất cả', 'Di sản', 'Nghệ nhân', 'Làng nghề', 'Sự kiện', 'Văn hóa'];

  const filteredArticles = useMemo(() => {
    return articleData.filter((art) => {
      const matchesSearch =
        art.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        art.summary.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCat = selectedCategory === 'Tất cả' || art.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [searchTerm, selectedCategory]);

  const totalPages = Math.ceil(filteredArticles.length / itemsPerPage);
  const currentArticles = filteredArticles.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const featuredArticle = articleData[0];

  return (
    <div className="bg-[#FFFCF5] text-[#161616] min-h-screen">
      <PageBanner
        title="Tin tức và câu chuyện văn hóa"
        subtitle="Những góc nhìn sâu sắc, phóng sự chuyên đề và câu chuyện đời thường về người giữ hồn nghề truyền thống Việt Nam."
        breadcrumbs={[{ label: 'Tin tức' }]}
        badge="Chuyên mục văn hóa"
        badgeColor="#007F80"
      />

      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
        {/* Featured Story at top */}
        {featuredArticle && !searchTerm && selectedCategory === 'Tất cả' && (
          <div className="mb-12">
            <NewsCard article={featuredArticle} variant="featured" />
          </div>
        )}

        {/* Filter & Search Bar */}
        <div className="bg-white p-5 rounded-xl border border-[#E4E1D9] shadow-sm mb-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-500 mr-1">
              Chủ đề:
            </span>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#082951] text-white font-bold'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Tìm bài viết..."
              className="w-full pl-9 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs text-gray-800 focus:bg-white focus:outline-none focus:border-[#C91F37]"
            />
          </div>
        </div>

        {/* Articles Grid */}
        {currentArticles.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {currentArticles.map((article) => (
              <NewsCard key={article.id} article={article} variant="standard" />
            ))}
          </div>
        ) : (
          <div className="py-20 text-center bg-white rounded-xl border border-[#E4E1D9] p-8">
            <p className="font-heading font-bold text-lg text-gray-700">
              Không tìm thấy bài viết phù hợp
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Hãy thử chọn chuyên mục khác hoặc tìm kiếm với từ khóa ngắn gọn hơn.
            </p>
          </div>
        )}

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={(page) => setCurrentPage(page)}
        />
      </div>
    </div>
  );
}
