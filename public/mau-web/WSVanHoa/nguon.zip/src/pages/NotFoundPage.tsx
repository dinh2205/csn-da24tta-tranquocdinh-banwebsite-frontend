import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, Home, Landmark, Users } from 'lucide-react';

export default function NotFoundPage() {
  return (
    <div className="min-h-[75vh] flex items-center justify-center bg-[#FFFCF5] px-4 py-16">
      <div className="max-w-lg w-full text-center space-y-6 bg-white p-8 sm:p-12 rounded-2xl border border-[#E4E1D9] shadow-xl">
        <div className="w-20 h-20 mx-auto rounded-full bg-red-50 text-[#C91F37] flex items-center justify-center">
          <Compass className="w-10 h-10 animate-spin-slow" />
        </div>

        <div className="space-y-2">
          <span className="font-heading font-black text-6xl text-[#082951] tracking-tighter">
            404
          </span>
          <h2 className="font-heading font-black text-2xl uppercase text-[#082951]">
            Trang không tìm thấy
          </h2>
          <p className="text-sm text-gray-600 leading-relaxed">
            Đường dẫn bạn yêu cầu không tồn tại trong hệ thống di sản của chúng tôi hoặc đã được sắp xếp lại vị trí.
          </p>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            to="/"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-[#C91F37] hover:bg-[#A71B32] text-white text-xs font-bold uppercase tracking-wider transition-colors shadow-md"
          >
            <Home className="w-4 h-4" />
            <span>Về Trang chủ</span>
          </Link>

          <Link
            to="/di-san"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg border border-[#082951] hover:bg-[#082951] hover:text-white text-[#082951] text-xs font-bold uppercase tracking-wider transition-colors"
          >
            <Landmark className="w-4 h-4" />
            <span>Khám phá Di sản</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
